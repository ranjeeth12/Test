"""Environment-driven configuration for the SDG proof of concept.

Connection settings come from a .env file (see .env.example). Credentials are
never written into artifacts; only the server, database, and driver appear in
plans and manifests.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

REPO_ROOT = Path(__file__).resolve().parent.parent

_loaded = False


def load_env(env_file: str | Path | None = None) -> None:
    """Load .env once. Existing process environment wins over the file."""
    global _loaded
    if _loaded and env_file is None:
        return
    path = Path(env_file) if env_file else REPO_ROOT / ".env"
    if path.exists():
        load_dotenv(path, override=False)
    _loaded = True


@dataclass(frozen=True)
class MssqlSettings:
    """Everything needed to build a SQL Server ODBC connection string."""

    server: str
    port: int
    user: str
    password: str
    driver: str
    trust_cert: bool
    # Windows authentication. The common case on a domain-joined machine, and
    # the one where there is no password to store anywhere.
    trusted: bool = False

    def connection_string(self, database: str) -> str:
        server = self.server if self.port == 1433 else f"{self.server},{self.port}"
        parts = [
            f"DRIVER={{{self.driver}}}",
            f"SERVER={server}",
            f"DATABASE={database}",
        ]
        if self.trusted:
            parts.append("Trusted_Connection=yes")
        else:
            parts.extend([f"UID={self.user}", f"PWD={self.password}"])
        if self.trust_cert:
            parts.append("TrustServerCertificate=yes")
        parts.append("Encrypt=yes" if self.trust_cert else "Encrypt=no")
        return ";".join(parts) + ";"

    def redacted(self, database: str) -> str:
        """Same string with the password removed, safe for logs and artifacts."""
        built = self.connection_string(database)
        if self.trusted or not self.password:
            return built
        return built.replace(f"PWD={self.password}", "PWD=***")


@dataclass(frozen=True)
class Settings:
    mssql: MssqlSettings
    source_db: str
    ref_db: str
    # Where analysis lives: the denormalized extracts every source is read
    # into, and the tool's own tables beside them -- saved patterns, baselines,
    # generation rules, layouts. A database of its own because none of it
    # belongs to the customer whose data is being read, and because the store
    # is centralized across sources while a source database is one source.
    denorm_db: str
    # Where generated rows land. Usually the source -- synthetic rows beside
    # the real ones they were measured from is the normal case -- but naming
    # it separately is what lets a run read one database and write another.
    target_db: str
    work_dir: Path
    # The pattern store's own connection and schema. It is often on another
    # server from the sources -- a customer's denorm database, reached with a
    # login of its own, where only one schema may be written -- so each part is
    # set on its own, and each defaults to the configured server's.
    denorm: MssqlSettings | None = None
    denorm_schema: str = "sdm"

    @property
    def store(self) -> MssqlSettings:
        """The connection settings for the pattern store."""
        return self.denorm or self.mssql


def _flag(name: str, default: str = "yes") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "yes", "true", "y"}


def get_settings(env_file: str | Path | None = None) -> Settings:
    load_env(env_file)
    mssql = MssqlSettings(
        server=os.getenv("SDG_MSSQL_SERVER", "localhost"),
        port=int(os.getenv("SDG_MSSQL_PORT", "1433")),
        user=os.getenv("SDG_MSSQL_USER", "sa"),
        password=os.getenv("SDG_MSSQL_PASSWORD", ""),
        driver=os.getenv("SDG_MSSQL_DRIVER", "ODBC Driver 18 for SQL Server"),
        trust_cert=_flag("SDG_MSSQL_TRUST_CERT"),
        trusted=_flag("SDG_MSSQL_TRUSTED", "no"),
    )
    # The pattern store: every setting falls back to the server's own.
    denorm = MssqlSettings(
        server=os.getenv("SDG_DENORM_SERVER", mssql.server),
        port=int(os.getenv("SDG_DENORM_PORT", str(mssql.port))),
        user=os.getenv("SDG_DENORM_USER", mssql.user),
        password=os.getenv("SDG_DENORM_PASSWORD", mssql.password),
        driver=os.getenv("SDG_DENORM_DRIVER", mssql.driver),
        trust_cert=_flag("SDG_DENORM_TRUST_CERT", "yes" if mssql.trust_cert else "no"),
        trusted=_flag("SDG_DENORM_TRUSTED", "yes" if mssql.trusted else "no"),
    )
    work_dir = Path(os.getenv("SDG_WORK_DIR", "work"))
    if not work_dir.is_absolute():
        work_dir = REPO_ROOT / work_dir
    return Settings(
        mssql=mssql,
        source_db=os.getenv("SDG_DB_SOURCE", "FACETS_QA"),
        ref_db=os.getenv("SDG_DB_REF", "MDM_REF"),
        denorm_db=os.getenv("SDG_DB_DENORM", "SDM_DENORM"),
        target_db=os.getenv("SDG_DB_TARGET", os.getenv("SDG_DB_SOURCE", "FACETS_QA")),
        work_dir=work_dir,
        denorm=denorm,
        denorm_schema=os.getenv("SDG_DENORM_SCHEMA", os.getenv("SDG_ANALYZER_SCHEMA", "sdm")),
    )

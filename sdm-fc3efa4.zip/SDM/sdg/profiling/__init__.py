"""SDG profiling package."""

"""Profile a whole database, inside a time budget.

Each table gets an allowance. Measures that every later step depends on run
first; the pairwise analyses run with whatever time is left and report what they
had to leave out. A profile that silently skipped half the schema would be worse
than one that says so.
"""

from __future__ import annotations

import time
from typing import Iterable

from sdg.discovery.connections import ConnectionRegistry
from sdg.discovery.model import PhysicalModel
from sdg.profiling.columns import SAMPLE_CAP, profile_table
from sdg.profiling.dependencies import (
    Budget,
    functional_dependencies,
    join_date_orderings,
    row_date_orderings,
)
from sdg.profiling.model import ProfileReport, SkippedAnalysis
from sdg.profiling.ratio import profile_ratios
from sdg.discovery.model import now_stamp

# The build brief: 60 seconds per table against the small fixture, ten minutes
# at full volume.
SMALL_TABLE_BUDGET_SECONDS = 60.0
FULL_TABLE_BUDGET_SECONDS = 600.0
LARGE_TABLE_ROWS = 500_000


def table_budget(row_count: int) -> float:
    return FULL_TABLE_BUDGET_SECONDS if row_count >= LARGE_TABLE_ROWS else SMALL_TABLE_BUDGET_SECONDS


def profile(
    registry: ConnectionRegistry,
    model: PhysicalModel,
    connection: str = "source",
    *,
    sample_cap: int = SAMPLE_CAP,
    tables: Iterable[str] | None = None,
    skip_pairwise: bool = False,
) -> ProfileReport:
    wanted = set(tables) if tables else None
    started = time.perf_counter()
    report = ProfileReport(
        connection=registry.ref(connection).as_dict(),
        profiled=now_stamp(),
        sample_cap=sample_cap,
    )

    for table in model.tables:
        if wanted and table.name not in wanted:
            continue
        table_started = time.perf_counter()
        budget = Budget.start(table_budget(table.row_count))

        profiles = profile_table(registry, table, connection, sample_cap=sample_cap)
        report.columns.extend(profiles)

        if skip_pairwise:
            report.skipped.append(
                SkippedAnalysis(
                    table=table.name,
                    analysis="pairwise",
                    reason="pairwise analysis was turned off for this run",
                )
            )
        elif budget.exhausted():
            report.skipped.append(
                SkippedAnalysis(
                    table=table.name,
                    analysis="pairwise",
                    reason=(
                        f"per-table budget of {budget.seconds:.0f}s was spent on column "
                        f"measures"
                    ),
                )
            )
        else:
            dependencies, skipped_pairs = functional_dependencies(
                registry, table, profiles, connection, budget=budget
            )
            report.dependencies.extend(d for d in dependencies if d.holds)
            if skipped_pairs:
                report.skipped.append(
                    SkippedAnalysis(
                        table=table.name,
                        analysis="functional_dependency",
                        reason=f"{skipped_pairs} column pairs left untested within the budget",
                    )
                )

            if budget.exhausted():
                report.skipped.append(
                    SkippedAnalysis(
                        table=table.name,
                        analysis="date_ordering",
                        reason=f"per-table budget of {budget.seconds:.0f}s was spent",
                    )
                )
            else:
                report.orderings.extend(row_date_orderings(registry, table, connection))
                report.orderings.extend(join_date_orderings(registry, model, table, connection))

        report.table_seconds[table.name] = round(time.perf_counter() - table_started, 3)

    report.ratios = profile_ratios(registry, model, connection)
    report.seconds = round(time.perf_counter() - started, 3)
    return report

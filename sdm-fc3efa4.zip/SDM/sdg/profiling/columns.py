"""Per-column measures.

Counts, distinct counts, ranges, and lengths are computed by the database and
come back as one row per table, so a wide table costs one query rather than one
per column. Only a bounded sample is pulled into the process, and only to fit a
format and to test for a check digit; whole columns are never extracted.

Nothing here writes to the source.
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sdg.discovery.connections import ConnectionRegistry
from sdg.discovery.model import Column, Table
from sdg.profiling.checks import check_digits, sequence_test
from sdg.profiling.format import fit_format
from sdg.profiling.model import ColumnProfile, TopValue, cardinality_class

SAMPLE_CAP = 100_000
TOP_N = 20
# Below this the profiler asks for an exact distinct count; above it the
# approximate one is close enough and far cheaper.
EXACT_DISTINCT_MAX_ROWS = 200_000


def _quote(name: str) -> str:
    return "[" + name.replace("]", "]]") + "]"


def _qualified(table: Table) -> str:
    return f"{_quote(table.schema_name)}.{_quote(table.table_name)}"


def _profilable(column: Column) -> bool:
    """Columns the profiler can measure. Large binary and text blobs are skipped."""
    if column.type_name in {"varbinary", "binary", "image", "xml", "geography", "geometry"}:
        return False
    if column.type_name in {"text", "ntext"}:
        return False
    return True


def aggregate_sql(table: Table, columns: list[Column], *, exact_distinct: bool) -> str:
    """One SELECT that measures every column in the table."""
    distinct_fn = "COUNT(DISTINCT {col})" if exact_distinct else "APPROX_COUNT_DISTINCT({col})"
    parts = ["COUNT_BIG(*) AS row_count"]
    for index, column in enumerate(columns):
        col = _quote(column.name)
        parts.append(f"SUM(CASE WHEN {col} IS NULL THEN 1 ELSE 0 END) AS nulls_{index}")
        parts.append(distinct_fn.format(col=col) + f" AS distinct_{index}")
        if column.is_numeric:
            parts.append(f"MIN({col}) AS min_{index}")
            parts.append(f"MAX({col}) AS max_{index}")
            parts.append(f"AVG(CAST({col} AS float)) AS mean_{index}")
            parts.append(f"STDEV(CAST({col} AS float)) AS stddev_{index}")
        elif column.is_date:
            parts.append(f"MIN({col}) AS min_{index}")
            parts.append(f"MAX({col}) AS max_{index}")
            if column.type_name in {"datetime", "datetime2", "smalldatetime", "datetimeoffset"}:
                parts.append(
                    f"SUM(CASE WHEN CAST({col} AS time) <> '00:00:00' THEN 1 ELSE 0 END) "
                    f"AS timed_{index}"
                )
        elif column.is_character:
            parts.append(f"MIN(LEN({col})) AS minlen_{index}")
            parts.append(f"MAX(LEN({col})) AS maxlen_{index}")
            parts.append(f"MIN({col}) AS min_{index}")
            parts.append(f"MAX({col}) AS max_{index}")
    return f"SELECT {', '.join(parts)} FROM {_qualified(table)}"  # noqa: S608 - names come from the catalog


def sample_sql(table: Table, columns: list[Column], cap: int, seed: int) -> str:
    """Up to `cap` rows. A large table is page-sampled with a fixed seed so a
    re-profile sees the same rows and the two reports can be compared."""
    column_list = ", ".join(_quote(c.name) for c in columns)
    source = _qualified(table)
    if table.row_count > cap * 2 and table.row_count > 0:
        percent = max(1.0, min(100.0, (cap * 2.5 / table.row_count) * 100))
        source += f" TABLESAMPLE SYSTEM ({percent:.4f} PERCENT) REPEATABLE ({seed})"
    return f"SELECT TOP ({cap}) {column_list} FROM {source}"  # noqa: S608


def top_values_sql(table: Table, column: Column, limit: int = TOP_N) -> str:
    col = _quote(column.name)
    return (
        f"SELECT TOP ({limit}) {col} AS value, COUNT_BIG(*) AS frequency "  # noqa: S608
        f"FROM {_qualified(table)} WHERE {col} IS NOT NULL "
        f"GROUP BY {col} ORDER BY COUNT_BIG(*) DESC, {col}"
    )


def _clean(value: Any) -> Any:
    """Make a database value comparable and serializable."""
    if isinstance(value, str):
        return value.rstrip()
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return value


def profile_table(
    registry: ConnectionRegistry,
    table: Table,
    connection: str = "source",
    *,
    sample_cap: int = SAMPLE_CAP,
    sample_seed: int = 20260915,
) -> list[ColumnProfile]:
    """Measure every column of one table."""
    columns = [c for c in table.columns if _profilable(c)]
    if not columns:
        return []

    exact = table.row_count <= EXACT_DISTINCT_MAX_ROWS
    aggregates = registry.query(connection, aggregate_sql(table, columns, exact_distinct=exact))
    row = aggregates[0] if aggregates else {}
    row_count = int(row.get("row_count") or 0)

    profiles: list[ColumnProfile] = []
    for index, column in enumerate(columns):
        null_count = int(row.get(f"nulls_{index}") or 0)
        distinct_count = int(row.get(f"distinct_{index}") or 0)
        profile = ColumnProfile(
            table=table.name,
            column=column.name,
            row_count=row_count,
            null_count=null_count,
            null_rate=(null_count / row_count) if row_count else 0.0,
            distinct_count=distinct_count,
            distinct_ratio=(distinct_count / row_count) if row_count else 0.0,
            approximate_distinct=not exact,
            cardinality=cardinality_class(distinct_count, row_count - null_count or row_count),
            minimum=_clean(row.get(f"min_{index}")),
            maximum=_clean(row.get(f"max_{index}")),
            mean=_as_float(row.get(f"mean_{index}")),
            stddev=_as_float(row.get(f"stddev_{index}")),
            min_length=_as_int(row.get(f"minlen_{index}")),
            max_length=_as_int(row.get(f"maxlen_{index}")),
        )
        if f"timed_{index}" in row:
            profile.has_time_component = bool(row.get(f"timed_{index}") or 0)
        profiles.append(profile)

    _add_top_values(registry, connection, table, columns, profiles)
    _add_sample_measures(registry, connection, table, columns, profiles, sample_cap, sample_seed)
    return profiles


def _as_float(value: Any) -> float | None:
    return None if value is None else float(value)


def _as_int(value: Any) -> int | None:
    return None if value is None else int(value)


def _add_top_values(
    registry: ConnectionRegistry,
    connection: str,
    table: Table,
    columns: list[Column],
    profiles: list[ColumnProfile],
) -> None:
    """Top values and their weights, for columns that read as codes."""
    for column, profile in zip(columns, profiles):
        if not profile.looks_like_a_code():
            continue
        rows = registry.query(connection, top_values_sql(table, column))
        non_null = profile.row_count - profile.null_count
        if not non_null:
            continue
        profile.top_values = [
            TopValue(
                value=_clean(r["value"]),
                count=int(r["frequency"]),
                share=round(int(r["frequency"]) / non_null, 6),
            )
            for r in rows
        ]


def _add_sample_measures(
    registry: ConnectionRegistry,
    connection: str,
    table: Table,
    columns: list[Column],
    profiles: list[ColumnProfile],
    sample_cap: int,
    sample_seed: int,
) -> None:
    """Format fitting, sequence, and check-digit tests, all from one sample."""
    if not table.row_count:
        return
    rows = registry.query(connection, sample_sql(table, columns, sample_cap, sample_seed))
    if not rows:
        return

    for column, profile in zip(columns, profiles):
        values = [r[column.name] for r in rows if r.get(column.name) is not None]
        profile.sample_size = len(values)
        if not values:
            continue

        if column.is_character:
            fitted = fit_format([str(v).rstrip() for v in values])
            if fitted:
                profile.fitted_format = fitted.as_dict()
            digits = check_digits([str(v).rstrip() for v in values])
            if digits:
                profile.check_digit = digits.as_dict()

        elif column.is_integer:
            result = sequence_test([int(v) for v in values])
            if result:
                profile.sequence = result.as_dict()
            digits = check_digits([str(int(v)) for v in values])
            if digits:
                profile.check_digit = digits.as_dict()

        if column.is_numeric and not column.is_integer:
            profile.distribution = _fit_distribution([float(v) for v in values])
        elif column.is_integer and not (profile.sequence or {}).get("is_sequence"):
            profile.distribution = _fit_distribution([float(v) for v in values])


def _fit_distribution(values: list[float]) -> dict[str, Any] | None:
    """Pick between uniform, normal, and log-normal by comparing skew.

    This is deliberately a rule of thumb rather than a goodness-of-fit test: the
    proposal is shown to a user with its evidence, and they can change it.
    """
    import math

    if len(values) < 20:
        return None
    count = len(values)
    mean = sum(values) / count
    variance = sum((v - mean) ** 2 for v in values) / max(1, count - 1)
    stddev = math.sqrt(variance)
    low, high = min(values), max(values)
    if stddev == 0:
        return {"kind": "constant", "min": low, "max": high, "mean": mean, "stddev": 0.0}

    skew = sum(((v - mean) / stddev) ** 3 for v in values) / count

    if all(v > 0 for v in values) and skew > 1.0:
        logs = [math.log(v) for v in values]
        log_mean = sum(logs) / count
        log_var = sum((x - log_mean) ** 2 for x in logs) / max(1, count - 1)
        return {
            "kind": "lognormal",
            "mean": round(log_mean, 6),
            "stddev": round(math.sqrt(log_var), 6),
            "min": low,
            "max": high,
            "skew": round(skew, 4),
        }

    # A uniform sample has a standard deviation near range / sqrt(12).
    expected_uniform = (high - low) / math.sqrt(12) if high > low else 0.0
    if expected_uniform and abs(stddev - expected_uniform) / expected_uniform < 0.15:
        return {"kind": "uniform", "min": low, "max": high, "skew": round(skew, 4)}

    return {
        "kind": "normal",
        "mean": round(mean, 6),
        "stddev": round(stddev, 6),
        "min": low,
        "max": high,
        "skew": round(skew, 4),
    }

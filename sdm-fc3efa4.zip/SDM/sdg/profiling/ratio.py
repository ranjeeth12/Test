"""How many children each parent has.

This is the measure that decides volumes. A flat "four claims per member"
produces data that no test exercises properly; real populations have parents
with none, parents with a handful, and a long tail of parents with many. The
profiler measures the real shape and proposes it.

The share of parents with no children is kept as its own bin rather than being
averaged into the first bucket, because it is usually the single most important
number in the distribution and the one a flat ratio loses.
"""

from __future__ import annotations

from dataclasses import dataclass

from sdg.discovery.connections import ConnectionRegistry
from sdg.discovery.model import PhysicalModel, Table
from sdg.profiling.model import HistogramBin, RatioProfile

# The build brief: below this, the spread is small enough that a fixed ratio
# describes the data as well as a distribution does.
FIXED_RATIO_MAX_DISPERSION = 0.25
# Enough that a realistic children-per-parent distribution keeps every count
# it actually has. Bucketing below is what a comb-shaped population comes from,
# so it is a fallback for pathological spreads rather than the normal path.
HISTOGRAM_BINS = 64


def _quote(name: str) -> str:
    return "[" + name.replace("]", "]]") + "]"


def _qualified(table: Table) -> str:
    return f"{_quote(table.schema_name)}.{_quote(table.table_name)}"


def _per_parent_cte(parent: Table, parent_column: str, child: Table, child_column: str) -> str:
    return (
        "WITH per_parent AS ("
        f" SELECT p.{_quote(parent_column)} AS parent_key, COUNT(c.{_quote(child_column)}) AS n"
        f" FROM {_qualified(parent)} AS p"
        f" LEFT JOIN {_qualified(child)} AS c"
        f" ON c.{_quote(child_column)} = p.{_quote(parent_column)}"
        f" GROUP BY p.{_quote(parent_column)}"
        ")"
    )


SUMMARY_SQL = """
{cte}
SELECT COUNT(*) AS parents,
       SUM(CAST(n AS bigint)) AS children,
       MIN(n) AS minimum,
       MAX(n) AS maximum,
       AVG(CAST(n AS float)) AS mean,
       STDEV(CAST(n AS float)) AS stddev,
       SUM(CASE WHEN n = 0 THEN 1 ELSE 0 END) AS childless
FROM per_parent
"""

PERCENTILE_SQL = """
{cte}
SELECT DISTINCT
       PERCENTILE_CONT(0.5)  WITHIN GROUP (ORDER BY n) OVER () AS median_all,
       PERCENTILE_CONT(0.9)  WITHIN GROUP (ORDER BY n) OVER () AS p90_all,
       PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY n) OVER () AS p99_all
FROM per_parent
"""

PERCENTILE_NONZERO_SQL = """
{cte}
SELECT DISTINCT
       PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY n) OVER () AS median_nonzero,
       PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY n) OVER () AS p90_nonzero
FROM per_parent
WHERE n > 0
"""

COUNTS_SQL = """
{cte}
SELECT n, COUNT(*) AS parents
FROM per_parent
GROUP BY n
ORDER BY n
"""


@dataclass
class RatioTarget:
    child_table: Table
    child_column: str
    parent_table: Table
    parent_column: str
    kind: str


def targets(model: PhysicalModel) -> list[RatioTarget]:
    """Every single-column foreign key, declared or inferred."""
    out: list[RatioTarget] = []
    for child in model.tables:
        for foreign_key in child.foreign_keys:
            if len(foreign_key.columns) != 1:
                continue
            parent = model.table(foreign_key.parent_table)
            if parent is None:
                continue
            out.append(
                RatioTarget(
                    child_table=child,
                    child_column=foreign_key.columns[0],
                    parent_table=parent,
                    parent_column=foreign_key.parent_columns[0],
                    kind=foreign_key.kind,
                )
            )
    return out


def build_histogram(counts: list[tuple[int, int]], bins: int = HISTOGRAM_BINS) -> list[HistogramBin]:
    """Turn (children, parents) counts into at most `bins` weighted bins.

    Zero keeps its own bin. The rest are used as they are when they fit, and
    bucketed by equal width when they do not, with each bucket represented by
    the mean number of children inside it so the total is preserved. A bucket
    that covers more than one count also records that range, because a bucket
    drawn as a single number turns a smooth tail into a comb.
    """
    if not counts:
        return []
    zero = next((parents for children, parents in counts if children == 0), 0)
    positive = [(children, parents) for children, parents in counts if children > 0]
    total = sum(parents for _, parents in counts)
    if not total:
        return []

    out: list[HistogramBin] = []
    if zero:
        out.append(HistogramBin(children=0, weight=round(zero / total, 6)))

    remaining_bins = bins - len(out)
    if not positive:
        return out

    if len(positive) <= remaining_bins:
        for children, parents in positive:
            out.append(HistogramBin(children=children, weight=round(parents / total, 6)))
        return out

    low = positive[0][0]
    high = positive[-1][0]
    width = max(1, (high - low + 1 + remaining_bins - 1) // remaining_bins)
    bucket: dict[int, list[int]] = {}
    for children, parents in positive:
        index = (children - low) // width
        bucket.setdefault(index, [0, 0, children, children])
        bucket[index][0] += parents
        bucket[index][1] += children * parents
        bucket[index][2] = min(bucket[index][2], children)
        bucket[index][3] = max(bucket[index][3], children)

    for index in sorted(bucket):
        parents, child_total, lowest, highest = bucket[index]
        representative = max(1, round(child_total / parents))
        out.append(HistogramBin(
            children=representative,
            weight=round(parents / total, 6),
            low=lowest if highest > lowest else None,
            high=highest if highest > lowest else None,
        ))
    return out


def profile_ratio(
    registry: ConnectionRegistry, target: RatioTarget, connection: str = "source"
) -> RatioProfile | None:
    cte = _per_parent_cte(
        target.parent_table, target.parent_column, target.child_table, target.child_column
    )

    summary = registry.query(connection, SUMMARY_SQL.format(cte=cte))
    if not summary or not summary[0]["parents"]:
        return None
    row = summary[0]
    parents = int(row["parents"])
    children = int(row["children"] or 0)
    mean = float(row["mean"] or 0.0)
    stddev = float(row["stddev"] or 0.0)
    childless = int(row["childless"] or 0)

    percentiles = registry.query(connection, PERCENTILE_SQL.format(cte=cte))
    nonzero = registry.query(connection, PERCENTILE_NONZERO_SQL.format(cte=cte))
    counts = [
        (int(r["n"]), int(r["parents"]))
        for r in registry.query(connection, COUNTS_SQL.format(cte=cte))
    ]

    profile = RatioProfile(
        child_table=target.child_table.name,
        child_column=target.child_column,
        parent_table=target.parent_table.name,
        parent_column=target.parent_column,
        kind=target.kind,
        parents=parents,
        children=children,
        minimum=int(row["minimum"] or 0),
        maximum=int(row["maximum"] or 0),
        mean=round(mean, 4),
        stddev=round(stddev, 4),
        median=_percentile(percentiles, "median_all"),
        p90=_percentile(percentiles, "p90_all"),
        p99=_percentile(percentiles, "p99_all"),
        median_nonzero=_percentile(nonzero, "median_nonzero"),
        p90_nonzero=_percentile(nonzero, "p90_nonzero"),
        zero_share=round(childless / parents, 6) if parents else 0.0,
        histogram=build_histogram(counts),
    )
    profile.proposal = propose(profile)
    profile.evidence = describe(profile)
    return profile


def _percentile(rows: list[dict], key: str) -> float:
    if not rows or rows[0].get(key) is None:
        return 0.0
    return round(float(rows[0][key]), 4)


def propose(profile: RatioProfile) -> dict:
    """A fixed ratio when the spread is small, a distribution when it is not."""
    dispersion = (profile.stddev / profile.mean) if profile.mean else 0.0
    if profile.mean and dispersion < FIXED_RATIO_MAX_DISPERSION:
        return {
            "kind": "fixed",
            "value": round(profile.mean, 4),
            "dispersion": round(dispersion, 4),
            "reason": (
                f"standard deviation is {dispersion:.2f} of the mean, below "
                f"{FIXED_RATIO_MAX_DISPERSION}, so one number describes it"
            ),
        }
    return {
        "kind": "distribution",
        "dispersion": round(dispersion, 4),
        "zero_share": profile.zero_share,
        "reason": (
            f"standard deviation is {dispersion:.2f} of the mean, at or above "
            f"{FIXED_RATIO_MAX_DISPERSION}, so the shape matters"
        ),
    }


def describe(profile: RatioProfile) -> str:
    """The sentence the hierarchy view shows next to the editable ratio."""
    return (
        f"observed {profile.children:,} {profile.child_table.split('.')[-1]} rows across "
        f"{profile.parents:,} {profile.parent_table.split('.')[-1]} rows; "
        f"{profile.zero_share:.0%} have none, median {profile.median_nonzero:g} among those "
        f"that do, 90th percentile {profile.p90_nonzero:g}, maximum {profile.maximum:,}"
    )


def profile_ratios(
    registry: ConnectionRegistry, model: PhysicalModel, connection: str = "source"
) -> list[RatioProfile]:
    results: list[RatioProfile] = []
    for target in targets(model):
        profile = profile_ratio(registry, target, connection)
        if profile is not None:
            results.append(profile)
    return results

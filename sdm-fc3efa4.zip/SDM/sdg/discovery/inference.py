"""Find foreign keys nobody declared.

Facets-style schemas carry relationships that exist in the data but not in the
catalog. A column is proposed as a foreign key when its values are contained in
another table's key column.

Candidates are narrowed first, because an inclusion check costs a query. A pair
is only worth testing when the types line up and the names share a token that
is not a generic key suffix. Without that second rule every `*_ID` column in the
schema would be compared against every other one.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from sdg.discovery.classify import tokenize
from sdg.discovery.connections import ConnectionRegistry
from sdg.discovery.model import ForeignKey, PhysicalModel, Table

# Shared by nearly every key column, so a match on one of these alone says
# nothing about whether two columns are related.
GENERIC_TOKENS = {"ID", "CK", "CD", "NO", "NUM", "KEY", "CODE", "SK", "NBR", "SEQ"}

INCLUSION_THRESHOLD = 0.995
MIN_DISTINCT_VALUES = 2
MIN_PARENT_ROWS = 2

INCLUSION_SQL = """
SELECT COUNT(*) AS distinct_values,
       SUM(CASE WHEN p.{parent_column} IS NULL THEN 1 ELSE 0 END) AS missing
FROM (
    SELECT DISTINCT {child_column} AS candidate_value
    FROM {child_table}
    WHERE {child_column} IS NOT NULL
) AS c
LEFT JOIN {parent_table} AS p ON p.{parent_column} = c.candidate_value
"""


@dataclass
class Candidate:
    child_table: str
    child_column: str
    parent_table: str
    parent_column: str
    shared_tokens: list[str] = field(default_factory=list)


@dataclass
class InferredKey:
    child_table: str
    child_column: str
    parent_table: str
    parent_column: str
    coverage: float
    distinct_values: int
    missing: int
    shared_tokens: list[str]

    def evidence(self) -> list[str]:
        return [
            f"{self.coverage:.1%} of {self.distinct_values:,} distinct values exist in "
            f"{self.parent_table}.{self.parent_column}",
            f"names share {', '.join(self.shared_tokens)}",
        ]


def _comparable(a, b) -> bool:
    """Do two columns hold the same kind of value?"""
    if a.type_name != b.type_name:
        return False
    if a.is_character and a.character_length() != b.character_length():
        return False
    if a.type_name in {"decimal", "numeric"} and (a.precision, a.scale) != (b.precision, b.scale):
        return False
    return True


def _key_columns(table: Table) -> list[str]:
    """Single-column keys another table could point at."""
    keys = set(table.unique_single_columns())
    if len(table.primary_key) == 1:
        keys.add(table.primary_key[0])
    return sorted(keys)


def candidates(model: PhysicalModel) -> list[Candidate]:
    """Pairs worth spending a query on."""
    found: list[Candidate] = []
    declared: set[tuple[str, str, str]] = set()
    for table in model.tables:
        for foreign_key in table.foreign_keys:
            for column in foreign_key.columns:
                declared.add((table.name, column, foreign_key.parent_table))

    for child in model.tables:
        for child_column in child.columns:
            if child_column.is_computed or child_column.is_identity:
                continue
            child_tokens = set(tokenize(child_column.name))
            for parent in model.tables:
                if parent.name == child.name:
                    continue
                if parent.row_count < MIN_PARENT_ROWS:
                    continue
                for parent_column_name in _key_columns(parent):
                    if (child.name, child_column.name, parent.name) in declared:
                        continue
                    parent_column = parent.column(parent_column_name)
                    if parent_column is None or not _comparable(child_column, parent_column):
                        continue
                    shared = (child_tokens & set(tokenize(parent_column_name))) - GENERIC_TOKENS
                    if not shared:
                        continue
                    found.append(
                        Candidate(
                            child_table=child.name,
                            child_column=child_column.name,
                            parent_table=parent.name,
                            parent_column=parent_column_name,
                            shared_tokens=sorted(shared),
                        )
                    )
    return found


def test_candidate(
    registry: ConnectionRegistry, connection: str, candidate: Candidate
) -> InferredKey | None:
    """One query: how many of the child's distinct values exist in the parent?"""
    sql = INCLUSION_SQL.format(
        child_table=candidate.child_table,
        child_column=candidate.child_column,
        parent_table=candidate.parent_table,
        parent_column=candidate.parent_column,
    )
    rows = registry.query(connection, sql)
    if not rows:
        return None
    distinct_values = int(rows[0]["distinct_values"] or 0)
    missing = int(rows[0]["missing"] or 0)
    if distinct_values < MIN_DISTINCT_VALUES:
        return None
    coverage = (distinct_values - missing) / distinct_values
    return InferredKey(
        child_table=candidate.child_table,
        child_column=candidate.child_column,
        parent_table=candidate.parent_table,
        parent_column=candidate.parent_column,
        coverage=coverage,
        distinct_values=distinct_values,
        missing=missing,
        shared_tokens=candidate.shared_tokens,
    )


def infer(
    registry: ConnectionRegistry,
    model: PhysicalModel,
    connection: str = "source",
    *,
    threshold: float = INCLUSION_THRESHOLD,
) -> list[InferredKey]:
    """Test every candidate and keep the ones above the inclusion threshold."""
    accepted: list[InferredKey] = []
    for candidate in candidates(model):
        result = test_candidate(registry, connection, candidate)
        if result is not None and result.coverage >= threshold:
            accepted.append(result)
    return one_way(model, accepted)


def one_way(model: PhysicalModel, accepted: list[InferredKey]) -> list[InferredKey]:
    """Keep one direction of a key the data shows both ways.

    Two tables holding the same set of keys -- two copies of one member list,
    say -- each contain all of the other's values, so each looks like the
    other's parent. That is the same kind of thing twice, not a parent and a
    child, and taking both directions is a cycle no load can satisfy: neither
    table's rows can go in first. The larger table is kept as the parent, and
    between equals the one whose name sorts first, so a schema read twice reads
    the same way. A key the data suggests in the reverse of one the schema
    declares is dropped: the declaration says which way it runs.
    """
    def rows(name: str) -> int:
        table = model.table(name)
        return table.row_count if table is not None else 0

    declared = {
        (fk.parent_table, fk.parent_columns[0], table.name, fk.columns[0])
        for table in model.tables for fk in table.foreign_keys
        if fk.kind == "declared" and len(fk.columns) == 1 and fk.parent_columns
    }
    found = {(k.child_table, k.child_column, k.parent_table, k.parent_column) for k in accepted}
    kept: list[InferredKey] = []
    for key in accepted:
        reverse = (key.parent_table, key.parent_column, key.child_table, key.child_column)
        if reverse in declared:
            continue
        if reverse in found:
            # The parent should be the larger table; between equals, the first
            # by name. Drop this direction if it points the other way.
            parent_first = (-rows(key.parent_table), key.parent_table)
            child_first = (-rows(key.child_table), key.child_table)
            if child_first < parent_first:
                continue
        kept.append(key)
    return kept


def attach(model: PhysicalModel, inferred: Iterable[InferredKey]) -> PhysicalModel:
    """Add the accepted keys to the model as inferred relationships."""
    for key in inferred:
        table = model.table(key.child_table)
        if table is None:
            continue
        already = any(
            fk.columns == [key.child_column] and fk.parent_table == key.parent_table
            for fk in table.foreign_keys
        )
        if already:
            continue
        table.foreign_keys.append(
            ForeignKey(
                name=None,
                columns=[key.child_column],
                parent_table=key.parent_table,
                parent_columns=[key.parent_column],
                kind="inferred",
                coverage=key.coverage,
                evidence=key.evidence(),
            )
        )
    return model

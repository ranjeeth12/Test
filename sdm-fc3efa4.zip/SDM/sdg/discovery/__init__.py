"""SDG discovery package."""

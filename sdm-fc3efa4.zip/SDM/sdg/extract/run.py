"""Run an extract: read a source, fill the analysis store.

One definition per source names the SELECT that produces each denorm table.
The SELECT runs on the source connection; the rows land on the denorm
connection. Both are SQL Server and usually the same server, but they are two
connections on purpose -- the store is not required to live beside the source,
and writing through a connection the tool controls is what keeps the source
read-only.

Rows move in blocks rather than one statement per row. A member book of any
size is hundreds of thousands of rows across sixty columns, and the difference
between `executemany` with a block and a row at a time is minutes.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterator

from sdg.discovery.connections import ConnectionRegistry

# Rows per round trip. Large enough that the round trip stops mattering, small
# enough that a block is held in memory rather than the whole table.
BLOCK = 2_000
# Blocks between progress reports: every 100,000 rows.
PROGRESS_EVERY = 50

DEFINITIONS = Path(__file__).resolve().parent / "definitions"

# A store holds one landscape: the customer's denorm tables carry no column
# naming the source a row came from, so an extract replaces the whole table.


class SourceQueryError(Exception):
    """A definition's SELECT failed on the source database."""


@dataclass
class TableResult:
    table: str
    rows: int
    seconds: float
    # Rows left behind because this tool generated them. Reported rather than
    # quietly dropped: an extract that is smaller than the source should say
    # why.
    skipped: int = 0
    # Why the table could not be filled, if it could not. Its old rows stay.
    error: str = ""


@dataclass
class ExtractResult:
    source: str
    tables: list[TableResult] = field(default_factory=list)
    seconds: float = 0.0

    @property
    def rows(self) -> int:
        return sum(t.rows for t in self.tables)

    @property
    def skipped(self) -> int:
        return sum(t.skipped for t in self.tables)

    def as_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "seconds": round(self.seconds, 2),
            "rows": self.rows,
            "tables": [
                {"table": t.table, "rows": t.rows, "skipped": t.skipped,
                 "seconds": round(t.seconds, 2)}
                for t in self.tables
            ],
        }


def sources() -> list[str]:
    """Every source with an extract definition on disk."""
    if not DEFINITIONS.exists():
        return []
    return sorted(p.stem for p in DEFINITIONS.glob("*.sql"))


def _statements(source: str) -> dict[str, str]:
    """The SELECT behind each denorm table, for one source.

    A definition file is a sequence of blocks, each introduced by a line naming
    the table it fills:

        -- table: member_denorm
        SELECT ...

    Plain SQL rather than anything generated, because an extract is exactly the
    join a person would write and reading it should not require this module.
    """
    path = DEFINITIONS / f"{source}.sql"
    if not path.exists():
        raise FileNotFoundError(
            f"no extract definition for {source!r}. Looked in {DEFINITIONS}; "
            f"found {', '.join(sources()) or 'nothing'}"
        )

    blocks: dict[str, str] = {}
    table: str | None = None
    lines: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        marker = line.strip().lower()
        if marker.startswith("-- table:"):
            if table:
                blocks[table] = "\n".join(lines).strip()
            table = line.split(":", 1)[1].strip()
            lines = []
            continue
        lines.append(line)
    if table:
        blocks[table] = "\n".join(lines).strip()

    if not blocks:
        raise ValueError(f"{path} names no tables; expected a '-- table: <name>' line")
    return blocks


def _blocks(cursor, size: int = BLOCK) -> Iterator[list[tuple]]:
    while True:
        rows = cursor.fetchmany(size)
        if not rows:
            return
        yield rows


def extract(
    source: str,
    *,
    registry: ConnectionRegistry | None = None,
    schema: str | None = None,
    only: list[str] | None = None,
    exclude_keys: dict[str, list] | None = None,
    progress: Callable[..., None] | None = None,
    stop_on_error: bool = True,
) -> ExtractResult:
    """Read `source` into the analysis store, replacing what was there.

    `schema` is the store's, as configured unless given.

    Complete refresh, per table: the table's rows go, then the source is read
    again. A store holds one landscape, as the customer's denorm tables do.

    Each table is one transaction. A failure part way leaves that table as it
    was rather than half replaced -- an analysis over half a book is wrong in a
    way nothing downstream could detect.
    """
    registry = registry or ConnectionRegistry()
    schema = schema or registry.settings.denorm_schema
    statements = _statements(source)
    if only:
        missing = [t for t in only if t not in statements]
        if missing:
            raise ValueError(
                f"{source} has no extract for {', '.join(missing)}; "
                f"it defines {', '.join(sorted(statements))}"
            )
        statements = {t: statements[t] for t in only}

    result = ExtractResult(source=source)
    started = time.perf_counter()

    with registry.connect("source") as read, registry.connect("denorm") as write:
        for table, select in statements.items():
            try:
                result.tables.append(
                    _one_table(
                        read, write, source, schema, table, select, exclude_keys or {},
                        progress,
                    )
                )
            except Exception as exc:
                if stop_on_error:
                    raise
                # One table that cannot be read leaves its old rows and says
                # why; the rest of a long overnight refresh still happens.
                from sdg.discovery.errors import plain

                error = str(exc) if isinstance(exc, SourceQueryError) else plain(exc)
                result.tables.append(TableResult(table=table, rows=0, seconds=0.0,
                                                 error=error))
                if progress:
                    # Said as a failure, never as "0 rows": an empty table and
                    # one that could not be read are not the same thing.
                    progress(table, 0, True, error=error)

    result.seconds = time.perf_counter() - started
    _log(registry, schema, source, result)
    return result


def log_ddl(schema: str) -> str:
    """The extract log, created if missing; customer-tables creates it up front
    so an extract under a login that may not create tables still logs."""
    return (f"IF OBJECT_ID(N'{schema}.extract_log', N'U') IS NULL "
            f"CREATE TABLE [{schema}].[extract_log] (source NVARCHAR(100) NOT NULL, "
            f"table_name NVARCHAR(128) NOT NULL, row_count BIGINT NOT NULL, "
            f"error NVARCHAR(1000) NULL, finished_at DATETIME2 NOT NULL)")


def _log(registry, schema: str, source: str, result: ExtractResult) -> None:
    """When each table was last filled, and with how many rows.

    A refresh can leave a table with as many rows as before; the pattern
    analyses cached against it would then look current. This is the stamp
    that says they are not.
    """
    from datetime import datetime

    table = f"[{schema}].[extract_log]"
    try:
        with registry.connect("denorm") as write:
            cursor = write.cursor()
            cursor.execute(log_ddl(schema))
            now = datetime.now()
            for done in result.tables:
                cursor.execute(
                    f"INSERT INTO {table} (source, table_name, row_count, error, finished_at) "
                    f"VALUES (?, ?, ?, ?, ?)",
                    source, done.table, done.rows, done.error or None, now)
            write.commit()
    except Exception:
        # A store this login cannot add a table to still gets its rows.
        pass


def _one_table(
    read, write, source: str, schema: str, table: str, select: str,
    exclude_keys: dict[str, list],
    progress: Callable[[str, int, bool], None] | None = None,
) -> TableResult:
    started = time.perf_counter()
    qualified = f"[{schema}].[{table}]"

    try:
        cursor = read.cursor().execute(select)
    except Exception as exc:
        # The query on the source failed: FACETS itself lacks what the
        # definition names. Nothing this tool's setup or upgrade would fix.
        raise SourceQueryError(
            f"The {source} query for {table} failed on the source database "
            f"({source}), not on the SDM tables: {exc}") from exc
    columns = [d[0] for d in cursor.description]

    placeholders = ", ".join(["?"] * len(columns))
    names = ", ".join(f"[{c}]" for c in columns)
    insert = f"INSERT INTO {qualified} ({names}) VALUES ({placeholders})"

    # What this tool generated, and must not read back as though it were
    # measured. Keyed by the column the manifest records them under; a denorm
    # row carrying one of those keys came from a run, not from the source.
    skip_column, skip_values = _exclusions(columns, exclude_keys)

    writer = write.cursor()
    writer.fast_executemany = True
    rows = skipped = 0
    try:
        # Replace rather than merge, emptied and filled in one transaction, so
        # a failure part way leaves the old rows in place. TRUNCATE is far
        # faster on a large table than deleting row by row; a login allowed
        # to delete but not to truncate gets the delete.
        try:
            writer.execute(f"TRUNCATE TABLE {qualified}")
        except Exception:
            write.rollback()
            writer = write.cursor()
            writer.fast_executemany = True
            writer.execute(f"DELETE FROM {qualified}")
        position = columns.index(skip_column) if skip_column else -1
        for number, block in enumerate(_blocks(cursor), start=1):
            if position >= 0:
                keep = [r for r in block if r[position] not in skip_values]
                skipped += len(block) - len(keep)
            else:
                keep = block
            if keep:
                writer.executemany(insert, [tuple(r) for r in keep])
            rows += len(keep)
            if progress and number % PROGRESS_EVERY == 0:
                progress(table, rows, False)
        write.commit()
        if progress:
            progress(table, rows, True)
    except Exception:
        write.rollback()
        raise

    return TableResult(
        table=table, rows=rows, skipped=skipped,
        seconds=time.perf_counter() - started,
    )


def _exclusions(columns: list[str], exclude_keys: dict[str, list]):
    """Which column to filter on, and which values to drop.

    `exclude_keys` is keyed by **column** -- see `keys_from_manifest`, which
    translates a run manifest into that shape. The manifest itself is keyed by
    table, and a denorm select has no tables in it, only the columns the join
    carried through. Translating at the boundary keeps the guessing in one
    place instead of here.

    Where none of the excluded columns is in this select, nothing is filtered:
    a denorm table that does not carry the key cannot be told which of its rows
    came from a run.
    """
    by_column = {c.upper(): c for c in columns}
    for column, values in (exclude_keys or {}).items():
        found = by_column.get(column.upper())
        if found and values:
            return found, set(values)
    return None, set()


def keys_from_manifest(manifest: dict | None) -> dict[str, set]:
    """The keys a run wrote, by the column that holds them.

    A manifest records `{table: [[key], [key], ...]}` and, separately, which
    columns those keys are. An extract needs the pairing: the column name is
    the only thing a denorm select and a source table have in common.

    Composite keys are reduced to their first column. A row of the denorm is
    one row of the child table, so the first key column identifies it; the
    second would narrow a set that is already right.
    """
    if not manifest:
        return {}
    columns = {
        record["table"]: (record.get("key_columns") or [])
        for record in manifest.get("tables") or []
    }
    out: dict[str, set] = {}
    for table, values in (manifest.get("keys") or {}).items():
        key_columns = columns.get(table) or []
        if not key_columns or not values:
            continue
        held = out.setdefault(key_columns[0], set())
        for value in values:
            held.add(value[0] if isinstance(value, (list, tuple)) else value)
    return out

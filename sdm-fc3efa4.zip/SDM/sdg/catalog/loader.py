"""Load the element catalog from YAML.

Dictionaries are kept as separate files rather than inline in the catalog, so a
list of six hundred postal codes does not drown the rules. A `dictionary:`
parameter is expanded into `values` at load time, and the element that the plan
and the engine see is self-contained.
"""

from __future__ import annotations

import csv
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

from sdg.catalog.model import Catalog, Element
from sdg.config import REPO_ROOT

DEFAULT_CATALOG = REPO_ROOT / "examples" / "catalog.yaml"
DEFAULT_DICTIONARIES = REPO_ROOT / "examples" / "dictionaries"


class CatalogError(ValueError):
    """A catalog that cannot be loaded."""


@lru_cache(maxsize=32)
def load_dictionary(name: str, directory: str | None = None) -> tuple[Any, ...]:
    """Read a dictionary file.

    A .txt file is one value per line. A .csv file with a header becomes a list
    of records, which is what a column set such as ZIP, city, and state needs.
    """
    base = Path(directory) if directory else DEFAULT_DICTIONARIES
    text_path = base / f"{name}.txt"
    csv_path = base / f"{name}.csv"

    if text_path.exists():
        lines = text_path.read_text(encoding="utf-8").splitlines()
        return tuple(line.strip() for line in lines if line.strip())

    if csv_path.exists():
        with csv_path.open(newline="", encoding="utf-8") as handle:
            return tuple(dict(row) for row in csv.DictReader(handle))

    raise CatalogError(
        f"dictionary {name!r} not found; looked for {text_path} and {csv_path}"
    )


def expand_dictionaries(element: Element, directory: str | None = None) -> Element:
    """Replace a `dictionary` parameter with the values it names."""
    name = element.params.get("dictionary")
    if not name or "values" in element.params:
        return element
    values = load_dictionary(str(name), directory)
    element.params = {**element.params, "values": list(values)}
    element.params.pop("dictionary", None)
    return element


def load_catalog(
    path: str | Path | None = None, *, dictionaries: str | None = None
) -> Catalog:
    path = Path(path) if path else DEFAULT_CATALOG
    if not path.exists():
        raise CatalogError(f"catalog not found: {path}")
    try:
        document = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise CatalogError(f"{path} is not valid YAML: {exc}") from exc
    if not isinstance(document, dict):
        raise CatalogError(f"{path} must hold a mapping at the top level")

    try:
        catalog = Catalog.model_validate(document)
    except Exception as exc:
        raise CatalogError(f"{path}: {exc}") from exc

    for element in catalog.elements:
        expand_dictionaries(element, dictionaries)
    return catalog

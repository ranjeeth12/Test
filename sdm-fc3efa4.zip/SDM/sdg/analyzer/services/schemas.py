"""Request and response models.

Responses are deliberately flat and JSON-native — the React client shouldn't
have to know that any of this came out of a pandas DataFrame.
"""

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field


# ── Hierarchy ────────────────────────────────────────────────────────────────

class Option(BaseModel):
    key: str
    label: str


class OverviewMetrics(BaseModel):
    n_members: int
    n_groups: int
    n_plan_categories: int
    n_plans: int
    n_products: int


# ── Pattern analysis ─────────────────────────────────────────────────────────

class Filters(BaseModel):
    grgr_ck: Optional[list[int]] = None
    cspd_cat: Optional[list[str]] = None
    cspi_id: Optional[list[str]] = None
    pdpd_id: Optional[list[str]] = None
    # A defined pattern's rules beyond the hierarchy: {feature: {"in": [...]}}
    # or {feature: {"min": x, "max": y}}.
    conditions: Optional[dict[str, Any]] = None

    def as_kwargs(self) -> dict:
        """Only non-empty filters — matches what the Streamlit page passed."""
        from sdg.analyzer.services.defined_patterns import check

        return {
            k: v for k, v in {
                "grgr_ck": self.grgr_ck or None,
                "cspd_cat": self.cspd_cat or None,
                "cspi_id": self.cspi_id or None,
                "pdpd_id": self.pdpd_id or None,
                "conditions": check("members", self.conditions) or None,
            }.items() if v is not None
        }


class AnalyzeRequest(BaseModel):
    filters: Filters = Field(default_factory=Filters)
    k: Optional[int] = Field(None, ge=1, le=20,
                             description="None selects K by silhouette score; 1 is the whole scope")
    reference_date: Optional[str] = None


class ContinuousStats(BaseModel):
    mean: float
    std: float
    min: float
    max: float
    median: float
    # The eleven cut points of ten equal shares, which generation draws from.
    deciles: Optional[list[float]] = None


class CategoricalDist(BaseModel):
    counts: dict[str, int]
    pct: dict[str, float]


class FamilyStats(BaseModel):
    avg_dependents: Optional[float] = None
    spouse_rate: Optional[float] = None
    n_subscribers: Optional[int] = None


class Pattern(BaseModel):
    """Anything the client reads must be declared here.

    FastAPI serializes strictly against this model — a field the service
    computes but this class omits is silently dropped, and the client sees
    undefined. That failure is invisible server-side, so it is worth being
    deliberate about every addition.
    """
    cluster_id: int
    name: str
    size: int
    pct_of_subset: float
    # Share of the stored baseline for this scope. Drives the weight band.
    pct_of_total: float = 0.0
    rare: bool
    weight_band: str
    continuous: dict[str, ContinuousStats]
    categorical: dict[str, CategoricalDist]
    family: dict[str, Any]
    descriptions: dict[str, list[str]]
    # Counts per bin of the response's `distributions`, feature by feature:
    # the shape behind this pattern's mean and range.
    histograms: dict[str, list[int]] = {}
    # Where the pattern's members live: address records with their shares.
    geography: list[dict[str, Any]] = []
    # Its own combinations of each group of dependent features, drawn whole.
    combinations: list[dict[str, Any]] = []
    # The group, plan and product its members are enrolled in, with shares.
    enrollment: list[dict[str, Any]] = []


class AnalyzeResponse(BaseModel):
    total_members: int
    subset_members: int
    pct_of_total: float
    n_patterns: int

    # Denominator behind every weight on this response.
    scope_total: int = 0
    scope_label: str = ""
    scope_from_baseline: bool = False
    weight_explained: str = ""
    pct_outside_filter: float = 0.0

    method: str
    silhouette: Optional[float] = None
    filters_used: dict[str, Any]
    patterns: list[Pattern]
    cache_key: str

    # The percentile cut-offs the weight bands were read against, when a
    # baseline has been computed. Declared because a response model drops what
    # it does not name: the member profiler has always sent this and it has
    # always been stripped here, so the screen could not say where a band came
    # from while the claims profiler, which has no response model, could.
    band_thresholds: Optional[dict[str, Any]] = None

    # Each continuous feature over the whole subset, on the bins every
    # pattern's histogram is counted into.
    distributions: dict[str, Any] = {}


# ── Generation ───────────────────────────────────────────────────────────────

DataType = Literal["Members", "Claims", "Enrollments"]


class GenerateRequest(BaseModel):
    filters: Filters = Field(default_factory=Filters)
    cluster_id: int
    k: Optional[int] = Field(None, ge=1, le=20)
    data_type: DataType = "Members"
    n_records: int = Field(100, ge=1, le=100_000)
    seed: Optional[int] = None
    reference_date: Optional[str] = None


class ValidationDetail(BaseModel):
    rule_name: str
    field: Optional[str] = None
    severity: str
    passed: bool
    violation_count: int = 0


class ValidationSummary(BaseModel):
    passed: bool
    total_rules: int
    errors: int
    warnings: int
    details: list[ValidationDetail] = []


class EdiRequest(GenerateRequest):
    """Same inputs as generation, plus an optional row subset.

    Empty or omitted row_indices means the whole dataset.
    """
    row_indices: Optional[list[int]] = None


class GenerateResponse(BaseModel):
    data_type: DataType
    n_records: int
    seed: int
    columns: list[str]
    preview: list[dict[str, Any]]
    validation: ValidationSummary
    pattern_name: str


# ── Claims ───────────────────────────────────────────────────────────────────

class ClaimsOverview(BaseModel):
    n_claim_lines: int = 0
    n_claims: int = 0
    n_members: int = 0
    n_diagnoses: int = 0
    n_procedures: int = 0


class CodeCount(BaseModel):
    code: str
    description: Optional[str] = None
    n: int


# ── Story → Data ─────────────────────────────────────────────────────────────

class StoryParseResponse(BaseModel):
    stories: list[str]
    column_used: Optional[str] = None
    filename: Optional[str] = None


class StoryMatchRequest(BaseModel):
    stories: Optional[list[str]] = None
    text: Optional[str] = None
    top_n: int = Field(4, ge=1, le=10)


class PatternCandidate(BaseModel):
    pattern_id: int
    name: str
    member_count: int
    match_score: float
    match_count: int
    group: Optional[str] = None
    plan_category: Optional[str] = None
    plan: Optional[str] = None
    product: Optional[str] = None


class StoryMatch(BaseModel):
    index: int
    story: str
    data_type: str
    volume: Optional[int] = None
    keywords: list[str] = []
    raw_terms: list[str] = []
    confidence: float
    matched: bool
    candidates: list[PatternCandidate] = []


class StoryMatchResponse(BaseModel):
    stories: list[StoryMatch]
    warning: Optional[str] = None


class StoryAllocateRequest(BaseModel):
    pattern_ids: list[int]
    total_volume: int = Field(100, ge=1, le=100_000)


class StoryGenerateItem(BaseModel):
    pattern_id: int
    data_type: str = "members"
    count: int = Field(100, ge=1, le=100_000)


class StoryGenerateRequest(BaseModel):
    items: list[StoryGenerateItem]
    seed: Optional[int] = None


class StoryGenerateResult(BaseModel):
    pattern_id: int
    pattern_name: str
    data_type: str
    n_records: int
    seed: int
    columns: list[str]
    preview: list[dict[str, Any]]
    validation: Optional[ValidationSummary] = None
    error: Optional[str] = None


class StoryGenerateResponse(BaseModel):
    results: list[StoryGenerateResult]

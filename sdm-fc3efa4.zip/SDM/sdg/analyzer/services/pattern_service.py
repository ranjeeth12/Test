"""User-defined patterns, cloning, and certification.

Three ideas, and the distinctions between them are the point:

  Discovered patterns are evidence. The system found the combination in real
  data. They are immutable — editing one would quietly turn evidence into
  opinion while leaving it labeled as evidence.

  User-defined patterns are hypotheses. An SME states a combination of feature
  values for a scenario the data has not seen yet. Values are deliberately NOT
  validated against reference data: a genuinely new line of business has codes
  that are not configured anywhere, and refusing them would defeat the purpose.
  The tool cannot vouch for these, which is exactly what the flag says.

  Certification closes the loop. When discovery later finds the same
  combination, the two are offered for merge. A reviewer approves it — never
  the system on its own, because silently promoting a hypothesis to evidence
  would rewrite the provenance of data already generated under it.
"""

from __future__ import annotations

import json
import time
from datetime import datetime
from typing import Optional

from sdg.analyzer import db
from sdg.analyzer.config import SQL_SCHEMA

PATTERNS = f"{SQL_SCHEMA}.patterns"

DISCOVERED = "discovered"
USER_DEFINED = "user_defined"

# The features a pattern is defined by. Fixed on purpose: a user-defined
# pattern varies the *values*, never the feature set, so a stated pattern stays
# structurally identical to a discovered one — which is what makes certification
# a like-for-like comparison rather than a guess.
FEATURES = ("grgr_ck", "cspd_cat", "cspi_id", "pdpd_id")

# Cluster id for user-defined patterns. They come from no clustering run, and
# reusing 0 would collide with a real cluster from discovery.
USER_CLUSTER_ID = -1


def _conn():
    """An open connection this module owns and closes itself.

    Not db.get_connection() — that is a @contextmanager, so calling it returns
    the manager object rather than a connection. Every use here follows the
    open / try / close shape, so it needs the raw connection.
    """
    return db.get_raw_connection()


def _norm_values(values) -> Optional[list]:
    """Normalize one feature's values so two spellings of the same combination
    produce the same key: sorted, de-duplicated, stringified, empty → None."""
    if values is None:
        return None
    if not isinstance(values, (list, tuple, set)):
        values = [values]
    cleaned = sorted({str(v).strip() for v in values
                      if v is not None and str(v).strip()})
    return cleaned or None


def combo_key(combo: dict, entity: str = "members") -> str:
    """The identity of a combination, independent of any clustering run.

    Certification matches on this. cluster_id is excluded deliberately: which
    cluster a discovery run assigned a combination to is an artifact of that
    run, not a property of the pattern. The domain tag is included so a member
    and a claims pattern over the same hierarchy never certify each other.
    """
    cat = _norm_values(combo.get("cspd_cat")) or []
    cat = sorted(cat + ["__CLAIMS__" if entity == "claims" else "__MEMBERS__"])

    parts = []
    for feature in FEATURES:
        values = cat if feature == "cspd_cat" else _norm_values(combo.get(feature))
        parts.append(str(values or "ALL"))
    return "|".join(parts)


def entity_of(pattern: dict) -> str:
    """Which domain a stored pattern belongs to.

    Three markers, because rows were written by three different generations of
    this code. Newer rows carry the __CLAIMS__ sentinel folded into cspd_cat.
    Rows saved before that sentinel existed are claims by name prefix only —
    checking the sentinel alone read them as members, so cloning one produced a
    "member" pattern that the claims dropdown then offered and generation could
    not use. The name marker is matched anywhere in the string rather than only
    at the start, because a clone is named "Copy of [Claims] ...".
    """
    if "__CLAIMS__" in str(pattern.get("cspd_cat") or ""):
        return "claims"
    if "[Claims]" in str(pattern.get("contextual_name") or pattern.get("name") or ""):
        return "claims"
    if str(pattern.get("cspd_cat_desc") or "").strip().lower() == "claims":
        return "claims"
    return "members"


# Kept as the internal spelling used throughout this module.
_entity_of = entity_of


def _row_to_pattern(row: dict) -> dict:
    """Shape a stored row for the API, with provenance made explicit."""
    origin = str(row.get("origin") or DISCOVERED)
    certified = row.get("certified_at") is not None
    return {
        "pattern_id": int(row["id"]),
        "name": str(row.get("contextual_name") or f"Pattern {row['id']}"),
        "origin": origin,
        "certified": certified,
        "certified_at": row["certified_at"].isoformat() if certified else None,
        "certified_by": row.get("certified_by"),
        "certified_against_id": row.get("certified_against_id"),
        "editable": origin == USER_DEFINED,
        "member_count": int(row.get("member_count") or 0),
        "combo_key": row.get("combo_key"),
        "entity": _entity_of(row),
        "features": {f: _parse(row.get(f)) for f in FEATURES},
        "labels": {
            "group": row.get("grgr_name"),
            "plan_category": row.get("cspd_cat_desc"),
            "plan": row.get("plds_desc"),
        },
        "created_by": row.get("created_by"),
        "saved": bool(row.get("saved_at")),
    }


def _parse(value):
    """Read one stored feature back into a list of values, or None.

    A feature left unset is stored as the JSON literal `null`. Wrapping that in
    a list produced [None], which _norm_values then stringified to the literal
    ["None"] — a feature value that matches nothing, silently rewrites the
    pattern's combo_key on an unrelated rename, and collides with the next
    pattern edited the same way (a UNIQUE violation surfacing as a 500).
    """
    if value is None:
        return None
    if isinstance(value, (list, tuple)):
        return [v for v in value if v is not None] or None
    try:
        parsed = json.loads(value)
    except (TypeError, ValueError):
        return [str(value)]
    if parsed is None:
        return None
    if isinstance(parsed, list):
        return [v for v in parsed if v is not None] or None
    return [parsed]


# ── Reads ────────────────────────────────────────────────────────────────────

_CATALOG_NS = "patterns.catalog"

# Bump when _row_to_pattern changes what it produces. The table signature keyed
# below tracks the *data*, not this code, so without a version marker a cached
# catalog would survive an edit to the transformation and keep serving the old
# shape. entity_of already moved once during this work; that is exactly the case
# this guards.
# v2: get_all_patterns gained an id tiebreaker, so lists cached under v1 carry
# the old, unstable ordering.
_CATALOG_VERSION = 2


def _catalog() -> list[dict]:
    """Every pattern, shaped for the API, from the temp-file cache.

    db.get_all_patterns already caches the rows; this caches the *transformed*
    list on top, because rebuilding 609 shaped dicts costs more than reading
    them back. Both are keyed on the same table signature, so a write to
    sdm.patterns invalidates this in the same breath as the rows underneath.

    Measured on 609 patterns: 36.5 ms to query and transform, 3.2 ms to check
    the signature and unpickle.
    """
    from . import disk_cache

    try:
        key = disk_cache.make_key(_CATALOG_NS, _CATALOG_VERSION,
                                  db.patterns_signature())
        hit = disk_cache.get(key)
        if hit is not None:
            return hit
    except Exception:
        # A cache that cannot answer must never stop the read.
        return [_row_to_pattern(r) for r in (db.get_all_patterns() or [])]

    started = time.perf_counter()
    out = [_row_to_pattern(r) for r in (db.get_all_patterns() or [])]
    try:
        disk_cache.put(key, out, ttl=1800, label=_CATALOG_NS,
                       namespace=_CATALOG_NS,
                       cost_seconds=time.perf_counter() - started)
    except Exception:
        pass
    return out


def list_patterns(origin: Optional[str] = None) -> list[dict]:
    # One cached list serves every origin filter; filtering here costs
    # microseconds and avoids an entry per filter value.
    out = _catalog()
    if origin:
        return [p for p in out if p["origin"] == origin]
    return out


def get(pattern_id: int) -> Optional[dict]:
    row = db.get_pattern(pattern_id)
    return _row_to_pattern(row) if row else None


# ── Creating a user-defined pattern ──────────────────────────────────────────

def create_user_pattern(name: str, features: dict, entity: str = "members",
                        created_by: str = "user",
                        labels: Optional[dict] = None) -> dict:
    """Define a new pattern from a combination of feature values.

    Values are not checked against reference data. A new line of business has
    codes that exist nowhere yet, and rejecting them would make this feature
    useless for the case it was asked for. The pattern carries the user_defined
    flag instead, so anyone reading it knows the tool has not vouched for it.

    No distribution is stored. A pattern is a combination; how many records to
    produce, and in what mix, is decided at generation time.
    """
    clean_name = (name or "").strip()
    if not clean_name:
        raise ValueError("A pattern needs a name.")

    values = {f: _norm_values(features.get(f)) for f in FEATURES}
    if not any(values.values()):
        raise ValueError(
            "A pattern needs at least one feature value — otherwise it matches "
            "everything and describes nothing."
        )

    ck = combo_key(values, entity)

    existing = _find_by_combo(ck)
    mine = [p for p in existing if p["origin"] == USER_DEFINED]
    if mine:
        raise ValueError(
            f"“{mine[0]['name']}” already defines this exact combination. "
            f"Edit that one, or clone it if you want a variant."
        )

    cat = (values.get("cspd_cat") or []) + [
        "__CLAIMS__" if entity == "claims" else "__MEMBERS__"]

    labels = labels or {}
    conn = _conn()
    try:
        cur = conn.cursor()
        from datetime import datetime

        from sdg.analyzer.db import insert_row

        new_id = insert_row(cur, PATTERNS, {
            "pattern_key": f"{ck}|{USER_CLUSTER_ID}", "combo_key": ck,
            "contextual_name": clean_name,
            "grgr_ck": json.dumps(values.get("grgr_ck")), "cspd_cat": json.dumps(sorted(cat)),
            "cspi_id": json.dumps(values.get("cspi_id")),
            "pdpd_id": json.dumps(values.get("pdpd_id")),
            "grgr_name": labels.get("group", ""),
            "cspd_cat_desc": labels.get("plan_category", ""),
            "plds_desc": labels.get("plan", ""),
            "cluster_id": USER_CLUSTER_ID, "member_count": 0, "origin": USER_DEFINED,
            "created_by": created_by, "saved_by": created_by, "saved_at": datetime.now(),
        })
        conn.commit()
    finally:
        conn.close()

    return {"pattern_id": new_id, "name": clean_name, "origin": USER_DEFINED,
            "combo_key": ck, "matches": [m["pattern_id"] for m in existing]}


def clone_pattern(source_id: int, name: str, features: Optional[dict] = None,
                  created_by: str = "user") -> dict:
    """Clone any pattern, optionally changing feature values.

    The result is always user_defined, even when cloned from a discovered
    pattern and even when no value was changed. A copy is not the evidence —
    only the discovered record itself is — and letting a clone inherit the
    discovered flag would make the flag meaningless.
    """
    source = db.get_pattern(source_id)
    if not source:
        raise ValueError(f"Pattern {source_id} not found.")

    base = {f: _parse(source.get(f)) for f in FEATURES}
    entity = _entity_of(source)

    # The domain tag is bookkeeping, not a feature value — it must not survive
    # into the clone's stated values or it becomes an unusable filter.
    if base.get("cspd_cat"):
        base["cspd_cat"] = [v for v in base["cspd_cat"]
                            if v not in ("__MEMBERS__", "__CLAIMS__")] or None

    if features:
        for f in FEATURES:
            if f in features:
                base[f] = features[f]

    result = create_user_pattern(
        name=name or f"Copy of {source.get('contextual_name')}",
        features=base, entity=entity, created_by=created_by,
        labels={
            "group": source.get("grgr_name"),
            "plan_category": source.get("cspd_cat_desc"),
            "plan": source.get("plds_desc"),
        },
    )
    result["cloned_from"] = source_id
    return result


def update_user_pattern(pattern_id: int, name: Optional[str] = None,
                        features: Optional[dict] = None) -> dict:
    """Edit a user-defined pattern. Discovered patterns are refused."""
    row = db.get_pattern(pattern_id)
    if not row:
        raise ValueError(f"Pattern {pattern_id} not found.")
    if str(row.get("origin") or DISCOVERED) == DISCOVERED:
        raise ValueError(
            f"“{row.get('contextual_name')}” was discovered from real data and "
            f"cannot be edited. Clone it to create an editable variant."
        )

    entity = _entity_of(row)
    values = {f: _parse(row.get(f)) for f in FEATURES}
    if values.get("cspd_cat"):
        values["cspd_cat"] = [v for v in values["cspd_cat"]
                              if v not in ("__MEMBERS__", "__CLAIMS__")] or None
    if features:
        for f in FEATURES:
            if f in features:
                values[f] = features[f]
    values = {f: _norm_values(values.get(f)) for f in FEATURES}

    if not any(values.values()):
        raise ValueError("A pattern needs at least one feature value.")

    ck = combo_key(values, entity)
    cat = (values.get("cspd_cat") or []) + [
        "__CLAIMS__" if entity == "claims" else "__MEMBERS__"]
    new_name = (name or row.get("contextual_name") or "").strip()

    # Changing the combination invalidates any certification: it was awarded to
    # a different combination, and carrying it over would assert evidence that
    # was never gathered for what the pattern now says.
    combo_changed = ck != str(row.get("combo_key") or "")

    conn = _conn()
    try:
        cur = conn.cursor()
        if combo_changed:
            cur.execute(f"""
                UPDATE {PATTERNS} SET contextual_name = ?, combo_key = ?,
                    pattern_key = ?, grgr_ck = ?, cspd_cat = ?, cspi_id = ?,
                    pdpd_id = ?, certified_at = NULL, certified_by = NULL,
                    certified_against_id = NULL, updated_at = GETDATE()
                WHERE id = ?
            """, new_name, ck, f"{ck}|{USER_CLUSTER_ID}",
                json.dumps(values.get("grgr_ck")), json.dumps(sorted(cat)),
                json.dumps(values.get("cspi_id")), json.dumps(values.get("pdpd_id")),
                pattern_id)
        else:
            cur.execute(
                f"UPDATE {PATTERNS} SET contextual_name = ?, updated_at = GETDATE() "
                f"WHERE id = ?", new_name, pattern_id)
        conn.commit()
    finally:
        conn.close()

    return {"pattern_id": pattern_id, "name": new_name, "combo_key": ck,
            "certification_cleared": combo_changed and row.get("certified_at") is not None}


# ── Certification ────────────────────────────────────────────────────────────

def _find_by_combo(ck: str) -> list[dict]:
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {PATTERNS} WHERE combo_key = ?", ck)
        cols = [d[0] for d in cur.description]
        return [_row_to_pattern(dict(zip(cols, r))) for r in cur.fetchall()]
    finally:
        conn.close()


def review_queue() -> list[dict]:
    """User-defined patterns whose combination discovery has since found.

    Computed live rather than stored. A queue table would go stale the moment a
    discovery run changed what exists, and would need its own reconciliation;
    the comparison is a single indexed lookup per candidate.
    """
    everything = list_patterns()
    discovered = {}
    for p in everything:
        if p["origin"] == DISCOVERED and p["combo_key"]:
            discovered.setdefault(p["combo_key"], []).append(p)

    queue = []
    for p in everything:
        if p["origin"] != USER_DEFINED or p["certified"]:
            continue
        matches = discovered.get(p["combo_key"] or "", [])
        if not matches:
            continue
        best = max(matches, key=lambda m: m["member_count"])
        queue.append({
            "user_pattern": p,
            "matched_pattern": best,
            "other_matches": len(matches) - 1,
            "observed_members": best["member_count"],
        })

    queue.sort(key=lambda q: q["observed_members"], reverse=True)
    return queue


def certify(user_pattern_id: int, discovered_id: int,
            approved_by: str = "user") -> dict:
    """Merge a user-defined pattern with the discovered pattern that matches it.

    The user-defined record is kept and marked certified rather than replaced.
    Layouts, saved configurations and past generation runs reference it by id;
    replacing it would break every one of those references, and deleting the
    discovered pattern would destroy evidence.

    Never called automatically. A reviewer approves each merge, because data
    generated last month under a hypothesis must not retroactively appear to
    have been evidence-backed.
    """
    user = db.get_pattern(user_pattern_id)
    if not user:
        raise ValueError(f"Pattern {user_pattern_id} not found.")
    if str(user.get("origin") or DISCOVERED) != USER_DEFINED:
        raise ValueError("Only a user-defined pattern can be certified.")
    if user.get("certified_at") is not None:
        raise ValueError(f"“{user.get('contextual_name')}” is already certified.")

    found = db.get_pattern(discovered_id)
    if not found:
        raise ValueError(f"Pattern {discovered_id} not found.")
    if str(found.get("origin") or DISCOVERED) != DISCOVERED:
        raise ValueError("A pattern can only be certified against a discovered one.")

    if str(user.get("combo_key") or "") != str(found.get("combo_key") or ""):
        raise ValueError(
            "These two do not describe the same combination, so one cannot "
            "certify the other."
        )

    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(f"""
            UPDATE {PATTERNS}
            SET certified_at = ?, certified_by = ?, certified_against_id = ?,
                member_count = ?, profile_json = COALESCE(?, profile_json),
                updated_at = GETDATE()
            WHERE id = ?
        """, datetime.now(), approved_by, discovered_id,
            int(found.get("member_count") or 0), found.get("profile_json"),
            user_pattern_id)
        conn.commit()
    finally:
        conn.close()

    return {
        "pattern_id": user_pattern_id,
        "certified_against_id": discovered_id,
        "certified_by": approved_by,
        "observed_members": int(found.get("member_count") or 0),
        "name": user.get("contextual_name"),
    }

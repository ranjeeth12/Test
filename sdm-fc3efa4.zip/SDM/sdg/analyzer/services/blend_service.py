"""Generating one dataset from several patterns at chosen proportions.

The mix belongs to the run, not to the patterns. A pattern is a combination of
feature values; how much of a dataset should look like it is a decision made at
generation time, and storing it back onto a pattern would contradict that.

Provenance travels with the output. A file blended 70/30 from a certified
pattern and an unvalidated one is partly evidence and partly hypothesis, and
once it is a CSV on a share nothing about it says which. The manifest records
the mix, each pattern's origin and its certification state, so the claim the
data supports can be reconstructed later.
"""

from __future__ import annotations

import random
from datetime import datetime
from typing import Optional

import pandas as pd

from . import pattern_service as ps


def allocate(n_records: int, weights: list[float]) -> list[int]:
    """Split a row count across weights, largest remainder first.

    Three patterns at 33.3% of 1,000 rows leaves a row over. It goes to the
    largest weight rather than wherever floating point happens to land, so the
    same request always produces the same split.
    """
    total = sum(weights)
    if total <= 0:
        raise ValueError("Weights must add up to more than zero.")

    exact = [n_records * w / total for w in weights]
    counts = [int(x) for x in exact]

    remainder = n_records - sum(counts)
    if remainder:
        # Rank by fractional part, then by weight so ties are deterministic.
        order = sorted(
            range(len(weights)),
            key=lambda i: (exact[i] - counts[i], weights[i]),
            reverse=True,
        )
        for i in range(remainder):
            counts[order[i % len(order)]] += 1

    return counts


def validate_mix(mix: list[dict]) -> list[dict]:
    """Check a requested blend before any generation work is done."""
    if not mix:
        raise ValueError("Choose at least one pattern to generate from.")

    seen = set()
    cleaned = []
    for entry in mix:
        pid = int(entry.get("pattern_id") or 0)
        if not pid:
            raise ValueError("Every entry in the mix needs a pattern.")
        if pid in seen:
            raise ValueError(f"Pattern {pid} appears twice in the mix.")
        seen.add(pid)

        weight = float(entry.get("weight_pct") or 0)
        if weight <= 0:
            raise ValueError("Every pattern in the mix needs a share above zero.")
        cleaned.append({"pattern_id": pid, "weight_pct": weight})

    total = sum(e["weight_pct"] for e in cleaned)
    if abs(total - 100.0) > 0.01:
        raise ValueError(f"Shares must add up to 100% — they currently total {total:g}%.")

    return cleaned


def generate_blend(mix: list[dict], data_type: str, n_records: int,
                   seed: Optional[int] = None) -> dict:
    """Generate one dataset drawn from several patterns at chosen proportions."""
    from .story_service import generate_for_pattern

    cleaned = validate_mix(mix)
    seed = seed if seed is not None else random.randint(0, 2**31 - 1)

    counts = allocate(n_records, [e["weight_pct"] for e in cleaned])

    frames = []
    manifest = []
    for offset, (entry, count) in enumerate(zip(cleaned, counts)):
        pattern = ps.get(entry["pattern_id"])
        if not pattern:
            raise ValueError(f"Pattern {entry['pattern_id']} no longer exists.")

        if count == 0:
            # A share too small to earn a row is worth reporting rather than
            # dropping silently — the user asked for it.
            manifest.append({
                "pattern_id": pattern["pattern_id"], "name": pattern["name"],
                "origin": pattern["origin"], "certified": pattern["certified"],
                "requested_pct": entry["weight_pct"], "rows": 0,
                "note": "Share too small to produce a row at this record count.",
            })
            continue

        # Each pattern gets its own derived seed so the blend is reproducible
        # as a whole, while no two patterns draw an identical sequence.
        df, _, name = generate_for_pattern(
            pattern["pattern_id"], data_type, count, seed + offset,
        )
        frames.append(df)
        manifest.append({
            "pattern_id": pattern["pattern_id"], "name": name,
            "origin": pattern["origin"], "certified": pattern["certified"],
            "requested_pct": entry["weight_pct"],
            # What was asked of the generator, and what it actually returned.
            # For members these differ: n_records counts subscribers, and the
            # frame also carries their spouses and dependents. Recording the
            # requested count as "rows" made the provenance arithmetic below
            # wrong — a blend of two discovered patterns reported half its rows
            # as unattributed hypothesis while listing no unvalidated pattern.
            "subscribers": count,
            "rows": int(len(df)),
        })

    if not frames:
        raise ValueError("No pattern in the mix produced any rows.")

    blended = pd.concat(frames, ignore_index=True)

    # Shares are reported against the rows that exist, so the percentages on the
    # manifest add up to the file the user is holding.
    total_rows = int(len(blended))
    for m in manifest:
        m["actual_pct"] = (round(100.0 * m["rows"] / total_rows, 2)
                           if total_rows else 0.0)

    unvalidated = [m for m in manifest
                   if m["origin"] == ps.USER_DEFINED and not m["certified"]
                   and m["rows"]]
    evidence_rows = sum(m["rows"] for m in manifest
                        if m["origin"] == ps.DISCOVERED or m["certified"])

    return {
        "df": blended,
        "seed": seed,
        "manifest": {
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "data_type": data_type,
            "requested_records": n_records,
            "produced_records": len(blended),
            "seed": seed,
            "patterns": manifest,
            "evidence_backed_rows": evidence_rows,
            "hypothesis_rows": len(blended) - evidence_rows,
            "unvalidated_patterns": [m["name"] for m in unvalidated],
        },
    }

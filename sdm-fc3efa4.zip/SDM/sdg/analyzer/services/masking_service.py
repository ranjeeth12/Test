"""Masking: transform an existing file in place of its sensitive values.

Deliberately separate from generation. Generation invents records from a
pattern's statistics; masking rewrites records that already exist. Different
input, different output, different catalog — they meet only at the layout, which
supplies the file's structure so masking knows where each value sits.

Nothing here touches sdm.generation_rules or a layout's field_spec. A layout
field already carries a *generation* assignment; putting a masking assignment in
the same place would have the two features overwrite each other.

Three tables:

    masking_lookups     files masking draws from, its own registry
    masking_rules       the user's algorithm instances
    layout_masking      which instance applies to which field of which layout

Masking is opt-in per field. A field with no rule is copied through unchanged,
so a layout with no assignments produces a faithful copy rather than an error.

Determinism is keyed on the value alone, never on the field, so the same member
key masks identically in a member file and a claims file and the two still
join. The key is an HMAC salt held in masking_config: once files exist that were
masked with it, it has to stay stable, so it is generated once and kept.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
from datetime import date, datetime
from typing import Any, Optional

import pyodbc

from sdg.analyzer.config import SQL_SCHEMA, get_connection_string

LOOKUPS_TABLE = f"{SQL_SCHEMA}.masking_lookups"
RULES_TABLE = f"{SQL_SCHEMA}.masking_rules"
ASSIGN_TABLE = f"{SQL_SCHEMA}.layout_masking"
CONFIG_TABLE = f"{SQL_SCHEMA}.masking_config"

# The four algorithm frameworks. A user creates instances of these; the
# instance carries the configuration, the framework carries the behavior.
ALGORITHMS = ("hash_lookup", "character_map", "lookup_substitute", "date_shift")

# Where masking is allowed to read and write.
#
# The API runs as whoever started uvicorn and this feature takes a filesystem
# path, so without a boundary a typo or a hostile request reaches anywhere that
# account can. Set SDM_MASKING_ROOT to widen it deliberately.
MASKING_ROOT = os.environ.get("SDM_MASKING_ROOT") or ""


DDL = f"""
IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'{CONFIG_TABLE}') AND type = N'U')
CREATE TABLE {CONFIG_TABLE} (
    setting  NVARCHAR(60)  NOT NULL PRIMARY KEY,
    value    NVARCHAR(400) NOT NULL,
    set_at   DATETIME2     NOT NULL DEFAULT GETDATE()
);

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'{LOOKUPS_TABLE}') AND type = N'U')
CREATE TABLE {LOOKUPS_TABLE} (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    name        NVARCHAR(120) NOT NULL UNIQUE,
    -- 'pool'  : one column of candidate values, chosen from by hash
    -- 'map'   : two columns, value -> replacement, matched exactly
    kind        NVARCHAR(10)  NOT NULL,
    -- Either a registered sdm.lkp_* table or a file on this machine.
    source_kind NVARCHAR(10)  NOT NULL,      -- 'table' | 'file'
    source      NVARCHAR(400) NOT NULL,
    value_col   NVARCHAR(120) NULL,          -- pool: which column to draw from
    n_rows      INT           NULL,
    created_by  NVARCHAR(100) NULL,
    created_at  DATETIME2     NOT NULL DEFAULT GETDATE()
);

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'{RULES_TABLE}') AND type = N'U')
CREATE TABLE {RULES_TABLE} (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    name        NVARCHAR(120) NOT NULL UNIQUE,
    algorithm   NVARCHAR(30)  NOT NULL,
    -- The instance's own configuration, shaped by its algorithm.
    config      NVARCHAR(MAX) NOT NULL,
    description NVARCHAR(400) NULL,
    created_by  NVARCHAR(100) NULL,
    created_at  DATETIME2     NOT NULL DEFAULT GETDATE(),
    updated_at  DATETIME2     NULL
);

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'{ASSIGN_TABLE}') AND type = N'U')
CREATE TABLE {ASSIGN_TABLE} (
    id         INT IDENTITY(1,1) PRIMARY KEY,
    layout_id  INT           NOT NULL,
    field_name NVARCHAR(200) NOT NULL,
    rule_id    INT           NOT NULL,
    assigned_by NVARCHAR(100) NULL,
    assigned_at DATETIME2    NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_layout_masking UNIQUE (layout_id, field_name)
);
"""


def _conn():
    return pyodbc.connect(get_connection_string())


def ensure_tables() -> None:
    conn = _conn()
    try:
        conn.cursor().execute(DDL)
        conn.commit()
    finally:
        conn.close()


# ── The salt ─────────────────────────────────────────────────────────────────

def _salt() -> bytes:
    """The HMAC key every deterministic algorithm derives from.

    Generated once and kept. Deterministic masking without a secret is
    reversible — an SSN has only a billion possibilities and a plain hash of one
    is enumerable in minutes — so the key is what makes this masking rather than
    obfuscation.

    It is also durable state: change it and files masked afterwards stop joining
    to files masked before.
    """
    ensure_tables()
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT value FROM {CONFIG_TABLE} WHERE setting = 'salt'")
        row = cur.fetchone()
        if row:
            return bytes.fromhex(str(row[0]))

        fresh = secrets.token_bytes(32)
        cur.execute(
            f"INSERT INTO {CONFIG_TABLE} (setting, value) VALUES ('salt', ?)",
            fresh.hex())
        conn.commit()
        return fresh
    finally:
        conn.close()


def _digest(value: str) -> bytes:
    return hmac.new(_salt(), str(value).encode("utf-8"), hashlib.sha256).digest()


# ── Lookups ──────────────────────────────────────────────────────────────────

def _read_lookup(row: dict) -> Any:
    """Load a lookup's contents: a list for a pool, a dict for a map."""
    import csv as csvmod

    kind, source_kind, source = row["kind"], row["source_kind"], row["source"]

    if source_kind == "table":
        conn = _conn()
        try:
            cur = conn.cursor()
            cur.execute(f"SELECT * FROM {SQL_SCHEMA}.{source}")
            cols = [d[0].lower() for d in cur.description]
            rows = cur.fetchall()
        finally:
            conn.close()

        if kind == "pool":
            col = (row.get("value_col") or "").lower()
            idx = cols.index(col) if col in cols else (1 if len(cols) > 1 else 0)
            return [str(r[idx]).strip() for r in rows if r[idx] is not None]

        # A map from a table takes its first two non-id columns.
        usable = [i for i, c in enumerate(cols) if c not in ("id", "created_at")]
        a, b = usable[0], usable[1]
        return {str(r[a]).strip(): str(r[b]).strip() for r in rows}

    with open(source, "r", encoding="utf-8-sig", newline="") as fh:
        reader = csvmod.reader(fh)
        records = [r for r in reader if r and any(c.strip() for c in r)]

    if not records:
        raise ValueError(f"Lookup file “{source}” is empty.")

    # A header is assumed only when the first row cannot be data — for a map
    # that means a row whose second cell duplicates its first.
    if kind == "pool":
        return [r[0].strip() for r in records if r[0].strip()]

    out = {}
    for r in records:
        if len(r) < 2:
            continue
        out[r[0].strip()] = r[1].strip()
    if not out:
        raise ValueError(
            f"“{source}” has no two-column rows — a substitution map needs "
            f"a value and its replacement on each line.")
    return out


def register_lookup(name: str, kind: str, source_kind: str, source: str,
                    value_col: Optional[str] = None,
                    created_by: str = "user") -> dict:
    """Add a lookup file or table to masking's own registry.

    Masking keeps its registry apart from the generation lookups even when it
    points at the same table: the two features acquire and retire sources on
    their own schedules, and a substitution map has no meaning to generation.
    """
    name = (name or "").strip()
    if not name:
        raise ValueError("A lookup needs a name.")
    if kind not in ("pool", "map"):
        raise ValueError("kind must be 'pool' or 'map'.")
    if source_kind not in ("table", "file"):
        raise ValueError("source_kind must be 'table' or 'file'.")

    if source_kind == "file":
        source = resolve_path(source, must_exist=True)

    probe = {"kind": kind, "source_kind": source_kind, "source": source,
             "value_col": value_col}
    loaded = _read_lookup(probe)          # fails now rather than mid-run
    n_rows = len(loaded)

    ensure_tables()
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(f"""
            INSERT INTO {LOOKUPS_TABLE}
                (name, kind, source_kind, source, value_col, n_rows, created_by)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, name, kind, source_kind, source, value_col, n_rows, created_by)
        new_id = int(cur.fetchone()[0])
        conn.commit()
    finally:
        conn.close()
    return {"id": new_id, "name": name, "kind": kind, "n_rows": n_rows}


def list_lookups() -> list[dict]:
    ensure_tables()
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(f"""
            SELECT id, name, kind, source_kind, source, value_col, n_rows,
                   created_by, created_at
            FROM {LOOKUPS_TABLE} ORDER BY name
        """)
        cols = [d[0] for d in cur.description]
        out = []
        for r in cur.fetchall():
            d = dict(zip(cols, r))
            d["id"] = int(d["id"])
            d["created_at"] = d["created_at"].isoformat() if d["created_at"] else None
            out.append(d)
        return out
    finally:
        conn.close()


def delete_lookup(lookup_id: int) -> dict:
    """Remove a lookup, unless a rule still draws from it."""
    ensure_tables()
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT name FROM {LOOKUPS_TABLE} WHERE id = ?", lookup_id)
        row = cur.fetchone()
        if not row:
            raise ValueError(f"No lookup with id {lookup_id}.")

        cur.execute(f"SELECT name, config FROM {RULES_TABLE}")
        users = [str(r[0]) for r in cur.fetchall()
                 if (json.loads(r[1]) or {}).get("lookup_id") == lookup_id]
        if users:
            raise ValueError(
                f"“{row[0]}” is used by {len(users)} masking rule(s): "
                f"{', '.join(users[:3])}. Change or remove those first.")

        cur.execute(f"DELETE FROM {LOOKUPS_TABLE} WHERE id = ?", lookup_id)
        conn.commit()
        return {"id": lookup_id, "name": str(row[0]), "removed": True}
    finally:
        conn.close()


# ── Rules: instances of the four frameworks ──────────────────────────────────

_CLASSES = {
    "numeric": "0123456789",
    "alpha_upper": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "alpha_lower": "abcdefghijklmnopqrstuvwxyz",
    "alphanumeric": "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
}


def validate_config(algorithm: str, config: dict) -> dict:
    """Check an instance's configuration before it is stored.

    A rule that cannot run is worth refusing at definition time; discovering it
    part-way through a file leaves half a masked output on disk.
    """
    config = dict(config or {})

    if algorithm == "hash_lookup":
        if not config.get("lookup_id"):
            raise ValueError("A hash-lookup rule needs a lookup to draw from.")

    elif algorithm == "lookup_substitute":
        if not config.get("lookup_id"):
            raise ValueError("A substitution rule needs a lookup map.")

    elif algorithm == "character_map":
        segments = config.get("segments") or []
        if not segments:
            raise ValueError(
                "A character map needs at least one segment — a literal, or a "
                "run of characters of a given class.")
        for i, seg in enumerate(segments, start=1):
            kind = str(seg.get("kind") or "")
            if kind == "literal":
                if not str(seg.get("value") or ""):
                    raise ValueError(f"Segment {i} is a literal with no text.")
            elif kind in _CLASSES:
                if int(seg.get("length") or 0) < 1:
                    raise ValueError(f"Segment {i} needs a length of at least 1.")
            else:
                raise ValueError(
                    f"Segment {i} has an unknown kind “{kind}”. Use 'literal' "
                    f"or one of: {', '.join(sorted(_CLASSES))}.")

    elif algorithm == "date_shift":
        if int(config.get("amount") or 0) == 0:
            raise ValueError("A date shift needs a non-zero amount.")
        if str(config.get("unit") or "") not in ("days", "months", "years"):
            raise ValueError("A date shift's unit must be days, months or years.")

    else:
        raise ValueError(
            f"Unknown algorithm “{algorithm}”. "
            f"Use one of: {', '.join(ALGORITHMS)}.")

    return config


def create_rule(name: str, algorithm: str, config: dict,
                description: str = "", created_by: str = "user") -> dict:
    name = (name or "").strip()
    if not name:
        raise ValueError("A masking rule needs a name.")
    if algorithm not in ALGORITHMS:
        raise ValueError(f"Unknown algorithm “{algorithm}”.")
    config = validate_config(algorithm, config)

    ensure_tables()
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT id FROM {RULES_TABLE} WHERE name = ?", name)
        if cur.fetchone():
            raise ValueError(f"A masking rule called “{name}” already exists.")
        cur.execute(f"""
            INSERT INTO {RULES_TABLE} (name, algorithm, config, description, created_by)
            OUTPUT INSERTED.id VALUES (?, ?, ?, ?, ?)
        """, name, algorithm, json.dumps(config), description or None, created_by)
        new_id = int(cur.fetchone()[0])
        conn.commit()
    finally:
        conn.close()
    return {"id": new_id, "name": name, "algorithm": algorithm, "config": config}


def update_rule(rule_id: int, name: Optional[str] = None,
                config: Optional[dict] = None,
                description: Optional[str] = None) -> dict:
    ensure_tables()
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(
            f"SELECT name, algorithm, config, description FROM {RULES_TABLE} "
            f"WHERE id = ?", rule_id)
        row = cur.fetchone()
        if not row:
            raise ValueError(f"No masking rule with id {rule_id}.")

        new_name = (name or str(row[0])).strip()
        new_config = validate_config(
            str(row[1]), config if config is not None else json.loads(row[2]))
        new_desc = description if description is not None else row[3]

        cur.execute(f"""
            UPDATE {RULES_TABLE}
            SET name = ?, config = ?, description = ?, updated_at = GETDATE()
            WHERE id = ?
        """, new_name, json.dumps(new_config), new_desc, rule_id)
        conn.commit()
        return {"id": rule_id, "name": new_name, "algorithm": str(row[1]),
                "config": new_config}
    finally:
        conn.close()


def list_rules() -> list[dict]:
    ensure_tables()
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(f"""
            SELECT r.id, r.name, r.algorithm, r.config, r.description,
                   r.created_by, r.created_at,
                   (SELECT COUNT(*) FROM {ASSIGN_TABLE} a WHERE a.rule_id = r.id)
            FROM {RULES_TABLE} r ORDER BY r.name
        """)
        out = []
        for r in cur.fetchall():
            out.append({
                "id": int(r[0]), "name": r[1], "algorithm": r[2],
                "config": json.loads(r[3]) if r[3] else {},
                "description": r[4], "created_by": r[5],
                "created_at": r[6].isoformat() if r[6] else None,
                # How many layout fields use this instance — shown before a delete.
                "assigned_count": int(r[7]),
            })
        return out
    finally:
        conn.close()


def delete_rule(rule_id: int) -> dict:
    ensure_tables()
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT name FROM {RULES_TABLE} WHERE id = ?", rule_id)
        row = cur.fetchone()
        if not row:
            raise ValueError(f"No masking rule with id {rule_id}.")
        cur.execute(f"DELETE FROM {ASSIGN_TABLE} WHERE rule_id = ?", rule_id)
        dropped = cur.rowcount
        cur.execute(f"DELETE FROM {RULES_TABLE} WHERE id = ?", rule_id)
        conn.commit()
        return {"id": rule_id, "name": str(row[0]), "removed": True,
                "assignments_removed": int(dropped)}
    finally:
        conn.close()


# ── Assignments ──────────────────────────────────────────────────────────────

def get_assignments(layout_id: int) -> dict:
    """field_name -> rule_id for one layout."""
    ensure_tables()
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(
            f"SELECT field_name, rule_id FROM {ASSIGN_TABLE} WHERE layout_id = ?",
            layout_id)
        return {str(r[0]): int(r[1]) for r in cur.fetchall()}
    finally:
        conn.close()


def set_assignment(layout_id: int, field_name: str,
                   rule_id: Optional[int], assigned_by: str = "user") -> dict:
    """Assign a masking rule to a field, or clear it.

    rule_id=None removes the assignment, which returns the field to being copied
    through unchanged — masking is opt-in, so that is a real state and not an
    error.
    """
    ensure_tables()
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(
            f"DELETE FROM {ASSIGN_TABLE} WHERE layout_id = ? AND field_name = ?",
            layout_id, field_name)
        if rule_id is not None:
            cur.execute(f"SELECT id FROM {RULES_TABLE} WHERE id = ?", rule_id)
            if not cur.fetchone():
                raise ValueError(f"No masking rule with id {rule_id}.")
            cur.execute(f"""
                INSERT INTO {ASSIGN_TABLE} (layout_id, field_name, rule_id, assigned_by)
                VALUES (?, ?, ?, ?)
            """, layout_id, field_name, rule_id, assigned_by)
        conn.commit()
        return {"layout_id": layout_id, "field_name": field_name,
                "rule_id": rule_id}
    finally:
        conn.close()


# ── The algorithms ───────────────────────────────────────────────────────────

def _hash_lookup(value: str, config: dict, cache: dict) -> str:
    pool = cache["lookups"][config["lookup_id"]]
    if not pool:
        return value
    idx = int.from_bytes(_digest(value)[:8], "big") % len(pool)
    return pool[idx]


def _lookup_substitute(value: str, config: dict, cache: dict) -> str:
    mapping = cache["lookups"][config["lookup_id"]]
    # A miss leaves the value as it was. Masking is opt-in throughout, and a
    # substitution map is a statement about the values it lists.
    return mapping.get(str(value).strip(), value)


def _character_map(value: str, config: dict, cache: dict) -> str:
    """Build a string to the configured shape, derived from the input.

    Every character comes from the HMAC of the input, so the same input always
    produces the same output, and one long digest covers every segment rather
    than each segment re-hashing the same value into the same bytes.
    """
    digest = _digest(value)
    out, cursor = [], 0
    for seg in config.get("segments") or []:
        kind = str(seg.get("kind"))
        if kind == "literal":
            out.append(str(seg.get("value") or ""))
            continue
        alphabet = _CLASSES[kind]
        for _ in range(int(seg.get("length") or 0)):
            if cursor >= len(digest):
                # A long template can exhaust one digest; extend it rather than
                # wrapping, which would repeat the same characters.
                digest += hashlib.sha256(digest).digest()
            out.append(alphabet[digest[cursor] % len(alphabet)])
            cursor += 1
    return "".join(out)


_DATE_FORMATS = (
    "%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y", "%d/%m/%Y", "%Y%m%d",
    "%m-%d-%Y", "%d-%m-%Y", "%Y-%m-%d %H:%M:%S", "%m/%d/%Y %H:%M:%S",
)


def _shift(d: date, amount: int, unit: str) -> date:
    if unit == "days":
        from datetime import timedelta
        return d + timedelta(days=amount)
    if unit == "months":
        total = (d.year * 12 + d.month - 1) + amount
        year, month = divmod(total, 12)
        month += 1
        # Clamp rather than roll over: 31 January shifted a month is the end of
        # February, not the 3rd of March.
        import calendar
        return date(year, month, min(d.day, calendar.monthrange(year, month)[1]))
    year = d.year + amount
    import calendar
    return date(year, d.month, min(d.day, calendar.monthrange(year, d.month)[1]))


def _date_shift(value: str, config: dict, cache: dict) -> str:
    """Move a date by a fixed offset, re-emitted in the format it arrived in.

    Fixed rather than derived per value, so intervals survive: ages, gaps
    between claims and event order all read the same after masking, which is
    usually the reason to shift a date rather than replace it.
    """
    text = str(value).strip()
    if not text:
        return value

    fmt_hint = config.get("date_format")
    formats = ([fmt_hint] if fmt_hint else []) + list(_DATE_FORMATS)
    for fmt in formats:
        try:
            parsed = datetime.strptime(text, fmt)
        except (ValueError, TypeError):
            continue
        moved = _shift(parsed.date(), int(config["amount"]), str(config["unit"]))
        if "%H" in fmt:
            moved_dt = datetime.combine(moved, parsed.time())
            return moved_dt.strftime(fmt)
        return moved.strftime(fmt)

    # Unparseable: leave it. A date column with a stray value should not have
    # that value replaced by something that looks like a date.
    return value


_APPLY = {
    "hash_lookup": _hash_lookup,
    "character_map": _character_map,
    "lookup_substitute": _lookup_substitute,
    "date_shift": _date_shift,
}


def mask_value(value: str, rule: dict, cache: dict) -> str:
    fn = _APPLY.get(str(rule["algorithm"]))
    if fn is None:
        return value
    return fn(value, rule["config"], cache)


# ── Running a job ────────────────────────────────────────────────────────────

def resolve_path(path: str, must_exist: bool = False) -> str:
    """Turn a caller-supplied path into one we are willing to touch.

    The API has no auth and runs with the rights of whoever started it, so a
    path from a request is not trusted. Resolved absolutely — which collapses
    any '..' — and, when a root is configured, required to sit inside it.
    """
    text = (path or "").strip().strip('"')
    if not text:
        raise ValueError("A file path is required.")

    full = os.path.abspath(os.path.expanduser(text))

    if MASKING_ROOT:
        root = os.path.abspath(MASKING_ROOT)
        if os.path.commonpath([root, full]) != root:
            raise ValueError(
                f"“{full}” is outside the permitted masking directory ({root}).")

    if must_exist and not os.path.isfile(full):
        raise ValueError(f"No file at “{full}”.")
    return full


def masked_path(source: str) -> str:
    """Where the masked copy goes: alongside the original, tagged _masked."""
    stem, ext = os.path.splitext(source)
    return f"{stem}_masked{ext}"


def _load_cache(rules: dict) -> dict:
    """Read every lookup a run needs, once."""
    by_id = {l["id"]: l for l in list_lookups()}
    loaded = {}
    for rule in rules.values():
        lid = (rule.get("config") or {}).get("lookup_id")
        if lid and lid not in loaded:
            if lid not in by_id:
                raise ValueError(
                    f"Masking rule “{rule['name']}” points at lookup {lid}, "
                    f"which no longer exists.")
            loaded[lid] = _read_lookup(by_id[lid])
    return {"lookups": loaded}


def run(layout_id: int, source_path: str, preview: bool = False,
        preview_rows: int = 20) -> dict:
    """Mask one file through a layout's assignments.

    Fields with no assignment are written back exactly as they arrived, so an
    unmasked column is untouched rather than reconstructed.
    """
    import csv as csvmod

    from . import layout_service as ls

    layout = ls.get_layout(layout_id)
    if not layout:
        raise ValueError(f"No layout with id {layout_id}.")

    # A generation layout's fields carry generation rules, which say nothing
    # about masking — running one here would produce a faithful copy and look
    # like it had worked.
    if layout.get("purpose") != "masking":
        raise ValueError(
            f"“{layout.get('name')}” is a generation layout. Masking needs a "
            f"layout whose purpose is masking.")

    if layout.get("status") != "approved":
        raise ValueError(
            f"“{layout.get('name')}” is {layout.get('status')}. Only an "
            f"approved masking layout can be used to mask a file.")

    source = resolve_path(source_path, must_exist=True)
    target = masked_path(source)

    assignments = get_assignments(layout_id)
    rules = {r["id"]: r for r in list_rules()}
    active = {f: rules[r] for f, r in assignments.items() if r in rules}
    cache = _load_cache(active)

    fields = layout.get("fields") or []
    kind = layout.get("kind")
    delimiter = layout.get("delimiter") or ","

    def mask_row(values: list[str]) -> list[str]:
        out = list(values)
        for i, field in enumerate(fields):
            if i >= len(out):
                break
            rule = active.get(field["name"])
            if rule is None:
                continue          # opt-in: no rule means leave it alone
            out[i] = mask_value(out[i], rule, cache)
        return out

    rows_in = rows_masked = 0
    sample: list[dict] = []

    with open(source, "r", encoding="utf-8-sig", newline="") as fh:
        if kind == "csv":
            reader = list(csvmod.reader(fh, delimiter=delimiter))
        else:
            reader = [[line.rstrip("\n\r")] for line in fh]

    out_lines: list[str] = []
    out_rows: list[list] = []
    header_taken = False

    for raw in reader:
        if kind == "csv":
            values = list(raw)
            # The first row is the header when it names the layout's fields.
            if not header_taken:
                header_taken = True
                if [v.strip().upper() for v in values[:len(fields)]] == \
                   [str(f["name"]).strip().upper() for f in fields]:
                    out_rows.append(values)
                    continue
            masked = mask_row(values)
        else:
            line = raw[0]
            values, spans = [], []
            for f in fields:
                start = int(f.get("start") or 0)
                length = int(f.get("length") or 0)
                values.append(line[start:start + length])
                spans.append((start, length))
            masked_vals = mask_row(values)
            rebuilt = list(line.ljust(sum(l for _, l in spans)))
            for (start, length), val in zip(spans, masked_vals):
                # Fixed width has to stay fixed: pad or clip to the field's own
                # width, or every column after this one shifts.
                cell = str(val)[:length].ljust(length)
                rebuilt[start:start + length] = list(cell)
            masked = ["".join(rebuilt)]

        rows_in += 1
        if kind == "csv":
            if masked != values:
                rows_masked += 1
            out_rows.append([str(v) for v in masked])
        else:
            if masked[0] != raw[0]:
                rows_masked += 1
            out_lines.append(masked[0])

        if len(sample) < preview_rows:
            sample.append({
                "before": values if kind == "csv" else [raw[0]],
                "after": masked,
            })

    if not preview:
        with open(target, "w", encoding="utf-8", newline="") as fh:
            if kind == "csv":
                # csv.writer, not a join on the delimiter. Joining loses the
                # quoting a value needed in order to survive it: a group name
                # containing a comma came back as two columns, silently widening
                # that row and shifting every field after it.
                w = csvmod.writer(fh, delimiter=delimiter, lineterminator="\n")
                w.writerows(out_rows)
            else:
                fh.write("\n".join(out_lines))
                if out_lines:
                    fh.write("\n")

    return {
        "layout_id": layout_id, "layout_name": layout.get("name"),
        "source": source,
        "output": None if preview else target,
        "preview": preview,
        "rows_read": rows_in,
        "rows_changed": rows_masked,
        "fields_masked": sorted(active.keys()),
        "fields_untouched": [str(f["name"]) for f in fields
                             if f["name"] not in active],
        "sample": sample,
    }

"""Pre-compute the Discover screen's landing result.

    python -m api.warm_discovery              # warm anything not already cached
    python -m api.warm_discovery --force      # re-walk regardless
    python -m api.warm_discovery --members    # one domain only

A cold walk is minutes of work — measured at 174s for members and 158s for
claims against SDM_Platform — and the Discover screen is the landing view. The
result is cached, so only the first person to open it after a restart or a data
reload pays that; this moves the cost off them and onto whoever is setting up.

Run it after loading data, or before a demo, and the first open is instant.

The parameters below are the ones web/src/lib/api.ts sends (top_n=50,
max_depth=2, no group limit). They have to match exactly: the cache is keyed on
them, so warming a different scope warms an entry the screen will never read.
"""

from __future__ import annotations

import sys
import time

# The Discover screen's request, verbatim. useDiscovery() sends entity,
# max_depth and top_n and no limit_groups, so the server default (None) applies.
LANDING_SCOPE = {"top_n": 50, "max_depth": 2, "limit_groups": None}

_RESULT_NAMESPACE = {"members": "discovery.top", "claims": "discovery.claims"}


def is_cached(entity: str) -> bool:
    """Whether the landing result is already on disk, without computing one."""
    from api import disk_cache

    key = disk_cache.make_key(_RESULT_NAMESPACE[entity], (),
                              sorted(LANDING_SCOPE.items()))
    try:
        return disk_cache.get(key) is not None
    except Exception:
        return False


def warm(entity: str, force: bool = False) -> dict:
    """Walk one domain at the landing scope. Returns a summary dict."""
    from api import discovery_service as ds

    if not force and is_cached(entity):
        return {"entity": entity, "skipped": True, "ms": 0, "patterns": 0}

    fn = ds.discover_claims if entity == "claims" else ds.discover
    t0 = time.perf_counter()
    result = fn(refresh=force, **LANDING_SCOPE)
    ms = (time.perf_counter() - t0) * 1000

    return {"entity": entity, "skipped": False, "ms": ms,
            "patterns": result.get("n_discovered", 0),
            "timing": result.get("timing") or {}}


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    force = "--force" in argv
    wanted = [e for e in ("members", "claims") if f"--{e}" in argv] or \
        ["members", "claims"]

    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError, ValueError):
        pass

    print(f"\nWarming Discover — top_n={LANDING_SCOPE['top_n']}, "
          f"max_depth={LANDING_SCOPE['max_depth']}, all groups\n" + "-" * 68)

    failures = 0
    for entity in wanted:
        try:
            out = warm(entity, force)
        except Exception as e:
            failures += 1
            print(f"  {entity:<8} FAILED  {type(e).__name__}: {e}", flush=True)
            continue

        if out["skipped"]:
            print(f"  {entity:<8} already cached — nothing to do "
                  f"(--force to re-walk)", flush=True)
            continue

        t = out["timing"]
        parts = ""
        if t:
            # Against total work, not wall clock: the member walk spreads its
            # combinations over a thread pool, so the phases sum to more than
            # the elapsed time and dividing by it printed shares like 312%.
            work = t.get("work_ms") or sum(
                t.get(k, 0) or 0
                for k in ("enumerate_ms", "load_ms", "cluster_ms", "persist_ms"))
            basis = max(work, out["ms"]) or 1
            parts = (" | " + " · ".join(
                f"{label} {t.get(key, 0) / 1000:.1f}s"
                f" {100 * (t.get(key, 0) or 0) / basis:.0f}%"
                for label, key in (("enumerate", "enumerate_ms"),
                                   ("load", "load_ms"),
                                   ("cluster", "cluster_ms"),
                                   ("persist", "persist_ms"))))
            if (t.get("workers") or 1) > 1 and out["ms"]:
                parts += f" · {t['workers']} workers, {work / out['ms']:.1f}x work"
        print(f"  {entity:<8} {out['ms'] / 1000:6.1f}s  "
              f"{out['patterns']} patterns{parts}", flush=True)

    print("-" * 68)
    print("Discover will open instantly for this scope until the cache expires "
          "or is cleared.\n")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())

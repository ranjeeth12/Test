"""Story → Data.

Two steps with a human gate between them:

    1. Match   — stories in, candidate patterns out, with a confidence score.
    2. Approve — the user picks what's right, then generation runs.

Nothing is written before approval. There is no LLM anywhere in this path:
matching is the deterministic keyword/tag scorer in keyword_search.py, and
generation is the same synthetic_* engines used everywhere else.
"""

import io
import json
from typing import Any, Optional

import pandas as pd

from sdg.analyzer import db
from sdg.analyzer.config import DEFAULT_REFERENCE_DATE
from sdg.analyzer.data_loader import load_filtered_members
from sdg.analyzer.keyword_search import allocate_volume, search

from .pattern_service import USER_CLUSTER_ID
from .service import to_py

# Column names seen in qTest / ADO exports, used to pick the text column
# when a spreadsheet is uploaded.
TEXT_COL_HINTS = [
    "scenario", "description", "summary", "test case", "testcase",
    "test_case", "steps", "story", "user story", "requirement",
    "expected", "title", "name",
]


# ── Step 0: turn an upload into a list of stories ────────────────────────────

def split_text(text: str) -> list[str]:
    """Blank line separates stories; failing that, one story per line."""
    text = (text or "").strip()
    if not text:
        return []
    blocks = [b.strip() for b in text.split("\n\n") if b.strip()]
    if len(blocks) > 1:
        return blocks
    lines = [ln.strip() for ln in text.split("\n") if ln.strip()]
    return lines if len(lines) > 1 else [text]


def _auto_text_col(df: pd.DataFrame) -> Optional[str]:
    lowered = {str(c).strip().lower(): c for c in df.columns}
    for hint in TEXT_COL_HINTS:
        for low, original in lowered.items():
            if hint in low:
                return original
    # Fall back to the widest string column.
    best, best_len = None, -1
    for c in df.columns:
        if df[c].dtype == object:
            avg = df[c].astype(str).str.len().mean()
            if avg > best_len:
                best, best_len = c, avg
    return best


def _from_json(raw: bytes) -> list[str]:
    obj = json.loads(raw.decode("utf-8"))
    if isinstance(obj, list):
        out = []
        for item in obj:
            if isinstance(item, str):
                out.append(item)
            elif isinstance(item, dict):
                vals = [str(v) for v in item.values() if isinstance(v, str)]
                out.append(" — ".join(vals) if vals else json.dumps(item))
        return [s for s in out if s.strip()]
    if isinstance(obj, dict):
        return [str(v) for v in obj.values() if isinstance(v, str)]
    return []


def _from_docx(raw: bytes) -> list[str]:
    try:
        import docx  # python-docx
    except ImportError as e:
        raise ValueError(
            "Reading .docx needs python-docx. Install it with: pip install python-docx"
        ) from e
    document = docx.Document(io.BytesIO(raw))
    return [p.text.strip() for p in document.paragraphs if p.text.strip()]


def parse_upload(filename: str, raw: bytes) -> tuple[list[str], Optional[str]]:
    """Return (stories, column_used). Raises ValueError with a fixable message."""
    name = (filename or "").lower()

    if name.endswith(".json"):
        try:
            return _from_json(raw), None
        except json.JSONDecodeError as e:
            raise ValueError(f"That file isn't valid JSON: {e}")

    if name.endswith(".docx"):
        return _from_docx(raw), None

    if name.endswith((".xlsx", ".xls", ".csv", ".tsv")):
        try:
            if name.endswith((".xlsx", ".xls")):
                df = pd.read_excel(io.BytesIO(raw))
            else:
                sep = "\t" if name.endswith(".tsv") else ","
                df = pd.read_csv(io.BytesIO(raw), sep=sep)
        except ImportError as e:
            raise ValueError(
                "Reading .xlsx needs openpyxl. Install it with: pip install openpyxl"
            ) from e
        except Exception as e:
            raise ValueError(f"Could not read that file: {e}")

        col = _auto_text_col(df)
        if col is None:
            raise ValueError("No text column found in that file.")
        stories = [s.strip() for s in df[col].astype(str).tolist() if s and s.strip()]
        return stories, str(col)

    # .txt, .md, anything else — treat as plain text
    try:
        return split_text(raw.decode("utf-8", errors="replace")), None
    except Exception as e:
        raise ValueError(f"Could not read that file as text: {e}")


# ── Step 1: match ────────────────────────────────────────────────────────────

def _pattern_summary(p: dict) -> dict:
    return {
        "pattern_id": int(p["id"]),
        "name": str(p.get("contextual_name") or f"Pattern {p['id']}"),
        "member_count": int(p.get("member_count") or 0),
        "match_score": float(p.get("match_score") or 0.0),
        "match_count": int(p.get("match_count") or 0),
        "group": p.get("grgr_name"),
        "plan_category": p.get("cspd_cat_desc"),
        "plan": p.get("plds_desc"),
        "product": p.get("pdds_desc"),
    }


def match_stories(stories: list[str], top_n: int = 4) -> dict:
    """Score every saved pattern against each story."""
    if not db.get_all_patterns():
        return {
            "stories": [],
            "warning": "No saved patterns yet. Save patterns from the profiler "
                       "before matching stories against them.",
        }

    results = []
    for idx, story in enumerate(stories):
        text = (story or "").strip()
        if not text:
            continue
        found = search(text)
        parsed = found.get("parsed", {})
        candidates = [_pattern_summary(p) for p in found.get("patterns", [])[:top_n]]
        best = candidates[0]["match_score"] if candidates else 0.0

        results.append({
            "index": idx,
            "story": text,
            "data_type": str(parsed.get("data_type") or "members"),
            "volume": parsed.get("volume"),
            "keywords": to_py(parsed.get("keywords") or []),
            "raw_terms": to_py(parsed.get("raw_terms") or []),
            "confidence": round(best, 3),
            # Nothing scored above zero means the matcher fell back to a broad
            # mix — say so rather than presenting noise as a match.
            "matched": best > 0.0,
            "candidates": candidates,
        })

    return {"stories": results, "warning": None}


def suggest_allocation(pattern_ids: list[int], total_volume: int) -> dict[int, int]:
    """Split a requested volume across patterns by member count."""
    patterns = {p["id"]: p for p in db.get_all_patterns()}
    total = sum(int(patterns.get(pid, {}).get("member_count") or 0) for pid in pattern_ids)
    if total <= 0:
        even = max(1, total_volume // max(1, len(pattern_ids)))
        return {pid: even for pid in pattern_ids}
    weights = {
        pid: (int(patterns.get(pid, {}).get("member_count") or 0) / total)
        for pid in pattern_ids
    }
    return {int(k): int(v) for k, v in allocate_volume(weights, total_volume).items()}


# ── Step 2: generate, after approval ─────────────────────────────────────────

# Sentinels canonical_combo folds into cspd_cat to keep the member and claims
# domains from colliding on the pattern key. They are bookkeeping, not real
# plan categories — passing one back as a filter matches no rows at all.
_DOMAIN_SENTINELS = {"__MEMBERS__", "__CLAIMS__"}

# Filters whose values reach SQL through int(), so a blank or non-numeric entry
# raises ValueError rather than simply matching nothing.
_NUMERIC_FILTERS = {"grgr_ck"}


def _clean_filter_values(key: str, values) -> list:
    """Drop values that cannot be used as a filter.

    A stored combo can carry a domain sentinel, an empty string, or a blank left
    by an older save. The loaders build `IN (...)` lists with int(), so a blank
    grgr_ck surfaced as `invalid literal for int() with base 10: ''` instead of
    anything a user could act on.
    """
    if not isinstance(values, (list, tuple, set)):
        values = [values]

    out = []
    for v in values:
        if v is None:
            continue
        text = str(v).strip()
        if not text or text in _DOMAIN_SENTINELS:
            continue
        if key in _NUMERIC_FILTERS:
            try:
                out.append(int(float(text)))
            except (TypeError, ValueError):
                continue
        else:
            out.append(text)
    return out


def _filters_from_pattern(pattern: dict) -> dict:
    raw = {
        "grgr_ck": pattern.get("grgr_ck"),
        "cspd_cat": pattern.get("cspd_cat"),
        "cspi_id": pattern.get("cspi_id"),
        "pdpd_id": pattern.get("pdpd_id"),
    }
    out = {}
    for k, v in raw.items():
        if not v:
            continue
        try:
            parsed = json.loads(v) if isinstance(v, str) else v
        except (json.JSONDecodeError, TypeError):
            continue
        cleaned = _clean_filter_values(k, parsed)
        if cleaned:
            out[k] = cleaned
    return out


def _profile_from_combination(filters: dict, name: str):
    """Build a profile for a pattern that stores a combination but no profile.

    A user-defined pattern is a combination of feature values by design —
    create_user_pattern deliberately stores no distribution, because how many
    records to produce and in what mix is decided at generation time. Generation
    still needs a distribution, so it is measured here from the real members the
    combination selects, rather than refusing outright.

    That refusal is what made every user-defined pattern ungeneratable: they
    were offered by the claims mapping dropdown, by Story → Data and by the
    blend mix, and each one failed with "re-save it from the profiler" — an
    instruction that cannot be followed, since these patterns never came from
    the profiler.

    Returns (profile, source_rows, family_rows).
    """
    import numpy as np

    from sdg.analyzer.profiler import profile_cluster

    try:
        members, _labels, family, _used = load_filtered_members(
            **filters, reference_date=DEFAULT_REFERENCE_DATE)
    except ValueError:
        # The loader raises its own "no members match" with the raw filter dict.
        # Name the pattern instead: the user picked a pattern, not a filter set.
        members = family = None

    if members is None or len(members) == 0:
        raise ValueError(
            f"“{name}” matches no members in the source data, so there is "
            f"nothing to measure a distribution from. Its combination is "
            f"{filters or 'empty'} — widen its feature values."
        )

    # No sub-clustering: a user-defined pattern describes its whole subset.
    mask = np.ones(len(members), dtype=bool)
    profile = profile_cluster(members, family, mask, USER_CLUSTER_ID, len(members))
    return profile, members, family


def generate_for_pattern(*_args, **_kwargs):
    """Gone: the analyzer's generator was removed.

    Generation runs through the plan engine now, and what it produced is
    written by /api/export in whichever shape is wanted. Two generators
    meant two definitions of a valid row, which is one more than a tool
    like this can hold.
    """
    raise NotImplementedError(
        "Generation moved to the plan engine. Build a plan, then use /api/export."
    )


def safe_filename(name: str) -> str:
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in name)[:80]


def coerce_rows(df: pd.DataFrame, limit: int) -> tuple[list[str], list[dict[str, Any]]]:
    if df is None or df.empty:
        return [], []
    head = df.head(limit)
    cols = [str(c) for c in head.columns]
    rows = [{str(k): to_py(v) for k, v in rec.items()}
            for rec in head.to_dict(orient="records")]
    return cols, rows

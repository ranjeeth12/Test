"""Reading a requirement into the rules of a pattern.

A tester writes "500 professional claims for female members aged 40 to 60
with type 2 diabetes on a PPO plan". Matching that against kept patterns finds
one only if somebody already kept it. Reading it instead gives the rules of a
pattern -- claim type, gender, age, diagnosis, plan -- which is then analyzed
like any user defined pattern: measured against the book, and looked inside.

The reading is local and plain. A feature's values are matched by their own
names in the catalog -- plan names, group names, diagnosis descriptions --
and by the words people use for the rest: female, married, Texas, aged 40 to
60, over $1,000, in network. What was read is said, with the words it came
from, so a wrong reading is seen and corrected rather than trusted.
"""

from __future__ import annotations

import re
from typing import Any

from . import defined_patterns

STOP = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "has", "have",
    "in", "is", "of", "on", "or", "the", "to", "who", "with", "without", "whose",
    "level", "product", "plan", "plans", "member", "members", "claim", "claims",
    "patient", "patients", "people", "data", "test", "generate", "need", "needs",
    "type", "all", "any", "some", "each", "per", "their", "they", "them",
}

GENDER = [(r"\b(female|females|women|woman|girls?)\b", "F"),
          (r"\b(male|males|men|man|boys?)\b", "M")]
MARITAL = [(r"\bmarried\b", "M"), (r"\bsingle\b", "S"), (r"\bdivorced\b", "D"),
           (r"\bwidow(ed|s|ers?)?\b", "W")]
CLAIM_TYPES = [(r"\bprofessional\b", "P"), (r"\b(institutional|inpatient|hospital)\b", "I"),
               (r"\bdental\b", "D")]
NETWORK = [(r"\bout[- ]of[- ]network\b", "O"), (r"\bin[- ]network\b", "I")]
AGE_WORDS = [(r"\b(children|child|pediatric|paediatric|kids|minors?)\b", (0, 17)),
             (r"\b(seniors?|elderly|retirees?|medicare[- ]age)\b", (65, None)),
             (r"\badults?\b", (18, 64))]

STATES = {
    "alabama": "AL", "alaska": "AK", "arizona": "AZ", "arkansas": "AR", "california": "CA",
    "colorado": "CO", "connecticut": "CT", "delaware": "DE", "florida": "FL", "georgia": "GA",
    "hawaii": "HI", "idaho": "ID", "illinois": "IL", "indiana": "IN", "iowa": "IA",
    "kansas": "KS", "kentucky": "KY", "louisiana": "LA", "maine": "ME", "maryland": "MD",
    "massachusetts": "MA", "michigan": "MI", "minnesota": "MN", "mississippi": "MS",
    "missouri": "MO", "montana": "MT", "nebraska": "NE", "nevada": "NV",
    "new hampshire": "NH", "new jersey": "NJ", "new mexico": "NM", "new york": "NY",
    "north carolina": "NC", "north dakota": "ND", "ohio": "OH", "oklahoma": "OK",
    "oregon": "OR", "pennsylvania": "PA", "rhode island": "RI", "south carolina": "SC",
    "south dakota": "SD", "tennessee": "TN", "texas": "TX", "utah": "UT", "vermont": "VT",
    "virginia": "VA", "washington": "WA", "west virginia": "WV", "wisconsin": "WI",
    "wyoming": "WY", "district of columbia": "DC",
}

NUMBER = r"(\d[\d,]*(?:\.\d+)?)"

# Words read as ages, genders and the like, and so never as part of a name: a
# group called Senior Services is not what "seniors" asks for.
SPOKEN_FOR = {
    "children", "child", "pediatric", "paediatric", "kids", "minor", "minors",
    "senior", "seniors", "elderly", "retiree", "retirees", "adult", "adults",
    "female", "females", "women", "woman", "girl", "girls", "male", "males", "men",
    "man", "boy", "boys", "married", "single", "divorced", "widowed",
    "professional", "institutional", "inpatient", "network",
}


def _number(text: str) -> float:
    return float(text.replace(",", ""))


def _tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9]+", text.lower()) if len(t) >= 3 and t not in STOP]


def _same(a: str, b: str) -> bool:
    """One word for the other: diabetes and diabetic, hypertension and hypertensive."""
    if a == b:
        return True
    return len(a) >= 6 and len(b) >= 6 and a[:6] == b[:6]


def _mentions(words: list[str], token: str) -> str | None:
    return next((w for w in words if _same(w, token)), None)


def entity_of(text: str) -> str:
    """Claims when the story is about claims, otherwise members."""
    if re.search(r"\b(claims?|837|diagnos\w*|procedures?|charges?|encounters?)\b", text, re.I):
        return "claims"
    return "members"


def _named(feature: dict[str, Any], words: list[str]) -> tuple[list[str], list[str]]:
    """The options a story names by the words of their names.

    A word counts only if it is one of these names' words and tells them apart
    -- held by some options, not all of them. An option is named when every
    such word the story uses for this feature is in its name.
    """
    options = [o for o in feature.get("options") or [] if o.get("label")]
    if not options:
        return [], []
    names = {o["value"]: _tokens(o["label"]) for o in options}
    share = {}
    for tokens in names.values():
        for token in set(tokens):
            share[token] = share.get(token, 0) + 1
    telling = {t for t, n in share.items() if n < len(options)}
    used = sorted({w for w in words for t in telling if _same(w, t)})
    if not used:
        return [], []
    chosen = [value for value, tokens in names.items()
              if all(any(_same(w, t) for t in tokens) for w in used)]
    return chosen, used


def read(text: str, entity: str | None = None) -> dict[str, Any]:
    """The rules a requirement states, with the words each was read from."""
    entity = entity or entity_of(text)
    lowered = text.lower()
    words = [w for w in _tokens(text) if w not in SPOKEN_FOR]
    features = {f["key"]: f for f in defined_patterns.catalog(entity)}
    rules: dict[str, dict[str, Any]] = {}
    found: list[dict[str, Any]] = []

    def state(key: str, rule: dict[str, Any], said: str) -> None:
        if key not in features:
            return
        rules[key] = rule
        found.append({"feature": key, "label": features[key]["label"],
                      "rule": rule, "from": said})

    # Names: groups, plans, products, diagnoses, procedures.
    for key in ("grgr_ck", "cspi_id", "pdpd_id", "diagnosis", "procedure"):
        if key == "pdpd_id" and "cspi_id" in rules:
            continue  # a plan already names its product
        if key in features:
            chosen, used = _named(features[key], words)
            if chosen:
                state(key, {"in": chosen}, " ".join(used))

    # Codes written as codes: a diagnosis, a procedure, a plan.
    for key in ("diagnosis", "procedure", "cspi_id"):
        options = {o["value"].upper() for o in (features.get(key) or {}).get("options") or []}
        codes = sorted({c for c in re.findall(r"\b[A-Z0-9]{4,10}\b", text.upper()) if c in options})
        if codes and key not in rules:
            state(key, {"in": codes}, ", ".join(codes))

    # Words for the rest.
    for key, table in (("gender", GENDER), ("marital_status", MARITAL),
                       ("claim_type", CLAIM_TYPES if entity == "claims" else []),
                       ("network", NETWORK)):
        values, said = [], []
        for pattern, value in table:
            hit = re.search(pattern, lowered)
            if hit and value not in values:
                values.append(value)
                said.append(hit.group(0))
        if values:
            state(key, {"in": values}, ", ".join(said))
    if entity == "members" and "state" in features:
        named = [code for name, code in STATES.items() if re.search(rf"\b{name}\b", lowered)]
        if named:
            state("state", {"in": named}, ", ".join(named))
    if entity == "members" and "claim_type" not in rules and re.search(r"\bdental\b", lowered):
        cat = features.get("cspd_cat")
        dental = next((o["value"] for o in (cat or {}).get("options") or []
                       if o["value"] in ("D", "DEN")), None)
        if cat and dental \
                and "cspi_id" not in rules:
            state("cspd_cat", {"in": [dental]}, "dental")

    # Ages, as ranges or as words.
    age_key = "member_age" if entity == "claims" else "age"
    age = None
    patterns = [
        (rf"\b(?:aged?|ages)\s*(?:between\s*)?{NUMBER}\s*(?:-|to|and|–)\s*{NUMBER}", "range"),
        (rf"\bbetween\s*{NUMBER}\s*(?:and|to)\s*{NUMBER}\s*(?:years?|yrs?)", "range"),
        (rf"\b{NUMBER}\s*(?:-|to|–)\s*{NUMBER}\s*(?:years?|yrs?)", "range"),
        (rf"\b(?:over|above|older than|at least)\s*{NUMBER}\s*(?:years?|yrs?)?(?!\s*(?:dollars|\$))", "min"),
        (rf"\b{NUMBER}\s*\+", "min"),
        (rf"\b(?:under|below|younger than)\s*{NUMBER}\s*(?:years?|yrs?)?", "max"),
    ]
    for pattern, kind in patterns:
        hit = re.search(pattern, lowered)
        if not hit:
            continue
        before = lowered[max(0, hit.start() - 2): hit.start()]
        if "$" in before or "$" in hit.group(0):
            continue
        if kind == "range":
            age = {"min": _number(hit.group(1)), "max": _number(hit.group(2))}
        elif kind == "min":
            age = {"min": _number(hit.group(1))}
        else:
            age = {"max": _number(hit.group(1))}
        said = hit.group(0)
        break
    if age is None:
        for pattern, (low, high) in AGE_WORDS:
            hit = re.search(pattern, lowered)
            if hit:
                age = {"min": low, **({"max": high} if high is not None else {})}
                said = hit.group(0)
                break
    if age is not None and all(v <= 120 for v in age.values()):
        state(age_key, age, said.strip(" ,.;"))

    # Charges, on claims.
    if entity == "claims":
        charge = None
        hit = re.search(rf"\$\s*{NUMBER}\s*(?:-|to|and)\s*\$?\s*{NUMBER}", lowered)
        if hit:
            charge = {"min": _number(hit.group(1)), "max": _number(hit.group(2))}
        else:
            hit = re.search(rf"(?:over|above|more than|at least|exceeding)\s*\$\s*{NUMBER}", lowered)
            if hit:
                charge = {"min": _number(hit.group(1))}
            else:
                hit = re.search(rf"(?:under|below|less than)\s*\$\s*{NUMBER}", lowered)
                if hit:
                    charge = {"max": _number(hit.group(1))}
        if charge:
            state("charge", charge, hit.group(0))

    # How many.
    count = None
    hit = re.search(rf"\b{NUMBER}\s+(?:\w+\s+){{0,3}}?(?:claims?|members?|patients?|records?|"
                    rf"subscribers?|people|lines?|children|kids|seniors|adults|women|men|"
                    rf"employees|dependents|enrollees|encounters)\b", lowered)
    if hit:
        count = int(_number(hit.group(1)))

    return {"entity": entity, "rules": rules, "found": found, "count": count, "story": text}

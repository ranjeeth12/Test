"""Orchestration over the existing sdg.analyzer modules.

This file adds no analytics of its own. It reproduces the sequence that
_pages/1_profiler.py ran inline — load, cluster, profile, name — and returns
plain Python so FastAPI can serialize it.

The two-layer cache mirrors the profiler page's split: member data survives a
change to K, cluster assignments do not.
"""

import hashlib
import json
import math
from typing import Any, Optional

import numpy as np
import pandas as pd

from sdg.analyzer.clustering import discover_clusters
from sdg.analyzer.config import DEFAULT_REFERENCE_DATE, DESCRIPTION_COLUMNS
from sdg.analyzer.data_loader import (
    get_groups, get_plan_categories, get_plans, get_products,
    get_overview_metrics, load_filtered_members,
)
from sdg.analyzer.naming import build_contextual_name
from sdg.analyzer.profiler import build_subset_summary, profile_cluster

from .cache import ttl_cache
from .disk_cache import two_tier

RARE_THRESHOLD = 0.03

# The denominator is the population at the TOPMOST level the user selected.
#
# Select three groups and nothing deeper: the patterns partition those groups,
# so their shares sum to 100%. Add a plan filter and they sum to less — the
# remainder of those groups belongs to patterns not currently in view, which is
# exactly what should be visible.
#
# The whole-book count is the wrong denominator here. Against a table with a
# billion claim lines every pattern rounds to zero, and a metric that always
# reads "<0.01%" ranks nothing.
# Fallback only, used before a baseline exists. Real banding comes from the
# percentile cut-offs computed during enumeration.
WEIGHT_BANDS = [
    (0.010,  "very high"),
    (0.004,  "high"),
    (0.0015, "medium"),
    (0.0004, "low"),
    (0.0,    "rare"),
]

# Which percentile of all observed pattern sizes each band starts at.
BAND_PERCENTILES = [
    ("p95", "very high"),
    ("p80", "high"),
    ("p50", "medium"),
    ("p20", "low"),
]


def weight_band(pct_of_scope: float, size: int = None,
                thresholds: dict = None) -> str:
    """Bucket a pattern.

    With stored thresholds, band by where the pattern's size falls among every
    pattern the enumeration saw — so "very high" means the top 5% of patterns
    that actually exist. Without them, fall back to fixed shares.
    """
    if thresholds and size is not None:
        for key, label in BAND_PERCENTILES:
            cut = thresholds.get(key)
            if cut is not None and size >= cut:
                return label
        return "rare"

    for floor, label in WEIGHT_BANDS:
        if pct_of_scope >= floor:
            return label
    return "rare"


def scope_denominator(filters: dict) -> tuple[int, str, bool]:
    """The stored baseline total these filters are measured against.

    Returns (count, label, from_baseline). Falls back to a live count only
    when no baseline has been computed yet, and says so, because a live count
    moves with the filter and a stored one does not.
    """
    from . import baseline as bl

    # The denominator for a displayed percentage is the whole member book, so a
    # pattern covering 40% of members reads 40%. (The enumeration baseline is a
    # different quantity, used only to place patterns into weight bands.)
    book = int(overview().get("n_members", 0))
    if book:
        return book, "all members", True
    counts = funnel_counts((), (), (), ())
    return counts["total"], "all members", False


# ── JSON coercion ────────────────────────────────────────────────────────────

def to_py(obj: Any) -> Any:
    """Recursively convert numpy / pandas scalars into JSON-safe Python."""
    if obj is None:
        return None
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        f = float(obj)
        return None if (math.isnan(f) or math.isinf(f)) else f
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, float):
        return None if (math.isnan(obj) or math.isinf(obj)) else obj
    if isinstance(obj, (pd.Timestamp,)):
        return obj.isoformat()
    if isinstance(obj, np.ndarray):
        return [to_py(x) for x in obj.tolist()]
    if isinstance(obj, dict):
        return {str(k): to_py(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [to_py(x) for x in obj]
    return obj


def cache_key(filters: dict, k: Optional[int]) -> str:
    raw = json.dumps({"filters": filters, "k": k}, sort_keys=True, default=str)
    return hashlib.md5(raw.encode()).hexdigest()


# ── Hierarchy options ────────────────────────────────────────────────────────

@ttl_cache(300)
def overview() -> dict:
    return to_py(get_overview_metrics())


@ttl_cache(300)
def groups() -> list[dict]:
    df = get_groups()
    return [{"key": str(r["GRGR_CK"]), "label": str(r["GRGR_NAME"]).strip()}
            for _, r in df.iterrows()]


@ttl_cache(300)
def plan_categories(grgr_cks: Optional[tuple] = None) -> list[dict]:
    df = get_plan_categories(list(grgr_cks) if grgr_cks else None)
    return [{"key": str(r["CSPD_CAT"]).strip(), "label": str(r["CSPD_CAT_DESC"]).strip()}
            for _, r in df.iterrows()]


@ttl_cache(300)
def plans(grgr_cks: Optional[tuple] = None, cspd_cats: Optional[tuple] = None) -> list[dict]:
    df = get_plans(list(grgr_cks) if grgr_cks else None,
                   list(cspd_cats) if cspd_cats else None)
    return [{"key": str(r["CSPI_ID"]).strip(), "label": str(r["PLDS_DESC"]).strip()}
            for _, r in df.iterrows()]


@ttl_cache(300)
def products(grgr_cks: Optional[tuple] = None, cspd_cats: Optional[tuple] = None,
             cspi_ids: Optional[tuple] = None) -> list[dict]:
    df = get_products(list(grgr_cks) if grgr_cks else None,
                      list(cspd_cats) if cspd_cats else None,
                      list(cspi_ids) if cspi_ids else None)
    return [{"key": str(r["PDPD_ID"]).strip(), "label": str(r["PDDS_DESC"]).strip()}
            for _, r in df.iterrows()]


# ── Analysis ─────────────────────────────────────────────────────────────────

@two_tier("members.load", ttl=3600)
def _load(filters: dict, reference_date: str):
    """Layer 1 — member data. Survives a change to K, and now a restart.

    A defined pattern's rules beyond the hierarchy come as `conditions`, and
    cut the loaded members down to the ones meeting them.
    """
    from . import defined_patterns

    scope, conditions = defined_patterns.split(filters)
    loaded = load_filtered_members(**scope, reference_date=reference_date)
    return defined_patterns.narrow_members(loaded, conditions) if conditions else loaded


@two_tier("members.cluster", ttl=3600)
def _cluster(filters: dict, k: Optional[int], reference_date: str):
    """Layer 2 — assignments. Invalidated by a change to K.

    Cached separately from the data so adjusting K reuses the loaded frame
    instead of going back to SQL Server.
    """
    members, labels, family, filters_used = _load(filters, reference_date)
    from .defined_patterns import WHOLE

    if k == WHOLE:
        # The whole scope as one pattern: what a defined pattern is.
        return np.zeros(len(members), dtype=int), {"method": "whole_scope"}
    assignments, metrics = discover_clusters(
        members, labels, k=k, use_labels=False, filters_used=filters_used,
    )
    return assignments, metrics


def _hierarchy_labels(summary: dict) -> tuple[str, str, str, str]:
    def first(col):
        vals = summary.get(col) or []
        return str(vals[0]) if len(vals) == 1 else "All"
    return (
        first("GRGR_NAME"), first("CSPD_CAT_DESC"),
        first("PLDS_DESC"), first("PDDS_DESC"),
    )


def analyze(filters: dict, k: Optional[int] = None,
            reference_date: Optional[str] = None) -> dict:
    """Full profiler run. Mirrors _pages/1_profiler.py end to end."""
    ref = reference_date or DEFAULT_REFERENCE_DATE

    members, labels, family, filters_used = _load(filters, ref)
    if members is None or len(members) == 0:
        return {
            "total_members": int(overview().get("n_members", 0)),
            "subset_members": 0, "pct_of_total": 0.0, "n_patterns": 0,
            "method": "empty", "silhouette": None,
            "filters_used": to_py(filters_used or {}),
            "patterns": [], "cache_key": cache_key(filters, k),
        }

    assignments, metrics = _cluster(filters, k, ref)
    summary = build_subset_summary(members, filters_used)
    total_n = len(members)

    grgr, cat, plan, prod = _hierarchy_labels(summary)

    scope_n, scope_label, from_baseline = scope_denominator(filters)
    scope_n = scope_n or total_n

    from . import baseline as _bl
    thresholds = _bl.get_thresholds("members")

    # The shape behind each pattern's mean and range, on bins shared with the
    # whole scope so the two can be laid over each other.
    from sdg.analyzer.histograms import describe as _describe

    clusters = sorted({int(a) for a in assignments if a >= 0})
    distributions, shapes = _describe(
        members, {"_age": "_age", "_tenure": "_tenure"},
        {cid: np.asarray(assignments) == cid for cid in clusters},
    )

    patterns = []
    for cid in clusters:
        mask = np.asarray(assignments) == cid
        profile = profile_cluster(members, family, mask, cid, total_n)
        from sdg.plan.combinations import for_patterns, of_rows

        combinations = of_rows(members[np.asarray(mask)], "member_denorm", for_patterns())
        name = build_contextual_name(
            grgr_name=grgr, cspd_cat_desc=cat, plds_desc=plan,
            pdds_desc=prod, cluster_id=cid, profile=profile,
        )
        patterns.append({
            "cluster_id": cid,
            "name": name,
            "size": int(profile["size"]),
            "pct_of_subset": float(profile["pct_of_subset"]),
            # Share of the topmost selected level — the figure the band uses.
            "pct_of_total": round(int(profile["size"]) / scope_n, 6) if scope_n else 0.0,
            "rare": float(profile["pct_of_subset"]) < RARE_THRESHOLD,
            "weight_band": weight_band(
                int(profile["size"]) / scope_n if scope_n else 0.0,
                size=int(profile["size"]),
                thresholds=thresholds,
            ),
            "continuous": to_py(profile["continuous"]),
            "categorical": to_py(profile["categorical"]),
            "family": to_py(profile["family"]),
            "descriptions": to_py(profile["descriptions"]),
            "geography": to_py(profile.get("geography") or []),
            "enrollment": to_py(profile.get("enrollment") or []),
            "combinations": combinations,
            "histograms": shapes.get(cid, {}),
        })

    patterns.sort(key=lambda p: p["size"], reverse=True)

    book_members = int(overview().get("n_members", 0)) or total_n

    return {
        # Context for the funnel header, not a denominator for weights.
        "total_members": book_members,
        "subset_members": total_n,
        "pct_of_total": round(total_n / book_members * 100, 3) if book_members else 0.0,
        "n_patterns": len(patterns),
        "scope_total": scope_n,
        "scope_label": scope_label,
        "scope_from_baseline": from_baseline,
        # Spelled out so the number on screen can always be traced back to the
        # arithmetic that produced it.
        "weight_explained": (
            f"pattern members / {scope_n:,} in {scope_label}"
            f" ({'stored baseline' if from_baseline else 'live count'})"
            + (f" · bands from percentiles of {thresholds.get('n_patterns', 0):,} patterns"
               if thresholds else " · bands from fixed shares (no baseline)")
        ),
        "band_thresholds": thresholds,
        # Share of the scope that deeper filters excluded. Zero when the only
        # selection is at the topmost level, which is when shares sum to 100%.
        "pct_outside_filter": round(1 - (total_n / scope_n), 6) if scope_n else 0.0,
        "method": str(metrics.get("method", "kmeans")),
        "silhouette": to_py(metrics.get("silhouette")),
        "filters_used": to_py(filters_used or {}),
        "patterns": patterns,
        "distributions": distributions,
        "cache_key": cache_key(filters, k),
    }


def pattern_context(filters: dict, k: Optional[int], cluster_id: int,
                    reference_date: Optional[str] = None):
    """Everything generation needs for one pattern: profile, source rows, name.

    Reuses the cached load and cluster, so this is cheap after an analyze().
    """
    ref = reference_date or DEFAULT_REFERENCE_DATE
    members, labels, family, filters_used = _load(filters, ref)
    if members is None or len(members) == 0:
        raise ValueError("No members match these filters.")

    assignments, _ = _cluster(filters, k, ref)
    mask = np.asarray(assignments) == cluster_id
    if not mask.any():
        raise ValueError(f"Pattern {cluster_id} is not present in this subset.")

    profile = profile_cluster(members, family, mask, cluster_id, len(members))
    summary = build_subset_summary(members, filters_used)
    grgr, cat, plan, prod = _hierarchy_labels(summary)
    name = build_contextual_name(
        grgr_name=grgr, cspd_cat_desc=cat, plds_desc=plan,
        pdds_desc=prod, cluster_id=cluster_id, profile=profile,
    )
    return profile, filters_used, members.iloc[mask], name


def df_preview(df: pd.DataFrame, limit: int = 100) -> tuple[list[str], list[dict]]:
    """Column order plus the first `limit` rows, JSON-safe."""
    if df is None or df.empty:
        return [], []
    head = df.head(limit)
    cols = [str(c) for c in head.columns]
    rows = [
        {str(c): to_py(v) for c, v in rec.items()}
        for rec in head.to_dict(orient="records")
    ]
    return cols, rows


# ── Funnel counts ────────────────────────────────────────────────────────────

@two_tier("funnel", ttl=1800)
def funnel_counts(grgr: tuple = (), cat: tuple = (),
                  plan: tuple = (), product: tuple = ()) -> dict:
    """Member count after each level of the hierarchy is applied.

    Five cheap COUNT(DISTINCT) queries rather than one full load. This exists
    so the funnel across the top can show real numbers at every step — showing
    a dash there tells the user nothing about how their filters are biting.
    """
    import pyodbc

    from sdg.analyzer.config import SQL_SCHEMA, get_connection_string
    from sdg.analyzer.data_loader import _build_where

    table = f"{SQL_SCHEMA}.member_denorm"
    levels = [
        ("total",   None, None, None, None),
        ("group",   list(grgr) or None, None, None, None),
        ("cat",     list(grgr) or None, list(cat) or None, None, None),
        ("plan",    list(grgr) or None, list(cat) or None, list(plan) or None, None),
        ("product", list(grgr) or None, list(cat) or None, list(plan) or None,
                    list(product) or None),
    ]

    out: dict[str, Optional[int]] = {}
    conn = pyodbc.connect(get_connection_string())
    try:
        cur = conn.cursor()
        for name, g, c, p, pr in levels:
            where = _build_where(g, c, p, pr)
            cur.execute(f"SELECT COUNT(DISTINCT MEME_CK) FROM {table} {where}")
            row = cur.fetchone()
            out[name] = int(row[0]) if row and row[0] is not None else 0
    finally:
        conn.close()
    return out

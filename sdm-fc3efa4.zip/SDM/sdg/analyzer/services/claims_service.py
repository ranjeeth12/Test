"""Claims pattern analysis.

Same shape as the member profiler: cascade the hierarchy, cluster the filtered
subset, profile each cluster. Claims carry more signal than members — age and
gender plus diagnosis, procedure, place of service, provider specialty, and the
financial columns — so the profile is richer, but the workflow is identical.

Clusters are found on the features chosen on the Config screen
(discovery_features): numbers standardized and weighted 2x, lists one-hot.
"""

from typing import Optional

import numpy as np
import pandas as pd

from sdg.analyzer import claims_data_loader as cdl
from sdg.analyzer.claims_data_loader import (
    load_filtered_claims, profile_claims_cluster,
)

from .cache import ttl_cache
from .disk_cache import two_tier
from .service import cache_key, to_py, weight_band

CONTINUOUS_WEIGHT = 2.0
RARE_THRESHOLD = 0.03
SILHOUETTE_SAMPLE = 5000

# Exclusive ceiling on the claims k sweep, kept wider than the member one.
#
# Members never select above k=4, so clustering.MEMBER_K_RANGE stops at 6. Claims
# do reach the top: across 63 combinations the sweep chose k=6 five times, k=7
# twice and k=10 twice. Capping at 6 would have cost those four combinations
# clusters — one dropped from 10 to 6 — for a silhouette loss of up to 0.0176 on
# a 0.40 score. That is a 1.7x walk against slightly coarser patterns on 6% of
# combinations, and the patterns are the product.
CLAIMS_K_MAX = 11
# Rows the cluster count is chosen on; the final fit uses all of them.
K_SEARCH_SAMPLE = 50_000


def _opts(df: pd.DataFrame, key_col: str, label_col: Optional[str] = None) -> list[dict]:
    if df is None or len(df) == 0:
        return []
    out = []
    for _, r in df.iterrows():
        key = str(r[key_col]).strip()
        label = str(r[label_col]).strip() if label_col and label_col in df.columns else key
        out.append({"key": key, "label": label or key})
    return out


@ttl_cache(300)
def groups() -> list[dict]:
    return _opts(cdl.get_claims_groups(), "GRGR_CK", "GRGR_NAME")


@ttl_cache(300)
def plans(grgr: Optional[tuple] = None) -> list[dict]:
    return _opts(cdl.get_claims_plans(list(grgr) if grgr else None), "CSPI_ID", "PLDS_DESC")


@ttl_cache(300)
def products(grgr: Optional[tuple] = None, plan: Optional[tuple] = None) -> list[dict]:
    df = cdl.get_claims_products(list(grgr) if grgr else None, list(plan) if plan else None)
    cols = list(df.columns) if df is not None and len(df) else []
    label = "PDDS_DESC" if "PDDS_DESC" in cols else None
    return _opts(df, "PDPD_ID", label)


@ttl_cache(300)
def claim_types(grgr: Optional[tuple] = None, plan: Optional[tuple] = None,
                product: Optional[tuple] = None) -> list[dict]:
    df = cdl.get_claims_types(
        list(grgr) if grgr else None,
        list(plan) if plan else None,
        list(product) if product else None,
    )
    cols = list(df.columns) if df is not None and len(df) else []
    key = "CLCL_CL_TYPE" if "CLCL_CL_TYPE" in cols else (cols[0] if cols else "CLCL_CL_TYPE")
    # get_claims_types returns a friendly Claim_Type column alongside the code.
    label = "Claim_Type" if "Claim_Type" in cols else None
    return _opts(df, key, label)


def _features(df: pd.DataFrame):
    """Numeric matrix from the features chosen on the Config screen."""
    from .discovery_features import matrix

    return matrix(df, "claims", CONTINUOUS_WEIGHT)


@two_tier("claims.booktotal", ttl=3600)
def book_totals() -> dict:
    """Whole-book claim and line counts. Context, not the denominator."""
    raw = cdl.get_claims_overview() or {}
    return {
        "claims": int(raw.get("n_claims", 0) or 0),
        "lines": int(raw.get("n_claim_lines", 0) or 0),
    }


def scope_denominator(filters: dict) -> tuple:
    """The stored baseline total for these filters.

    Falls back to a live count only when nothing has been computed yet.
    """
    from . import baseline as bl

    total = book_totals()["claims"]
    return total, "all claims", True


@two_tier("claims.load", ttl=3600)
def _load(filters: dict):
    from . import defined_patterns

    scope, conditions = defined_patterns.split(filters)
    loaded = load_filtered_claims(**scope)
    return defined_patterns.narrow_claims(loaded, conditions) if conditions else loaded


@two_tier("claims.cluster", ttl=3600)
def _cluster(filters: dict, k: Optional[int]):
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score

    df, _ = _load(filters)
    n = len(df)
    from .defined_patterns import WHOLE

    if k == WHOLE:
        # The whole scope as one pattern: what a defined pattern is.
        return np.zeros(n, dtype=int), {"method": "whole_scope"}
    if n < 8:
        return np.zeros(n, dtype=int), {"method": "single_cluster",
                                        "reason": f"n={n} < 8, too few to cluster"}

    X = _features(df)
    if X is None:
        return np.zeros(n, dtype=int), {"method": "single_cluster",
                                        "reason": "no usable feature columns"}

    def sil(mat, labels):
        return float(silhouette_score(
            mat, labels, sample_size=min(SILHOUETTE_SAMPLE, mat.shape[0]), random_state=42,
        ))

    if k is None:
        # The number of clusters is chosen on a fixed sample and only the final
        # fit sees every line. Nine trial fits over the whole book were most of
        # a cold analysis; the silhouette was only ever read from 5,000 rows,
        # so a 50,000-row sample loses nothing it was measuring.
        trial = X
        if n > K_SEARCH_SAMPLE:
            pick = np.sort(np.random.default_rng(42).choice(n, K_SEARCH_SAMPLE, replace=False))
            trial = X[pick]
        best_k, best = 2, -1.0
        for cand in range(2, min(CLAIMS_K_MAX, n)):
            labels = KMeans(n_clusters=cand, n_init=3, random_state=42).fit_predict(trial)
            if len(set(labels)) < 2:
                continue
            s = sil(trial, labels)
            if s > best:
                best, best_k = s, cand
        k = best_k

    assignments = KMeans(n_clusters=k, n_init=10, random_state=42).fit_predict(X)
    score = sil(X, assignments) if len(set(assignments)) >= 2 else 0.0
    return assignments, {"method": "kmeans", "n_clusters": int(k), "silhouette": score}


def _name(profile: dict, cid: int) -> str:
    """Readable label from the claim's own vocabulary."""
    bits = []

    age = profile.get("member_age") or {}
    mean = age.get("mean")
    if mean is not None:
        m = float(mean)
        bits.append(
            "Pediatric" if m < 18 else "Young adult" if m < 30
            else "Adult" if m < 50 else "Middle-aged" if m < 65 else "Senior"
        )

    gender = profile.get("gender") or {}
    if gender:
        top, share = max(gender.items(), key=lambda kv: kv[1])
        if share >= 0.65:
            bits.append("female" if top.upper().startswith("F") else "male")

    dx = profile.get("top_diagnoses") or {}
    if dx:
        code = next(iter(dx))
        desc = (profile.get("diagnosis_descriptions") or {}).get(code)
        bits.append(f"{desc}" if desc else f"dx {code}")

    return " · ".join(bits) if bits else f"Claim pattern {cid}"


# The clinical facts of a claim line, and the element each one is. Kept as
# whole combinations, the way an address is kept: a diagnosis and a procedure
# drawn apart can make a pair no claim has ever carried.
CLINICAL_COLUMNS = {"IDCD_ID_PRIMARY": "DIAGNOSIS_CODE", "IPCD_ID": "PROCEDURE_CODE"}
# The most common combinations a pattern keeps, with how often each occurs.
MAX_COMBINATIONS = 300


def _combinations(subset: pd.DataFrame, store: str) -> list[dict]:
    from sdg.plan.combinations import for_patterns, of_rows

    return of_rows(subset, store, for_patterns())


def clinical_combinations(subset: pd.DataFrame) -> list[dict]:
    """The diagnosis and procedure pairs the lines carry, most common first.

    Every generated line takes one whole pair, so nothing generated pairs a
    diagnosis with a procedure the book has never seen it with.
    """
    columns = [c for c in CLINICAL_COLUMNS if c in subset.columns]
    if len(columns) < 2 or subset.empty:
        return []
    frame = subset[columns].dropna()
    if frame.empty:
        return []
    frame = frame.apply(lambda s: s.astype(str).str.strip())
    frame = frame[(frame != "").all(axis=1)]
    counts = frame.value_counts().head(MAX_COMBINATIONS)
    total = float(counts.sum()) or 1.0
    return [
        {**{CLINICAL_COLUMNS[c]: v for c, v in zip(columns, key)},
         "share": round(float(n) / total, 6)}
        for key, n in counts.items()
    ]


def describe(subset: pd.DataFrame, cid: int, *, total_claims: int,
             total_lines: int, scope_n: int, thresholds: dict | None = None) -> dict:
    """One claims pattern as the screen and a saved pattern both read it.

    Shared by the analysis and by saving a pattern made of chosen records, so
    the two can never describe the same lines differently.
    """
    has_claim_id = "CLCL_ID" in subset.columns
    profile = profile_claims_cluster(subset)
    size = int(profile.get("size", len(subset)))
    n_claims = int(subset["CLCL_ID"].nunique()) if has_claim_id else size

    # Weight is a share of CLAIMS, not claim lines. Lines-per-claim varies
    # between patterns, so a line-based share overstates patterns whose
    # claims happen to carry more detail lines.
    pct = (n_claims / total_claims) if total_claims else 0.0
    pct_lines = (size / total_lines) if total_lines else 0.0
    # Share of the topmost selected level, not the whole table.
    pct_total = (n_claims / scope_n) if scope_n else 0.0

    return {
        "cluster_id": cid,
        "name": _name(profile, cid),
        "size": size,
        "pct_of_subset": round(pct, 4),
        "pct_of_lines": round(pct_lines, 4),
        "pct_of_total": round(pct_total, 6),
        "rare": pct < RARE_THRESHOLD,
        "weight_band": weight_band(pct_total, size=n_claims, thresholds=thresholds),
        "n_claims": n_claims,
        "n_members": int(subset["MEME_CK"].nunique()) if "MEME_CK" in subset.columns else 0,
        # Its own combinations of every group of dependent features -- the
        # diagnosis with the procedure, the claim type with both -- drawn whole.
        "combinations": _combinations(subset, "claims_denorm"),
        "approval_rate": to_py(profile.get("approval_rate")),
        "in_network_rate": to_py(profile.get("in_network_rate")),
        "continuous": {
            label: to_py(profile[label])
            for label in ("member_age", "charge_amount", "allowed_amount",
                          "paid_amount", "deductible", "copay", "coinsurance")
            if label in profile
        },
        "categorical": {
            label: to_py(profile[label])
            for label in ("gender", "claim_status", "claim_type",
                          "network", "network_name", "network_type", "place_of_service",
                          "provider_specialty", "provider_type")
            if label in profile
        },
        "top_diagnoses": to_py(profile.get("top_diagnoses") or {}),
        "top_procedures": to_py(profile.get("top_procedures") or {}),
        "diagnosis_descriptions": to_py(profile.get("diagnosis_descriptions") or {}),
        "procedure_descriptions": to_py(profile.get("procedure_descriptions") or {}),
    }


def analyze(filters: dict, k: Optional[int] = None) -> dict:
    df, filters_used = _load(filters)
    total_lines = len(df)
    has_claim_id = "CLCL_ID" in df.columns
    total_claims = int(df["CLCL_ID"].nunique()) if has_claim_id else total_lines
    book = book_totals()
    book_claims = book["claims"] or total_claims
    scope_n, scope_label, from_baseline = scope_denominator(filters)
    scope_n = scope_n or total_claims

    from . import baseline as _bl
    thresholds = _bl.get_thresholds("claims")
    assignments, metrics = _cluster(filters, k)

    from sdg.analyzer.histograms import describe as _describe

    clusters = sorted({int(a) for a in assignments if a >= 0})
    distributions, shapes = _describe(
        df, {"member_age": "CLCL_ME_AGE", "charge_amount": "CDML_CHG_AMT"},
        {cid: np.asarray(assignments) == cid for cid in clusters},
    )

    patterns = []
    claims_seen = 0
    for cid in clusters:
        mask = np.asarray(assignments) == cid
        subset = df.iloc[mask]
        pattern = describe(subset, cid, total_claims=total_claims,
                           total_lines=total_lines, scope_n=scope_n,
                           thresholds=thresholds)
        claims_seen += pattern["n_claims"]
        pattern["histograms"] = shapes.get(cid, {})
        patterns.append(pattern)

    patterns.sort(key=lambda p: p["n_claims"], reverse=True)

    # Clustering runs at line grain, so a single claim's lines can be split
    # across patterns. When that happens the per-pattern claim counts sum to
    # more than the subset total and the percentages exceed 100. Report it
    # rather than quietly rescaling — it tells the user something true about
    # how well the chosen features separate whole claims.
    split_claims = max(0, claims_seen - total_claims)

    return {
        "subset_claim_lines": total_lines,
        "subset_claims": total_claims,
        "denominator": "claims",
        "book_claims": book_claims,
        "book_claim_lines": book["lines"],
        "scope_total": scope_n,
        "scope_label": scope_label,
        "scope_from_baseline": from_baseline,
        "weight_explained": (
            f"pattern claims / {scope_n:,} in {scope_label}"
            f" ({'stored baseline' if from_baseline else 'live count'})"
            + (f" · bands from percentiles of {thresholds.get('n_patterns', 0):,} patterns"
               if thresholds else " · bands from fixed shares (no baseline)")
        ),
        "band_thresholds": thresholds,
        "pct_outside_filter": round(1 - (total_claims / scope_n), 6) if scope_n else 0.0,
        "split_claims": split_claims,
        "avg_lines_per_claim": round(total_lines / total_claims, 2) if total_claims else 0.0,
        "subset_members": int(df["MEME_CK"].nunique()) if "MEME_CK" in df.columns else 0,
        "n_patterns": len(patterns),
        "method": str(metrics.get("method", "kmeans")),
        "silhouette": to_py(metrics.get("silhouette")),
        "filters_used": to_py(filters_used or {}),
        "patterns": patterns,
        "distributions": distributions,
        "cache_key": cache_key(filters, k),
    }


def pattern_rows(filters: dict, k: Optional[int], cluster_id: int) -> pd.DataFrame:
    """The real claim rows behind one pattern — used for generation."""
    df, _ = _load(filters)
    assignments, _ = _cluster(filters, k)
    mask = np.asarray(assignments) == cluster_id
    if not mask.any():
        raise ValueError(f"Pattern {cluster_id} is not present in this subset.")
    return df.iloc[mask]


# ── Generation ───────────────────────────────────────────────────────────────

def _is_member_pattern(p: dict) -> bool:
    """Whether a stored pattern belongs to the member domain.

    Delegates to pattern_service.entity_of so the dropdown and the clone path
    cannot disagree about a row's domain. They previously used separate tests:
    a clone of a legacy claims pattern was tagged a member by one and a claims
    pattern by the other, so it was offered here and then failed to generate.
    """
    from . import pattern_service as ps

    return ps.entity_of(p) == "members"


def saved_member_patterns() -> list[dict]:
    """Member patterns available to attach generated claims to.

    Claims patterns are excluded. Mapping claims onto a claims pattern is not a
    coherent request — the generator would be handed a claims profile where it
    expects member demographics — and it was the source of the int('') failure
    rather than a readable message.
    """
    from sdg.analyzer import db

    out = []
    for p in db.get_all_patterns() or []:
        if not _is_member_pattern(p):
            continue
        out.append({
            "pattern_id": int(p["id"]),
            "name": str(p.get("contextual_name") or f"Pattern {p['id']}"),
            "member_count": int(p.get("member_count") or 0),
            "group": p.get("grgr_name"),
            "plan_category": p.get("cspd_cat_desc"),
            "plan": p.get("plds_desc"),
            "saved": bool(p.get("saved_at")),
        })
    out.sort(key=lambda x: (not x["saved"], -x["member_count"]))
    return out


def _require_member_pattern(member_pattern_id: int) -> None:
    """Reject a mapping onto anything that isn't a member pattern.

    The dropdown no longer offers claims patterns, but a stale browser tab or a
    direct API call still can — and the failure was a raw int() error from deep
    inside the loaders rather than anything explaining what went wrong.
    """
    from sdg.analyzer import db

    if not member_pattern_id:
        raise ValueError(
            "Choose a member pattern first — generated claims attach to "
            "subscribers drawn from it."
        )

    pattern = db.get_pattern(member_pattern_id)
    if not pattern:
        raise ValueError(
            f"Member pattern {member_pattern_id} no longer exists. "
            "Pick another from the list."
        )
    if not _is_member_pattern(pattern):
        name = pattern.get("contextual_name") or f"Pattern {member_pattern_id}"
        raise ValueError(
            f"“{name}” is a claims pattern, not a member pattern. Claims attach "
            "to subscribers, so the mapping has to be a member pattern."
        )


def generate(*_args, **_kwargs):
    """Gone with the analyzer's generator; the plan engine generates now."""
    raise NotImplementedError(
        "Generation moved to the plan engine. Build a plan, then use /api/export."
    )


def _sanitise_pool(df):
    """Coerce every key column to int, leaving everything else alone.

    Defensive on purpose: it does not matter which rule is missing or which
    downstream line would have cast it — after this, none of them can fail.
    """
    if df is None or df.empty:
        return df

    from sdg.analyzer import coerce

    for col in df.columns:
        if coerce.is_numeric_column(col):
            df[col] = coerce.to_int(df[col])
    return df

"""Enumerate hierarchy combinations and batch-discover top K-means patterns.

Hierarchy: Group (GRGR) → Plan Category (CSPD_CAT) → Plan (CSPI_ID/PLDS_DESC) → Product (PDPD_ID/PDDS_DESC)
"""

import numpy as np
import pandas as pd

from . import coerce

from sdg.analyzer.clustering import discover_clusters
from sdg.analyzer.data_loader import apply_filters
from sdg.analyzer.profiler import profile_all_clusters
from sdg.analyzer.naming import build_contextual_name
from sdg.analyzer.tagging import generate_tags
from sdg.analyzer import db


def enumerate_hierarchy_combos(df):
    """Return all valid hierarchy filter combos at every depth.

    Each combo is a dict with keys: grgr_ck, cspd_cat, cspi_id, pdpd_id, plus display names.
    Filter values are single-element lists or None (meaning all values at that level).
    """
    combos = []

    # Depth 1: Group only
    for _, row in (
        df[["GRGR_CK", "GRGR_NAME"]].drop_duplicates().iterrows()
    ):
        combos.append({
            "grgr_ck": [coerce.one_int(row["GRGR_CK"])],
            "cspd_cat": None,
            "cspi_id": None,
            "pdpd_id": None,
            "grgr_name": row["GRGR_NAME"],
            "cspd_cat_desc": "All",
            "plds_desc": "All",
            "pdds_desc": "All",
        })

    # Depth 2: Group + Plan Category
    for _, row in (
        df[["GRGR_CK", "GRGR_NAME", "CSPD_CAT", "CSPD_CAT_DESC"]]
        .drop_duplicates()
        .iterrows()
    ):
        combos.append({
            "grgr_ck": [coerce.one_int(row["GRGR_CK"])],
            "cspd_cat": [row["CSPD_CAT"]],
            "cspi_id": None,
            "pdpd_id": None,
            "grgr_name": row["GRGR_NAME"],
            "cspd_cat_desc": row["CSPD_CAT_DESC"],
            "plds_desc": "All",
            "pdds_desc": "All",
        })

    # Depth 3: Group + Plan Category + Plan
    for _, row in (
        df[["GRGR_CK", "GRGR_NAME", "CSPD_CAT", "CSPD_CAT_DESC",
            "CSPI_ID", "PLDS_DESC"]]
        .drop_duplicates()
        .iterrows()
    ):
        combos.append({
            "grgr_ck": [coerce.one_int(row["GRGR_CK"])],
            "cspd_cat": [row["CSPD_CAT"]],
            "cspi_id": [row["CSPI_ID"]],
            "pdpd_id": None,
            "grgr_name": row["GRGR_NAME"],
            "cspd_cat_desc": row["CSPD_CAT_DESC"],
            "plds_desc": row["PLDS_DESC"],
            "pdds_desc": "All",
        })

    # Depth 4: Full hierarchy
    for _, row in (
        df[["GRGR_CK", "GRGR_NAME", "CSPD_CAT", "CSPD_CAT_DESC",
            "CSPI_ID", "PLDS_DESC", "PDPD_ID", "PDDS_DESC"]]
        .drop_duplicates()
        .iterrows()
    ):
        combos.append({
            "grgr_ck": [coerce.one_int(row["GRGR_CK"])],
            "cspd_cat": [row["CSPD_CAT"]],
            "cspi_id": [row["CSPI_ID"]],
            "pdpd_id": [row["PDPD_ID"]],
            "grgr_name": row["GRGR_NAME"],
            "cspd_cat_desc": row["CSPD_CAT_DESC"],
            "plds_desc": row["PLDS_DESC"],
            "pdds_desc": row["PDDS_DESC"],
        })

    return combos


def discover_top_patterns(df, labels_df, top_n=50, progress_callback=None):
    """Run K-means on every hierarchy combo and return the top_n patterns by size."""
    combos = enumerate_hierarchy_combos(df)
    all_patterns = []

    for i, combo in enumerate(combos):
        if progress_callback:
            progress_callback(i, len(combos), combo)

        try:
            subset_members, subset_labels, family_data, filters_used = apply_filters(
                df, labels_df,
                grgr_ck=combo["grgr_ck"],
                cspd_cat=combo["cspd_cat"],
                cspi_id=combo["cspi_id"],
                pdpd_id=combo["pdpd_id"],
            )
        except ValueError:
            continue

        assignments, metrics = discover_clusters(
            subset_members, subset_labels,
            k=None, use_labels=False,
            filters_used=filters_used,
        )

        profiles = profile_all_clusters(subset_members, family_data, assignments)
        n_patterns = metrics.get("n_clusters", 1)
        silhouette = metrics.get("silhouette", 0.0)
        total_pop = df["MEME_CK"].nunique()

        for profile in profiles:
            pct_of_pop = profile["size"] / total_pop if total_pop > 0 else 0

            ctx_name = build_contextual_name(
                grgr_name=combo["grgr_name"],
                cspd_cat_desc=combo["cspd_cat_desc"],
                plds_desc=combo["plds_desc"],
                pdds_desc=combo.get("pdds_desc", ""),
                cluster_id=profile["cluster_id"],
                profile=profile,
            )

            pattern_entry = {
                "combo": {
                    "grgr_ck": combo["grgr_ck"],
                    "cspd_cat": combo["cspd_cat"],
                    "cspi_id": combo["cspi_id"],
                    "pdpd_id": combo["pdpd_id"],
                },
                "cluster_id": profile["cluster_id"],
                "size": profile["size"],
                "silhouette": silhouette,
                "n_patterns": n_patterns,
                "grgr_name": combo["grgr_name"],
                "cspd_cat_desc": combo["cspd_cat_desc"],
                "plds_desc": combo["plds_desc"],
                "pdds_desc": combo.get("pdds_desc", ""),
                "contextual_name": ctx_name,
                "profile": profile,
            }
            all_patterns.append(pattern_entry)

            # Persist to DB
            try:
                pattern_id = db.upsert_pattern(
                    combo={
                        "grgr_ck": combo["grgr_ck"],
                        "cspd_cat": combo["cspd_cat"],
                        "cspi_id": combo["cspi_id"],
                        "pdpd_id": combo["pdpd_id"],
                        "grgr_name": combo["grgr_name"],
                        "cspd_cat_desc": combo["cspd_cat_desc"],
                        "plds_desc": combo["plds_desc"],
                        "pdds_desc": combo.get("pdds_desc", ""),
                    },
                    cluster_id=profile["cluster_id"],
                    contextual_name=ctx_name,
                    member_count=profile["size"],
                    pct_of_pop=pct_of_pop,
                    silhouette=silhouette,
                    profile=profile,
                )

                tags = generate_tags(
                    grgr_name=combo["grgr_name"],
                    cspd_cat_desc=combo["cspd_cat_desc"],
                    plds_desc=combo["plds_desc"],
                    pdds_desc=combo.get("pdds_desc", ""),
                    profile=profile,
                    silhouette=silhouette,
                    pct_of_pop=pct_of_pop,
                )
                db.add_tags(pattern_id, tags, source="auto")
            except Exception:
                pass

    all_patterns.sort(key=lambda p: p["size"], reverse=True)
    return all_patterns[:top_n]

"""EDI 837 Professional formatter for synthetic claims.

Generates basic 837P structure from claims DataFrame.
POC-level — not a complete production EDI implementation.
"""

import pandas as pd
from datetime import datetime


def claims_to_edi_837(df):
    """Convert claims DataFrame to EDI 837P format string."""
    lines = []
    now = datetime.now()
    date_str = now.strftime("%Y%m%d")
    time_str = now.strftime("%H%M")
    ctrl = now.strftime("%y%m%d%H%M")

    lines.append(
        f"ISA*00*          *00*          *ZZ*SYNTH_SENDER   "
        f"*ZZ*CARESOURCE     *{now.strftime('%y%m%d')}*{time_str}"
        f"*^*00501*{ctrl}*0*T*:~"
    )
    lines.append(f"GS*HC*SYNTH_SENDER*CARESOURCE*{date_str}*{time_str}*{ctrl}*X*005010X222A1~")
    lines.append(f"ST*837*0001*005010X222A1~")
    lines.append(f"BHT*0019*00*{ctrl}*{date_str}*{time_str}*CH~")

    hl_counter = 1
    lines.append(f"HL*{hl_counter}**20*1~")
    lines.append(f"NM1*41*2*SYNTHETIC DATA GENERATOR*****46*SYNTH001~")
    hl_submitter = hl_counter

    hl_counter += 1
    lines.append(f"HL*{hl_counter}*{hl_submitter}*22*1~")
    lines.append(f"NM1*85*2*SYNTHETIC PROVIDER*****XX*1234567890~")
    lines.append(f"N3*100 SYNTHETIC BLVD~")
    lines.append(f"N4*DAYTON*OH*45402~")
    hl_billing = hl_counter

    for idx, row in df.iterrows():
        meme_ck = str(row.get("MEME_CK", ""))
        gender = str(row.get("MEME_SEX", "U")).strip()
        gender_code = {"M": "M", "F": "F"}.get(gender, "U")

        proc_cd = str(row.get("IPCD_ID", row.get("Procedure_CD", "99213"))).strip()
        diag_cd = str(row.get("IDCD_ID_PRIMARY", row.get("IDCD_ID", "Z0000"))).strip().replace(".", "")
        amount = f"{float(row.get('CDML_CHG_AMT', row.get('Claim_Amount', 0))):.2f}"

        birth_dt = row.get("MEME_BIRTH_DT")
        if pd.notna(birth_dt):
            try:
                dob = pd.Timestamp(birth_dt).strftime("%Y%m%d")
            except Exception:
                dob = "19800101"
        else:
            dob = "19800101"

        svc_date = date_str
        for dt_col in ["CDML_FROM_DT", "CLCL_LOW_SVC_DT", "Claim_Date"]:
            if dt_col in row.index and pd.notna(row.get(dt_col)):
                try:
                    svc_date = pd.Timestamp(row[dt_col]).strftime("%Y%m%d")
                    break
                except Exception:
                    pass

        hl_counter += 1
        lines.append(f"HL*{hl_counter}*{hl_billing}*23*0~")
        lines.append(f"NM1*IL*1*MEMBER*SYNTH_{meme_ck}****MI*S{meme_ck}~")
        lines.append(f"DMG*D8*{dob}*{gender_code}~")

        claim_num = f"CLM{meme_ck}_{idx}"
        lines.append(f"CLM*{claim_num}*{amount}***11:B:1*Y*A*Y*Y~")
        lines.append(f"HI*ABK:{diag_cd}~")
        lines.append(f"LX*1~")
        lines.append(f"SV1*HC:{proc_cd}*{amount}*UN*1***1~")
        lines.append(f"DTP*472*D8*{svc_date}~")

    lines.append(f"SE*{len(lines) - 2}*0001~")
    lines.append(f"GE*1*{ctrl}~")
    lines.append(f"IEA*1*{ctrl}~")

    return "\n".join(lines)

"""Pattern analyzer, merged from the SDM Pattern Analyzer project."""

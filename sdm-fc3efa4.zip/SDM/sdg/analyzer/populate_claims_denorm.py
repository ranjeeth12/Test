"""Populate sdm.claims_denorm with mock data joined to real member_denorm.

Reads actual members from sdm.member_denorm and generates realistic
claims referencing those members, groups, plans, and products.

Usage:
    cd C:/Windows/System32/SDM
    python -m sdg.analyzer.populate_claims_denorm

Prerequisites:
    - sdm.member_denorm populated with member data
    - sdm.claims_denorm table created (run SDM_Claims_Denorm.sql first)
"""

import random
import numpy as np
import pandas as pd
import pyodbc
from datetime import datetime, timedelta

from sdg.analyzer.config import get_connection_string, SQL_SCHEMA
from sdg.analyzer.sql import read_sql

# ── Reference Data ────────────────────────────────────────────────────────────

ICD_CODES = {
    # Code: (Description, typical age range, gender bias)
    "Z00.00": ("Encounter for general adult medical exam", "adult", None),
    "Z23":    ("Encounter for immunization", "any", None),
    "J06.9":  ("Acute upper respiratory infection", "any", None),
    "J20.9":  ("Acute bronchitis, unspecified", "any", None),
    "M54.5":  ("Low back pain", "adult", None),
    "E11.9":  ("Type 2 diabetes without complications", "adult", None),
    "I10":    ("Essential hypertension", "adult", None),
    "J45.909":("Unspecified asthma, uncomplicated", "any", None),
    "K21.0":  ("GERD with esophagitis", "adult", None),
    "F41.1":  ("Generalized anxiety disorder", "adult", None),
    "R10.9":  ("Unspecified abdominal pain", "any", None),
    "N39.0":  ("Urinary tract infection", "adult", "F"),
    "M79.3":  ("Panniculitis, unspecified", "adult", None),
    "G43.909":("Migraine, unspecified", "adult", "F"),
    "L30.9":  ("Dermatitis, unspecified", "any", None),
    "R05.9":  ("Cough, unspecified", "any", None),
    "E78.5":  ("Hyperlipidemia, unspecified", "adult", None),
    "J02.9":  ("Acute pharyngitis, unspecified", "any", None),
    "Z12.31": ("Encounter for screening mammogram", "adult", "F"),
    "Z01.00": ("Encounter for exam of eyes", "any", None),
    "E03.9":  ("Hypothyroidism, unspecified", "adult", "F"),
    "D64.9":  ("Anemia, unspecified", "adult", None),
    "R51.9":  ("Headache, unspecified", "any", None),
    "J18.9":  ("Pneumonia, unspecified", "senior", None),
    "K58.9":  ("IBS without diarrhea", "adult", None),
    "M25.50": ("Pain in unspecified joint", "adult", None),
    "E55.9":  ("Vitamin D deficiency", "adult", None),
    "B34.9":  ("Viral infection, unspecified", "any", None),
    "R50.9":  ("Fever, unspecified", "any", None),
    "N18.3":  ("Chronic kidney disease, stage 3", "senior", None),
    "F32.1":  ("Major depressive disorder, moderate", "adult", None),
    "G47.33": ("Obstructive sleep apnea", "adult", "M"),
    "J44.1":  ("COPD with acute exacerbation", "senior", None),
    "E66.01": ("Morbid obesity due to excess calories", "adult", None),
    "I25.10": ("Atherosclerotic heart disease", "senior", "M"),
    "C50.911":("Malignant neoplasm of breast", "adult", "F"),
    "M17.11": ("Primary osteoarthritis, right knee", "senior", None),
    "Z96.641":("Presence of right artificial hip joint", "senior", None),
}

CPT_CODES = {
    "99213": ("Office visit, est patient, low complexity", 85, 150),
    "99214": ("Office visit, est patient, moderate", 120, 250),
    "99215": ("Office visit, est patient, high", 200, 400),
    "99203": ("Office visit, new patient, low", 150, 300),
    "99204": ("Office visit, new patient, moderate", 200, 450),
    "99395": ("Preventive visit, 18-39", 150, 350),
    "99396": ("Preventive visit, 40-64", 180, 400),
    "99385": ("Preventive visit, new, 18-39", 200, 450),
    "36415": ("Venipuncture", 10, 35),
    "80053": ("Comprehensive metabolic panel", 30, 80),
    "85025": ("CBC with differential", 15, 50),
    "80061": ("Lipid panel", 25, 75),
    "71046": ("Chest X-ray, 2 views", 50, 200),
    "73030": ("Shoulder X-ray", 40, 180),
    "77067": ("Screening mammography", 100, 350),
    "90471": ("Immunization admin, first", 15, 40),
    "90686": ("Flu vaccine, quadrivalent", 20, 60),
    "99283": ("ER visit, moderate severity", 250, 800),
    "99284": ("ER visit, high severity", 400, 1500),
    "99285": ("ER visit, high severity with threat", 600, 2500),
    "10060": ("Incision and drainage, abscess", 150, 500),
    "20610": ("Arthrocentesis, major joint", 100, 400),
    "43239": ("Upper GI endoscopy with biopsy", 300, 1200),
    "27447": ("Total knee replacement", 15000, 45000),
    "99291": ("Critical care, first 30-74 min", 500, 2000),
}

PROVIDER_SPECS = {
    "IM":  "Internal Medicine",
    "FP":  "Family Practice",
    "PD":  "Pediatrics",
    "OBG": "OB/GYN",
    "OR":  "Orthopedics",
    "CD":  "Cardiology",
    "GE":  "Gastroenterology",
    "ER":  "Emergency Medicine",
    "DR":  "Dermatology",
    "PS":  "Psychiatry",
    "PN":  "Pulmonology",
    "ON":  "Oncology",
    "NE":  "Neurology",
    "UR":  "Urology",
    "OP":  "Ophthalmology",
}

POS_CODES = {
    "11": "Office",
    "21": "Inpatient Hospital",
    "22": "Outpatient Hospital",
    "23": "Emergency Room",
    "31": "Skilled Nursing Facility",
    "81": "Independent Lab",
}

CLAIM_STATUSES = [
    ("01", 0.70),   # Approved / Paid
    ("04", 0.08),   # Denied
    ("09", 0.05),   # Pended
    ("02", 0.12),   # In Process
    ("07", 0.05),   # Adjusted
]


def generate_claims(n_claims=25000):
    conn_str = get_connection_string()
    conn = pyodbc.connect(conn_str)

    print("Reading member data from sdm.member_denorm...")
    members = read_sql(f"""
        SELECT DISTINCT
            MEME_CK, SBSB_CK, MEME_SEX,
            GRGR_CK, RTRIM(GRGR_NAME) AS GRGR_NAME, SGSG_CK,
            RTRIM(CSPD_CAT) AS CSPD_CAT,
            RTRIM(CSPI_ID) AS CSPI_ID,
            RTRIM(PLDS_DESC) AS PLDS_DESC,
            RTRIM(PDPD_ID) AS PDPD_ID,
            MEME_BIRTH_DT, MEME_REL
        FROM {SQL_SCHEMA}.member_denorm
    """, conn)
    print(f"  Found {len(members)} member-plan rows, {members['MEME_CK'].nunique()} unique members")

    if members.empty:
        print("ERROR: No members in member_denorm. Populate members first.")
        conn.close()
        return

    rng = np.random.default_rng(42)

    # Compute member ages
    ref = pd.Timestamp("2026-04-01")
    members["_age"] = ((ref - pd.to_datetime(members["MEME_BIRTH_DT"], errors="coerce")).dt.days / 365.25).fillna(40).astype(int)

    # Sample members for claims (some members have more claims than others — lognormal)
    claim_counts = np.clip(rng.lognormal(mean=1.0, sigma=0.8, size=len(members)), 1, 50).astype(int)
    total_available = claim_counts.sum()

    if total_available < n_claims:
        scale = n_claims / total_available + 1
        claim_counts = (claim_counts * scale).astype(int)

    rows = []
    for idx in range(len(members)):
        n = claim_counts[idx]
        for _ in range(n):
            rows.append(idx)
            if len(rows) >= n_claims:
                break
        if len(rows) >= n_claims:
            break

    sampled_indices = rows[:n_claims]
    sampled = members.iloc[sampled_indices].reset_index(drop=True)

    print(f"Generating {n_claims} mock claims...")

    # Generate claim IDs
    claim_ids = [f"CLM{i:09d}" for i in range(1, n_claims + 1)]

    # Select ICD codes weighted by age/gender
    icd_keys = list(ICD_CODES.keys())
    cpt_keys = list(CPT_CODES.keys())
    spec_keys = list(PROVIDER_SPECS.keys())
    pos_keys = list(POS_CODES.keys())
    status_codes = [s[0] for s in CLAIM_STATUSES]
    status_weights = [s[1] for s in CLAIM_STATUSES]

    all_rows = []
    for i in range(n_claims):
        m = sampled.iloc[i]
        age = int(m["_age"])
        gender = str(m.get("MEME_SEX", "M")).strip()

        # Pick diagnosis based on age
        if age < 18:
            icd_pool = [k for k, v in ICD_CODES.items() if v[1] in ("any",)]
        elif age >= 65:
            icd_pool = [k for k, v in ICD_CODES.items() if v[1] in ("any", "adult", "senior")]
        else:
            icd_pool = [k for k, v in ICD_CODES.items() if v[1] in ("any", "adult")]

        # Gender filter
        icd_pool = [k for k in icd_pool if ICD_CODES[k][2] is None or ICD_CODES[k][2] == gender]
        if not icd_pool:
            icd_pool = icd_keys

        primary_icd = random.choice(icd_pool)
        icd_desc = ICD_CODES[primary_icd][0]

        # Pick procedure
        cpt = random.choice(cpt_keys)
        cpt_desc, low_amt, high_amt = CPT_CODES[cpt]

        # Generate amounts
        charge = round(rng.uniform(low_amt, high_amt), 2)
        allowed = round(charge * rng.uniform(0.5, 0.95), 2)
        deductible = round(allowed * rng.uniform(0, 0.15), 2)
        copay = round(rng.choice([0, 15, 20, 25, 30, 40, 50, 75]), 2)
        coinsurance = round((allowed - deductible - copay) * rng.uniform(0, 0.2), 2)
        paid = round(max(0, allowed - deductible - copay - coinsurance), 2)
        disallow = round(max(0, charge - allowed), 2)
        discount = round(disallow * rng.uniform(0, 0.3), 2)
        patient_liab = round(deductible + copay + coinsurance, 2)

        # Claim dates — use Python datetime, not pandas Timestamp
        days_ago = int(rng.integers(1, 730))
        svc_date = datetime(2026, 4, 1) - timedelta(days=days_ago)
        svc_end = svc_date + timedelta(days=int(rng.choice([0, 0, 0, 1, 2, 3])))
        recd_date = svc_date + timedelta(days=int(rng.integers(1, 30)))
        paid_date = recd_date + timedelta(days=int(rng.integers(5, 60)))

        # Status
        status = rng.choice(status_codes, p=status_weights)

        # Network
        ntwk = rng.choice(["I", "I", "I", "I", "O"])

        # Claim type
        cl_type = rng.choice(["M", "M", "M", "M", "D"])

        # Provider
        spec = random.choice(spec_keys)
        prpr_id = f"PRPR{hash((spec, i)) % 99999:05d}"
        prpr_name = f"Dr. {PROVIDER_SPECS[spec]} {prpr_id[-4:]}"[:60]
        npi = f"1{rng.integers(100000000, 999999999)}"[:10]

        # Place of service
        pos = random.choice(pos_keys)

        # Number of diagnosis codes
        diag_count = int(rng.choice([1, 1, 1, 2, 2, 3, 4]))

        # Lines per claim (usually 1, sometimes 2-3)
        n_lines = int(rng.choice([1, 1, 1, 1, 2, 2, 3]))

        for line_no in range(1, n_lines + 1):
            if line_no > 1:
                # Additional lines get different procedure and lower amounts
                cpt = random.choice(cpt_keys)
                cpt_desc, low_amt, high_amt = CPT_CODES[cpt]
                charge = round(rng.uniform(low_amt, high_amt) * 0.6, 2)
                allowed = round(charge * rng.uniform(0.5, 0.95), 2)
                paid = round(max(0, allowed - deductible * 0.3), 2)

            row = {
                "CLCL_ID": claim_ids[i],
                "CDML_SEQ_NO": line_no,
                "CLCL_CL_TYPE": cl_type,
                "CLCL_CL_SUB_TYPE": "",
                "CLCL_CUR_STS": status,
                "CLST_MCTR_REAS": "",
                "CLCL_NTWK_IND": ntwk,
                "CLCL_INPUT_DT": recd_date,
                "CLCL_RECD_DT": recd_date,
                "CLCL_PAID_DT": paid_date if status == "01" else None,
                "CLCL_LOW_SVC_DT": svc_date,
                "CLCL_HIGH_SVC_DT": svc_end,
                "CLCL_TOT_CHG": charge if line_no == 1 else 0,
                "CLCL_TOT_PAYABLE": paid if line_no == 1 else 0,
                "MEME_CK": int(m["MEME_CK"]),
                "SBSB_CK": int(m["SBSB_CK"]),
                "CLCL_ME_AGE": age,
                "MEME_SEX": gender,
                "MEME_REL": str(m.get("MEME_REL", "")).strip(),
                "MEPE_FI": "",
                "GRGR_CK": int(m["GRGR_CK"]),
                "GRGR_NAME": str(m.get("GRGR_NAME", "")).strip(),
                "SGSG_CK": int(m["SGSG_CK"]) if pd.notna(m.get("SGSG_CK")) else None,
                "CSPD_CAT": str(m.get("CSPD_CAT", "")).strip(),
                "CSPI_ID": str(m.get("CSPI_ID", "")).strip(),
                "PLDS_DESC": str(m.get("PLDS_DESC", "")).strip(),
                "PDPD_ID": str(m.get("PDPD_ID", "")).strip(),
                "PDDS_PROD_TYPE": "",
                "IDCD_ID_PRIMARY": primary_icd,
                "IDCD_DESC_PRIMARY": icd_desc,
                "IDCD_ID_ADMIT": None,
                "CLMD_DIAG_COUNT": diag_count,
                "IPCD_ID": cpt,
                "IPCD_DESC": cpt_desc,
                "IPCD_TYPE": "CP",
                "CDML_UNITS": 1,
                "CDML_UNITS_ALLOW": 1,
                "PSCD_ID": pos,
                "RCRC_ID": "",
                "LOBD_ID": "",
                "PRPR_ID": prpr_id,
                "PRPR_NAME": prpr_name,
                "PRPR_NPI": str(npi),
                "PRPR_MCTR_SPEC": spec,
                "NWNW_ID": "",
                "CDML_CHG_AMT": charge,
                "CDML_ALLOW": allowed,
                "CDML_PAID_AMT": paid,
                "CDML_DED_AMT": deductible,
                "CDML_COPAY_AMT": copay,
                "CDML_COINS_AMT": coinsurance,
                "CDML_DISALL_AMT": disallow,
                "CDML_DISC_AMT": discount,
                "CDML_TOT_PA_LIAB": patient_liab,
                "CDML_FROM_DT": svc_date,
                "CDML_TO_DT": svc_end,
                "CDML_CUR_STS": status,
                "CLCL_EXT_AUTH_NO": "",
                "CDML_PRE_AUTH_IND": "",
                "CLCL_PRPR_ID_REF": "",
                "CLCL_PRPR_ID_PCP": "",
                "CLCL_PCP_IND": "",
            }
            all_rows.append(row)

    df = pd.DataFrame(all_rows)
    print(f"  Generated {len(df)} claim lines for {df['CLCL_ID'].nunique()} claims")
    print(f"  Members: {df['MEME_CK'].nunique()}")
    print(f"  Groups: {df['GRGR_CK'].nunique()}")
    print(f"  Plans: {df['CSPI_ID'].nunique()}")
    print(f"  Unique diagnoses: {df['IDCD_ID_PRIMARY'].nunique()}")
    print(f"  Unique procedures: {df['IPCD_ID'].nunique()}")
    print(f"  Avg charge: ${df['CDML_CHG_AMT'].mean():.2f}")
    print(f"  Approval rate: {(df['CLCL_CUR_STS'] == '01').mean():.0%}")

    # Insert into SQL Server
    print(f"\nInserting into {SQL_SCHEMA}.claims_denorm...")
    conn2 = pyodbc.connect(conn_str)
    cur = conn2.cursor()

    # Truncate existing
    cur.execute(f"TRUNCATE TABLE {SQL_SCHEMA}.claims_denorm")
    conn2.commit()

    # Batch insert
    cols = list(df.columns)
    placeholders = ",".join(["?"] * len(cols))
    col_str = ",".join(cols)
    insert_sql = f"INSERT INTO {SQL_SCHEMA}.claims_denorm ({col_str}) VALUES ({placeholders})"

    # Batch insert with explicit Python type conversion
    batch_size = 1000
    total = len(df)

    def to_python(val):
        """Convert any pandas/numpy type to native Python for pyodbc."""
        if val is None:
            return None
        if isinstance(val, float) and np.isnan(val):
            return None
        if hasattr(val, 'to_pydatetime'):  # pandas Timestamp
            try:
                return val.strftime('%Y-%m-%d %H:%M:%S')
            except Exception:
                return None
        if isinstance(val, datetime):
            return val.strftime('%Y-%m-%d %H:%M:%S')
        if isinstance(val, (np.integer,)):
            return int(val)
        if isinstance(val, (np.floating,)):
            v = float(val)
            return None if np.isnan(v) else v
        if isinstance(val, (np.bool_,)):
            return bool(val)
        if pd.isna(val):
            return None
        return val

    for start in range(0, total, batch_size):
        batch = df.iloc[start:start + batch_size]
        rows_to_insert = []
        for _, row in batch.iterrows():
            rows_to_insert.append(tuple(to_python(v) for v in row))
        cur.executemany(insert_sql, rows_to_insert)
        conn2.commit()
        pct = min(100, (start + batch_size) / total * 100)
        print(f"  Inserted {min(start + batch_size, total):,} / {total:,} ({pct:.0f}%)")

    cur.close()
    conn2.close()

    print(f"\nDone. {total:,} claim lines inserted into {SQL_SCHEMA}.claims_denorm")


if __name__ == "__main__":
    generate_claims()

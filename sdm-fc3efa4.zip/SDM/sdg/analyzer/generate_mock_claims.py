"""Generate mock claims Excel from member denorm.

Run this ONCE on the VDI to create data/claims_mock.xlsx.
Reads real MEME_CK, GRGR_CK, CSPI_ID etc from member_denorm
and generates realistic claims rows referencing those members.

Usage:
    cd C:/Windows/System32/SDM
    python -m sdg.analyzer.generate_mock_claims
"""

import random
import numpy as np
import pandas as pd
import pyodbc
from datetime import datetime, timedelta

from sdg.analyzer.config import get_connection_string, SQL_SCHEMA
from sdg.analyzer.sql import read_sql

# ── Reference data ────────────────────────────────────────────────────────────

# Common ICD-10 codes
ICD_CODES = [
    "Z00.00", "Z23", "J06.9", "J20.9", "M54.5", "E11.9", "I10", "J45.909",
    "K21.0", "F41.1", "R10.9", "N39.0", "M79.3", "G43.909", "L30.9",
    "R05.9", "E78.5", "J02.9", "Z12.31", "Z01.00", "E03.9", "D64.9",
    "R51.9", "J18.9", "K58.9", "M25.50", "E55.9", "Z87.891", "B34.9",
    "R50.9", "Z96.641", "N18.3", "F32.1", "G47.33", "J44.1", "E66.01",
    "I25.10", "Z79.4", "M17.11", "Z51.11", "C50.911", "Z85.3",
]

# Common CPT/Procedure codes
CPT_CODES = [
    "99213", "99214", "99215", "99203", "99204", "99211", "99212",
    "99395", "99396", "99385", "99386",  # Preventive
    "90471", "90472", "90686", "90688",  # Immunization
    "36415", "80053", "85025", "80061",  # Lab
    "71046", "73030", "77067",           # Radiology
    "99243", "99244",                     # Consultation
    "99281", "99282", "99283", "99284", "99285",  # ER
    "10060", "20610", "43239",           # Surgical
]

# Drug codes (NDC-like)
DRUG_CODES = [
    "00002-7140", "00006-0277", "00074-3799", "00078-0357", "00093-7180",
    "00173-0682", "00228-2001", "00310-0175", "00378-1800", "00456-2010",
    "00591-0405", "00603-3215", "00781-1506", "49502-0696", "55111-0467",
    "", "", "", "", "",  # 50% no drug code (medical claims)
]

CLAIM_STATUSES = ["A", "A", "A", "A", "A", "A", "A", "D", "P", "P"]  # 70% approved
NETWORK_IND = ["I", "I", "I", "I", "O"]  # 80% in-network
CLAIM_TYPES = ["M", "M", "M", "M", "D"]  # 80% medical, 20% dental

LOB_CODES = [
    "OHMCD", "OHMCR", "OHEXC", "OHDNL", "GAEXC", "GAMCD", "KYEXC",
    "KYMCD", "INMCD", "WVMCD",
]


def generate_mock_claims(n_claims=20000):
    """Generate mock claims joined to real member denorm data."""
    conn_str = get_connection_string()
    conn = pyodbc.connect(conn_str)

    # Read real member data for joining
    print("Reading member data...")
    members = read_sql(f"""
        SELECT DISTINCT
            MEME_CK, MEME_BIRTH_DT, MEME_SEX, SBSB_CK,
            GRGR_CK, GRGR_NAME, CSPI_ID, RTRIM(PLDS_DESC) AS PLDS_DESC
        FROM {SQL_SCHEMA}.member_denorm
    """, conn)
    conn.close()

    print(f"  Found {len(members)} member-plan combinations")

    # Sample members with replacement for claims
    rng = np.random.default_rng(42)
    sampled = members.sample(n=n_claims, replace=True, random_state=42).reset_index(drop=True)

    print(f"Generating {n_claims} mock claims...")

    # Build claims
    claims = pd.DataFrame()
    claims["MEME_CK"] = sampled["MEME_CK"].values
    claims["MEME_BIRTH_DT"] = sampled["MEME_BIRTH_DT"].values
    claims["MEME_SEX"] = sampled["MEME_SEX"].values
    claims["SBSB_CK"] = sampled["SBSB_CK"].values
    claims["GRGR_CK"] = sampled["GRGR_CK"].values
    claims["GRGR_NAME"] = sampled["GRGR_NAME"].values
    claims["CSPI_ID"] = sampled["CSPI_ID"].values
    claims["PLDS_DESC"] = sampled["PLDS_DESC"].values

    # Generate claims-specific fields
    claims["Procedure_CD"] = [random.choice(CPT_CODES) for _ in range(n_claims)]
    claims["IDCD_ID"] = [random.choice(ICD_CODES) for _ in range(n_claims)]
    claims["LOBD_ID"] = [random.choice(LOB_CODES) for _ in range(n_claims)]
    claims["CLM_STATUS"] = [random.choice(CLAIM_STATUSES) for _ in range(n_claims)]
    claims["AGRG_ID"] = [random.choice(DRUG_CODES) for _ in range(n_claims)]
    claims["CLCL_NTWK_IND"] = [random.choice(NETWORK_IND) for _ in range(n_claims)]
    claims["Network_Indicator"] = claims["CLCL_NTWK_IND"].map({"I": "In-Network", "O": "Out-Network"})
    claims["CLCL_CL_TYPE"] = [random.choice(CLAIM_TYPES) for _ in range(n_claims)]
    claims["Claim_Type"] = claims["CLCL_CL_TYPE"].map({"M": "Medical", "D": "Dental"})

    # Generate amounts
    base_amounts = rng.lognormal(mean=5.5, sigma=1.2, size=n_claims)
    claims["Claim_Amount"] = np.round(base_amounts, 2)
    claims["Deductible_Amount"] = np.round(base_amounts * rng.uniform(0.0, 0.3, size=n_claims), 2)
    claims["Net_Amount"] = np.round(claims["Claim_Amount"] - claims["Deductible_Amount"], 2)

    # Generate claim dates (last 2 years)
    end_date = datetime(2026, 4, 1)
    start_date = end_date - timedelta(days=730)
    random_days = rng.integers(0, 730, size=n_claims)
    claims["Claim_Date"] = [start_date + timedelta(days=int(d)) for d in random_days]

    # Reorder columns to match the spec
    col_order = [
        "Procedure_CD", "LOBD_ID", "IDCD_ID", "CLM_STATUS",
        "MEME_CK", "MEME_BIRTH_DT", "MEME_SEX",
        "AGRG_ID", "CLCL_NTWK_IND", "Network_Indicator",
        "CLCL_CL_TYPE", "Claim_Type",
        "CSPI_ID", "PLDS_DESC", "GRGR_CK", "GRGR_NAME", "SBSB_CK",
        "Claim_Amount", "Deductible_Amount", "Net_Amount", "Claim_Date",
    ]
    claims = claims[col_order]

    # Save
    out_path = "data/claims_mock.xlsx"
    claims.to_excel(out_path, index=False, sheet_name="Claims")
    print(f"Saved {len(claims)} claims to {out_path}")
    print(f"  Unique members: {claims['MEME_CK'].nunique()}")
    print(f"  Groups: {claims['GRGR_CK'].nunique()}")
    print(f"  Plans: {claims['CSPI_ID'].nunique()}")
    print(f"  LOBs: {claims['LOBD_ID'].nunique()}")
    print(f"  Claim types: Medical={len(claims[claims['CLCL_CL_TYPE']=='M'])}, Dental={len(claims[claims['CLCL_CL_TYPE']=='D'])}")
    print(f"  Avg claim amount: ${claims['Claim_Amount'].mean():.2f}")


if __name__ == "__main__":
    generate_mock_claims()

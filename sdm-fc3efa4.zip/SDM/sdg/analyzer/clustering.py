"""K-means clustering with auto-k selection and label-based mode."""

import numpy as np

from .config import CONTINUOUS_WEIGHT, LABEL_CLUSTER_COLUMNS


# Silhouette computes every pairwise distance, so it costs O(n^2). Above a
# few thousand points that dominates everything else in this module. Scoring a
# fixed-size sample estimates the same value closely enough to choose k, and
# caps the cost regardless of subset size. random_state keeps it deterministic.
SILHOUETTE_SAMPLE = 5000

# n_init controls how many random restarts K-Means tries. The sweep below only
# needs a good-enough fit to compare k values against each other, so it uses
# fewer restarts; the final fit that produces the clusters people actually see
# still uses the full count.
SWEEP_N_INIT = 3
FINAL_N_INIT = 10


def _silhouette(X, labels):
    """Silhouette score, sampled so the cost stays flat as n grows."""
    from sklearn.metrics import silhouette_score
    return silhouette_score(
        X, labels,
        sample_size=min(SILHOUETTE_SAMPLE, X.shape[0]),
        random_state=42,
    )


def build_features(data, continuous_cols=None):
    """The clustering's input: the features chosen on the Config screen.

    Numbers standardized and weighted (CONTINUOUS_WEIGHT), lists one-hot.
    `continuous_cols` is kept for callers that pass it; the choice decides.
    """
    from .services.discovery_features import matrix

    X = matrix(data, "members", CONTINUOUS_WEIGHT)
    if X is None:
        X = np.zeros((len(data), 1))
    return X, None


# The k values the member sweep considers.
#
# Measured over all 42 member combinations in SDM_Platform: the sweep chose k=3
# eighteen times and k=4 twenty-four times, and never once chose anything above
# 4. Values 7-10 were 27 KMeans fits per combination that could not win, and the
# sweep is ~85% of a discovery walk. Cutting to 2-6 keeps two values of headroom
# above the highest ever selected and measured 1.76x faster with an identical
# silhouette to four decimal places, the same k on every combination, and the
# same cluster count.
#
# Claims keeps the wider sweep and sets its own range — see CLAIMS_K_MAX in
# api/claims_service.py. There the ceiling is real: four combinations select
# k=7 or k=10, so the same narrowing would cost them clusters.
#
# This is a property of the data, not of the algorithm. A book whose members
# genuinely split into eight groups would want the range back, and the symptom
# would be the sweep always landing on the top of the range.
MEMBER_K_RANGE = range(2, 7)


def find_optimal_k(X, k_range=MEMBER_K_RANGE):
    """Silhouette sweep over k_range, return best k."""
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score

    best_k = 2
    best_score = -1
    for k in k_range:
        if k >= X.shape[0]:
            break
        km = KMeans(n_clusters=k, n_init=SWEEP_N_INIT, random_state=42)
        labels = km.fit_predict(X)
        if len(set(labels)) < 2:
            continue
        try:
            score = _silhouette(X, labels)
        except ValueError:
            continue
        if score > best_score:
            best_score = score
            best_k = k
    return best_k


def select_label_column(filters_used):
    """Pick the most specific label column based on which filters were applied."""
    if 'pdpd_id' in filters_used:
        return 'product'
    if 'cspd_cat' in filters_used:
        return 'plan'
    if 'cspi_id' in filters_used:
        return 'plan'
    return 'group'


def discover_clusters(data, labels_df, k=None, use_labels=False, filters_used=None):
    """Run clustering and return (assignments, metrics)."""
    from sklearn.cluster import KMeans
    from sklearn.metrics import adjusted_rand_score, silhouette_score
    n = len(data)
    metrics = {}

    # Guard: too few members for meaningful clustering
    if n < 8:
        assignments = np.zeros(n, dtype=int)
        metrics['method'] = 'single_cluster'
        metrics['reason'] = f'n={n} < 8, too few for clustering'
        return assignments, metrics

    X, _ = build_features(data)

    if use_labels and labels_df is not None and not labels_df.empty:
        level = select_label_column(filters_used or {})
        col = LABEL_CLUSTER_COLUMNS[level]

        # Join labels to data on MEME_CK
        label_lookup = labels_df.drop_duplicates(subset=['MEME_CK'])[['MEME_CK', col]].copy()
        merged = data[['MEME_CK']].merge(label_lookup, on='MEME_CK', how='left')
        assignments = merged[col].fillna(-1).astype(int).values

        # Re-index assignments to 0..n_clusters-1
        unique_labels = sorted(set(assignments[assignments >= 0]))
        label_map = {old: new for new, old in enumerate(unique_labels)}
        assignments = np.array([label_map.get(a, -1) for a in assignments])

        # Validate with K-means
        n_clusters = len(unique_labels)
        if n_clusters >= 2:
            km = KMeans(n_clusters=n_clusters, n_init=FINAL_N_INIT, random_state=42)
            km_labels = km.fit_predict(X)
            ari = adjusted_rand_score(assignments, km_labels)
            try:
                sil = _silhouette(X, assignments)
            except ValueError:
                sil = 0.0
            metrics['ari'] = round(ari, 4)
            metrics['silhouette'] = round(sil, 4)

        metrics['method'] = 'labels'
        metrics['level'] = level
        metrics['n_clusters'] = n_clusters
        return assignments, metrics

    # K-means mode
    if k is None:
        k = find_optimal_k(X)
        metrics['k_selection'] = 'silhouette'
    else:
        metrics['k_selection'] = 'user_specified'

    km = KMeans(n_clusters=k, n_init=FINAL_N_INIT, random_state=42)
    assignments = km.fit_predict(X)

    try:
        sil = _silhouette(X, assignments) if len(set(assignments)) >= 2 else 0.0
    except ValueError:
        sil = 0.0
    metrics['method'] = 'kmeans'
    metrics['n_clusters'] = k
    metrics['silhouette'] = round(sil, 4)

    return assignments, metrics

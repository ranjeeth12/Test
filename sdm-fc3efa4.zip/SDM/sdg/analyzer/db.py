"""SQL Server backend for pattern storage, rules, tags, and keyword vocabulary.

SQL Server only - no fallback. All tables created by SDM_SQL_Server_Setup.sql.
"""

import json
import time

import pyodbc
from contextlib import contextmanager

from .config import get_connection_string, SQL_SCHEMA

_SCHEMA = SQL_SCHEMA


# ── Inserting into tables that may not be this tool's ─────────────────────────
#
# On a customer's side the store's tables are theirs: an `id` may be a plain
# int rather than an IDENTITY, and `created_at` may have no default. Every
# insert into such a table goes through insert_row, which assigns the id when
# the database will not and stamps the times when nothing else does. What a
# table is like is read once per process.

_TABLE_SHAPE: dict[str, tuple[bool, set[str]]] = {}


def _table_shape(cur, table: str) -> tuple[bool, set[str]]:
    """Whether `table`.id is an identity column, and the table's columns."""
    if table not in _TABLE_SHAPE:
        try:
            cur.execute(
                "SELECT c.name, c.is_identity FROM sys.columns c "
                "WHERE c.object_id = OBJECT_ID(?)", (table,))
            rows = cur.fetchall()
        except Exception:
            # Nothing to read the table's shape from: insert as the database
            # would want by default, and let it assign the id.
            return True, set()
        columns = {str(r[0]) for r in rows}
        identity = any(str(r[0]).lower() == "id" and bool(r[1]) for r in rows)
        _TABLE_SHAPE[table] = (identity, columns)
    return _TABLE_SHAPE[table]


def insert_row(cur, table: str, values: dict) -> int:
    """Insert one row into a store table and return its id.

    Where `id` is an identity the database assigns it. Where it is a plain int
    the next one is taken under an update lock held to the end of the
    transaction, so two saves at once cannot take the same id.
    """
    identity, columns = _table_shape(cur, table)
    row = {k: v for k, v in values.items() if not columns or k in columns}
    stamped = [c for c in ("created_at", "updated_at") if c in columns and c not in row]
    names = list(row) + stamped
    marks = ["?"] * len(row) + ["SYSDATETIME()"] * len(stamped)
    params = list(row.values())
    if identity or "id" not in columns:
        cur.execute(
            f"INSERT INTO {table} ({', '.join(names)}) OUTPUT INSERTED.id "
            f"VALUES ({', '.join(marks)})", *params)
        got = cur.fetchone()
        return int(got[0]) if got else 0
    cur.execute(f"SELECT ISNULL(MAX(id), 0) + 1 FROM {table} WITH (UPDLOCK, HOLDLOCK)")
    new_id = int(cur.fetchone()[0])
    cur.execute(
        f"INSERT INTO {table} (id, {', '.join(names)}) VALUES (?, {', '.join(marks)})",
        new_id, *params)
    return new_id


@contextmanager
def get_connection():
    """Yield a pyodbc connection to SQL Server."""
    try:
        conn = pyodbc.connect(get_connection_string(), autocommit=False)
    except pyodbc.Error as e:
        raise ConnectionError(
            f"Cannot connect to SQL Server. Check config.py SQL_SERVER value. Error: {e}"
        ) from e
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _dict_rows(cursor):
    columns = [col[0] for col in cursor.description]
    return [dict(zip(columns, row)) for row in cursor.fetchall()]


# -- Pattern CRUD -------------------------------------------------------------

def _make_combo_key(combo):
    """Identity of a combination, independent of any clustering run.

    This is pattern_key without the trailing cluster id, which is exactly what
    SDM_Migration_Pattern_Provenance.sql back-fills into combo_key. Certification
    matches on it, so a pattern stored without one can never be certified — and
    discovery used to store every pattern that way, leaving the migration as the
    only thing that ever populated the column.

    The three keys are derived from one place so they cannot drift apart.
    """
    return "|".join([
        str(combo.get("grgr_ck") or "ALL"),
        str(combo.get("cspd_cat") or "ALL"),
        str(combo.get("cspi_id") or "ALL"),
        str(combo.get("pdpd_id") or "ALL"),
    ])


def _make_pattern_key(combo, cluster_id):
    return f"{_make_combo_key(combo)}|{cluster_id}"


def _make_combo_prefix(combo):
    """Build pattern_key prefix from a filter combo (without cluster_id)."""
    return _make_combo_key(combo) + "|"


def get_patterns_for_combo(filters_used):
    """Find all persisted patterns matching a filter combo.

    Returns list of pattern dicts if found, empty list otherwise.
    Used by profilers to skip clustering when system discovery already ran.
    """
    combo = {
        "grgr_ck": filters_used.get("grgr_ck"),
        "cspd_cat": filters_used.get("cspd_cat"),
        "cspi_id": filters_used.get("cspi_id"),
        "pdpd_id": filters_used.get("pdpd_id"),
    }
    prefix = _make_combo_prefix(combo)
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"""
            SELECT * FROM {_SCHEMA}.patterns
            WHERE pattern_key LIKE ?
            ORDER BY member_count DESC
        """, (prefix + "%",))
        return _dict_rows(cur)


def upsert_pattern(combo, cluster_id, contextual_name, member_count,
                    pct_of_pop, silhouette, profile=None, ai_summary=None,
                    conn=None, pattern_key=None):
    """Insert or update one pattern.

    Pass `conn` to reuse an open connection. A discovery walk persists several
    patterns per combination — hundreds per run — and opening a fresh
    connection for each one cost more than the upsert itself.
    """
    if conn is not None:
        return _upsert_pattern_on(conn, combo, cluster_id, contextual_name,
                                  member_count, pct_of_pop, silhouette,
                                  profile, ai_summary, pattern_key)
    with get_connection() as owned:
        return _upsert_pattern_on(owned, combo, cluster_id, contextual_name,
                                  member_count, pct_of_pop, silhouette,
                                  profile, ai_summary, pattern_key)


def _upsert_pattern_on(conn, combo, cluster_id, contextual_name, member_count,
                       pct_of_pop, silhouette, profile=None, ai_summary=None,
                       pattern_key=None):
    # A saved pattern brings its own key. The hierarchy-and-cluster key names
    # a slot in a discovery walk, and a pattern saved from an analysis with a
    # chosen k, or from chosen records, is not that slot -- sharing the key
    # would overwrite one with the other.
    key = pattern_key or _make_pattern_key(combo, cluster_id)
    combo_key = _make_combo_key(combo)
    profile_json = json.dumps(profile, default=str) if profile else None
    if True:
        cur = conn.cursor()
        cur.execute(f"SELECT id FROM {_SCHEMA}.patterns WHERE pattern_key = ?", (key,))
        existing = cur.fetchone()
        if existing:
            cur.execute(f"""
                UPDATE {_SCHEMA}.patterns SET
                    contextual_name = ?, member_count = ?, pct_of_pop = ?,
                    silhouette = ?, profile_json = ?, combo_key = ?,
                    ai_summary = COALESCE(?, ai_summary), updated_at = GETDATE()
                WHERE pattern_key = ?
            """, (contextual_name, member_count, pct_of_pop, silhouette,
                  profile_json, combo_key, ai_summary, key))
            return existing[0]
        else:
            return insert_row(cur, f"{_SCHEMA}.patterns", {
                "pattern_key": key, "combo_key": combo_key,
                "contextual_name": contextual_name,
                "grgr_ck": json.dumps(combo.get("grgr_ck")),
                "cspd_cat": json.dumps(combo.get("cspd_cat")),
                "cspi_id": json.dumps(combo.get("cspi_id")),
                "pdpd_id": json.dumps(combo.get("pdpd_id")),
                "grgr_name": combo.get("grgr_name", ""),
                "cspd_cat_desc": combo.get("cspd_cat_desc", ""),
                "plds_desc": combo.get("plds_desc", ""),
                "pdds_desc": combo.get("pdds_desc", ""),
                "cluster_id": cluster_id, "member_count": member_count,
                "pct_of_pop": pct_of_pop, "silhouette": silhouette,
                "profile_json": profile_json, "ai_summary": ai_summary,
            })


def get_pattern(pattern_id):
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {_SCHEMA}.patterns WHERE id = ?", (pattern_id,))
        if cur.description is None:
            return None
        row = cur.fetchone()
        if row is None:
            return None
        columns = [col[0] for col in cur.description]
        return dict(zip(columns, row))


# ── Pattern reads, served from the temp-file cache ───────────────────────────
#
# get_all_patterns is the one pattern read worth caching: 29.6 ms over 609 rows,
# and every screen that lists patterns calls it — the claims mapping dropdown,
# the catalog, Story matching, saved patterns. It returns both domains, since
# members and claims share this table, so one cached copy serves both.
#
# get_pattern (1.0 ms) and get_saved_patterns (1.4 ms) are left uncached: both
# are already cheaper than the freshness check below, so caching them would cost
# more than it saved.
#
# Freshness is a signature, not a TTL. "Recent" is not good enough here — saving
# a pattern and not seeing it appear is precisely the bug this table has
# produced before. The signature is a 1.9 ms aggregate that moves on every write
# path in the codebase: COUNT(*) catches inserts and deletes, COUNT(saved_at)
# catches save and unsave (which touch neither updated_at nor the row count),
# MAX(updated_at) catches edits, and MAX(id) catches an insert that replaces a
# delete. Any write therefore produces a different key and the next read misses.

_PATTERNS_NS = "patterns.all"


def _disk_cache():
    """The API's two-tier cache, if this process has it.

    Imported lazily and defensively: sdg.analyzer is used on its own by the
    Streamlit pages, where the api package is not on the path. Without it these
    functions simply query every time, exactly as they used to.
    """
    try:
        from api import disk_cache
        return disk_cache
    except Exception:
        return None


def patterns_signature():
    """Cheap fingerprint of the patterns table — changes on any write."""
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"""
            SELECT COUNT(*), COUNT(saved_at), MAX(updated_at), MAX(id)
            FROM {_SCHEMA}.patterns
        """)
        return tuple(str(v) for v in cur.fetchone())


def _read_all_patterns():
    with get_connection() as conn:
        cur = conn.cursor()
        # id breaks ties. 172 member_count values are shared by more than one
        # pattern here (the largest group is 8), and without a tiebreaker SQL
        # Server is free to order them differently between queries — which a
        # paginated caller sees as rows repeated on one page and missing from
        # the next.
        cur.execute(
            f"SELECT * FROM {_SCHEMA}.patterns ORDER BY member_count DESC, id")
        return _dict_rows(cur)


def get_all_patterns():
    dc = _disk_cache()
    if dc is None:
        return _read_all_patterns()

    try:
        key = dc.make_key(_PATTERNS_NS, patterns_signature())
        hit = dc.get(key)
        if hit is not None:
            return hit
    except Exception:
        # A cache that cannot answer must never stop the read.
        return _read_all_patterns()

    started = time.perf_counter()
    rows = _read_all_patterns()
    try:
        dc.put(key, rows, ttl=1800, label=_PATTERNS_NS, namespace=_PATTERNS_NS,
               cost_seconds=time.perf_counter() - started)
    except Exception:
        pass
    return rows


def get_patterns_for_members(meme_cks):
    return get_all_patterns()


# -- Saved Patterns -----------------------------------------------------------

def pattern_id_for_key(pattern_key):
    """The id of the pattern stored under this key, or None."""
    with get_connection() as conn:
        row = conn.cursor().execute(
            f"SELECT id FROM {_SCHEMA}.patterns WHERE pattern_key = ?", (pattern_key,)
        ).fetchone()
    return int(row[0]) if row else None


def mark_pattern_saved(pattern_id, saved_by="user"):
    """Mark a pattern as saved/favorited."""
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"""
            UPDATE {_SCHEMA}.patterns
            SET saved_by = ?, saved_at = GETDATE()
            WHERE id = ?
        """, (saved_by, pattern_id))


def mark_pattern_origin(pattern_id, origin, created_by="user"):
    """Record where a pattern came from: found by analysis, or defined."""
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"""
            UPDATE {_SCHEMA}.patterns
            SET origin = ?, created_by = ?
            WHERE id = ?
        """, (origin, created_by, pattern_id))


def mark_pattern_unsaved(pattern_id):
    """Remove saved status from a pattern."""
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"""
            UPDATE {_SCHEMA}.patterns
            SET saved_by = NULL, saved_at = NULL
            WHERE id = ?
        """, (pattern_id,))


def get_saved_patterns():
    """Fetch all saved patterns ordered by saved_at desc."""
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"""
            SELECT * FROM {_SCHEMA}.patterns
            WHERE saved_by IS NOT NULL
            ORDER BY saved_at DESC
        """)
        return _dict_rows(cur)


def is_pattern_saved(pattern_id):
    """Check if a specific pattern is saved."""
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT saved_by FROM {_SCHEMA}.patterns WHERE id = ? AND saved_by IS NOT NULL", (pattern_id,))
        return cur.fetchone() is not None


def save_pattern_from_profiler(combo, cluster_id, contextual_name, member_count,
                                pct_of_pop, silhouette, profile=None,
                                ai_summary=None, saved_by="user"):
    """Upsert a pattern and mark it as saved. Returns pattern ID.

    Handles dedup via pattern_key — if the exact hierarchy + cluster combo
    already exists, it updates and marks saved. Otherwise inserts new.
    """
    pattern_id = upsert_pattern(
        combo, cluster_id, contextual_name, member_count,
        pct_of_pop, silhouette, profile, ai_summary,
    )
    if pattern_id:
        mark_pattern_saved(pattern_id, saved_by)
    return pattern_id


# -- Pattern Rules ------------------------------------------------------------

def save_rule(pattern_id, rule_name, rule_text, member_count=None, created_by="system"):
    with get_connection() as conn:
        cur = conn.cursor()
        insert_row(cur, f"{_SCHEMA}.pattern_rules", {
            "pattern_id": pattern_id, "rule_name": rule_name, "rule_text": rule_text,
            "member_count": member_count, "created_by": created_by,
        })


def get_rules(pattern_id=None):
    with get_connection() as conn:
        cur = conn.cursor()
        if pattern_id:
            cur.execute(f"SELECT * FROM {_SCHEMA}.pattern_rules WHERE pattern_id = ? ORDER BY created_at DESC", (pattern_id,))
        else:
            cur.execute(f"SELECT * FROM {_SCHEMA}.pattern_rules ORDER BY created_at DESC")
        return _dict_rows(cur)


# -- Pattern Tags -------------------------------------------------------------

def add_tags(pattern_id, tags, source="auto"):
    with get_connection() as conn:
        cur = conn.cursor()
        for tag in tags:
            tag_clean = tag.lower().strip()
            cur.execute(f"SELECT id FROM {_SCHEMA}.pattern_tags WHERE pattern_id = ? AND tag = ?", (pattern_id, tag_clean))
            if cur.fetchone() is None:
                insert_row(cur, f"{_SCHEMA}.pattern_tags",
                           {"pattern_id": pattern_id, "tag": tag_clean, "source": source})


def get_tags(pattern_id):
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT tag, source, confirmed_by FROM {_SCHEMA}.pattern_tags WHERE pattern_id = ? ORDER BY tag", (pattern_id,))
        return _dict_rows(cur)


def get_tags_batch(pattern_ids):
    """Fetch tags for multiple patterns in one query. Returns dict of pattern_id → [tags]."""
    if not pattern_ids:
        return {}
    safe_ids = ",".join(str(int(x)) for x in pattern_ids)
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"""
            SELECT pattern_id, tag, source, confirmed_by
            FROM {_SCHEMA}.pattern_tags
            WHERE pattern_id IN ({safe_ids})
            ORDER BY pattern_id, tag
        """)
        rows = _dict_rows(cur)

    result = {}
    for row in rows:
        pid = row["pattern_id"]
        if pid not in result:
            result[pid] = []
        result[pid].append(row)
    return result


def confirm_tag(pattern_id, tag, confirmed_by="SME"):
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"UPDATE {_SCHEMA}.pattern_tags SET confirmed_by = ?, confirmed_at = GETDATE() WHERE pattern_id = ? AND tag = ?", (confirmed_by, pattern_id, tag.lower().strip()))


def search_patterns_by_tags(tags):
    if not tags:
        return []
    clean = [t.lower().strip() for t in tags]
    placeholders = ",".join("?" * len(clean))
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"""
            SELECT p.*, COUNT(pt.tag) as match_count
            FROM {_SCHEMA}.patterns p
            JOIN {_SCHEMA}.pattern_tags pt ON p.id = pt.pattern_id
            WHERE pt.tag IN ({placeholders})
            GROUP BY p.id, p.pattern_key, p.contextual_name, p.grgr_ck,
                     p.cspd_cat, p.cspi_id, p.pdpd_id, p.grgr_name,
                     p.cspd_cat_desc, p.plds_desc, p.pdds_desc, p.cluster_id, p.member_count,
                     p.pct_of_pop, p.silhouette, p.profile_json, p.ai_summary,
                     p.created_at, p.updated_at, p.saved_by, p.saved_at
            ORDER BY COUNT(pt.tag) DESC, p.member_count DESC
        """, clean)
        return _dict_rows(cur)


# -- Tag Vocabulary -----------------------------------------------------------

def add_synonym(canonical_tag, synonym, category=None):
    with get_connection() as conn:
        cur = conn.cursor()
        canonical = canonical_tag.lower()
        syn = synonym.lower()
        cur.execute(f"SELECT id FROM {_SCHEMA}.tag_vocabulary WHERE canonical_tag = ? AND synonym = ?", (canonical, syn))
        if cur.fetchone() is None:
            insert_row(cur, f"{_SCHEMA}.tag_vocabulary",
                       {"canonical_tag": canonical, "synonym": syn, "category": category})


def resolve_synonyms(terms):
    if not terms:
        return []
    clean = [t.lower().strip() for t in terms]
    resolved = []
    with get_connection() as conn:
        cur = conn.cursor()
        for term in clean:
            cur.execute(f"SELECT canonical_tag FROM {_SCHEMA}.tag_vocabulary WHERE synonym = ?", (term,))
            row = cur.fetchone()
            resolved.append(row[0] if row else term)
    return list(set(resolved))


def get_vocabulary():
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {_SCHEMA}.tag_vocabulary ORDER BY canonical_tag, synonym")
        return _dict_rows(cur)


def seed_default_vocabulary():
    defaults = [
        ("pediatric", "pediatric", "age"), ("pediatric", "child", "age"),
        ("pediatric", "children", "age"), ("pediatric", "minor", "age"),
        ("pediatric", "under-18", "age"),
        ("adult", "adult", "age"), ("adult", "working-age", "age"),
        ("senior", "senior", "age"), ("senior", "elderly", "age"),
        ("senior", "65+", "age"), ("senior", "medicare-age", "age"),
        ("new-member", "new-member", "tenure"), ("new-member", "new", "tenure"),
        ("new-member", "recent", "tenure"),
        ("long-term", "long-term", "tenure"), ("long-term", "established", "tenure"),
        ("long-term", "loyal", "tenure"),
        ("family", "family", "family"), ("family", "with-dependents", "family"),
        ("single", "single", "family"), ("single", "individual", "family"),
        ("single", "no-dependents", "family"),
        ("dental", "dental", "plan"), ("dental", "dental-plan", "plan"),
        ("medical", "medical", "plan"), ("medical", "med", "plan"),
        ("vision", "vision", "plan"), ("vision", "eye", "plan"),
        ("medicaid", "medicaid", "lob"), ("medicare", "medicare", "lob"),
        ("medicare-advantage", "medicare-advantage", "lob"),
        ("medicare-advantage", "ma", "lob"),
        ("exchange", "exchange", "lob"), ("exchange", "marketplace", "lob"),
        ("exchange", "aca", "lob"),
        ("edge-case", "edge-case", "quality"), ("edge-case", "rare", "quality"),
        ("edge-case", "anomaly", "quality"), ("edge-case", "outlier", "quality"),
        ("edge-case", "unusual", "quality"),
        ("high-volume", "high-volume", "quality"), ("high-volume", "common", "quality"),
        ("high-volume", "dominant", "quality"),
        ("ohio", "ohio", "state"), ("ohio", "oh", "state"),
        ("kentucky", "kentucky", "state"), ("kentucky", "ky", "state"),
        ("indiana", "indiana", "state"), ("indiana", "in", "state"),
        ("georgia", "georgia", "state"), ("georgia", "ga", "state"),
        ("west-virginia", "west-virginia", "state"), ("west-virginia", "wv", "state"),
    ]
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            for canonical, synonym, category in defaults:
                canonical = canonical.lower()
                synonym = synonym.lower()
                cur.execute(f"SELECT id FROM {_SCHEMA}.tag_vocabulary WHERE canonical_tag = ? AND synonym = ?",
                            (canonical, synonym))
                if cur.fetchone() is None:
                    insert_row(cur, f"{_SCHEMA}.tag_vocabulary",
                               {"canonical_tag": canonical, "synonym": synonym,
                                "category": category})
    except Exception:
        pass


# -- Generation Log -----------------------------------------------------------

def log_generation(pattern_ids, data_type, volume, output_path=None,
                   weighting=None, requested_by="user"):
    with get_connection() as conn:
        cur = conn.cursor()
        insert_row(cur, f"{_SCHEMA}.generation_log", {
            "pattern_ids": json.dumps(pattern_ids), "data_type": data_type,
            "volume": volume, "output_path": output_path,
            "weighting": json.dumps(weighting) if weighting else None,
            "requested_by": requested_by,
        })


def get_generation_history(limit=50):
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT TOP (?) * FROM {_SCHEMA}.generation_log ORDER BY created_at DESC", (limit,))
        return _dict_rows(cur)


# -- Generation Rules ---------------------------------------------------------

def upsert_generation_rule(field_name, field_label, field_category="id",
                            gen_method="sequential", data_type="alphanumeric",
                            length=10, prefix="", postfix="", start_value=1,
                            domain="", format_pattern="", lookup_source="",
                            active=True, updated_by="system"):
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT id FROM {_SCHEMA}.generation_rules WHERE field_name = ?", (field_name,))
        existing = cur.fetchone()
        if existing:
            cur.execute(f"""
                UPDATE {_SCHEMA}.generation_rules SET
                    field_label = ?, field_category = ?, gen_method = ?, data_type = ?,
                    length = ?, prefix = ?, postfix = ?, start_value = ?,
                    domain = ?, format_pattern = ?, lookup_source = ?,
                    active = ?, updated_by = ?, updated_at = GETDATE()
                WHERE field_name = ?
            """, (field_label, field_category, gen_method, data_type,
                  length, prefix, postfix, start_value,
                  domain, format_pattern, lookup_source,
                  1 if active else 0, updated_by, field_name))
        else:
            insert_row(cur, f"{_SCHEMA}.generation_rules", {
                "field_name": field_name, "field_label": field_label,
                "field_category": field_category, "gen_method": gen_method,
                "data_type": data_type, "length": length, "prefix": prefix,
                "postfix": postfix, "start_value": start_value, "domain": domain,
                "format_pattern": format_pattern, "lookup_source": lookup_source,
                "active": 1 if active else 0, "updated_by": updated_by,
            })


def get_generation_rules():
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {_SCHEMA}.generation_rules ORDER BY field_category, field_name")
        return _dict_rows(cur)


def get_generation_rule(field_name):
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {_SCHEMA}.generation_rules WHERE field_name = ?", (field_name,))
        row = cur.fetchone()
        if row is None:
            return None
        columns = [col[0] for col in cur.description]
        return dict(zip(columns, row))


def delete_generation_rule(field_name):
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(f"DELETE FROM {_SCHEMA}.generation_rules WHERE field_name = ?", (field_name,))


def seed_default_generation_rules():
    defaults = [
        ("MEME_FIRST_NAME", "Member First Name", "default", "lookup", "text", 0, "", "", 0, "", "", "first_names"),
        ("MEME_LAST_NAME", "Member Last Name", "default", "lookup", "text", 0, "", "", 0, "", "", "last_names"),
        ("SBSB_FIRST_NAME", "Subscriber First Name", "default", "lookup", "text", 0, "", "", 0, "", "", "first_names"),
        ("SBSB_LAST_NAME", "Subscriber Last Name", "default", "lookup", "text", 0, "", "", 0, "", "", "last_names"),
        ("STREET_1", "Street Address 1", "default", "lookup", "text", 0, "", "", 0, "", "{number} {street} {type}", "street_names"),
        ("ZIP_CODE", "ZIP Code", "default", "lookup", "text", 5, "", "", 0, "", "", "zip_city_state"),
    ]
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            for (field_name, label, category, method, dtype, length,
                 prefix, postfix, start, domain, fmt, lookup) in defaults:
                cur.execute(f"SELECT id FROM {_SCHEMA}.generation_rules WHERE field_name = ?", (field_name,))
                if cur.fetchone() is None:
                    insert_row(cur, f"{_SCHEMA}.generation_rules", {
                        "field_name": field_name, "field_label": label,
                        "field_category": category, "gen_method": method,
                        "data_type": dtype, "length": length, "prefix": prefix,
                        "postfix": postfix, "start_value": start, "domain": domain,
                        "format_pattern": fmt, "lookup_source": lookup,
                        "active": 1, "updated_by": "system",
                    })
    except Exception:
        pass


# -- Validation Rules ---------------------------------------------------------

def get_validation_rules(active_only=True):
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            if active_only:
                cur.execute(f"SELECT * FROM {_SCHEMA}.validation_rules WHERE active = 1 ORDER BY field_name, rule_name")
            else:
                cur.execute(f"SELECT * FROM {_SCHEMA}.validation_rules ORDER BY field_name, rule_name")
            return _dict_rows(cur)
    except Exception:
        return []  # Table doesn't exist yet


def upsert_validation_rule(rule_name, field_name, rule_type, expression,
                            severity="error", active=True, created_by="user"):
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                f"UPDATE {_SCHEMA}.validation_rules SET rule_type = ?, expression = ?, "
                f"severity = ?, active = ?, updated_at = SYSDATETIME() "
                f"WHERE rule_name = ? AND field_name = ?",
                (rule_type, expression, severity, 1 if active else 0, rule_name, field_name))
            if cur.rowcount == 0:
                insert_row(cur, f"{_SCHEMA}.validation_rules", {
                    "rule_name": rule_name, "field_name": field_name, "rule_type": rule_type,
                    "expression": expression, "severity": severity,
                    "active": 1 if active else 0, "created_by": created_by,
                })
    except Exception:
        pass


def delete_validation_rule(rule_id):
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute(f"DELETE FROM {_SCHEMA}.validation_rules WHERE id = ?", (rule_id,))
    except Exception:
        pass


def toggle_validation_rule(rule_id, active):
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute(f"UPDATE {_SCHEMA}.validation_rules SET active = ?, updated_at = GETDATE() WHERE id = ?",
                        (1 if active else 0, rule_id))
    except Exception:
        pass


def seed_default_validation_rules():
    """Create built-in validation rules if table is empty. Skips if table doesn't exist."""
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute(f"SELECT COUNT(*) FROM {_SCHEMA}.validation_rules")
            if cur.fetchone()[0] > 0:
                return

            defaults = [
                ("Age range", "_age", "range", '{"min": 0, "max": 115}', "error"),
                ("Valid gender", "MEME_SEX", "values", '{"values": ["M", "F", ""]}', "warning"),
                ("Effective before term", "MEME_ORIG_EFF_DT", "cross_field", '{"operator": "<=", "other_field": "GRGR_TERM_DT"}', "warning"),
                ("SSN format", "MEME_SSN", "regex", '{"pattern": "^(9\\\\d{8}|)$"}', "warning"),
                ("Member key required", "MEME_CK", "required", '{}', "error"),
                ("Subscriber key required", "SBSB_CK", "required", '{}', "error"),
            ]
            for name, field, rtype, expr, severity in defaults:
                insert_row(cur, f"{_SCHEMA}.validation_rules", {
                    "rule_name": name, "field_name": field, "rule_type": rtype,
                    "expression": expr, "severity": severity, "active": 1,
                    "created_by": "system",
                })
    except Exception:
        pass  # Table doesn't exist yet — user needs to run SQL setup


# -- Generation Runs (replay) -------------------------------------------------

def save_generation_run(run_name, pattern_ids, data_type, volume, seed,
                         rules_snapshot=None, filters_json=None,
                         weighting=None, validation_result=None,
                         created_by="user"):
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            return insert_row(cur, f"{_SCHEMA}.generation_runs", {
                "run_name": run_name,
                "pattern_ids": json.dumps(pattern_ids, default=str),
                "data_type": data_type, "volume": volume, "seed": seed,
                "rules_snapshot": json.dumps(rules_snapshot, default=str) if rules_snapshot else None,
                "filters_json": json.dumps(filters_json, default=str) if filters_json else None,
                "weighting": json.dumps(weighting, default=str) if weighting else None,
                "validation_result": (json.dumps(validation_result, default=str)
                                      if validation_result else None),
                "created_by": created_by,
            })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return str(e)


def get_generation_runs(limit=50):
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute(f"SELECT TOP ({limit}) * FROM {_SCHEMA}.generation_runs ORDER BY created_at DESC")
            return _dict_rows(cur)
    except Exception:
        return []


def get_generation_run(run_id):
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute(f"SELECT * FROM {_SCHEMA}.generation_runs WHERE id = ?", (run_id,))
            rows = _dict_rows(cur)
            return rows[0] if rows else None
    except Exception:
        return None


def delete_generation_run(run_id):
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute(f"DELETE FROM {_SCHEMA}.generation_runs WHERE id = ?", (run_id,))
    except Exception:
        pass


# -- Bootstrap ----------------------------------------------------------------

def bootstrap():
    """Seed defaults. Safe to call multiple times."""
    seed_default_vocabulary()
    seed_default_generation_rules()
    seed_default_validation_rules()


def get_raw_connection():
    """An open connection the caller owns and must close.

    get_connection is a context manager that commits and closes on exit, which
    is right for a single operation and wrong for a long walk that wants one
    connection across hundreds of writes.
    """
    try:
        return pyodbc.connect(get_connection_string(), autocommit=False)
    except pyodbc.Error as e:
        raise ConnectionError(
            f"Cannot connect to SQL Server. Check config.py SQL_SERVER value. Error: {e}"
        ) from e

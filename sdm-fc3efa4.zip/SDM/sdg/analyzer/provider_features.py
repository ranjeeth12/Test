"""Provider features, joined onto members and claim lines as they are loaded.

The customer's member_denorm and claims_denorm are theirs and are not
altered. What a pattern needs to know about providers comes from the tables
beside them (scripts/customer/03_denorm_837_tables.sql): a member's primary
care provider from member_pcp, a provider's type from provider_denorm, a
network's name and type from provider_network. They are small next to the
denorms and read once, then joined in memory.

A store without those tables yet -- a customer who has not run 03 and 04 --
gets the features empty rather than an error.
"""

from __future__ import annotations

from typing import Optional

import pandas as pd

from sdg.analyzer.config import SQL_SCHEMA
from sdg.analyzer.services.cache import ttl_cache
from sdg.analyzer.sql import read_sql

MEMBER_COLUMNS = ("_pcp_id", "_pcp_specialty", "_pcp_entity", "_has_pcp")
CLAIM_COLUMNS = ("_provider_entity", "_network_name", "_network_type")
ENTITY_WORDS = {"P": "Practitioner", "F": "Facility", "G": "Group", "I": "IPA"}


def _read(sql: str, *params) -> Optional[pd.DataFrame]:
    from sdg.analyzer.data_loader import _conn

    conn = _conn()
    try:
        return read_sql(sql, conn, params=list(params) if params else None)
    except Exception:
        return None
    finally:
        conn.close()


@ttl_cache(600)
def _providers() -> pd.DataFrame:
    frame = _read(f"SELECT LTRIM(RTRIM(PRPR_ID)) AS PRPR_ID, LTRIM(RTRIM(PRPR_ENTITY)) AS ENT, "
                  f"LTRIM(RTRIM(PRCF_MCTR_SPEC)) AS SPEC FROM {SQL_SCHEMA}.provider_denorm")
    return frame if frame is not None else pd.DataFrame(columns=["PRPR_ID", "ENT", "SPEC"])


@ttl_cache(600)
def _networks() -> pd.DataFrame:
    frame = _read(f"SELECT DISTINCT LTRIM(RTRIM(NWNW_ID)) AS NWNW_ID, "
                  f"LTRIM(RTRIM(NWNW_NAME)) AS NAME, LTRIM(RTRIM(NWNW_MCTR_TYPE)) AS KIND "
                  f"FROM {SQL_SCHEMA}.provider_network")
    if frame is None:
        return pd.DataFrame(columns=["NWNW_ID", "NAME", "KIND"])
    return frame.drop_duplicates("NWNW_ID")


@ttl_cache(600)
def _pcps(reference_date: str) -> pd.DataFrame:
    """Each member's primary care provider on the reference date."""
    frame = _read(f"SELECT MEME_CK, LTRIM(RTRIM(PRPR_ID)) AS PRPR_ID, MEPR_EFF_DT "
                  f"FROM {SQL_SCHEMA}.member_pcp "
                  f"WHERE MEPR_EFF_DT <= ? AND (MEPR_TERM_DT IS NULL OR MEPR_TERM_DT >= ?)",
                  reference_date, reference_date)
    if frame is None or frame.empty:
        return pd.DataFrame(columns=["MEME_CK", "PRPR_ID"])
    frame = frame.sort_values("MEPR_EFF_DT").drop_duplicates("MEME_CK", keep="last")
    return frame[["MEME_CK", "PRPR_ID"]]


def members(df: pd.DataFrame, reference_date: str) -> pd.DataFrame:
    """Members with their PCP, its specialty and type, and whether they have one."""
    if df is None or df.empty or "MEME_CK" not in df.columns:
        return df
    pcps = _pcps(str(reference_date)[:10]).merge(_providers(), on="PRPR_ID", how="left")
    found = pcps.set_index("MEME_CK")
    keys = df["MEME_CK"]
    df["_pcp_id"] = keys.map(found["PRPR_ID"]) if len(found) else None
    df["_pcp_specialty"] = keys.map(found["SPEC"]) if len(found) else None
    df["_pcp_entity"] = (keys.map(found["ENT"]).map(ENTITY_WORDS)
                         if len(found) else None)
    df["_has_pcp"] = df["_pcp_id"].notna().map({True: "Y", False: "N"})
    return df


def claims(df: pd.DataFrame) -> pd.DataFrame:
    """Claim lines with the provider's type and the network's name and type."""
    if df is None or df.empty:
        return df
    if "PRPR_ID" in df.columns:
        entity = _providers().set_index("PRPR_ID")["ENT"]
        df["_provider_entity"] = (df["PRPR_ID"].astype(str).str.strip().map(entity)
                                  .map(ENTITY_WORDS))
    else:
        df["_provider_entity"] = None
    if "NWNW_ID" in df.columns:
        nets = _networks().set_index("NWNW_ID")
        ids = df["NWNW_ID"].astype(str).str.strip()
        df["_network_name"] = ids.map(nets["NAME"]) if len(nets) else None
        df["_network_type"] = ids.map(nets["KIND"]) if len(nets) else None
    else:
        df["_network_name"] = df["_network_type"] = None
    # Out of network names no network, and says so.
    if "CLCL_NTWK_IND" in df.columns:
        out = df["CLCL_NTWK_IND"].astype(str).str.strip() == "O"
        df.loc[out, "_network_name"] = "Out of network"
        df.loc[out, "_network_type"] = "OUT"
    return df


def clear() -> None:
    for fn in (_providers, _networks, _pcps):
        getattr(fn, "cache_clear", lambda: None)()

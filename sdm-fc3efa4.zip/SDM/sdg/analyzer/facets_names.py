"""What a person calls a FACETS column: "Product ID" for PDPD_ID, "Plan
Description" for PLDS_DESC. Taken from the FACETS data dictionary by
scripts/build_facets_names.py; screens and reports show these, while generated
files and database loads keep the column names Facets needs.
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path


@lru_cache(maxsize=1)
def names() -> dict[str, str]:
    return json.loads((Path(__file__).with_name("facets_names.json")).read_text(encoding="utf-8"))


def name(column: str) -> str:
    """The column's business name; the column itself where the dictionary has none."""
    found = names()
    return found.get(column) or found.get(column.upper()) or column

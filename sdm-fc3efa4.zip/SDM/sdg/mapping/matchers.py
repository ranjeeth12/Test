"""Evidence that a column is a particular business element.

Four kinds, each answering a different question.

    alias        does the column's name contain an alias the catalog records?
                 Matched on tokens, so an alias of FIRST_NAME covers
                 MEME_FIRST_NAME without anyone writing that down.
    format       do the column's values match the element's format? Strong for
                 a distinctive shape, worthless for a two-letter code that a
                 dozen elements share, which is why it never scores on its own.
    check digit  do the values satisfy the element's check-digit scheme? Almost
                 nothing passes an NPI check by accident.
    propagation  is the column a foreign key to a column already mapped? Then
                 it holds the same element by construction.

A name-token overlap is also recorded, but only as support for another kind.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from sdg.catalog.model import Catalog, Element
from sdg.discovery.classify import tokenize
from sdg.discovery.model import Column, PhysicalModel, Table
from sdg.profiling.format import matches_format
from sdg.profiling.model import ColumnProfile

# Tokens that say nothing about what a column holds. An alias made only of
# these would match half the schema.
GENERIC_TOKENS = {
    "ID", "CK", "CD", "NO", "NUM", "KEY", "CODE", "SK", "NBR", "SEQ",
    "DT", "TS", "FLAG", "IND", "TYPE", "NAME", "VAL", "AMT", "QTY",
}

FORMAT_MATCH_MIN_COVERAGE = 0.98


@dataclass
class Evidence:
    kind: str
    detail: str
    score: float = 0.0

    def as_dict(self) -> dict:
        return {"kind": self.kind, "detail": self.detail, "score": round(self.score, 4)}


@dataclass
class Match:
    element: str
    evidence: list[Evidence] = field(default_factory=list)

    def kinds(self) -> set[str]:
        return {e.kind for e in self.evidence}

    def score(self) -> float:
        return round(sum(e.score for e in self.evidence), 4)


def informative(tokens: Iterable[str]) -> set[str]:
    """Tokens that carry meaning, with the generic key words removed."""
    return {t for t in tokens if t not in GENERIC_TOKENS}


def alias_match(column_name: str, element: Element) -> Evidence | None:
    """An alias matches when all of its tokens appear in the column's name.

    Requiring a non-generic token stops an alias like SEQ_NO from matching
    every sequence column in the schema.
    """
    column_tokens = set(tokenize(column_name))
    best: tuple[int, str] | None = None
    for alias in element.all_names():
        alias_tokens = set(tokenize(alias))
        if not alias_tokens or not informative(alias_tokens):
            continue
        if alias_tokens <= column_tokens:
            weight = len(informative(alias_tokens))
            if best is None or weight > best[0]:
                best = (weight, alias)
    if best is None:
        return None
    weight, alias = best
    exact = set(tokenize(alias)) == set(tokenize(column_name))
    return Evidence(
        kind="alias",
        detail=(
            f"column name contains the alias {alias}"
            + ("" if not exact else ", exactly")
        ),
        score=1.0 if exact else 0.85 + 0.03 * weight,
    )


def name_token_match(column_name: str, element: Element) -> Evidence | None:
    """A weak signal: meaningful tokens shared with the element or its aliases."""
    column_tokens = informative(tokenize(column_name))
    if not column_tokens:
        return None
    best: tuple[int, str] | None = None
    for name in element.all_names():
        shared = column_tokens & informative(tokenize(name))
        if shared and (best is None or len(shared) > best[0]):
            best = (len(shared), ", ".join(sorted(shared)))
    if best is None:
        return None
    count, shared = best
    return Evidence(
        kind="name_token",
        detail=f"name shares {shared} with {element.name}",
        score=0.2 * count,
    )


def format_match(profile: ColumnProfile | None, element: Element) -> Evidence | None:
    """The column's fitted pattern equals the element's, or is covered by it."""
    if profile is None or not element.format:
        return None

    fitted = profile.format_regex()
    if fitted and fitted == element.format:
        return Evidence(
            kind="format",
            detail=f"fitted format {fitted} equals the element's",
            score=0.6,
        )

    # Not identical, but the element's pattern may still cover the values.
    if fitted:
        sample = _sample_values(profile)
        if sample:
            coverage = matches_format(sample, element.format)
            if coverage >= FORMAT_MATCH_MIN_COVERAGE:
                return Evidence(
                    kind="format",
                    detail=(
                        f"{coverage:.0%} of sampled values match the element's "
                        f"format {element.format}"
                    ),
                    score=0.45,
                )
    return None


def _sample_values(profile: ColumnProfile) -> list[str]:
    """Values kept on the profile that a format can be tested against."""
    values: list[str] = []
    for top in profile.top_values or []:
        values.append(str(top.value).rstrip())
    for bound in (profile.minimum, profile.maximum):
        if isinstance(bound, str):
            values.append(bound.rstrip())
    return values


def check_digit_match(profile: ColumnProfile | None, element: Element) -> Evidence | None:
    """The values satisfy the check-digit scheme the element declares."""
    if profile is None or not element.check_digit or not profile.check_digit:
        return None
    if profile.check_digit.get("scheme") != element.check_digit:
        return None
    share = float(profile.check_digit.get("share") or 0.0)
    return Evidence(
        kind="check_digit",
        detail=(
            f"{share:.0%} of sampled values pass the {element.check_digit} "
            f"check-digit test"
        ),
        score=0.9,
    )


def propagation_match(
    table: Table,
    column: Column,
    model: PhysicalModel,
    already_mapped: dict[str, str],
) -> tuple[str, Evidence] | None:
    """A foreign key inherits the element its parent column carries."""
    foreign_key = table.foreign_key_columns().get(column.name)
    if foreign_key is None or len(foreign_key.columns) != 1:
        return None
    parent = model.table(foreign_key.parent_table)
    if parent is None:
        return None
    parent_column = foreign_key.parent_columns[0]
    element_name = already_mapped.get(f"{parent.name}.{parent_column}")
    if not element_name:
        return None
    kind = "inferred " if foreign_key.kind == "inferred" else ""
    return element_name, Evidence(
        kind="fk_propagation",
        detail=(
            f"{kind}foreign key to {parent.name}.{parent_column}, which maps to "
            f"{element_name}"
        ),
        score=0.95,
    )


def candidates_for(
    table: Table,
    column: Column,
    catalog: Catalog,
    profile: ColumnProfile | None,
    model: PhysicalModel,
    already_mapped: dict[str, str],
) -> list[Match]:
    """Every element with any evidence behind it, best first."""
    matches: dict[str, Match] = {}

    def add(element_name: str, evidence: Evidence | None) -> None:
        if evidence is None:
            return
        matches.setdefault(element_name, Match(element=element_name)).evidence.append(evidence)

    propagated = propagation_match(table, column, model, already_mapped)
    if propagated:
        add(*propagated)

    for element in catalog.elements:
        add(element.name, alias_match(column.name, element))
        add(element.name, format_match(profile, element))
        add(element.name, check_digit_match(profile, element))
        add(element.name, name_token_match(column.name, element))

    return sorted(matches.values(), key=lambda m: (-m.score(), m.element))

"""Detections that need to look at the data, not just at the profile.

Only one so far: whether a parent's amount column is the sum of one of its
children's. That cannot be seen in a column profile, because the evidence lives
in the join, and it is exactly the kind of rule that a person would otherwise
have to notice and write by hand.

Read-only, like everything else in profiling.
"""

from __future__ import annotations

from dataclasses import dataclass

from sdg.discovery.connections import ConnectionRegistry
from sdg.discovery.model import Column, PhysicalModel, Table

# The build brief: propose the sum only when it holds for essentially every row.
EXPRESSION_MATCH_THRESHOLD = 0.999
MIN_ROWS = 20


def _quote(name: str) -> str:
    return "[" + name.replace("]", "]]") + "]"


def _qualified(table: Table) -> str:
    return f"{_quote(table.schema_name)}.{_quote(table.table_name)}"


SUM_SQL = """
SELECT COUNT(*) AS rows_compared,
       SUM(CASE WHEN p.{parent_column} = t.child_total THEN 1 ELSE 0 END) AS matched
FROM {parent} AS p
JOIN (
    SELECT {child_key} AS parent_key, SUM({child_column}) AS child_total
    FROM {child}
    GROUP BY {child_key}
) AS t ON t.parent_key = p.{parent_key}
"""


@dataclass
class SumExpression:
    parent_table: str
    parent_column: str
    child_table: str
    child_column: str
    rows_compared: int
    matched: int

    @property
    def match_rate(self) -> float:
        return self.matched / self.rows_compared if self.rows_compared else 0.0

    def expression(self) -> str:
        return f"sum({self.child_table}.{self.child_column})"

    def detail(self) -> str:
        return (
            f"equals {self.expression()} in {self.match_rate:.1%} of "
            f"{self.rows_compared:,} parent rows that have children"
        )


def _amount_columns(table: Table) -> list[Column]:
    """Decimal columns that could hold a total. Integers and keys are skipped."""
    return [
        c for c in table.columns
        if c.type_name in {"decimal", "numeric", "money", "smallmoney"}
        and not c.is_computed
        and not c.is_primary_key
        and c.bucket not in {"system", "reference"}
    ]


def detect_sum_expressions(
    registry: ConnectionRegistry,
    model: PhysicalModel,
    connection: str = "source",
    *,
    threshold: float = EXPRESSION_MATCH_THRESHOLD,
) -> list[SumExpression]:
    """Test every parent amount against every child amount across each key."""
    found: list[SumExpression] = []

    for child in model.tables:
        child_amounts = _amount_columns(child)
        if not child_amounts:
            continue
        for foreign_key in child.foreign_keys:
            if len(foreign_key.columns) != 1:
                continue
            parent = model.table(foreign_key.parent_table)
            if parent is None or parent.name == child.name:
                continue
            parent_amounts = _amount_columns(parent)
            if not parent_amounts:
                continue

            for parent_column in parent_amounts:
                for child_column in child_amounts:
                    sql = SUM_SQL.format(
                        parent=_qualified(parent),
                        parent_column=_quote(parent_column.name),
                        parent_key=_quote(foreign_key.parent_columns[0]),
                        child=_qualified(child),
                        child_key=_quote(foreign_key.columns[0]),
                        child_column=_quote(child_column.name),
                    )
                    rows = registry.query(connection, sql)
                    if not rows:
                        continue
                    rows_compared = int(rows[0]["rows_compared"] or 0)
                    matched = int(rows[0]["matched"] or 0)
                    if rows_compared < MIN_ROWS:
                        continue
                    candidate = SumExpression(
                        parent_table=parent.name,
                        parent_column=parent_column.name,
                        child_table=child.name,
                        child_column=child_column.name,
                        rows_compared=rows_compared,
                        matched=matched,
                    )
                    if candidate.match_rate >= threshold:
                        found.append(candidate)
    return found

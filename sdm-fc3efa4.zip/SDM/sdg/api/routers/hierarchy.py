"""Cascading hierarchy options: Group → Plan Category → Plan → Product.

Each level accepts the selections above it, which is the SQL pushdown the
Streamlit sidebar was already doing — just over HTTP now.
"""

from typing import Optional

from fastapi import APIRouter, Query

from sdg.analyzer.services import service
from sdg.analyzer.services.schemas import Option, OverviewMetrics

router = APIRouter(prefix="/hierarchy", tags=["hierarchy"])


def _t(v: Optional[list]) -> Optional[tuple]:
    """Tuples so the values are hashable for the cache."""
    return tuple(v) if v else None


@router.get("/overview", response_model=OverviewMetrics)
def overview():
    return service.overview()


@router.get("/groups", response_model=list[Option])
def groups():
    return service.groups()


@router.get("/plan-categories", response_model=list[Option])
def plan_categories(
    grgr_ck: Optional[list[int]] = Query(None),
):
    return service.plan_categories(_t(grgr_ck))


@router.get("/plans", response_model=list[Option])
def plans(
    grgr_ck: Optional[list[int]] = Query(None),
    cspd_cat: Optional[list[str]] = Query(None),
):
    return service.plans(_t(grgr_ck), _t(cspd_cat))


@router.get("/products", response_model=list[Option])
def products(
    grgr_ck: Optional[list[int]] = Query(None),
    cspd_cat: Optional[list[str]] = Query(None),
    cspi_id: Optional[list[str]] = Query(None),
):
    return service.products(_t(grgr_ck), _t(cspd_cat), _t(cspi_id))


@router.get("/counts")
def counts(
    grgr_ck: Optional[list[int]] = Query(None),
    cspd_cat: Optional[list[str]] = Query(None),
    cspi_id: Optional[list[str]] = Query(None),
    pdpd_id: Optional[list[str]] = Query(None),
):
    """Member counts at each level of the funnel."""
    return service.funnel_counts(
        tuple(grgr_ck or ()), tuple(cspd_cat or ()),
        tuple(cspi_id or ()), tuple(pdpd_id or ()),
    )

"""Masking — define algorithm instances, assign them to layout fields, run.

Separate from generation throughout. The only thing the two share is the
layout, which describes where each value sits in a file.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from sdg.analyzer.services import masking_service as ms
from sdg.discovery.errors import plain

router = APIRouter(prefix="/masking", tags=["masking"])


@router.get("/algorithms")
def algorithms():
    """The frameworks a user can create an instance of, and what each needs."""
    return {
        "algorithms": [
            {
                "id": "hash_lookup",
                "label": "Hash lookup",
                "description": "Hashes the value and picks a replacement from a "
                               "lookup list. The same input always lands on the "
                               "same entry. Two inputs can share one — that is "
                               "accepted.",
                "needs": ["lookup_id"],
                "lookup_kind": "pool",
            },
            {
                "id": "lookup_substitute",
                "label": "Lookup substitution",
                "description": "Matches the value against the first column of a "
                               "two-column list and substitutes the second. A "
                               "value that is not listed is left as it is.",
                "needs": ["lookup_id"],
                "lookup_kind": "map",
            },
            {
                "id": "character_map",
                "label": "Character map",
                "description": "Builds a replacement to a shape you define — "
                               "literal text and runs of letters or digits. "
                               "Derived from the value, so it is stable.",
                "needs": ["segments"],
                "classes": ["literal", "numeric", "alpha_upper", "alpha_lower",
                            "alphanumeric"],
            },
            {
                "id": "date_shift",
                "label": "Date shift",
                "description": "Moves a date by a fixed amount, keeping its "
                               "original format. Intervals between dates are "
                               "preserved.",
                "needs": ["amount", "unit"],
                "units": ["days", "months", "years"],
            },
        ],
        "masking_root": ms.MASKING_ROOT or None,
    }


# ── Lookups ──────────────────────────────────────────────────────────────────

class LookupBody(BaseModel):
    name: str
    kind: str                      # 'pool' | 'map'
    source_kind: str               # 'table' | 'file'
    source: str
    value_col: str | None = None


@router.get("/lookups")
def lookups():
    """Masking's own lookup registry, kept apart from the generation lookups."""
    try:
        return {"lookups": ms.list_lookups()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


@router.post("/lookups")
def add_lookup(req: LookupBody):
    try:
        return ms.register_lookup(req.name, req.kind, req.source_kind,
                                  req.source, req.value_col)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


@router.delete("/lookups/{lookup_id}")
def drop_lookup(lookup_id: int):
    try:
        return ms.delete_lookup(lookup_id)
    except ValueError as e:
        raise HTTPException(status_code=404 if "No lookup" in str(e) else 409,
                            detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


# ── Rules ────────────────────────────────────────────────────────────────────

class RuleBody(BaseModel):
    name: str
    algorithm: str
    config: dict = Field(default_factory=dict)
    description: str = ""


class RuleEdit(BaseModel):
    name: str | None = None
    config: dict | None = None
    description: str | None = None


@router.get("/rules")
def rules():
    """Every masking rule the user has defined."""
    try:
        return {"rules": ms.list_rules()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


@router.post("/rules")
def add_rule(req: RuleBody):
    """Create an instance of one of the algorithm frameworks."""
    try:
        return ms.create_rule(req.name, req.algorithm, req.config,
                              req.description)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


@router.put("/rules/{rule_id}")
def edit_rule(rule_id: int, req: RuleEdit):
    try:
        return ms.update_rule(rule_id, req.name, req.config, req.description)
    except ValueError as e:
        raise HTTPException(status_code=404 if "No masking rule" in str(e) else 422,
                            detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


@router.delete("/rules/{rule_id}")
def drop_rule(rule_id: int):
    """Delete a rule and any field assignments that used it."""
    try:
        return ms.delete_rule(rule_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


# ── Assignments ──────────────────────────────────────────────────────────────

class AssignBody(BaseModel):
    field_name: str
    # None clears the assignment: the field goes back to being copied through.
    rule_id: int | None = None


@router.get("/layouts/{layout_id}")
def layout_masking(layout_id: int):
    """A layout's fields with whatever masking each one carries.

    Fields are listed whether or not they are masked — masking is opt-in, so an
    unassigned field is a real and expected state, not an omission.
    """
    from sdg.analyzer.services import layout_service as ls

    layout = ls.get_layout(layout_id)
    if not layout:
        raise HTTPException(status_code=404, detail="Layout not found.")

    try:
        assigned = ms.get_assignments(layout_id)
        rules = {r["id"]: r for r in ms.list_rules()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")

    fields = []
    for f in layout.get("fields") or []:
        rule_id = assigned.get(f["name"])
        rule = rules.get(rule_id) if rule_id else None
        fields.append({
            "name": f["name"],
            "type": f.get("type"),
            "start": f.get("start"),
            "length": f.get("length"),
            "samples": (f.get("samples") or [])[:3],
            "masking_rule_id": rule_id,
            "masking_rule_name": rule["name"] if rule else None,
            "masking_algorithm": rule["algorithm"] if rule else None,
        })

    return {
        "layout_id": layout_id,
        "layout_name": layout.get("name"),
        "kind": layout.get("kind"),
        "delimiter": layout.get("delimiter"),
        "status": layout.get("status"),
        "fields": fields,
        "n_fields": len(fields),
        "n_masked": sum(1 for f in fields if f["masking_rule_id"]),
    }


@router.post("/layouts/{layout_id}/assign")
def assign(layout_id: int, req: AssignBody):
    """Assign a masking rule to one field, or clear it with rule_id=null."""
    try:
        return ms.set_assignment(layout_id, req.field_name, req.rule_id)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


# ── Running ──────────────────────────────────────────────────────────────────

class RunBody(BaseModel):
    layout_id: int
    path: str
    # Preview reads and masks without writing, so an assignment can be checked
    # against real data before a file is produced.
    preview: bool = False


@router.post("/run")
def run(req: RunBody):
    """Mask a file on this machine, writing <name>_masked<ext> beside it.

    A path rather than an upload: a browser only ever sends a basename, so
    "write it back next to the original" is not something an upload can express.
    The API runs locally and reads the path directly.
    """
    try:
        return ms.run(req.layout_id, req.path, preview=req.preview)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")

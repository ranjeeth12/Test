"""Story → Data endpoints.

The approval gate is structural, not cosmetic: /match never generates, and
/generate only accepts explicit pattern IDs the user selected.
"""


from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel


from sdg.analyzer.services import story_service as svc
from sdg.analyzer.services.schemas import (
    StoryAllocateRequest, StoryGenerateRequest, StoryGenerateResponse,
    StoryMatchRequest, StoryMatchResponse, StoryParseResponse,
)
from sdg.discovery.errors import plain

router = APIRouter(prefix="/story", tags=["story"])

PREVIEW_ROWS = 50
MAX_UPLOAD_BYTES = 10 * 1024 * 1024


@router.post("/parse", response_model=StoryParseResponse)
async def parse(file: UploadFile = File(...)):
    """Turn an uploaded file into a list of stories. Reads only — no matching."""
    raw = await file.read()
    if len(raw) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="That file is larger than 10 MB.")
    try:
        stories, column = svc.parse_upload(file.filename or "", raw)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))

    if not stories:
        raise HTTPException(
            status_code=422,
            detail="No readable text in that file.",
        )
    return {"stories": stories, "column_used": column, "filename": file.filename}


class StoryReadRequest(BaseModel):
    story: str
    entity: str | None = None


@router.post("/read")
def read(req: StoryReadRequest):
    """A requirement read into the rules of a pattern, to analyze like one."""
    from sdg.analyzer.services import story_reading

    if not req.story.strip():
        raise HTTPException(status_code=422, detail="Write the requirement first.")
    try:
        return story_reading.read(req.story, req.entity)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.post("/match", response_model=StoryMatchResponse)
def match(req: StoryMatchRequest):
    stories = req.stories or svc.split_text(req.text or "")
    if not stories:
        raise HTTPException(status_code=422, detail="No stories to match.")
    try:
        return svc.match_stories(stories, req.top_n)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


@router.post("/allocate")
def allocate(req: StoryAllocateRequest):
    """Split a total volume across the selected patterns by member count."""
    if not req.pattern_ids:
        raise HTTPException(status_code=422, detail="No patterns selected.")
    return {"allocation": svc.suggest_allocation(req.pattern_ids, req.total_volume)}





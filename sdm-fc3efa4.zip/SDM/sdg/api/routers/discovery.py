"""System discovery (the landing view) and saved patterns."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from sdg.analyzer.services import discovery_service as ds
from sdg.discovery.errors import plain

router = APIRouter(prefix="/discovery", tags=["discovery"])


# Discovery reads from these caches, so a real refresh must drop the whole
# chain — otherwise the walk recomputes from stale loads and shows no change.
_REFRESH_NAMESPACES = {
    "members": ["discovery.top", "members.load", "members.cluster", "funnel"],
    "claims":  ["discovery.claims", "claims.load", "claims.cluster",
                "claims.booktotal"],
}


@router.get("")
def discover(entity: str = "members", top_n: int = 50,
             max_depth: int = 2, limit_groups: int | None = None,
             refresh: bool = False):
    """Largest patterns across the book, for members or claims.

    Cached, so instant after the first walk. Pass refresh=true to re-walk after
    the underlying data has changed. Refresh clears not just the discovery
    cache but everything it reads from — the per-combination loads, the
    clustering, and the book totals — so the new data actually surfaces.
    """
    from sdg.analyzer.services import disk_cache

    if refresh:
        for ns in _REFRESH_NAMESPACES.get(entity, []):
            disk_cache.clear_namespace(ns)

    fn = ds.discover_claims if entity == "claims" else ds.discover
    try:
        return fn(top_n=top_n, max_depth=max_depth,
                  limit_groups=limit_groups, refresh=refresh)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


@router.get("/status")
def status(entity: str = "members", top_n: int = 50,
           max_depth: int = 2, limit_groups: int | None = None):
    """Whether a discovery result is already cached — without computing one.

    The landing page calls this first. A cold walk is minutes of work, and
    firing it automatically on page load meant the first thing anyone saw was a
    spinner with no indication of how long it would take or that it had even
    started. This answers in milliseconds so the page can render immediately
    and let the user start the walk deliberately.
    """
    from sdg.analyzer.services import disk_cache

    namespace = "discovery.claims" if entity == "claims" else "discovery.top"
    # Must mirror how two_tier builds its key, or the probe misses a live entry.
    kwargs = sorted({"top_n": top_n, "max_depth": max_depth,
                     "limit_groups": limit_groups}.items())
    key = disk_cache.make_key(namespace, (), kwargs)

    cached = False
    try:
        cached = disk_cache.get(key) is not None
    except Exception:
        cached = False

    return {"entity": entity, "cached": cached}


# ── Save / retrieve ──────────────────────────────────────────────────────────

class SaveRequest(BaseModel):
    pattern_id: int = Field(..., description="ID from a discovered or analyzed pattern.")


@router.post("/save")
def save(req: SaveRequest):
    try:
        return ds.save(req.pattern_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


@router.post("/unsave")
def unsave(req: SaveRequest):
    try:
        return ds.unsave(req.pattern_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


@router.get("/saved")
def saved():
    """Every saved pattern, so a user retrieves rather than re-searches."""
    try:
        return {"patterns": ds.list_saved()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")

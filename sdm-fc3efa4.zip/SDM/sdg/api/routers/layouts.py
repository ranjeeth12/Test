"""Layout Builder API — parse a sample, assign rules, save for review, approve.

Decoupled from generation. Everything here builds and reviews layout definitions;
the generator is not touched. Only approved layouts become selectable downstream,
and that wiring is deferred.
"""

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel

from sdg.analyzer.services import layout_service as ls
from sdg.discovery.errors import plain

router = APIRouter(prefix="/layouts", tags=["layouts"])


@router.post("/parse")
async def parse(file: UploadFile = File(...)):
    """Parse an uploaded sample into fields, then auto-assign a rule to each.

    Unmatched fields come back flagged is_default=True so the review UI can show
    they carry the blank fallback rather than a real assignment.
    """
    content = await file.read()
    try:
        parsed = ls.parse_sample(file.filename, content)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Parse failed: {plain(e)}")

    try:
        rules = ls.get_rules()
    except Exception:
        rules = []
    parsed["fields"] = ls.auto_assign(parsed["fields"], rules)
    parsed["sample_name"] = file.filename
    parsed["n_default"] = sum(1 for f in parsed["fields"] if f.get("is_default"))
    return parsed


@router.get("/rules")
def rules():
    """Active generation rules, for the assignment dropdown."""
    try:
        return {"rules": ls.get_rules()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


class CreateRuleRequest(BaseModel):
    field_name: str
    field_label: str | None = None
    field_category: str = "custom"
    gen_method: str
    data_type: str = "text"
    length: int | None = None
    prefix: str | None = None
    postfix: str | None = None
    start_value: int | None = None
    domain: str | None = None
    format_pattern: str | None = None
    lookup_source: str | None = None


@router.post("/rules")
def add_rule(req: CreateRuleRequest):
    """Create a generation rule inline, so an unmatched field can be assigned.

    Returns the new rule so the client can attach it to the field immediately.
    """
    try:
        rule_id = ls.create_rule(req.model_dump())
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Rule create failed: {plain(e)}")
    return {"id": rule_id, **req.model_dump()}


class SaveLayoutRequest(BaseModel):
    name: str
    kind: str
    delimiter: str | None = None
    fields: list[dict]
    sample_name: str | None = None
    # 'generation' assigns generation rules to fields; 'masking' assigns
    # masking rules. The catalogs are separate, so the layout declares which.
    purpose: str = "generation"
    # Saving as a new layout must not land on an existing one: saving under a
    # taken name replaces that layout, which is right for re-reading a sample
    # and wrong for "keep a copy of this".
    as_new: bool = False


@router.post("/save")
def save(req: SaveLayoutRequest):
    """Save as pending_review. Every field already has a rule (real or default)."""
    if not req.name.strip():
        raise HTTPException(status_code=422, detail="A layout name is required.")
    if not req.fields:
        raise HTTPException(status_code=422, detail="The layout has no fields.")
    try:
        ls.check_field_names(req.fields)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    if req.as_new and any(
        row["name"].strip().lower() == req.name.strip().lower()
        for row in ls.list_layouts(include_archived=True)
    ):
        raise HTTPException(
            status_code=409,
            detail=f"There is already a layout called “{req.name.strip()}”. "
                   f"Give the new one a name of its own.")
    try:
        saved = ls.save_layout(
            req.name.strip(), req.kind, req.delimiter, req.fields,
            req.sample_name or "", created_by="user", purpose=req.purpose,
        )
    except ValueError as e:
        # 409: the name belongs to something that still exists. Not a malformed
        # request, and not a server fault — a conflict the caller can resolve.
        raise HTTPException(status_code=409, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Save failed: {plain(e)}")
    if req.purpose == "generation":
        saved.update(ls.alias_chosen(req.fields))
    return saved


@router.get("")
def layouts(include_archived: bool = False):
    """Saved layouts. Archived ones are hidden unless include_archived=true."""
    return {"layouts": ls.list_layouts(include_archived)}


@router.get("/approved")
def approved_layouts(purpose: str | None = None):
    """Approved layouts, optionally of one purpose.

    The generation format selector wants generation layouts; the masking screen
    wants masking ones. Offering either the wrong list is how a file gets run
    through a layout whose fields carry the other kind of rule entirely.
    """
    out = [l for l in ls.list_layouts() if l["status"] == "approved"]
    if purpose:
        out = [l for l in out if l.get("purpose", "generation") == purpose]
    return {"layouts": out}


@router.get("/{layout_id}")
def one(layout_id: int):
    """A layout with each field's assigned rule resolved in full.

    field_spec stores only the rule id and a label captured at assignment time.
    Rules are shared and editable, so the detail view resolves them fresh —
    what the field will actually produce, not what it produced when saved.
    """
    layout = ls.get_layout(layout_id)
    if not layout:
        raise HTTPException(status_code=404, detail="Layout not found.")

    try:
        by_id = {r["id"]: r for r in ls.get_rules()}
    except Exception:
        by_id = {}

    for f in layout.get("fields", []):
        rule = by_id.get(f.get("rule_id"))
        if rule:
            f["rule"] = {
                "id": rule["id"],
                "field_name": rule.get("field_name"),
                "field_label": rule.get("field_label"),
                "gen_method": rule.get("gen_method"),
                "lookup_source": rule.get("lookup_source"),
                "data_type": rule.get("data_type"),
                "length": rule.get("length"),
                "prefix": rule.get("prefix"),
                "postfix": rule.get("postfix"),
                "start_value": rule.get("start_value"),
                "domain": rule.get("domain"),
                "format_pattern": rule.get("format_pattern"),
            }
            # The rule may have been renamed or repointed since assignment.
            f["rule_label"] = rule.get("field_label") or f.get("rule_label")
            f["gen_method"] = rule.get("gen_method") or f.get("gen_method")
        elif f.get("rule_id"):
            f["rule"] = None
            f["rule_missing"] = True

    layout["n_default"] = sum(1 for f in layout.get("fields", [])
                              if f.get("is_default"))
    return layout


class ApproveRequest(BaseModel):
    layout_id: int


@router.post("/approve")
def approve(req: ApproveRequest):
    """Flip pending_review → approved. No role check; the UI shows a soft note."""
    layout = ls.get_layout(req.layout_id)
    if not layout:
        raise HTTPException(status_code=404, detail="Layout not found.")
    try:
        return ls.approve_layout(req.layout_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Approve failed: {plain(e)}")


@router.post("/{layout_id}/withdraw")
def withdraw(layout_id: int):
    """Send an approved layout back to review, without deleting it.

    Only approved layouts are selectable for generation, so this is how you take
    one out of circulation while keeping the definition and its history.
    """
    try:
        return ls.withdraw_approval(layout_id)
    except ValueError as e:
        raise HTTPException(status_code=404 if "No layout" in str(e) else 422,
                            detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


@router.post("/{layout_id}/restore")
def restore(layout_id: int):
    """Bring an archived layout back into service."""
    try:
        return ls.restore_layout(layout_id)
    except ValueError as e:
        raise HTTPException(status_code=404 if "No layout" in str(e) else 422,
                            detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


@router.delete("/{layout_id}")
def remove(layout_id: int):
    """Take a layout out of service.

    An approved layout is archived, not deleted — its approval records that
    somebody reviewed a specific set of fields and rules, and nothing else in
    the system remembers that happened. Anything not approved is deleted, since
    it carries no review and can be re-uploaded from the same sample.

    The response says which happened via `action`, so the caller reports what
    the server actually did rather than what it assumed.
    """
    try:
        return ls.remove_layout(layout_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


class LayoutEdit(BaseModel):
    fields: list[dict] | None = None
    name: str | None = None
    delimiter: str | None = None
    keep_approval: bool = False


@router.put("/{layout_id}")
def update(layout_id: int, req: LayoutEdit):
    """Edit a layout — including an approved one.

    Resets to pending_review unless keep_approval is set, because the approval
    attested to a specific set of fields and rules. Renaming fields is the main
    use: a fixed-width layout arrives as FIELD_1, FIELD_2, which match no
    generated column and therefore render blank.
    """
    try:
        updated = ls.update_layout(
            layout_id, fields=req.fields, name=req.name,
            delimiter=req.delimiter, keep_approval=req.keep_approval,
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")
    if req.fields is not None:
        updated.update(ls.alias_chosen(req.fields))
    return updated

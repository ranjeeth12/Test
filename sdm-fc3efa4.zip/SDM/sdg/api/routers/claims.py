"""Claims profiling over sdm.claims_denorm.

claims_data_loader still carries @st.cache_data decorators. They function
outside a Streamlit runtime (you'll see a ScriptRunContext warning on first
call and nothing else), so this router works as-is. Swapping them for
api.cache.ttl_cache removes the warning and is a five-minute job — see the
README.
"""

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from sdg.analyzer.services import errors

from sdg.analyzer.services.schemas import ClaimsOverview, CodeCount
from sdg.discovery.errors import plain

router = APIRouter(prefix="/claims", tags=["claims"])


def _loader():
    try:
        from sdg.analyzer import claims_data_loader as cdl
        return cdl
    except Exception as e:
        raise HTTPException(
            status_code=503,
            detail=f"Claims module unavailable: {plain(e)}",
        )


@router.get("/available")
def available():
    cdl = _loader()
    try:
        return {"available": bool(cdl.claims_available())}
    except Exception:
        return {"available": False}


@router.get("/overview", response_model=ClaimsOverview)
def overview():
    cdl = _loader()
    if not cdl.claims_available():
        raise HTTPException(
            status_code=404,
            detail="claims_denorm is empty or missing. Create the table, then run "
                   "python -m sdg.analyzer.populate_claims_denorm",
        )
    raw = cdl.get_claims_overview() or {}
    return {k: int(raw.get(k, 0) or 0) for k in ClaimsOverview.model_fields}


@router.get("/diagnoses", response_model=list[CodeCount])
def diagnoses(n: int = 30):
    cdl = _loader()
    df = cdl.get_top_diagnoses(n)
    return _codes(df)


@router.get("/procedures", response_model=list[CodeCount])
def procedures(n: int = 30):
    cdl = _loader()
    df = cdl.get_top_procedures(n)
    return _codes(df)


def _codes(df) -> list[dict]:
    """Map whatever column names the query returned onto code/description/n."""
    if df is None or len(df) == 0:
        return []
    cols = list(df.columns)
    code_col = next((c for c in cols if "CD" in c.upper() or "CODE" in c.upper()), cols[0])
    desc_col = next((c for c in cols if "DESC" in c.upper()), None)
    n_col = next(
        (c for c in cols if c.upper() in ("N", "CNT", "COUNT", "N_CLAIMS", "TOTAL")),
        cols[-1],
    )
    out = []
    for _, r in df.iterrows():
        out.append({
            "code": str(r[code_col]).strip(),
            "description": str(r[desc_col]).strip() if desc_col else None,
            "n": int(r[n_col] or 0),
        })
    return out


# ── Hierarchy cascade ────────────────────────────────────────────────────────

def _t(v):
    return tuple(v) if v else None


def _guard(fn, *args):
    """Run a hierarchy lookup, turning any failure into a readable message.

    Without this an exception surfaces as a bare 500 and the filter rail shows
    an empty list — indistinguishable from a table that legitimately has no
    rows. The distinction matters: one is a bug, the other is a valid answer.
    """
    from sdg.analyzer.services import claims_service as cs
    try:
        return fn(cs, *args)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Claims hierarchy lookup failed: {plain(e)}",
        )


@router.get("/groups")
def claim_groups():
    return _guard(lambda cs: cs.groups())


@router.get("/plans")
def claim_plans(grgr_ck: list[int] | None = Query(None)):
    return _guard(lambda cs, g: cs.plans(g), _t(grgr_ck))


@router.get("/products")
def claim_products(grgr_ck: list[int] | None = Query(None),
                   cspi_id: list[str] | None = Query(None)):
    return _guard(lambda cs, g, p: cs.products(g, p), _t(grgr_ck), _t(cspi_id))


@router.get("/types")
def claim_types(grgr_ck: list[int] | None = Query(None),
                cspi_id: list[str] | None = Query(None),
                pdpd_id: list[str] | None = Query(None)):
    return _guard(lambda cs, g, p, d: cs.claim_types(g, p, d),
                  _t(grgr_ck), _t(cspi_id), _t(pdpd_id))


# ── Pattern analysis ─────────────────────────────────────────────────────────

class ClaimsAnalyzeRequest(BaseModel):
    grgr_ck: list[int] | None = None
    cspi_id: list[str] | None = None
    pdpd_id: list[str] | None = None
    claim_type: list[str] | None = None
    gender: str | None = None
    # A defined pattern's rules beyond the hierarchy; see defined_patterns.
    conditions: dict | None = None
    # 1 is the whole scope as one pattern.
    k: int | None = Field(None, ge=1, le=20)

    def as_kwargs(self) -> dict:
        from sdg.analyzer.services.defined_patterns import check

        return {k: v for k, v in {
            "grgr_ck": self.grgr_ck or None,
            "cspi_id": self.cspi_id or None,
            "pdpd_id": self.pdpd_id or None,
            "claim_type": self.claim_type or None,
            "gender": self.gender or None,
            "conditions": check("claims", self.conditions) or None,
        }.items() if v is not None}


@router.post("/analyze")
def claims_analyze(req: ClaimsAnalyzeRequest):
    from sdg.analyzer.services import claims_service as cs
    try:
        return cs.analyze(req.as_kwargs(), req.k)
    except ValueError as e:
        # load_filtered_claims raises this when a filter combination is empty.
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


# ── Generation ───────────────────────────────────────────────────────────────

class ClaimsRowsRequest(ClaimsAnalyzeRequest):
    """Source rows for one cluster of a claims analysis."""
    cluster_id: int
    limit: int = Field(25, ge=1, le=500)
    offset: int = Field(0, ge=0)


@router.post("/rows")
def claims_pattern_rows(req: ClaimsRowsRequest):
    """The real claim rows behind one analyzed claims pattern.

    The claims profiler's patterns have no pattern_id until they are saved, so
    they are addressed by the analysis that produced them.
    """
    from sdg.analyzer.services import pattern_data

    try:
        return pattern_data.page_live(
            "claims", req.as_kwargs(), req.k, req.cluster_id,
            req.limit, req.offset)
    except pattern_data.StalePattern as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=errors.detail(e))


class ClaimsGenerateRequest(ClaimsAnalyzeRequest):
    cluster_id: int
    n_records: int = Field(100, ge=1, le=100_000)
    member_pattern_id: int = Field(
        ..., description="Member pattern the generated claims attach to.",
    )
    seed: int | None = None
    row_indices: list[int] | None = None


@router.get("/member-patterns")
def member_patterns():
    """Member patterns available to map claims onto."""
    from sdg.analyzer.services import claims_service as cs
    try:
        return cs.saved_member_patterns()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")


class ClaimsSaveRequest(ClaimsAnalyzeRequest):
    cluster_id: int


@router.post("/save")
def claims_save(req: ClaimsSaveRequest):
    """Persist and mark-saved a claims pattern, so it's retrievable later."""
    from sdg.analyzer import db

    from sdg.analyzer.services import claims_service as cs

    try:
        result = cs.analyze(req.as_kwargs(), req.k)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{plain(e)}")

    pattern = next(
        (p for p in result["patterns"] if p["cluster_id"] == req.cluster_id), None
    )
    if pattern is None:
        raise HTTPException(status_code=404, detail=f"Pattern {req.cluster_id} not in this view.")

    try:
        book = cs.book_totals().get("claims", 0) or 1
        from sdg.analyzer.services.discovery_service import canonical_combo
        pattern_id = db.save_pattern_from_profiler(
            combo=canonical_combo({**req.as_kwargs(),
                   "grgr_name": "", "cspd_cat_desc": "Claims",
                   "plds_desc": "", "pdds_desc": ""}, entity="claims"),
            cluster_id=req.cluster_id,
            contextual_name=f"[Claims] {pattern['name']}",
            member_count=int(pattern["n_claims"]),
            pct_of_pop=int(pattern["n_claims"]) / book,
            silhouette=float(result.get("silhouette") or 0.0),
            profile={"claims_pattern": True, **pattern},
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Save failed: {plain(e)}")

    return {"pattern_id": pattern_id, "saved": True, "name": pattern["name"]}


class ClaimsLayoutRequest(ClaimsGenerateRequest):
    layout_id: int



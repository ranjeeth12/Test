"""HTTP API for the web interface.

Endpoints return the shape a screen needs rather than the shape an artifact
happens to have. The schema endpoint, for instance, folds the physical model,
the profile, the mapping, and the proposal into one row per column, because
that is the unit a person looks at.
"""

from __future__ import annotations

import json
import mimetypes
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from sdg import __version__
from sdg.api.service import Service, ServiceError
from sdg.discovery.errors import plain

UI_DIST = Path(__file__).resolve().parent.parent.parent / "ui" / "dist"

# Python takes content types from the Windows registry, and many managed
# machines map .js to text/plain. A browser will not run a module script
# served as text/plain: the interface stays blank with no error on screen.
mimetypes.add_type("text/javascript", ".js")
mimetypes.add_type("text/css", ".css")

app = FastAPI(title="SDM", version=__version__, docs_url="/api/docs")
service = Service()


@app.exception_handler(ServiceError)
async def _service_error(_request, exc: ServiceError):
    from fastapi.responses import JSONResponse

    return JSONResponse(status_code=409, content={"detail": str(exc)})


@app.exception_handler(Exception)
async def _unexpected(_request, exc: Exception):
    """Anything nothing caught reaches the screen as a sentence, never as
    "Internal Server Error"."""
    from fastapi.responses import JSONResponse

    return JSONResponse(status_code=500, content={"detail": plain(exc)})


def _guard(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except ServiceError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        # An edit that cannot be read as the type it belongs to. It is the
        # person's typing, not a fault, so it gets the same treatment as any
        # other refused edit rather than a stack trace.
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except Exception as exc:  # surfaced to the user rather than swallowed
        raise HTTPException(status_code=500, detail=f"{plain(exc)}") from exc


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------


@app.get("/api/state")
def state() -> dict[str, Any]:
    """What exists so far, and the headline number for each step."""
    settings = service.settings
    steps: list[dict[str, Any]] = [
        {
            "id": "connect",
            "label": "Connect",
            "done": service.exists("connections"),
            # The database being worked on: the one chosen on Connect.
            "detail": service.working_database()["database"],
        }
    ]

    # Reading the structure and measuring it are one step to look at: the
    # same columns, what they are and what they hold. They are still two
    # stages of a read, and Connect shows each, so both are said here.
    model = service.model
    report = service.report
    found = [f"{len(model.tables)} tables"] if model else []
    if report:
        found.append(f"{len(report.columns)} columns")
    steps.append({
        "id": "discover",
        "label": "Discover and Profile",
        "done": model is not None and report is not None,
        "detail": " · ".join(found),
        "value": len(model.tables) if model else None,
        "read": model is not None,
        "measured": report is not None,
    })

    # Matching columns to elements and deciding what the tool would not are
    # one screen: the decisions waiting first, then every column's match.
    mappings = service.mappings
    stats = mappings.statistics() if mappings else None
    queued = None
    if model is not None and mappings is not None and service.exists("proposals"):
        queued = len(_queue_items())
    said = [f"{stats['auto_map_rate']:.0%} auto-mapped"] if stats else []
    if queued is not None:
        said.append(f"{queued} to decide")
    steps.append({
        "id": "map",
        "label": "Map & Review",
        "done": service.exists("proposals"),
        "detail": " · ".join(said),
        "value": round(stats["auto_map_rate"] * 100) if stats else None,
        "mapped": mappings is not None,
        "proposed": service.exists("proposals"),
    })

    steps.append({
        "id": "patterns",
        "label": "Patterns",
        "done": mappings is not None,
        "detail": "ready" if mappings is not None else "",
        "value": None,
    })

    plan = service.plan
    total = (
        sum(t.effective_count or 0 for t in plan.tables if t.mode == "generate")
        if plan else None
    )

    # One step with two tabs: a database load, or files. The plan belongs to
    # the first -- the cascade of tables and how many rows each gets.
    manifest = service.manifest
    steps.append({
        "id": "run",
        "label": "Generation",
        "done": manifest is not None,
        "detail": (
            f"{manifest['run']['rows_written']:,} written" if manifest
            else (f"{total:,} rows planned" if total else "")
        ),
        "value": manifest["run"]["rows_written"] if manifest else total,
    })

    working = service.working_database()
    return {
        "version": __version__,
        # The database every step reads and writes: the one chosen on Connect.
        "database": working["database"],
        # Patterns always come from the pattern store, whatever is worked on.
        "landscape": settings.denorm_db,
        "referenceDatabase": settings.ref_db,
        "server": working["server"],
        "steps": steps,
        "settings": service.read_settings(),
    }


@app.post("/api/connect")
def connect() -> dict[str, Any]:
    return _guard(service.connect)


@app.post("/api/discover")
def discover() -> dict[str, Any]:
    return _guard(service.discover)


@app.post("/api/profile")
def profile() -> dict[str, Any]:
    return _guard(service.profile)


@app.post("/api/map")
def map_columns() -> dict[str, Any]:
    return _guard(service.map)


@app.post("/api/review")
def review() -> dict[str, Any]:
    return _guard(service.review)


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------


def _column_payload(table, column, report, mappings, proposal, decision=None) -> dict[str, Any]:
    column_profile = report.column(table.name, column.name) if report else None
    mapping = mappings.for_column(table.name, column.name) if mappings else None

    # What the tool worked out on its own. It is kept whole, because the editor
    # offers to put it back and the panel says what it was.
    proposed_element = mapping.element if mapping else None
    proposed_generator = proposal.generator if proposal else None
    proposed_params = proposal.params if proposal else {}

    element = proposed_element
    accepted = mapping.accepted if mapping else False
    generator = proposed_generator
    params = proposed_params
    provenance = proposal.provenance if proposal else None

    # A person's decision beats the proposal, which is the precedence the
    # resolver applies when it builds the plan. Reporting the proposal here
    # would describe a rule the run is not going to use.
    if decision and decision.get("approved"):
        if "element" in decision:
            element = decision["element"]
            accepted = element is not None
        if decision.get("generator"):
            generator = decision["generator"]
            params = decision.get("params") or {}
        provenance = "user"

    return {
        "table": table.name,
        "name": column.name,
        "type": column.type_description(),
        "nullable": column.nullable,
        "bucket": column.bucket,
        "bucketReason": column.bucket_reason,
        "isPrimaryKey": column.is_primary_key,
        "isIdentity": column.is_identity,
        "isComputed": column.is_computed,
        "profile": _profile_payload(column_profile),
        "element": element,
        "decision": decision,
        "mappingConfidence": mapping.confidence if mapping else None,
        "mappingAccepted": accepted,
        "mappingReason": mapping.reason if mapping else "",
        "mappingEvidence": mapping.evidence if mapping else [],
        "alternatives": [a.element for a in mapping.alternatives] if mapping else [],
        "generator": generator,
        "params": params,
        "proposedElement": proposed_element,
        "proposedGenerator": proposed_generator,
        "proposedParams": proposed_params,
        "provenance": provenance,
        "confidence": proposal.confidence if proposal else None,
        "coverage": proposal.coverage if proposal else None,
        "evidence": proposal.evidence if proposal else [],
        "note": proposal.note if proposal else "",
    }


def _decisions_by_column() -> dict[tuple[str, str], dict[str, Any]]:
    """Everything a person has said, read once rather than once per column."""
    return {
        (entry.get("table"), entry.get("column")): entry
        for entry in service.read_decisions().get("columns", [])
    }


def _profile_payload(column_profile) -> dict[str, Any] | None:
    if column_profile is None:
        return None
    return {
        "rowCount": column_profile.row_count,
        "nullRate": column_profile.null_rate,
        "distinctCount": column_profile.distinct_count,
        "distinctRatio": column_profile.distinct_ratio,
        "cardinality": column_profile.cardinality,
        "minimum": _plain(column_profile.minimum),
        "maximum": _plain(column_profile.maximum),
        "mean": column_profile.mean,
        "stddev": column_profile.stddev,
        "minLength": column_profile.min_length,
        "maxLength": column_profile.max_length,
        "format": column_profile.fitted_format,
        "checkDigit": column_profile.check_digit,
        "sequence": column_profile.sequence,
        "distribution": column_profile.distribution,
        "topValues": [
            {"value": _plain(t.value), "count": t.count, "share": t.share}
            for t in (column_profile.top_values or [])
        ],
    }


def _plain(value):
    return value if value is None or isinstance(value, (int, float, str, bool)) else str(value)


@app.get("/api/schema")
def schema() -> dict[str, Any]:
    model = _guard(service.require_model)
    report = service.report
    mappings = service.mappings
    by_column = {p.qualified: p for p in service.proposals()} if mappings else {}
    decisions = _decisions_by_column()

    tables = []
    for table in model.tables:
        tables.append({
            "name": table.name,
            "schema": table.schema_name,
            "table": table.table_name,
            "rowCount": table.row_count,
            "primaryKey": table.primary_key,
            "triggers": table.triggers,
            "foreignKeys": [
                {
                    "kind": fk.kind,
                    "name": fk.name,
                    "columns": fk.columns,
                    "parentTable": fk.parent_table,
                    "parentColumns": fk.parent_columns,
                    "coverage": fk.coverage,
                    "evidence": fk.evidence,
                }
                for fk in table.foreign_keys
            ],
            "columns": [
                _column_payload(
                    table, column, report, mappings,
                    by_column.get(f"{table.name}.{column.name}"),
                    decisions.get((table.name, column.name)),
                )
                for column in table.columns
            ],
        })

    return {
        "tables": tables,
        "dependencies": [d.model_dump() for d in (report.dependencies if report else [])],
        "orderings": [o.model_dump() for o in (report.orderings if report else [])],
        "ratios": [r.model_dump() for r in (report.ratios if report else [])],
    }


# ---------------------------------------------------------------------------
# Review queue
# ---------------------------------------------------------------------------


def _queue_items():
    from sdg.review.queue import build_queue

    return build_queue(
        service.require_model(), service.require_mappings(), service.proposals()
    )


@app.get("/api/queue")
def queue() -> dict[str, Any]:
    items = _guard(_queue_items)
    decisions = {
        f"{d.get('table')}.{d.get('column')}": d
        for d in service.read_decisions().get("columns", [])
    }
    return {
        "items": [
            {
                **item.as_dict(),
                "qualified": item.qualified,
                "mappingEvidence": item.mapping_evidence,
                "proposalEvidence": item.proposal_evidence,
                "decision": decisions.get(item.qualified),
            }
            for item in items
        ],
        "decided": sum(
            1 for item in items if decisions.get(item.qualified, {}).get("approved")
        ),
    }


class Decision(BaseModel):
    table: str
    column: str
    approved: bool | None = None
    element: str | None = None
    generator: str | None = None
    params: dict[str, Any] | None = None
    # Drop the override and go back to what the tool worked out.
    reset: bool | None = None


@app.post("/api/decisions")
def record_decision(decision: Decision) -> dict[str, Any]:
    # element is allowed to be null: "this column maps to nothing" is an answer.
    payload = decision.model_dump(exclude_unset=True)
    return _guard(service.record_decision, payload)


@app.get("/api/ratio-shapes")
def ratio_shapes() -> dict[str, Any]:
    """The shapes a children-per-parent rule can take, for building a form."""
    from sdg.plan.editing import ratio_shapes as shapes

    return {"shapes": shapes()}


@app.get("/api/generators")
def generators() -> dict[str, Any]:
    """Every rule a column can be given, and what each one needs."""
    from sdg.plan.editing import STRUCTURAL_WARNING, generator_catalog

    return {
        "generators": generator_catalog(),
        "structuralWarning": STRUCTURAL_WARNING,
    }


# ---------------------------------------------------------------------------
# Where generated rows go
# ---------------------------------------------------------------------------


@app.get("/api/databases")
def list_databases() -> dict[str, Any]:
    """Every database on this server, and which one each role points at."""
    return {
        "databases": _guard(service.databases),
        "source": service.settings.source_db,
        "store": service.settings.denorm_db,
        "target": service.registry.database_for("target"),
        "server": service.settings.mssql.server,
    }


class TargetRequest(BaseModel):
    database: str


@app.get("/api/databases/onboarded")
def onboarded_databases() -> dict[str, Any]:
    """The databases onboarded here, and whether rows written into them remain."""
    return {"databases": _guard(service.onboarded)}


class OffboardRequest(BaseModel):
    key: str


@app.post("/api/databases/offboard")
def offboard_database(req: OffboardRequest) -> dict[str, Any]:
    """Forget an onboarded database. Patterns and the analysis store are untouched."""
    return _guard(service.offboard, req.key)


@app.post("/api/target")
def choose_target(req: TargetRequest) -> dict[str, Any]:
    """Point generation at a database on the configured server."""
    return _guard(service.set_target, req.database)


class TargetConnection(BaseModel):
    """A target somewhere other than the configured server.

    `trusted` is Windows authentication, which is both the common case on a
    domain-joined machine and the one where no password is stored anywhere.
    """

    database: str
    server: str | None = None
    port: int | None = None
    trusted: bool = False
    user: str | None = None
    password: str | None = None
    driver: str | None = None
    trustCert: bool = True


@app.post("/api/target/test")
def test_target(req: TargetConnection) -> dict[str, Any]:
    """Reach a connection without saving it."""
    return _guard(service.test_target_connection, req.model_dump())


@app.post("/api/target/connection")
def save_target(req: TargetConnection) -> dict[str, Any]:
    """Check a connection, keep it, and generate into it from now on."""
    return _guard(service.save_target_connection, req.model_dump())


@app.delete("/api/target/connection")
def forget_target() -> dict[str, Any]:
    """Back to the database named in `.env`, on the configured server."""
    return _guard(service.clear_target_connection)


@app.get("/api/target/connection")
def read_target() -> dict[str, Any]:
    """What is configured, with the password withheld."""
    stored = _guard(service.target_connection)
    if not stored:
        return {"configured": False}
    return {
        "configured": True,
        **{k: v for k, v in stored.items() if k != "password"},
        "hasPassword": bool(stored.get("password")),
    }


# ---------------------------------------------------------------------------
# Settings and plan
# ---------------------------------------------------------------------------


class Settings(BaseModel):
    rootCounts: dict[str, int] | None = None
    # Which kind of thing each table holds, named by the store table that holds
    # the same kind. Stated the way a root count is: the tool can read the
    # shape of a database but not what its rows mean.
    subjects: dict[str, str] | None = None
    # Where generated rows go. Named here rather than only in .env so a target
    # can be chosen without restarting the process.
    targetDb: str | None = None
    modes: dict[str, str] | None = None
    drivingParents: dict[str, str] | None = None
    ratios: dict[str, dict[str, Any] | None] | None = None
    seed: str | None = None
    planName: str | None = None


@app.put("/api/settings")
def put_settings(values: Settings) -> dict[str, Any]:
    return _guard(service.write_settings, values.model_dump(exclude_none=True))


@app.post("/api/plan")
def build() -> dict[str, Any]:
    plan, graph, extra = _guard(service.build)
    return _plan_payload(plan, graph, extra)


@app.get("/api/plan")
def get_plan() -> dict[str, Any]:
    plan = service.plan
    if plan is None:
        return {"built": False}
    # Stale: built before a rule, a pattern or a count changed. The screen
    # rebuilds it rather than show a load the decisions no longer describe.
    return {"built": True, "stale": service.plan_stale(), **_plan_payload(plan, None, {})}


def _plan_payload(plan, graph, extra: dict[str, Any]) -> dict[str, Any]:
    provenance: dict[str, int] = {}
    for table in plan.tables:
        for field in table.fields:
            provenance[field.provenance] = provenance.get(field.provenance, 0) + 1

    nodes = []
    generated_names = {t.name for t in plan.tables if t.mode == "generate"}

    for table in plan.tables:
        node = graph.nodes.get(table.name) if graph else None
        ratio = table.ratio
        # A reloaded plan has no graph behind it, but the ratio it carries is
        # enough to recover the mean, so the cascade reads the same either way.
        ratio_mean = node.ratio_mean if node else None
        if ratio_mean is None and ratio is not None:
            ratio_mean = round(ratio.mean_children(), 4)
        nodes.append({
            "name": table.name,
            "mode": table.mode,
            "level": table.level,
            "drivingParent": table.driving_parent,
            # Every parent this table could be driven by, which is what the
            # builder validates an override against. Only a parent that is
            # itself generated counts: the cascade is over generated tables,
            # and a reference set sits outside it. Computed from the plan
            # rather than the graph, because a reloaded plan has no graph and
            # the two must not disagree about what is on offer.
            "parents": sorted(
                {
                    r.parent_table
                    for r in (table.relationships or [])
                    if r.parent_table in generated_names and r.parent_table != table.name
                }
            ),
            "count": table.count,
            "effectiveCount": table.effective_count,
            "ratioMean": ratio_mean,
            "ratio": ratio.model_dump(exclude_none=True) if ratio else None,
            "ratioOverride": bool(ratio and ratio.provenance == "user"),
            "fields": [
                {
                    "name": f.name,
                    "bucket": f.bucket,
                    "element": f.element,
                    "generator": f.generator,
                    "params": f.params,
                    "provenance": f.provenance,
                    "confidence": f.confidence,
                    "coverage": f.coverage,
                    "userOverride": f.user_override,
                    "nullRate": f.null_rate,
                    "dataType": f.data_type,
                    "evidence": [e.model_dump(exclude_none=True) for e in (f.evidence or [])],
                    "overrode": [o.model_dump(exclude_none=True) for o in (f.overrode or [])],
                }
                for f in table.fields
            ],
        })

    return {
        "built": True,
        "meta": plan.meta.model_dump(exclude_none=True),
        "generationOrder": plan.generation_order,
        "tables": nodes,
        "warnings": [w.model_dump(exclude_none=True) for w in plan.warnings],
        "blocking": sum(1 for w in plan.warnings if w.severity == "block"),
        "provenance": dict(sorted(provenance.items())),
        "totalRows": sum(
            t.effective_count or 0 for t in plan.tables if t.mode == "generate"
        ),
        **extra,
    }


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------


@app.post("/api/dryrun")
def dryrun(rows: int = 6) -> dict[str, Any]:
    return _guard(service.dry_run, rows)


@app.post("/api/generate")
def generate() -> dict[str, Any]:
    return _guard(service.generate)


@app.post("/api/validate")
def validate() -> dict[str, Any]:
    return _guard(service.validate)


@app.post("/api/cleanup")
def cleanup() -> dict[str, Any]:
    return _guard(service.cleanup)


@app.get("/api/run")
def run() -> dict[str, Any]:
    manifest = service.manifest
    return {"hasRun": manifest is not None, "manifest": manifest}


@app.get("/api/catalog")
def catalog() -> dict[str, Any]:
    loaded = service.catalog
    mappings = service.mappings
    used: dict[str, list[str]] = {}
    if mappings:
        for mapping in mappings.mappings:
            if mapping.element:
                used.setdefault(mapping.element, []).append(mapping.qualified)
    return {
        "organization": loaded.organization,
        "version": loaded.version,
        "summary": loaded.summary(),
        "elements": [
            {
                "name": element.name,
                "description": element.description,
                "domain": element.domain,
                "rule": element.rule,
                "generator": element.generator,
                "format": element.format,
                "pii": element.pii,
                "consistencyScope": element.consistency_scope,
                "aliases": element.aliases,
                "checkDigit": element.check_digit,
                "reuseDomain": (
                    element.reuse_domain.model_dump(exclude_none=True, by_alias=True)
                    if element.reuse_domain else None
                ),
                "usedBy": used.get(element.name, []),
                "valueCount": len(element.params.get("values") or []),
            }
            for element in loaded.elements
        ],
    }


# ---------------------------------------------------------------------------
# The pattern analyzer
# ---------------------------------------------------------------------------

# The analyzer arrived as its own FastAPI process on another port, with its own
# CORS rules and its own copy of the interface. It is mounted here instead, so
# there is one process, one origin, and one place a browser has to be pointed.
# Its routes keep the paths they had, under /api.
from sdg.api.routers import (  # noqa: E402  (mounted after the native routes)
    baseline, claims, discovery, files, hierarchy, layouts, masking, patterns, rules,
    story,
)

for _router in (
    hierarchy.router, patterns.router, claims.router, story.router,
    baseline.router, discovery.router, layouts.router, rules.router,
    masking.router, files.router,
):
    app.include_router(_router, prefix="/api")

# The analyzer's own generation routes are gone. It had a second generator --
# its own synthetic engine and its own validator -- and two engines meant two
# definitions of a valid row. The plan engine generates; /api/export writes the
# result in whichever shape another system reads, including the analyzer's EDI.


class ToPlanRequest(BaseModel):
    """A pattern the analyzer produced, on its way to becoming generation rules."""

    pattern: dict[str, Any]
    kind: str = "member"
    as_of: str | None = None
    apply: bool = False
    # Whether the pattern describes the whole run or its own share of the
    # population. A share needs the pattern's support, which the analyzer
    # measured; this tool will not invent one.
    as_cohort: bool = False


@app.post("/api/patterns/to-plan")
def pattern_to_plan(request: ToPlanRequest) -> dict[str, Any]:
    """Resolve a discovered pattern onto the columns it governs.

    This is the join between the two halves: the analyzer says what a cohort
    looks like, and this says which columns would have to carry which rules for
    the generator to produce one. Nothing is written unless `apply` is set, and
    what is written is an ordinary review decision, so `sdg plan` picks it up
    the same way it picks up an edit made by hand.
    """
    from sdg.analyzer.bridge import to_pattern
    from sdg.plan.patterns import apply_to_decisions, resolve_pattern

    pattern = request.pattern
    # Where the store holds no addresses, as a customer's denorm does not, a
    # member's ZIP, city and state still go in together, from the store's own
    # address list.
    if request.kind == "member" and not pattern.get("geography") and _addresses():
        share = 1 / len(_addresses())
        pattern = {**pattern, "geography": [{**a, "share": share} for a in _addresses()]}
    analyzer_pattern = to_pattern(pattern, kind=request.kind, as_of=request.as_of)
    # A pattern reaches the database through the plan's columns. With no plan
    # yet, one is built here rather than sending the person off to build it
    # and come back: it is the step they would take anyway.
    plan = (_guard(service.build)[0] if service.plan is None or service.plan_stale()
            else service.plan)
    resolution = _guard(
        resolve_pattern,
        analyzer_pattern,
        catalog=service.catalog,
        mappings=service.require_mappings(),
        plan=plan,
        model=service.model,
    )

    written: list[str] = []
    if request.apply and resolution.targets:
        document, written = _guard(
            apply_to_decisions, [resolution], service.read_decisions(),
            as_cohort=request.as_cohort,
        )
        service.write_decisions(document)

    return {
        "pattern": analyzer_pattern.model_dump(mode="json"),
        "resolution": resolution.model_dump(mode="json"),
        "applied": written,
    }


@app.get("/api/edi/snip")
def snip_rules() -> dict[str, Any]:
    """The SNIP rule files in effect, the trading partners, and where a
    customer's own files go -- so the screen can say what is being checked."""
    from sdg.writers.snip import engine

    return {"rules": engine.rule_files(), "partners": engine.partners(),
            "customerDir": str(engine.customer_dir())}


class SnipCheck(BaseModel):
    """The file this screen would write, and a trading partner's rules to add."""

    export: dict[str, Any]
    partner: str | None = None


@app.post("/api/edi/snip/check")
def snip_check(request: SnipCheck) -> dict[str, Any]:
    """SNIP-style checks of exactly the file the export would write."""
    from sdg.writers.snip import validate

    export_request = ExportRequest(**request.export)
    snip = export_request.format.startswith("edi")
    if export_request.format.startswith("sample:"):
        # A file modeled on a sample is checked as its format says it can be.
        from sdg.analyzer.services import sample_gen_configs
        from sdg.writers import samples

        config_id = export_request.format.split(":", 1)[1]
        modeled = sample_gen_configs.get_config(int(config_id)) if config_id.isdigit() else None
        fmt = samples.FORMATS.get(modeled["format"]) if modeled else None
        snip = fmt is not None and fmt.VALIDATION == "snip"
    if not snip:
        raise HTTPException(status_code=422, detail="SNIP checks apply to EDI formats only.")
    stream, _media, _name = _export_stream(export_request)
    try:
        text = "".join(
            chunk.decode("utf-8") if isinstance(chunk, bytes) else chunk for chunk in stream
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    return validate(text, partner=request.partner)


@app.post("/api/samples/check")
def sample_check(request: SnipCheck) -> dict[str, Any]:
    """The file a sample config writes, checked as its format checks (FHIR: models,
    references, value sets). X12 is checked by /api/edi/snip/check."""
    from sdg.analyzer.services import sample_gen_configs
    from sdg.writers import samples

    export_request = ExportRequest(**request.export)
    config_id = export_request.format.split(":", 1)[1] if ":" in export_request.format else ""
    modeled = sample_gen_configs.get_config(int(config_id)) if config_id.isdigit() else None
    if modeled is None or not export_request.format.startswith("sample:"):
        raise HTTPException(status_code=404, detail="Choose a saved sample config to check.")
    fmt = samples.FORMATS.get(modeled["format"])
    if fmt is None or not hasattr(fmt, "check"):
        raise HTTPException(status_code=422,
                            detail=f"{modeled['format']} files are not checked here.")
    export_request.packaged = False
    stream, _media, _name = _export_stream(export_request)
    try:
        text = "".join(
            chunk.decode("utf-8") if isinstance(chunk, bytes) else chunk for chunk in stream
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    from sdg.writers.samples import profile

    return fmt.check(text, profile.for_kind(modeled["format"], modeled["kind"]) or {})


@app.post("/api/edi/snip/check-file")
async def snip_check_file(file: UploadFile = File(...),
                          partner: str | None = Form(None)) -> dict[str, Any]:
    """SNIP-style checks of an X12 file from anywhere -- another system's too."""
    from sdg.writers.snip import validate

    raw = await file.read()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")
    report = validate(text, partner=partner or None)
    report["file"] = file.filename
    return report


@app.get("/api/edi/formats")
def edi_formats() -> dict[str, Any]:
    """Every transaction set this installation can write.

    Described in files rather than compiled in, so a format somebody adds
    appears here without anything being rebuilt.
    """
    from sdg.writers.edi_formats import formats

    return {"formats": [f.summary() for f in formats()]}


class SampleRead(BaseModel):
    """A sample file and the config whose places are proposed for it.

    The master is a config's JSON text (a masking config or a generation
    config) or a saved generation config by id, whose sample is used when no
    other is given. The format is read off the sample."""

    sample: str | None = None
    sampleName: str | None = None
    master: str | None = None
    masterName: str | None = None
    configId: int | None = None


@app.post("/api/samples/read")
def sample_read(request: SampleRead) -> dict[str, Any]:
    """Every place of the sample, with the algorithm the master proposes."""
    from sdg.analyzer.services import sample_gen_configs
    from sdg.writers import samples

    sample_text, master, based_on = request.sample, request.master, request.masterName
    if request.configId is not None:
        saved = sample_gen_configs.get_config(request.configId)
        if saved is None:
            raise HTTPException(status_code=404, detail=f"No sample config {request.configId}.")
        master, based_on = json.dumps(saved["config"]), saved["name"]
        sample_text = sample_text or saved["sample_text"]
    if not sample_text:
        raise HTTPException(status_code=422, detail="Choose a sample file first.")
    try:
        fmt = samples.detect(sample_text)
        sample = fmt.read_sample(sample_text)
        entries = fmt.read_config(master) if master else []
    except samples.SampleError as e:
        raise HTTPException(status_code=422, detail=str(e))
    algorithms = samples.algorithm_rules()
    counts, summary = fmt.facts(sample)
    return {
        "format": fmt.FORMAT, "kind": sample.kind, "version": sample.version,
        "sampleName": request.sampleName, "basedOn": based_on,
        "counts": counts, "summary": summary, "subject": fmt.subject(sample.kind),
        "validation": fmt.VALIDATION,
        "rows": fmt.propose(sample, entries, algorithms),
        "algorithms": sorted(algorithms),
    }


class GenConfigSave(BaseModel):
    """Save the chosen places as a new generation config."""

    name: str
    sample: str | None = None
    sampleName: str | None = None
    basedOn: str | None = None
    rows: list[dict[str, Any]]
    # Read from a saved config and no other sample chosen: that config's sample.
    fromConfigId: int | None = None


@app.get("/api/samples/configs")
def sample_config_list() -> dict[str, Any]:
    from sdg.analyzer.services import sample_gen_configs

    return {"configs": sample_gen_configs.list_configs()}


@app.get("/api/samples/configs/{config_id}")
def sample_config_get(config_id: int) -> dict[str, Any]:
    from sdg.analyzer.services import sample_gen_configs

    saved = sample_gen_configs.get_config(config_id)
    if saved is None:
        raise HTTPException(status_code=404, detail=f"No sample config {config_id}.")
    saved.pop("sample_text", None)
    return saved


@app.post("/api/samples/configs")
def sample_config_save(request: GenConfigSave) -> dict[str, Any]:
    """Save as: always a new config; the master it came from is not touched."""
    from sdg.analyzer.services import sample_gen_configs
    from sdg.writers import samples

    sample_text, sample_name = request.sample, request.sampleName
    if not sample_text and request.fromConfigId is not None:
        source = sample_gen_configs.get_config(request.fromConfigId)
        if source is None:
            raise HTTPException(status_code=404,
                                detail=f"No sample config {request.fromConfigId}.")
        sample_text, sample_name = source["sample_text"], sample_name or source["sample_name"]
    if not sample_text:
        raise HTTPException(status_code=422, detail="Choose a sample file first.")
    try:
        fmt = samples.detect(sample_text)
        sample = fmt.read_sample(sample_text)
    except samples.SampleError as e:
        raise HTTPException(status_code=422, detail=str(e))
    config = fmt.write_config(
        request.rows, transaction=sample.kind, version=sample.version,
        based_on=request.basedOn, sample_name=sample_name)
    if not fmt.positions(config):
        raise HTTPException(status_code=422, detail="No position takes a generated value: "
                            "choose an algorithm for at least one.")
    try:
        return sample_gen_configs.save_as(
            name=request.name, format=fmt.FORMAT, kind=sample.kind, version=sample.version,
            based_on=request.basedOn, config=config, sample_name=sample_name,
            sample_text=sample_text)
    except ValueError as e:
        raise HTTPException(status_code=409, detail=str(e))


@app.delete("/api/samples/configs/{config_id}")
def sample_config_delete(config_id: int) -> dict[str, Any]:
    from sdg.analyzer.services import sample_gen_configs

    if not sample_gen_configs.delete_config(config_id):
        raise HTTPException(status_code=404, detail=f"No sample config {config_id}.")
    return {"deleted": config_id}


@app.get("/api/patterns/for-files")
def patterns_for_files() -> dict[str, Any]:
    """The saved patterns, which are what a file can be written for.

    Saved means somebody kept it -- from an analysis, from chosen records, or
    by starring it in discovery. The patterns a discovery walk stores on its
    own are its working state, not a list anyone chose, and are left out.
    """
    import json

    from sdg.analyzer import db

    out = []
    for row in db.get_saved_patterns():
        if not row.get("profile_json"):
            continue
        profile = json.loads(row["profile_json"])
        out.append({
            "pattern_id": int(row["id"]),
            "name": str(row.get("contextual_name") or f"Pattern {row['id']}"),
            "domain": "claims" if profile.get("claims_pattern") else "members",
            "member_count": int(profile.get("n_members") or row.get("member_count") or 0),
            "saved": row.get("saved_by") is not None,
            "origin": row.get("origin") or "discovered",
        })
    # Most recently saved first, which is the order get_saved_patterns reads.
    return {"patterns": out}


class KeepPattern(BaseModel):
    """A pattern to save: what an analysis found, or only chosen records of it."""

    domain: str = "members"        # members | claims
    filters: dict[str, Any] = {}
    k: int | None = None
    cluster_id: int
    claim_type: str | None = None
    # Row names from the rows view; empty keeps the whole pattern.
    record_keys: list[str] = []
    name: str | None = None
    # "user_defined" for a pattern somebody defined by its rules.
    origin: str | None = None


@app.get("/api/discovery-features")
def discovery_features_get() -> dict[str, Any]:
    """Every feature of members and of claims, and which ones patterns are found on."""
    from sdg.analyzer.services import discovery_features

    return {entity: discovery_features.described(entity) for entity in ("members", "claims")}


class DiscoveryFeatures(BaseModel):
    entity: str
    features: list[str]


@app.put("/api/discovery-features")
def discovery_features_put(request: DiscoveryFeatures) -> dict[str, Any]:
    """Find patterns of this kind on these features from now on."""
    from sdg.analyzer.services import discovery_features

    try:
        discovery_features.choose(request.entity, request.features)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    return {request.entity: discovery_features.described(request.entity)}


@app.get("/api/report-fields")
def report_fields_get() -> dict[str, Any]:
    """Every field a pattern's counts can be made on, built-in and denorm, and
    which are chosen."""
    from sdg.analyzer.services import report_fields

    return {entity: report_fields.offered(entity) for entity in ("members", "claims")}


class ReportFields(BaseModel):
    entity: str
    fields: list[str]
    # Back to the built-in fields, whatever `fields` says.
    reset: bool = False


@app.put("/api/report-fields")
def report_fields_put(request: ReportFields) -> dict[str, Any]:
    """Count patterns of this kind on these fields, in this order, from now on."""
    from sdg.analyzer.services import report_fields

    try:
        if request.reset:
            report_fields.reset(request.entity)
        else:
            report_fields.choose(request.entity, request.fields)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    return {request.entity: report_fields.offered(request.entity)}


@app.get("/api/patterns/features")
def pattern_features(entity: str = "members") -> dict[str, Any]:
    """What a pattern can be defined by: each feature and the values it can take."""
    from sdg.analyzer.services import defined_patterns

    try:
        return {"entity": entity, "features": defined_patterns.catalog(entity)}
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.post("/api/patterns/keep")
def keep_pattern(request: KeepPattern) -> dict[str, Any]:
    """Save a pattern so it is ready under File Generation next time."""
    from sdg.analyzer.services import saved_patterns

    try:
        return saved_patterns.save(
            request.domain, request.filters, request.k, request.cluster_id,
            claim_type=request.claim_type, record_keys=request.record_keys,
            name=request.name, origin=request.origin,
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))


class LivePattern(BaseModel):
    """A pattern that exists only as the result of an analysis, not yet saved.

    Addressed the way the analysis addressed it -- its filters, k and cluster --
    because that is what rebuilds its members.
    """

    profile: dict[str, Any]
    domain: str = "members"        # members | claims
    filters: dict[str, Any] = {}
    k: int | None = None
    cluster_id: int
    claim_type: str | None = None


class ExportRequest(BaseModel):
    """What to write, in what shape, and for whom."""

    format: str = "csv"            # csv | fixed | edi:<id> | edi834 | edi837
    subject: str = "members"       # members | claims
    rows: int | None = None        # cap on records written
    root_limit: int | None = 2000  # cap on root rows generated, for speed
    layout_id: int | None = None   # for format=fixed or a delimited layout
    as_of: str = "2026-06-30"
    # EDI only: how many groups -- members, claims -- go in one ST/SE set. One
    # transaction holding a whole book is valid and nobody sends it.
    per_transaction: int | None = None
    # A pattern: a saved one by id, or one an analysis just found. With one,
    # members are new people with the pattern's values and claims are made for
    # the members the pattern holds. Without one, the plan's run is written.
    pattern_id: int | None = None
    pattern: LivePattern | None = None
    members: int = 100             # new members, for a member file from a pattern
    claims_per_member: int | None = None
    lines_per_claim: int | None = None
    # Several scenarios of a pattern, each kept as a pattern of its own rows,
    # written into one file: each scenario's count of records, tagged with it.
    scenarios: list["ScenarioPart"] | None = None
    # A format whose download is a package (CDA: a zip of documents) is written
    # unpacked when this is false: a preview, the checks.
    packaged: bool = True


class ScenarioPart(BaseModel):
    pattern_id: int
    label: str
    count: int = 1


ExportRequest.model_rebuild()


# Elements a file carries when no layout says otherwise.
DEFAULT_ELEMENTS = {
    "members": [
        "MEMBER_ID", "SUBSCRIBER_ID", "FIRST_NAME", "LAST_NAME", "SEX", "DOB",
        "MARITAL_STATUS", "EFFECTIVE_DATE", "TERMINATION_DATE",
        "COVERAGE_PLAN_ID", "PRODUCT_CODE",
        # Where the member lives, which a member pattern carries.
        "ADDRESS_CITY", "ADDRESS_STATE", "ADDRESS_ZIP",
    ],
    "claims": [
        "CLAIM_ID", "LINE_NUMBER", "MEMBER_ID", "SERVICE_DATE", "DIAGNOSIS_CODE",
        "PROCEDURE_CODE", "CHARGE_AMOUNT", "SERVICE_UNITS", "CLAIM_STATUS",
    ],
}


def _export_records(request: ExportRequest, rules: dict[str, dict]):
    """The records to write, keyed by element, and the rules to fill them with.

    A pattern replaces the rules for the elements it names. Members from a
    pattern are new; claims from a pattern belong to the members it holds,
    because a claim is always made by somebody who exists.
    """
    import json

    from sdg.writers import elements

    if request.pattern_id is None and request.pattern is None:
        # The plan's run: this one belongs to the database being worked on.
        plan = service.require_plan()
        result = _guard(service.run_for_export, request.root_limit)
        if request.subject == "claims":
            return elements.run_claim_lines(result, plan, limit=request.rows), rules
        return elements.run_members(result, plan, limit=request.rows), rules

    if request.pattern is not None:
        profile = dict(request.pattern.profile)
        scope = dict(request.pattern.filters)
    else:
        from sdg.analyzer import db

        row = db.get_pattern(request.pattern_id)
        if row is None or not row.get("profile_json"):
            raise HTTPException(status_code=404,
                                detail=f"No pattern {request.pattern_id}.")
        profile = json.loads(row["profile_json"])
        scope = {k: _listed(row.get(k)) for k in ("grgr_ck", "cspd_cat", "cspi_id", "pdpd_id")}

    claims_pattern = bool(profile.get("claims_pattern")) or (
        request.pattern is not None and request.pattern.domain == "claims")
    rules = elements.with_pattern(rules, elements.pattern_rules(
        profile, service.catalog,
        kind="claim" if claims_pattern else "member", as_of=request.as_of,
    ))

    # The pattern's group, plan and product, where no combination of the
    # pattern's already draws them together with what they depend on.
    combined = {e for e, r in rules.items() if r.get("record_key")}
    rules = elements.with_pattern(rules, {e: r for e, r in _scope_rules(scope, rules).items()
                                          if e not in combined})
    # Where the pattern carries no addresses -- the store holds none, as a
    # customer's denorm does not -- a ZIP, its city and state are still drawn
    # together, from the store's own address list.
    rules = elements.with_pattern(rules, {e: r for e, r in _address_rules().items()
                                          if not rules.get(e, {}).get("record_key")})

    if request.subject != "claims":
        count = request.members if request.rows is None else min(request.members, request.rows)
        return elements.new_members(count), rules

    per_member, per_claim = _claim_shape(profile, claims_pattern)
    per_member = request.claims_per_member or per_member
    per_claim = request.lines_per_claim or per_claim
    # A capped file needs only the members its lines reach; a preview of six
    # lines should not read four thousand people to show one.
    needed = None if request.rows is None else -(-request.rows // (per_member * per_claim))
    # From the pattern store alone: its members and which elements a claim
    # carries once or per line. No target is involved, onboarded or not.
    shape = _store_shape()
    members = _pattern_members(request, shape, claims_pattern, needed)
    claim_level, line_level = elements.store_claim_elements(shape)
    return elements.claims_for(
        members, rules,
        claim_level=claim_level, line_level=line_level,
        claims_per_member=per_member,
        lines_per_claim=per_claim,
        seed=_file_seed(), as_of=request.as_of, limit=request.rows,
    ), rules


def _store_shape():
    """The pattern store's description, which a file from a pattern is built on."""
    shape = service.landscape()
    if shape is None:
        raise HTTPException(
            status_code=409,
            detail="The pattern store has not been described yet. Run "
                   "`sdg landscape` (first-run does) and try again.",
        )
    return shape


def _file_seed() -> str:
    """The seed for a file from a pattern: the installation's, not a plan's."""
    return str(service.read_settings().get("seed") or "demo-seed-001")


def _listed(value: Any) -> list[str]:
    """A stored scope value -- a JSON list, a sentinel, or nothing -- as a list."""
    import json

    if value in (None, "", "null", "ALL"):
        return []
    try:
        parsed = json.loads(value) if isinstance(value, str) else value
    except ValueError:
        parsed = [value]
    if not isinstance(parsed, list):
        parsed = [parsed]
    return [str(v) for v in parsed if v not in (None, "") and not str(v).startswith("__")]


# What a pattern's scope names, as the elements it narrows.
SCOPE_ELEMENTS = {"grgr_ck": "GROUP_KEY", "cspi_id": "COVERAGE_PLAN_ID",
                  "pdpd_id": "PRODUCT_CODE"}


def _addresses() -> list[dict[str, Any]]:
    """The store's address list: the one every address rule draws from."""
    from sdg.analyzer.generation_rules import address_records

    try:
        return address_records()
    except Exception:
        return []


def _address_rules() -> dict[str, dict]:
    """ZIP, city and state as whole records from the store's address list."""
    if not _addresses():
        return {}
    return {
        element: {"element": element, "gen_method": "lookup", "values": _addresses(),
                  "record_key": "pattern_address", "field": element}
        for element in ("ADDRESS_ZIP", "ADDRESS_CITY", "ADDRESS_STATE", "ADDRESS_COUNTY")
    }


def _scope_rules(scope: dict[str, Any], rules: dict[str, dict]) -> dict[str, dict]:
    """The pattern's group, plan and product, as rules.

    A pattern found in one employer's book describes that employer's members,
    so new members drawn from it belong to the same group and plans. A plan
    category narrows the plans to the ones in that category.
    """
    out: dict[str, dict] = {}
    for key, element in SCOPE_ELEMENTS.items():
        values = _listed(scope.get(key))
        if values:
            out[element] = {"element": element, "gen_method": "lookup", "values": values}
    categories = set(_listed(scope.get("cspd_cat")))
    if categories and "COVERAGE_PLAN_ID" not in out:
        # The plans in those categories, as the pattern store holds them.
        from sdg.config import get_settings

        marks = ", ".join("?" for _ in categories)
        plans = [str(r["CSPI_ID"]).strip() for r in service.registry.query(
            "denorm",
            f"SELECT DISTINCT CSPI_ID FROM {get_settings().denorm_schema}.member_denorm "
            f"WHERE CSPD_CAT IN ({marks})",
            sorted(categories),
        ) if r.get("CSPI_ID")]
        if plans:
            out["COVERAGE_PLAN_ID"] = {"element": "COVERAGE_PLAN_ID",
                                       "gen_method": "lookup", "values": sorted(plans)}
    return out


def _pattern_members(request: ExportRequest, shape, claims_pattern: bool,
                     needed: int | None = None):
    """The members a pattern holds, read from the pattern store."""
    from sdg.analyzer.services import pattern_data
    from sdg.writers import elements

    try:
        if request.pattern is not None:
            live = request.pattern
            if claims_pattern:
                from sdg.api.routers.claims import ClaimsAnalyzeRequest

                filters = ClaimsAnalyzeRequest(
                    grgr_ck=live.filters.get("grgr_ck"),
                    cspi_id=live.filters.get("cspi_id"),
                    pdpd_id=live.filters.get("pdpd_id"),
                    claim_type=[live.claim_type] if live.claim_type else None,
                    conditions=live.filters.get("conditions"),
                    k=live.k,
                ).as_kwargs()
            else:
                from sdg.analyzer.services.schemas import Filters

                filters = Filters(**live.filters).as_kwargs()
            frame = pattern_data.rows_for_live(
                "claims" if claims_pattern else "members",
                filters, live.k, live.cluster_id,
            )["df"]
        else:
            # A saved pattern recorded the members it holds; a claim file is
            # for exactly those, without rebuilding anything.
            import json

            from sdg.analyzer import db
            from sdg.analyzer.services.saved_patterns import member_keys

            row = db.get_pattern(request.pattern_id) or {}
            recorded = member_keys(json.loads(row.get("profile_json") or "{}"))
            if recorded:
                keys = recorded[:needed] if needed is not None else recorded
                # A pattern's members are people in the landscape it was found
                # in, held in the store, whichever database is being worked on.
                members = elements.store_members(keys, shape, service.registry)
                if not members:
                    raise HTTPException(status_code=404,
                                        detail="None of this pattern's members were found.")
                return members
            frame = pattern_data.rows_for(request.pattern_id)["df"]
    except pattern_data.StalePattern as e:
        raise HTTPException(status_code=409, detail=str(e))

    # The pattern's rows are store rows; MEME_CK is the store's member key.
    key = "MEME_CK"
    if key not in frame.columns:
        raise HTTPException(
            status_code=422,
            detail="The pattern's rows do not say which members they are.",
        )
    keys = [k for k in dict.fromkeys(frame[key].tolist()) if k is not None]
    if needed is not None:
        keys = keys[:needed]
    members = elements.store_members(keys, shape, service.registry)
    if not members:
        raise HTTPException(status_code=404,
                            detail="None of this pattern's members were found.")
    return members


def _claim_shape(profile: dict[str, Any], claims_pattern: bool) -> tuple[int, int]:
    """Claims per member and lines per claim, as the pattern measured them."""
    if not claims_pattern:
        return 1, 1
    members = float(profile.get("n_members") or 0)
    claims = float(profile.get("n_claims") or 0)
    lines = float(profile.get("size") or 0)
    per_member = round(claims / members) if members else 1
    per_claim = round(lines / claims) if claims else 1
    return max(1, min(per_member, 50)), max(1, min(per_claim, 10))


# Streaming rather than building a response body: an extract is the one thing
# here whose size is not bounded by the screen, and the formatter holds a block
# at a time however many rows go through it.
@app.post("/api/export")
def export(request: ExportRequest) -> StreamingResponse:
    """Write records in the shape another system reads.

    Every record is keyed by element and every format names elements -- an EDI
    position, a layout field -- so nothing here knows a column. Where a record
    lacks an element, its rule makes one; the same rules, seed and position
    give the same value, so the same request produces byte-identical output.
    """
    stream, media, filename = _export_stream(request)
    return StreamingResponse(
        stream,
        media_type=media,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def _export_stream(request: ExportRequest):
    """The file an export writes, as a stream of text, with its type and name.

    Separate from the response so the SNIP checks read exactly the same file
    the download sends.
    """
    from sdg.analyzer.services.layout_service import rules_by_element
    from sdg.writers import elements
    from sdg.writers import export as export_writer

    rules = rules_by_element()
    modeled = None
    if request.format.startswith("sample:"):
        # A file modeled on a sample: its kind says what is written -- new
        # members for an 834, the pattern's members' claims for an 837.
        from sdg.analyzer.services import sample_gen_configs
        from sdg.writers import samples

        config_id = request.format.split(":", 1)[1]
        modeled = sample_gen_configs.get_config(int(config_id)) if config_id.isdigit() else None
        if modeled is None:
            raise HTTPException(status_code=404, detail=f"No sample config {config_id}.")
        try:
            sample_format = samples.module(modeled["format"])
        except samples.SampleError as e:
            raise HTTPException(status_code=422, detail=str(e))
        request.subject = sample_format.subject(modeled["kind"])
    if request.scenarios:
        records, rules = _scenario_records(request, rules)
    else:
        records, rules = _export_records(request, rules)
    seed = (_file_seed() if (request.pattern_id is not None or request.pattern is not None
                             or request.scenarios)
            else service.require_plan().meta.seed)

    if modeled is not None:
        try:
            sample = sample_format.read_sample(modeled["sample_text"])
            entries = sample_format.read_config(modeled["config"])
        except samples.SampleError as e:
            raise HTTPException(status_code=422, detail=str(e))
        all_rules = samples.algorithm_rules(rules)
        wanted = sorted(name for name in sample_format.used(entries) if name in all_rules)
        stream = sample_format.stream(
            sample, entries,
            elements.complete(records, wanted, all_rules, seed=seed, as_of=request.as_of),
            all_rules, seed=seed, as_of=request.as_of,
        )
        media, extension = sample_format.MEDIA, sample_format.EXTENSION
        if hasattr(sample_format, "package"):
            if request.packaged:
                stream = sample_format.package(stream, modeled["kind"])
            else:
                media, extension = sample_format.TEXT_MEDIA, ".xml"
        filename = f"{modeled['kind']}-{modeled['name']}{extension}".replace(" ", "_")
    elif request.format.startswith("edi"):
        from sdg.writers.edi_formats import load_format, stream_format

        legacy = {"edi834": "834", "edi837": "837P"}
        wanted = legacy.get(request.format) or request.format.split(":", 1)[-1]
        chosen = load_format(wanted)
        stream = stream_format(
            chosen, records, as_of=request.as_of,
            per_transaction=request.per_transaction, rules=rules, seed=seed,
        )
        media = "application/edi-x12"
        filename = f"{chosen.id.lower()}.txt"
    elif request.format == "fixed":
        fields = _layout_fields(request.layout_id)
        names = _layout_elements(fields)
        rows = elements.complete(records, _named(names), rules,
                                 seed=seed, as_of=request.as_of)
        stream = export_writer.stream_fixed_width(
            (_layout_row(r, fields, names) for r in rows), fields,
        )
        media, filename = "text/plain", "extract.txt"
    else:
        delimiter = ","
        if request.layout_id is not None:
            fields = _layout_fields(request.layout_id)
            names = _layout_elements(fields)
            columns = [f["name"] for f in fields]
            # The layout says what separates its fields; a pipe-delimited
            # layout written with commas is a file its reader cannot split.
            delimiter = _layout_delimiter(request.layout_id)
        else:
            columns = DEFAULT_ELEMENTS.get(request.subject, DEFAULT_ELEMENTS["members"])
            if request.scenarios:
                # Which scenario each row belongs to.
                columns = ["SCENARIO", *columns]
            fields = [{"name": c} for c in columns]
            names = {c: c for c in columns}
        rows = elements.complete(records, _named(names), rules,
                                 seed=seed, as_of=request.as_of)
        stream = export_writer.stream_delimited(
            (_layout_row(r, fields, names) for r in rows), columns,
            delimiter=delimiter,
        )
        media = "text/csv" if delimiter == "," else "text/plain"
        filename = f"{request.subject}.{'csv' if delimiter == ',' else 'txt'}"

    return stream, media, filename


def _scenario_records(request: ExportRequest, base: dict[str, dict]):
    """Every chosen scenario's records, in one stream, each tagged with its scenario.

    Each scenario is a pattern of its own rows; its records carry its own
    values, completed here from its own rules, and the rest is filled from
    the shared ones afterwards -- across the whole file, so the people in one
    scenario are never the people in another.
    """
    from sdg.writers import elements

    out: list[dict[str, Any]] = []
    for part in request.scenarios or []:
        sub = request.model_copy(update={
            "scenarios": None, "pattern_id": part.pattern_id, "pattern": None,
            "members": max(1, part.count),
            "rows": max(1, part.count) if request.subject == "claims" else None,
        })
        records, rules = _export_records(sub, dict(base))
        own = [e for e, rule in rules.items() if base.get(e) is not rule]
        for record in elements.complete(records, own, rules,
                                        seed=f"{_file_seed()}:{part.pattern_id}",
                                        as_of=request.as_of):
            record["SCENARIO"] = part.label
            out.append(record)
    return out, base


@app.get("/api/patterns/scenario-dimensions")
def scenario_dimensions(entity: str = "members") -> dict[str, Any]:
    """The features a pattern can be split into scenarios on."""
    from sdg.analyzer.services import scenarios

    return {"dimensions": scenarios.dimensions(entity)}


class ScenarioRequest(BaseModel):
    """A pattern, addressed as its analysis or by its id, and what to split it on."""

    domain: str = "members"
    filters: dict[str, Any] = {}
    k: int | None = None
    cluster_id: int = 0
    claim_type: str | None = None
    pattern_id: int | None = None
    dimensions: list[str] = []


@app.post("/api/patterns/scenarios")
def pattern_scenarios(request: ScenarioRequest) -> dict[str, Any]:
    """The combinations of the chosen features the pattern's own rows hold."""
    from sdg.analyzer.services import scenarios

    try:
        frame = scenarios.rows_of(request.domain, request.filters, request.k,
                                  request.cluster_id, request.claim_type, request.pattern_id)
        return scenarios.list_scenarios(request.domain, request.dimensions, frame)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))


class KeepScenarios(ScenarioRequest):
    name: str
    scenarios: list[dict[str, str]]


@app.post("/api/patterns/scenarios/keep")
def keep_scenarios(request: KeepScenarios) -> dict[str, Any]:
    """Keep each chosen scenario as a pattern of exactly its rows."""
    from sdg.analyzer.services import scenarios

    if not request.scenarios:
        raise HTTPException(status_code=422, detail="Choose at least one scenario.")
    try:
        kept = scenarios.keep_scenarios(
            request.domain, request.dimensions, request.scenarios, request.filters,
            request.k, request.cluster_id, request.claim_type, request.name,
            request.pattern_id,
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    return {"kept": kept}


def _layout_fields(layout_id: int | None) -> list[dict[str, Any]]:
    """The fields of an approved layout. Only approved ones may be written."""
    if layout_id is None:
        raise HTTPException(status_code=422, detail="This format needs a layout.")
    from sdg.analyzer.services import layout_service

    layout = layout_service.get_layout(layout_id)
    if layout is None:
        raise HTTPException(status_code=404, detail=f"No layout {layout_id}.")
    if layout.get("status") != "approved":
        raise HTTPException(
            status_code=409,
            detail=f"Layout {layout_id} is {layout.get('status')}. Approve it first.",
        )
    return layout.get("fields") or []


def _layout_delimiter(layout_id: int) -> str:
    """What separates a delimited layout's fields; a comma if it never said."""
    from sdg.analyzer.services import layout_service

    layout = layout_service.get_layout(layout_id) or {}
    return layout.get("delimiter") or ","


def _layout_elements(fields: list[dict[str, Any]]) -> dict[str, str | None]:
    """Each layout field's element: the rule it is bound to, or its own name.

    A field names what goes in it the same way an EDI position does -- by the
    rule. A field bound to none is read as an element of its own name, which
    is what a layout defined from the rule list already is. A field somebody
    chose to leave blank has no element at all, whatever it is called.
    """
    from sdg.analyzer.services import layout_service

    by_id = {int(r["id"]): str(r["field_name"]).strip().upper()
             for r in layout_service.get_all_rules()}
    out: dict[str, str | None] = {}
    for f in fields:
        rule_id = f.get("rule_id")
        if f.get("blank"):
            out[f["name"]] = None
        elif rule_id is not None and int(rule_id) in by_id:
            out[f["name"]] = by_id[int(rule_id)]
        else:
            out[f["name"]] = str(f["name"]).strip().upper()
    return out


def _named(names: dict[str, str | None]) -> list[str]:
    """The elements a layout's fields name, once each, blanks left out."""
    return list(dict.fromkeys(e for e in names.values() if e))


def _layout_row(record: dict[str, Any], fields: list[dict[str, Any]],
                names: dict[str, str | None]) -> dict[str, Any]:
    """One record as a layout's fields read it, each in the field's own form."""
    from sdg.writers.export import layout_value

    return {
        f["name"]: (layout_value(record.get(names[f["name"]]), f)
                    if names[f["name"]] else None)
        for f in fields
    }


class StoryToPlanRequest(BaseModel):
    """Saved patterns a requirement matched, and how much of each is wanted."""

    pattern_ids: list[int]
    total_volume: int = 1000
    as_of: str = "2026-06-30"
    apply: bool = False


@app.post("/api/story/to-plan")
def story_to_plan(request: StoryToPlanRequest) -> dict[str, Any]:
    """Turn a requirement's matched patterns into cohorts on the plan.

    Story to Data used to run a generator of its own. It does not need one: a
    requirement that names three cohorts and how much of each it wants is a
    description of a population, and a population is what the plan engine makes.
    The volume asked for becomes each pattern's share of the run, so a request
    for a thousand rows with six hundred of one kind generates a plan where that
    kind is sixty per cent -- rather than a separate dataset nobody can validate,
    clean up, or export alongside the rest.
    """
    import json

    from sdg.analyzer import db
    from sdg.analyzer.bridge import to_pattern
    from sdg.analyzer.services import story_service
    from sdg.plan.patterns import apply_to_decisions, resolve_pattern

    if not request.pattern_ids:
        raise HTTPException(status_code=422, detail="No patterns selected.")

    allocation = story_service.suggest_allocation(
        request.pattern_ids, request.total_volume
    )
    total = sum(allocation.values()) or 1

    resolutions = []
    missing: list[int] = []
    for pattern_id in request.pattern_ids:
        row = db.get_pattern(pattern_id)
        if row is None or not row.get("profile_json"):
            missing.append(pattern_id)
            continue
        profile = json.loads(row["profile_json"])
        # The share is what the allocation asked for, not what the pattern
        # covers in the source: the requirement is the thing being satisfied.
        profile["pct_of_total"] = allocation.get(pattern_id, 0) / total
        analyzer_pattern = to_pattern(
            profile,
            kind="claim" if str(row.get("entity") or "") == "claims" else "member",
            as_of=request.as_of,
            pattern_id=str(row.get("contextual_name") or f"pattern-{pattern_id}"),
        )
        resolutions.append((
            pattern_id,
            _guard(
                resolve_pattern,
                analyzer_pattern,
                catalog=service.catalog,
                mappings=service.require_mappings(),
                plan=service.require_plan(),
                model=service.model,
            ),
        ))

    usable = [r for _id, r in resolutions if r.targets]
    written: list[str] = []
    if request.apply and usable:
        document, written = _guard(
            apply_to_decisions, usable, service.read_decisions(), as_cohort=True,
        )
        service.write_decisions(document)

    return {
        "allocation": {str(k): v for k, v in allocation.items()},
        "total_volume": request.total_volume,
        "patterns": [
            {
                # The id is carried back so the caller can join a row to its
                # allocation without relying on the order they came out in.
                "pattern_id": pattern_id,
                "rows": allocation.get(pattern_id, 0),
                "pattern": r.pattern,
                "subject": r.subject,
                "share": r.support,
                "targets": [t.model_dump(mode="json") for t in r.targets],
                "rejections": [x.model_dump(mode="json") for x in r.rejections],
            }
            for pattern_id, r in resolutions
        ],
        "unreadable": missing,
        "applied": written,
    }


@app.get("/api/analyzer/health")
def analyzer_health() -> dict[str, Any]:
    """Whether the analyzer can reach its schema, and which one it is reading."""
    from sdg.analyzer import config as analyzer_config

    detail = analyzer_config.describe_connection()
    detail["build"] = __version__
    try:
        import pyodbc

        with pyodbc.connect(analyzer_config.get_connection_string(), timeout=5) as connection:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ?",
                analyzer_config.SQL_SCHEMA,
            )
            detail["tables"] = cursor.fetchone()[0]
            detail["ok"] = True
    except Exception as exc:  # reported, not raised: the screen says what is wrong
        detail["ok"] = False
        detail["error"] = f"{plain(exc)}"
    return detail


# ---------------------------------------------------------------------------
# The built interface
# ---------------------------------------------------------------------------

if UI_DIST.exists():
    app.mount("/assets", StaticFiles(directory=UI_DIST / "assets"), name="assets")

    # The asset filenames carry a content hash, so they may be cached forever.
    # index.html names them, and must not be: a cached copy keeps pointing at
    # the previous bundle after a rebuild, and the screens added since come up
    # blank with nothing in the console to say why.
    NO_CACHE = {"Cache-Control": "no-store, must-revalidate"}

    @app.get("/")
    def index() -> FileResponse:
        return FileResponse(UI_DIST / "index.html", headers=NO_CACHE)

    @app.get("/{path:path}")
    def spa(path: str) -> FileResponse:
        candidate = UI_DIST / path
        if candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(UI_DIST / "index.html", headers=NO_CACHE)

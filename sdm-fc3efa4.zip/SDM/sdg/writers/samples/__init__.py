"""Files modeled on a sample: everything copied, except what a config names.

One way of working for every file format: a sample file is the model, a
config names the places in it that take generated values (a path and an
algorithm), and the masking tool's config for that format is the master a
generation config starts from. What differs per format is how a place is
addressed and what repeats; that lives in the format's module, which the
screens and the API never look inside.

A format module provides:

    FORMAT, LABEL, MEDIA, EXTENSION, VALIDATION (a checker's name, or None)
    detect(text) -> bool                   the sample is this format
    read_sample(text) -> sample            with .kind and .version
    facts(sample) -> (counts, summary)     what the sample holds, for the screen
    subject(kind) -> "members" | "claims"  what records a file of that kind is written for
    read_config(body) -> entries           a generation config, or a masking config
    write_config(rows, **meta) -> dict     rows chosen on the screen, as a config
    positions(config) -> int               how many places a saved config generates
    used(entries) -> set[str]              the algorithm names entries refer to
    propose(sample, entries, algorithms)   every place of the sample, with a proposal
    stream(sample, entries, records, rules, seed=, as_of=) -> Iterator[str]

and may provide:

    check(text, profile) -> report         the written file checked as the format checks
    package(chunks, kind) -> Iterator[bytes], TEXT_MEDIA
                                           the download packed (CDA: a zip of documents);
                                           stream's text is what a preview shows
"""

from __future__ import annotations

from types import ModuleType

from sdg.writers.samples import cda, fhir, hl7v2, x12
from sdg.writers.samples.base import SampleError, algorithm_rules

FORMATS: dict[str, ModuleType] = {m.FORMAT: m for m in (x12, fhir, hl7v2, cda)}

__all__ = ["FORMATS", "SampleError", "algorithm_rules", "detect", "module"]


def module(format_: str) -> ModuleType:
    try:
        return FORMATS[format_]
    except KeyError:
        raise SampleError(f"No sample format {format_!r}.") from None


def detect(text: str) -> ModuleType:
    """The format a sample is written in, from its content."""
    for fmt in FORMATS.values():
        if fmt.detect(text):
            return fmt
    known = ", ".join(m.LABEL for m in FORMATS.values())
    raise SampleError(f"The sample is not a format a file can be modeled on ({known}).")

"""The one engine every sample format runs on.

It knows units, records, rules and derived positions -- never a segment, a
resource or an element of any particular format. The format's profile says
what repeats and what follows from what; the format's reader says how a file
is read and written and how a place is addressed. So the same engine writes
an 834, an 837 and (as further profiles and readers) FHIR, HL7 v2 and CDA.

Writing walks the profile's units over the records:

* a unit with `group` takes consecutive records sharing that element's value
  (one subscriber's claim lines), or, split further, those elements' values
  (`["CLAIM_ID", "SERVICE_DATE"]`: a claim's lines per day of service); a
  unit without takes one record. How many of a unit are written is always
  the records', never the profile's;
* each unit written is a copy of one of the sample's occurrences of it, taken
  in turn, filled from the first of its records (`row` numbers the seed a rule
  draws with: `count` counts the units of that level written so far, `nested`
  is the parent's row times 1000 plus the unit's place among its siblings);
* `derive` rules then set what the structure carries (`sequence`, `index`,
  `sum`), and the unit is rendered.

Derive rules: `sequence` (number an item across the file, re-pointing a
parent reference), `index` (an item's place among its siblings), `sum` (a
unit's total over its children), `rename` (a new identity per written copy,
every reference to it in the unit following; `to` may use {id}, {n} and
{uuid}, a UUID made from the old identity and n), `set` (a fixed value, where
the place -- or the element it is on, `on` -- is), `drop` (remove a place).
A rule with `unit` applies to that unit's items only (a CDA entry's id, not
the document's other ids at the same path).

A reader provides: shape(sample, entries, known) -> Shape;
fill(template, record, row, values) -> item; render(item) -> str;
lines(written unit) -> rendered pieces, children placed where the syntax puts
them; matches/get/set/original/drop(item, at), get being None where the item
has no such place; aliases(item, old, new) -> {how others refer to it: new}
and relink(item, mapping) for `rename`; envelope(sample) -> (before,
opening); closing(sample, count) -> lines; after(sample) -> lines;
join(lines) -> str.
"""

from __future__ import annotations

import re
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any, Iterable, Iterator

from sdg.writers.samples import profile as profiles
from sdg.writers.samples.base import SampleError

# Lines held before they are handed on as one piece of text.
CHUNK = 512


# ---------------------------------------------------------------------------
# The sample's shape, and what is written from it
# ---------------------------------------------------------------------------

@dataclass
class Unit:
    """One occurrence of a unit in the sample: its own templates, then its children,
    then any templates of its own that follow them (`after`)."""
    spec: dict[str, Any]
    items: list[Any]
    children: list["Unit"] = field(default_factory=list)
    after: list[Any] = field(default_factory=list)


@dataclass
class Shape:
    head: list[Any]               # templates before the first unit
    units: list[Unit]             # the top unit's occurrences
    spec: dict[str, Any]          # the top unit


@dataclass
class Written:
    spec: dict[str, Any]
    items: list[Any]
    children: list["Written"]
    index: int                    # among its siblings, from 0
    modeled: bool                 # the sample's occurrence had children of its own
    after: list[Any] = field(default_factory=list)

    def walk(self) -> Iterator[Any]:
        """Every item, in the order it is written."""
        yield from self.items
        for child in self.children:
            yield from child.walk()
        yield from self.after


def cut(templates: list[Any], spec: dict[str, Any], starts, stops=None):
    """Templates before the first unit, and the unit's occurrences, each from a
    start to the next (or to a stop, whose templates and all after are dropped)."""
    head: list[Any] = []
    occurrences: list[list[Any]] = []
    for t in templates:
        if starts(t):
            occurrences.append([t])
        elif occurrences:
            occurrences[-1].append(t)
        else:
            head.append(t)
    if stops is not None:
        occurrences = [occ[:next((i for i, t in enumerate(occ) if stops(t)), len(occ))]
                       for occ in occurrences]
    return head, occurrences


# ---------------------------------------------------------------------------
# Values
# ---------------------------------------------------------------------------

class Values:
    """An element's value for a record: the record's own, else its rule's.

    `levels` holds, for each unit being written and those enclosing it, the
    record and row it is filled from: a place the profile says is an enclosing
    unit's (the member's name in each of the member's documents) is filled
    from that unit's, so every copy under it agrees."""

    def __init__(self, rules: dict[str, dict], seed: str, as_of: str,
                 levels: dict[str, tuple[dict[str, Any], int]] | None = None):
        self.rules = rules
        self.seed = seed
        self.as_of = as_of
        self.levels = levels or {}

    def within(self, name: str, record: dict[str, Any], row: int) -> "Values":
        return Values(self.rules, self.seed, self.as_of, {**self.levels, name: (record, row)})

    def __call__(self, element: str, record: dict[str, Any], row_index: int) -> str:
        from sdg.writers import rule_values

        held = record.get(element)
        if held not in (None, ""):
            return rule_values._as_text(held)
        rule = self.rules.get(element)
        if rule is None:
            return ""
        return rule_values.produce({**rule, "element": element}, seed=self.seed,
                                   row_index=row_index, record=record, as_of=self.as_of)


def fit(value: str, example: str) -> str:
    """A value written the way the sample writes that place."""
    text = str(value)
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", example):
        day = _compact(text)
        return f"{day[:4]}-{day[4:6]}-{day[6:]}" if day else text
    if re.fullmatch(r"\d{8}-\d{8}", example):
        day = _compact(text)
        return f"{day}-{day}" if day else text
    if re.fullmatch(r"\d{8}", example):
        return _compact(text) or text
    if re.fullmatch(r"\d+\.\d{2}", example):
        try:
            return f"{float(text):.2f}"
        except ValueError:
            return text
    if example.isdigit() and re.fullmatch(r"[\d\- ]+", text):
        return re.sub(r"\D", "", text)
    if example.isupper() and any(ch.isalpha() for ch in example):
        return text.upper()
    return text


def _compact(text: str) -> str:
    if isinstance(text, (date, datetime)):
        return text.strftime("%Y%m%d")
    t = str(text)[:10]
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", t):
        return t.replace("-", "")
    return t if re.fullmatch(r"\d{8}", t) else ""


# ---------------------------------------------------------------------------
# Proposing
# ---------------------------------------------------------------------------

def hint(name: str) -> str | None:
    """The element a masking algorithm's name says it makes."""
    flat = re.sub(r"[^A-Z0-9]", "", name.upper())
    for piece, element in profiles.name_hints():
        if piece in flat:
            return element
    return None


def decide(config_name: str | None, place: str | None, blocked: bool,
           known: set[str]) -> tuple[str | None, str]:
    """The algorithm proposed for a place, and why."""
    if not config_name:
        return None, "copied from the sample"
    if config_name.upper() in known:
        return config_name.upper(), "the config names it"
    guess = None if blocked else (place or hint(config_name))
    if guess and guess in known:
        return guess, f"the config's {config_name}, read as {guess}"
    return None, f"the config's {config_name} is not an SDM algorithm; choose one"


# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------

def _groups(records: Iterable[dict[str, Any]], spec: dict[str, Any]) -> Iterator[list[dict]]:
    key = spec.get("group")
    if not key:
        for record in records:
            yield [record]
        return
    yield from by(records, key)


def by(records: Iterable[dict[str, Any]], key: str | list[str]) -> Iterator[list[dict[str, Any]]]:
    """Consecutive records sharing a key's value, as one list each; a record
    without it is a group of its own. With several keys (["CLAIM_ID",
    "SERVICE_DATE"]) each run of the first is split by the others' values, in
    the order they first appear: a claim's lines, a group per day of service."""
    keys = [key] if isinstance(key, str) else list(key)
    current: list[dict[str, Any]] = []
    marker: Any = object()
    for index, record in enumerate(records):
        value = record.get(keys[0])
        value = value if value not in (None, "") else ("#", index)
        if current and value != marker:
            yield from _split(current, keys[1:])
            current = []
        marker = value
        current.append(record)
    if current:
        yield from _split(current, keys[1:])


def _split(run: list[dict[str, Any]], keys: list[str]) -> Iterator[list[dict[str, Any]]]:
    if not keys:
        yield run
        return
    parts: dict[tuple, list[dict[str, Any]]] = {}
    for record in run:
        held = tuple(record.get(k) if record.get(k) not in (None, "") else None for k in keys)
        parts.setdefault(held, []).append(record)
    yield from parts.values()


class _Writer:
    def __init__(self, reader, values: Values):
        self.reader = reader
        self.values = values
        self.counters: dict[str, int] = defaultdict(int)

    def unit(self, spec: dict[str, Any], occurrences: list[Unit], records: list[dict],
             index: int, parent_row: int, outer: Values | None = None) -> Written:
        occ = occurrences[index % len(occurrences)] if occurrences else None
        if spec.get("row") == "nested":
            row = parent_row * 1000 + index
        else:
            self.counters[spec["name"]] += 1
            row = self.counters[spec["name"]]
        record = records[0]
        values = (outer or self.values).within(spec["name"], record, row)
        items = [self.reader.fill(t, record, row, values) for t in (occ.items if occ else [])]
        children = []
        child = (spec.get("units") or [None])[0]
        if child is not None:
            for i, group in enumerate(_groups(records, child)):
                children.append(self.unit(child, occ.children if occ else [], group, i, row,
                                          values))
        after = [self.reader.fill(t, record, row, values) for t in (occ.after if occ else [])]
        return Written(spec, items, children, index, bool(occ and occ.children), after)


class _Derive:
    """The profile's derive rules, applied to each top unit as it is written."""

    def __init__(self, reader, rules: list[dict[str, Any]], head: list[Any]):
        self.reader = reader
        self.rules = rules
        self.counters: dict[int, int] = {}
        for n, rule in enumerate(rules):
            if rule["op"] == "sequence":
                taken = [int(v) for v in (reader.get(i, rule["at"]) or "" for i in head
                                          if reader.matches(i, rule["at"])) if v.isdigit()]
                self.counters[n] = max(taken or [0])

    def apply(self, top: Written) -> None:
        r = self.reader
        for n, rule in enumerate(self.rules):
            op, at = rule["op"], rule["at"]
            if op == "sequence":
                mapping: dict[str, str] = {}
                for item in top.walk():
                    if not r.matches(item, at):
                        continue
                    self.counters[n] += 1
                    mapping[r.original(item, at)] = str(self.counters[n])
                    r.set(item, at, str(self.counters[n]))
                    parent = rule.get("parent")
                    if parent and r.get(item, parent) in mapping:
                        r.set(item, parent, mapping[r.get(item, parent)])
            elif op == "index":
                for unit in _units(top):
                    for item in unit.items:
                        if r.matches(item, at):
                            r.set(item, at, str(unit.index + 1))
            elif op == "sum":
                for unit in _units(top):
                    if not (unit.modeled and unit.items and r.matches(unit.items[0], at)
                            and r.get(unit.items[0], at) is not None):
                        continue
                    total = 0.0
                    for child in unit.children:
                        for item in child.walk():
                            for source in rule["of"]:
                                if r.matches(item, source):
                                    try:
                                        total += float(r.get(item, source))
                                    except (TypeError, ValueError):
                                        pass
                    r.set(unit.items[0], at, f"{total:.{int(rule.get('decimals', 2))}f}")
            elif op == "rename":
                scope = list(_scoped(top, rule))
                # Each written copy of a sample record is a record of its own: its
                # identity changes, and every reference to it in the unit with it.
                # {n} counts every item renamed in the file, so two copies of one
                # sample record never share an identity.
                mapping: dict[str, str] = {}
                for item in scope:
                    if not r.matches(item, at):
                        continue
                    self.counters[n] = self.counters.get(n, 0) + 1
                    old = r.get(item, at)
                    made = uuid.uuid5(uuid.NAMESPACE_URL, f"{old}#{self.counters[n]}")
                    new = str(rule.get("to") or "{id}-{n}").format(
                        id=old, n=self.counters[n], uuid=made)
                    r.set(item, at, new)
                    mapping.update(r.aliases(item, old, new))
                for item in top.walk():
                    r.relink(item, mapping)
            elif op == "set":
                # A fixed value, where the place (or the element it is on, `on`) is.
                for item in _scoped(top, rule):
                    if r.matches(item, rule.get("on") or at):
                        r.set(item, at, str(rule["value"]))
            elif op == "drop":
                for item in _scoped(top, rule):
                    if r.matches(item, at):
                        r.drop(item, at)
            else:
                raise SampleError(f"Profile rule {op!r} is not one the engine knows.")


def _scoped(top: Written, rule: dict[str, Any]) -> Iterator[Any]:
    """The items a rule applies to: all of them, or one unit's (`unit`)."""
    if not rule.get("unit"):
        yield from top.walk()
        return
    for unit in _units(top):
        if unit.spec.get("name") == rule["unit"]:
            yield from unit.items
            yield from unit.after


def _units(top: Written) -> Iterator[Written]:
    yield top
    for child in top.children:
        yield from _units(child)


def derived_targets(profile: dict[str, Any]) -> list[str]:
    """Places a derive rule sets, which nobody chooses an algorithm for."""
    return [rule["at"] for rule in profile.get("derive") or []]


def stream(reader, sample, entries, records: Iterable[dict[str, Any]], rules: dict[str, dict],
           *, seed: str, as_of: str) -> Iterator[str]:
    """The file modeled on the sample, written for these records."""
    shape = reader.shape(sample, entries, set(rules))
    values = Values(rules, seed, str(as_of))
    writer = _Writer(reader, values)
    head = [reader.fill(t, {}, 0, values) for t in shape.head]
    derive = _Derive(reader, sample.profile.get("derive") or [], head)

    before, opening = reader.envelope(sample)
    out: list[str] = list(before)
    body: list[str] = [*opening, *(reader.render(i) for i in head)]
    counted = 0              # transaction lines already handed on

    def flush() -> str:
        nonlocal counted
        counted += len(body)
        text = reader.join([*out, *body])
        out.clear()
        body.clear()
        return text

    written = 0
    for group in _groups(records, shape.spec):
        top = writer.unit(shape.spec, shape.units, group, written, 0)
        derive.apply(top)
        body.extend(reader.lines(top))
        written += 1
        if len(body) >= CHUNK:
            yield flush()

    if written == 0:
        raise SampleError("No records to write; generate some first.")
    body.extend(reader.closing(sample, counted + len(body)))
    yield flush()
    yield reader.join(reader.after(sample))

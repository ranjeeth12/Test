"""Records keyed by element, which is what every file this tool writes reads.

A file says DOB, never MEME_BIRTH_DT. A column is a fact about one database; an
element is what the value means, and it is the only name a format description,
a layout or a rule uses. So everything that feeds a writer arrives here keyed
by element, and the translation from columns happens once -- through the
plan's own bindings, the same ones generation already runs on.

Three ways a record comes to exist:

    from a run        the rows the plan generated, so a file describes the
                      same population a database load would write
    from a pattern    new members whose elements take the pattern's values --
                      what an 834 for a pattern is
    for a pattern     claims for the members the pattern actually holds --
                      what an 837 for a pattern is, because a claim is always
                      made by somebody who exists

A pattern is a saved list of elements and their values. Applied to rules, it
replaces the rule for each element it names and leaves the rest alone.
"""

from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable, Iterator

from sdg.writers import rule_values


# ---------------------------------------------------------------------------
# Bindings: which column carries which element, per table
# ---------------------------------------------------------------------------

def bindings(plan) -> dict[str, dict[str, str]]:
    """Table -> {column: element}, for every column the plan bound to one."""
    out: dict[str, dict[str, str]] = {}
    for table in plan.tables:
        bound = {
            field.name: str(field.element).strip().upper()
            for field in table.fields
            if field.element
        }
        if bound:
            out[table.name] = bound
    return out


def _table_with(found: dict[str, dict[str, str]], *elements: str,
                without: Iterable[str] = ()) -> str | None:
    """The table that carries every one of these elements, and none of those."""
    wanted, refused = set(elements), set(without)
    for table, bound in found.items():
        carried = set(bound.values())
        if wanted <= carried and not (refused & carried):
            return table
    return None


def _column_for(found: dict[str, dict[str, str]], table: str | None,
                element: str) -> str | None:
    for column, bound in (found.get(table or "") or {}).items():
        if bound == element:
            return column
    return None


def as_elements(row: dict[str, Any] | None, bound: dict[str, str],
                into: dict[str, Any] | None = None) -> dict[str, Any]:
    """A row's values under the elements its columns carry.

    Written over `into`, so the more specific row is applied last and wins: a
    member's own first name over the subscriber's.
    """
    out = into if into is not None else {}
    for column, element in bound.items():
        if row and column in row and row[column] not in (None, ""):
            out[element] = row[column]
    return out


def tables(plan) -> dict[str, str | None]:
    """The member, subscriber, claim and line tables, found by what they carry."""
    found = bindings(plan)
    return {
        "members": _table_with(found, "MEMBER_ID", "DOB"),
        "subscribers": _table_with(found, "SUBSCRIBER_ID", "SUBSCRIBER_KEY"),
        "claims": _table_with(found, "CLAIM_ID", "SERVICE_DATE",
                              without=("LINE_NUMBER",)),
        "lines": _table_with(found, "CLAIM_ID", "LINE_NUMBER"),
    }


# ---------------------------------------------------------------------------
# From a run
# ---------------------------------------------------------------------------

def run_members(result, plan, *, limit: int | None = None) -> Iterator[dict[str, Any]]:
    """One record per generated member, its subscriber's elements beside it."""
    found = bindings(plan)
    where = tables(plan)
    members, subscribers = where["members"], where["subscribers"]
    if not members:
        return
    member_parent = _column_for(found, members, "SUBSCRIBER_KEY")
    subscriber_key = _column_for(found, subscribers, "SUBSCRIBER_KEY")
    by_subscriber = {
        row.get(subscriber_key): row for row in result.rows(subscribers or "")
    } if subscribers and subscriber_key else {}

    for position, member in enumerate(result.rows(members)):
        if limit is not None and position >= limit:
            return
        record: dict[str, Any] = {}
        if member_parent:
            as_elements(by_subscriber.get(member.get(member_parent)),
                        found.get(subscribers or "", {}), record)
        yield as_elements(member, found[members], record)


def run_claim_lines(result, plan, *, limit: int | None = None) -> Iterator[dict[str, Any]]:
    """One record per generated claim line, its claim and member beside it."""
    found = bindings(plan)
    where = tables(plan)
    lines, claims, members = where["lines"], where["claims"], where["members"]
    if not lines:
        return
    line_claim = _column_for(found, lines, "CLAIM_ID")
    claim_key = _column_for(found, claims, "CLAIM_ID")
    claim_member = _column_for(found, claims, "MEMBER_KEY")
    member_key = _column_for(found, members, "MEMBER_KEY")

    by_claim = {row.get(claim_key): row for row in result.rows(claims or "")} \
        if claims and claim_key else {}
    by_member = {row.get(member_key): row for row in result.rows(members or "")} \
        if members and member_key else {}

    for position, line in enumerate(result.rows(lines)):
        if limit is not None and position >= limit:
            return
        claim = by_claim.get(line.get(line_claim), {})
        member = by_member.get(claim.get(claim_member)) if claim_member else None
        record: dict[str, Any] = {}
        as_elements(member, found.get(members or "", {}), record)
        as_elements(claim, found.get(claims or "", {}), record)
        yield as_elements(line, found[lines], record)


# ---------------------------------------------------------------------------
# A pattern, as rules
# ---------------------------------------------------------------------------

def pattern_rules(profile: dict[str, Any], catalog, *, kind: str = "member",
                  as_of: str = "2026-06-30") -> dict[str, dict[str, Any]]:
    """The rule a pattern implies for each element it names.

    A band stays a band and a distribution stays a distribution: ages 51 to
    75 become a birth-date window, 54/46 becomes a weighted list. Nothing the
    pattern does not name is touched.
    """
    from sdg.analyzer.bridge import to_pattern
    from sdg.plan.patterns import element_keys, match_derivation, match_element

    found = to_pattern(profile, kind=kind, as_of=as_of)
    index = element_keys(catalog)
    reference = date.fromisoformat(str(as_of)[:10])
    out: dict[str, dict[str, Any]] = {}

    for parameter in found.parameters:
        derived = match_derivation(parameter.label)
        if derived is not None:
            element = derived[1]["element"]
            if parameter.min is None or parameter.max is None:
                continue
            months = str(parameter.unit or "").lower().startswith("month")
            latest = _back(reference, int(parameter.min), months)
            earliest = _back(reference, int(parameter.max) + 1, months) + timedelta(days=1)
            out[element] = {
                "element": element, "gen_method": "date",
                "format_pattern": latest.isoformat(),
                "start_value": max(1, (latest - earliest).days + 1),
            }
            if parameter.bands:
                # Ages (or months) spread as the pattern's: each slice a window of
                # days back from the latest day, drawn at its share.
                per = 30.4375 if months else 365.25
                start = float(parameter.min)
                out[element]["bands"] = [
                    [-int(round((high - start) * per)), -int(round((low - start) * per)),
                     share]
                    for low, high, share in parameter.bands]
            continue

        element, _near = match_element(parameter.label, index)
        if element is None:
            continue
        if parameter.record_field and parameter.values:
            out[element] = {
                "element": element, "gen_method": "lookup",
                "values": list(parameter.values), "weights": list(parameter.weights or []),
                "record_key": parameter.record_key(), "field": parameter.record_field,
            }
            if parameter.record_group and parameter.record_group != "address":
                # A line's procedure is drawn from the combinations holding
                # the diagnosis its claim already has, and the other way round.
                fields = sorted({k for r in parameter.values if isinstance(r, dict)
                                 for k in r})
                out[element]["given"] = {f: f for f in fields
                                         if f != parameter.record_field}
        elif parameter.values:
            out[element] = {
                "element": element, "gen_method": "lookup",
                "values": [str(v) for v in parameter.values],
                "weights": list(parameter.weights or []),
            }
        elif parameter.value is not None:
            out[element] = {"element": element, "gen_method": "constant",
                            "domain": str(parameter.value)}
        elif parameter.min is not None and parameter.max is not None:
            out[element] = {"element": element, "gen_method": "range",
                            "min": parameter.min, "max": parameter.max}
            if parameter.bands:
                # Amounts spread as the pattern's: each slice drawn at its share.
                out[element]["bands"] = [list(b) for b in parameter.bands]
    return out


def _back(day: date, amount: int, months: bool) -> date:
    if months:
        month = day.month - 1 - amount
        year = day.year + month // 12
        return _safe(day, year, month % 12 + 1)
    return _safe(day, day.year - amount, day.month)


def _safe(day: date, year: int, month: int) -> date:
    try:
        return day.replace(year=year, month=month)
    except ValueError:
        return day.replace(year=year, month=month, day=28)


def with_pattern(rules: dict[str, dict], pattern: dict[str, dict]) -> dict[str, dict]:
    """The rules, with the pattern's replacing the ones it names."""
    merged = dict(rules)
    for element, rule in pattern.items():
        base = merged.get(element) or {}
        # The base rule's decoration -- a prefix, a width -- survives; what the
        # value is drawn from is the pattern's.
        merged[element] = {
            **{k: base[k] for k in ("prefix", "postfix", "data_type") if k in base},
            **rule,
        }
    return merged


# ---------------------------------------------------------------------------
# New members, for an 834
# ---------------------------------------------------------------------------

def new_members(count: int) -> list[dict[str, Any]]:
    """`count` members nobody has made yet.

    Empty on purpose: every element is drawn from its rule when the file is
    written, at the member's own position, so the same seed writes the same
    members. The pattern reaches them through the rules it replaced.
    """
    return [{} for _ in range(max(0, int(count)))]


# ---------------------------------------------------------------------------
# Existing members, and claims for them, for an 837
# ---------------------------------------------------------------------------

def existing_members(keys: list[Any], plan, registry, *, connection: str = "source",
                     ) -> list[dict[str, Any]]:
    """The members with these keys, read from the database, keyed by element.

    Their identity -- ID, name, birth date, sex -- is what they are, not what
    a rule would make, so it is read rather than produced.
    """
    found = bindings(plan)
    where = tables(plan)
    members, subscribers = where["members"], where["subscribers"]
    if not members:
        raise ValueError("the plan binds no table carrying MEMBER_ID and DOB")
    member_key = _column_for(found, members, "MEMBER_KEY")
    if not member_key:
        raise ValueError(f"{members} has no column bound to MEMBER_KEY")
    member_parent = _column_for(found, members, "SUBSCRIBER_KEY")
    subscriber_key = _column_for(found, subscribers, "SUBSCRIBER_KEY")

    columns = sorted(found[members])
    sub_columns = sorted(found.get(subscribers or "", {}))
    join = bool(subscribers and member_parent and subscriber_key and sub_columns)
    select = ", ".join(
        [f"m.[{c}] AS [m__{c}]" for c in columns]
        + ([f"s.[{c}] AS [s__{c}]" for c in sub_columns] if join else [])
    )
    source = f"{members} AS m" + (
        f" LEFT JOIN {subscribers} AS s ON s.[{subscriber_key}] = m.[{member_parent}]"
        if join else ""
    )

    wanted = [k for k in dict.fromkeys(keys) if k is not None]
    by_key: dict[Any, dict[str, Any]] = {}
    # In slices: a parameter list has a ceiling, and a pattern can hold more
    # members than it.
    for start in range(0, len(wanted), 1000):
        piece = wanted[start:start + 1000]
        marks = ", ".join("?" for _ in piece)
        rows = registry.query(
            connection,
            f"SELECT {select} FROM {source} WHERE m.[{member_key}] IN ({marks})",
            piece,
        )
        for row in rows:
            record: dict[str, Any] = {}
            if join:
                as_elements({c: row.get(f"s__{c}") for c in sub_columns},
                            found[subscribers], record)
            as_elements({c: row.get(f"m__{c}") for c in columns}, found[members], record)
            by_key[row.get(f"m__{member_key}")] = record
    # In the order the pattern listed them, so the file is reproducible.
    return [by_key[k] for k in wanted if k in by_key]


def claim_elements(plan) -> tuple[list[str], list[str]]:
    """Which elements a claim carries, and which its lines carry.

    Read off the plan: an element bound on the claims table is the claim's,
    one on the lines table is the line's. Keys and the member's own elements
    are neither -- the member exists and the claim points at them.
    """
    found = bindings(plan)
    where = tables(plan)
    keys = {"MEMBER_KEY", "SUBSCRIBER_KEY", "CLAIM_ID", "LINE_NUMBER"}
    member_side = set((found.get(where["members"] or "") or {}).values())
    claim = [e for e in dict.fromkeys((found.get(where["claims"] or "") or {}).values())
             if e not in keys and e not in member_side]
    line = [e for e in dict.fromkeys((found.get(where["lines"] or "") or {}).values())
            if e not in keys]
    return claim, line


def claims_for(
    members: list[dict[str, Any]],
    rules: dict[str, dict],
    *,
    claim_level: list[str],
    line_level: list[str],
    claims_per_member: int = 1,
    lines_per_claim: int = 1,
    seed: str = "claims",
    as_of: str = "2026-06-30",
    limit: int | None = None,
) -> Iterator[dict[str, Any]]:
    """Claim lines for members who exist.

    Everything a claim says -- its status, diagnosis, dates, charges -- is
    drawn from the rules, which a pattern has already replaced where it names
    an element. The member is read, never made.
    """
    # A claim's totals: elements whose rule sums an element of its lines.
    totals = {e: rule_values.summed(rules.get(e)) for e in [*claim_level, *line_level]}
    totals = {e: of for e, of in totals.items() if of}
    claim_no = 0
    line_no = 0
    written = 0
    for member in members:
        for _ in range(max(1, claims_per_member)):
            claim_no += 1
            claim = dict(member)
            claim["CLAIM_ID"] = (_made("CLAIM_ID", rules, seed, claim_no, as_of)
                                 or f"{seed[:4].upper()}{claim_no:08d}")
            for element in claim_level:
                if element in rules and element not in totals:
                    claim[element] = _made(element, rules, seed, claim_no, as_of, claim)
            lines = []
            for number in range(1, max(1, lines_per_claim) + 1):
                line_no += 1
                line = dict(claim)
                line["LINE_NUMBER"] = number
                for element in line_level:
                    if element in rules and element not in totals:
                        line[element] = _made(element, rules, seed, line_no, as_of, line)
                lines.append(line)
            for element, of in totals.items():
                total = _total(lines, of)
                for line in lines:
                    line[element] = total
            for line in lines:
                yield line
                written += 1
                if limit is not None and written >= limit:
                    return


def _total(lines: list[dict[str, Any]], element: str) -> str:
    """The sum of an element over a claim's lines, to the cent."""
    amounts = []
    for line in lines:
        try:
            amounts.append(Decimal(str(line.get(element) or "0").strip() or "0"))
        except InvalidOperation:
            continue
    return f"{sum(amounts, Decimal('0')):.2f}" if amounts else ""


def _made(element: str, rules: dict[str, dict], seed: str, index: int,
          as_of: str, context: dict[str, Any] | None = None) -> str:
    """A claim's own value, never read off the member it belongs to.

    `context` is what the claim or line holds so far, which a combination is
    drawn to agree with.
    """
    rule = rules.get(element)
    if rule is None:
        return ""
    return rule_values.produce({**rule, "element": element}, seed=seed,
                               row_index=index, as_of=as_of, context=context)


# ---------------------------------------------------------------------------
# Filling in what a record does not hold
# ---------------------------------------------------------------------------

def complete(
    records: Iterable[dict[str, Any]],
    wanted: list[str],
    rules: dict[str, dict],
    *,
    seed: str,
    as_of: str = "2026-06-30",
) -> Iterator[dict[str, Any]]:
    """Each record with every wanted element present, drawn from its rule.

    Drawn at the record's position, counted from one, with the seed an EDI
    file uses -- so a CSV and an 834 of the same new members name the same
    people.
    """
    for position, record in enumerate(records, start=1):
        for element in wanted:
            if record.get(element) not in (None, ""):
                continue
            rule = rules.get(element)
            if rule is not None:
                record[element] = rule_values.produce(
                    {**rule, "element": element}, seed=seed,
                    row_index=position, as_of=as_of, context=record,
                )
        yield record


# ---------------------------------------------------------------------------
# The pattern store: members and claim structure without any target's plan
# ---------------------------------------------------------------------------

_KEYS = {"MEMBER_KEY", "SUBSCRIBER_KEY", "CLAIM_ID", "LINE_NUMBER"}


def _store_columns(shape, table_suffix: str) -> dict[str, str]:
    """Element to column, in the store extract whose name ends `table_suffix`."""
    out: dict[str, str] = {}
    for element in shape.elements:
        for qualified in element.observed_in:
            table, _, column = qualified.rpartition(".")
            if table.endswith(table_suffix) and element.element not in out:
                out[element.element] = column
    return out


def store_members(keys: list[Any], shape, registry, *, connection: str = "denorm",
                  table: str | None = None) -> list[dict[str, Any]]:
    """The members with these keys, read from the pattern store, keyed by element.

    A pattern's members are people in the sources; the store holds them. Read
    here, a file from a pattern needs no target, onboarded or not. One row
    per member: the latest enrollment.
    """
    if table is None:
        from sdg.config import get_settings

        table = f"{get_settings().denorm_schema}.member_denorm"
    columns = _store_columns(shape, table.split(".")[-1])
    key = columns.get("MEMBER_KEY")
    if not key:
        raise ValueError(f"the store's description has no member key in {table}")
    from sdg.analyzer.data_loader import present_columns

    have = present_columns(table)
    # A member's ID, where the store holds none of its own: the subscriber's ID
    # and the member's two-digit suffix, the way FACETS identifies a member.
    composed = "MEMBER_ID" not in columns and {"SBSB_ID", "MEME_SFX"} <= have
    named = sorted(set(columns.values()) | ({"SBSB_ID", "MEME_SFX"} if composed else set()))
    select = ", ".join(f"[{c}]" for c in named)
    # The latest enrollment: the one whose plan took effect last.
    latest = next((c for c in ("MEME_EFF_DT", "CSPI_EFF_DT", "MEME_ORIG_EFF_DT") if c in have), None)
    order = f"[{latest}] DESC" if latest else f"[{key}]"
    wanted = [k for k in dict.fromkeys(keys) if k is not None]
    by_key: dict[Any, dict[str, Any]] = {}
    for start in range(0, len(wanted), 1000):
        piece = wanted[start:start + 1000]
        marks = ", ".join("?" for _ in piece)
        rows = registry.query(
            connection,
            f"SELECT {select} FROM (SELECT {select}, ROW_NUMBER() OVER "
            f"(PARTITION BY [{key}] ORDER BY {order}) AS _rn FROM {table} "
            f"WHERE [{key}] IN ({marks})) AS m WHERE _rn = 1",
            piece,
        )
        for row in rows:
            record = {element: row.get(column) for element, column in columns.items()
                      if row.get(column) not in (None, "")}
            if composed and row.get("SBSB_ID") not in (None, ""):
                suffix = row.get("MEME_SFX")
                record["MEMBER_ID"] = (f"{str(row['SBSB_ID']).strip()}"
                                       f"{int(suffix) if suffix is not None else 0:02d}")
            by_key[row.get(key)] = record
    return [by_key[k] for k in wanted if k in by_key]


def store_claim_elements(shape) -> tuple[list[str], list[str]]:
    """What a claim carries once and what each line carries, from the store.

    The member's own elements are neither: the member exists and is read.
    """
    member_side = set(_store_columns(shape, "member_denorm"))
    claims = _store_columns(shape, "claims_denorm")
    line = [e for e in shape.line_elements if e not in _KEYS]
    claim = [e for e in claims if e not in _KEYS and e not in member_side and e not in line]
    return claim, line

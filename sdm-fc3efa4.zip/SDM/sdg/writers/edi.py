"""EDI 834 and 837 from generated rows, streamed.

The segment knowledge is the analyzer's and is not rewritten here: this calls
its builders row by row. What changes is the shape of the output. The analyzer
built a list of every line in the file and joined it at the end, which holds the
whole transaction in memory twice -- once as a million small strings and again
as the joined result. For a preview that is nothing; for a real extract it is
the difference between a file that streams and a process that is killed.

So the envelope is written around a generator and the segments come out in
blocks. Peak memory is a block, whatever the row count.

The envelope is still a transaction, not a concatenation: the ISA/GS/ST headers
and their matching trailers carry counts that have to be right, so the counting
happens as the blocks are yielded rather than being known in advance.


Superseded, and kept on purpose.

Nothing reaches these writers any more: every transaction set the API offers
is a description in `sdg/writers/edi_formats/`, including the two older format
names. What remains here is the reference the equivalence tests compare the
descriptions against -- 834 segment for segment, 837 everywhere except CLM05,
where this code wrote a composite flat and the description does not.

Deleting them would remove the only evidence that the descriptions say what
the code said. They are test fixtures now, not a second way to write EDI."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any, Iterable, Iterator

from sdg.analyzer.edi_formatter import (
    ELEMENT_SEP,
    SEGMENT_TERM,
    _build_member_segments,
)

# Segments per yielded block. Same reasoning as the delimited writer: one yield
# per segment is a syscall per segment at volume.
BLOCK = 512


def _compact(value: Any) -> str:
    """A date as EDI writes it: CCYYMMDD, with nothing else accepted."""
    if value is None or value == "":
        return ""
    if isinstance(value, (date, datetime)):
        return value.strftime("%Y%m%d")
    text = str(value)[:10].replace("-", "").replace("/", "")
    return text if len(text) == 8 and text.isdigit() else ""


def _stamp(as_of: str | date) -> tuple[str, str, str]:
    """Interchange date, time and control number, from a stated date.

    Never the clock. Two runs of the same seed and the same as-of date produce
    byte-identical files, which is the property the whole tool is built on and
    would be lost to a timestamp taken at the moment of export.
    """
    when = date.fromisoformat(str(as_of)[:10]) if not isinstance(as_of, date) else as_of
    return when.strftime("%y%m%d"), "0000", when.strftime("%y%m%d") + "01"


def stream_834(
    records: Iterable[dict[str, Any]],
    *,
    sender_id: str = "SDM",
    receiver_id: str = "RECEIVER",
    as_of: str | date = "2026-06-30",
    control_number: int = 1,
) -> Iterator[str]:
    """An 834 benefit enrollment transaction, a block of segments at a time."""
    short_date, time_str, control = _stamp(as_of)
    long_date = f"20{short_date}"
    ctrl = f"{control_number:09d}"

    yield SEGMENT_TERM.join([
        ELEMENT_SEP.join([
            "ISA", "00", " " * 10, "00", " " * 10, "ZZ", sender_id.ljust(15),
            "ZZ", receiver_id.ljust(15), short_date, time_str, "^", "00501",
            ctrl, "0", "T", ":",
        ]),
        ELEMENT_SEP.join([
            "GS", "BE", sender_id, receiver_id, long_date, time_str,
            str(control_number), "X", "005010X220A1",
        ]),
        ELEMENT_SEP.join(["ST", "834", "0001", "005010X220A1"]),
        ELEMENT_SEP.join(["BGN", "00", control, long_date, time_str, "", "", "", "2"]),
        "",
    ])

    segment_count = 2  # ST and BGN, which the SE count includes
    block: list[str] = []
    append = block.append
    for record in records:
        segments = _build_member_segments(record)
        segment_count += len(segments)
        for segment in segments:
            append(segment)
        if len(block) >= BLOCK:
            yield "".join(block)
            block = []
            append = block.append
    if block:
        yield "".join(block)

    yield SEGMENT_TERM.join([
        ELEMENT_SEP.join(["SE", str(segment_count + 1), "0001"]),
        ELEMENT_SEP.join(["GE", "1", str(control_number)]),
        ELEMENT_SEP.join(["IEA", "1", ctrl]),
        "",
    ])


def stream_837(
    records: Iterable[dict[str, Any]],
    *,
    sender_id: str = "SDM",
    receiver_id: str = "RECEIVER",
    as_of: str | date = "2026-06-30",
    control_number: int = 1,
) -> Iterator[str]:
    """An 837 professional claim transaction, a block of segments at a time.

    One claim line per record, and **the records must arrive grouped by claim**:
    a new CLM segment is opened whenever the claim id changes, so lines of the
    same claim arriving apart would open that claim twice and the transaction
    would be malformed. `claim_line_records` guarantees the grouping, because
    the engine writes every line of a claim together and the join preserves
    that order. Grouping here instead would mean sorting, and sorting means
    holding the dataset -- which is the thing this writer exists to avoid.
    """
    short_date, time_str, control = _stamp(as_of)
    long_date = f"20{short_date}"
    ctrl = f"{control_number:09d}"

    yield SEGMENT_TERM.join([
        ELEMENT_SEP.join([
            "ISA", "00", " " * 10, "00", " " * 10, "ZZ", sender_id.ljust(15),
            "ZZ", receiver_id.ljust(15), short_date, time_str, "^", "00501",
            ctrl, "0", "T", ":",
        ]),
        ELEMENT_SEP.join([
            "GS", "HC", sender_id, receiver_id, long_date, time_str,
            str(control_number), "X", "005010X222A1",
        ]),
        ELEMENT_SEP.join(["ST", "837", "0001", "005010X222A1"]),
        ELEMENT_SEP.join(["BHT", "0019", "00", control, long_date, time_str, "CH"]),
        ELEMENT_SEP.join(["HL", "1", "", "20", "1"]),
        ELEMENT_SEP.join(["NM1", "41", "2", "SDM SYNTHETIC", "", "", "", "", "46", "SDM001"]),
        "",
    ])

    segment_count = 4
    hl = 1
    current_claim: str | None = None
    line_number = 0
    block: list[str] = []
    append = block.append

    for record in records:
        claim_id = record.get("CLCL_ID")
        if claim_id != current_claim:
            current_claim = claim_id
            line_number = 0
            hl += 1
            segments = [
                ELEMENT_SEP.join(["HL", str(hl), "1", "22", "0"]),
                ELEMENT_SEP.join([
                    "NM1", "IL", "1",
                    str(record.get("MEME_ID") or record.get("MEME_CK") or ""),
                    "", "", "", "", "MI", str(record.get("MEME_ID") or ""),
                ]),
                ELEMENT_SEP.join([
                    "DMG", "D8", _compact(record.get("MEME_BIRTH_DT")),
                    str(record.get("MEME_SEX") or "U"),
                ]),
                ELEMENT_SEP.join([
                    "CLM", str(claim_id or ""),
                    str(record.get("CLCL_TOT_CHG") or "0"),
                    "", "", ELEMENT_SEP.join(["11", "B", "1"]), "Y", "A", "Y", "Y",
                ]),
                ELEMENT_SEP.join([
                    "HI", f"ABK:{str(record.get('IDCD_ID_PRIMARY') or '').strip()}",
                ]),
            ]
            for segment in segments:
                append(segment + SEGMENT_TERM)
            segment_count += len(segments)

        line_number += 1
        service = [
            ELEMENT_SEP.join([
                "LX", str(line_number),
            ]),
            ELEMENT_SEP.join([
                "SV1", f"HC:{str(record.get('IPCD_ID') or '').strip()}",
                str(record.get("CDML_CHG_AMT") or "0"), "UN",
                str(record.get("CDML_UNITS") or "1"), "", "", "1",
            ]),
            ELEMENT_SEP.join([
                "DTP", "472", "D8", _compact(record.get("CLCL_SVC_DT")),
            ]),
        ]
        for segment in service:
            append(segment + SEGMENT_TERM)
        segment_count += len(service)

        if len(block) >= BLOCK:
            yield "".join(block)
            block = []
            append = block.append

    if block:
        yield "".join(block)

    yield SEGMENT_TERM.join([
        ELEMENT_SEP.join(["SE", str(segment_count + 1), "0001"]),
        ELEMENT_SEP.join(["GE", "1", str(control_number)]),
        ELEMENT_SEP.join(["IEA", "1", ctrl]),
        "",
    ])

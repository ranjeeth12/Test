"""Export generated rows in the shapes other systems read.

The plan engine produces rows table by table. An EDI transaction or a
fixed-width file wants one record per subject with its related fields already
beside it, so this module joins what the engine produced and hands the result
out one row at a time.

Two decisions here are about size rather than taste.

**Nothing is joined with a scan.** The indexes are built once, as dicts, and
every lookup after that is constant time. A nested scan over claims and members
is quadratic and stops being usable somewhere around ten thousand rows, which
is well inside the volumes this tool is for.

**Nothing accumulates.** Every function here is a generator. The engine already
holds its rows in memory -- it has to, because a claim total sums claim lines
that do not exist yet when the claim is built -- so the formatter refusing to
hold a second copy is what keeps the peak from doubling.
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any, Iterable, Iterator

from sdg.engine.execute import RunResult
from sdg.plan.model import Plan

# How a member's enrollment reads when the coverage has ended. The EDI builder
# wants a maintenance type and a benefit status; the generated row carries a
# termination date, which is the same fact in the form this tool stores it.
ACTIVE = {"MAINTENANCE_TYPE": "021", "MAINTENANCE_REASON": "AI", "BENEFIT_STATUS": "A"}
TERMED = {"MAINTENANCE_TYPE": "024", "MAINTENANCE_REASON": "AI", "BENEFIT_STATUS": "T"}

# Coverage line, from the plan category the member is enrolled on.
INSURANCE_LINE = {"MED": "HLT", "DEN": "DEN", "VIS": "VIS", "M": "HLT", "D": "DEN", "V": "VIS"}


def _text(value: Any) -> str:
    """One canonical text form, matching the CSV writer so exports agree."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, datetime):
        return value.isoformat(sep=" ", timespec="seconds")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, float):
        return repr(value)
    return str(value)


# The date formats a sample can be read as, in strftime terms.
DATE_FORMATS = {"YYYY-MM-DD": "%Y-%m-%d", "MM/DD/YYYY": "%m/%d/%Y", "YYYYMMDD": "%Y%m%d"}


def layout_value(value: Any, field: dict[str, Any]) -> Any:
    """A value as a layout field writes it: dated the way the sample was.

    A sample whose dates read 01/31/1980 describes a file that writes them that
    way, and a file in ISO dates where the receiver expects that is a file it
    rejects. Anything that is not a date, or will not read as one, is left be.
    """
    fmt = DATE_FORMATS.get(str(field.get("date_format") or ""))
    if fmt is None or value is None or value == "":
        return value
    if isinstance(value, (date, datetime)):
        return value.strftime(fmt)
    try:
        return datetime.fromisoformat(str(value)[:10]).strftime(fmt)
    except ValueError:
        return value


def _index(rows: list[dict], key: str) -> dict[Any, dict]:
    """Rows by one key. Built once; every later lookup is constant time."""
    return {row[key]: row for row in rows if key in row}


def member_records(
    result: RunResult,
    plan: Plan,
    *,
    members_table: str = "dbo.CMC_MEME_MEMBER",
    subscribers_table: str = "dbo.CMC_SBSB_SUBSC",
    plans: dict[str, dict[str, Any]] | None = None,
    limit: int | None = None,
) -> Iterator[dict[str, Any]]:
    """One record per generated member, with its subscriber and plan beside it.

    `plans` maps a coverage plan id to the descriptive fields an enrollment
    transaction names. It is small -- one row per plan -- and is passed in
    rather than read here, so this stays a pure function of the run.
    """
    members = result.rows(members_table)
    if not members:
        return

    by_subscriber = _index(result.rows(subscribers_table), "SBSB_CK")
    plans = plans or {}

    for position, member in enumerate(members):
        if limit is not None and position >= limit:
            return
        subscriber = by_subscriber.get(member.get("SBSB_CK"), {})
        coverage = dict(plans.get(subscriber.get("CSPI_ID"), {}))
        termed = member.get("MEME_TERM_DT") is not None

        record = dict(member)
        record.update(
            SBSB_ID=subscriber.get("SBSB_ID"),
            SBSB_LAST_NAME=subscriber.get("SBSB_LAST_NAME"),
            SBSB_FIRST_NAME=subscriber.get("SBSB_FIRST_NAME"),
            CSPI_ID=subscriber.get("CSPI_ID"),
            CSPD_CAT=coverage.get("CSPD_CAT"),
            PLDS_DESC=coverage.get("PLDS_DESC"),
            INS_LINE_CD=INSURANCE_LINE.get(coverage.get("CSPD_CAT"), "HLT"),
            COVERAGE_EFF_DT=member.get("MEME_EFF_DT"),
            COVERAGE_TERM_DT=member.get("MEME_TERM_DT"),
        )
        record.update(TERMED if termed else ACTIVE)
        yield record


def claim_line_records(
    result: RunResult,
    plan: Plan,
    *,
    lines_table: str = "dbo.CMC_CDML_CL_LINE",
    claims_table: str = "dbo.CMC_CLCL_CLAIM",
    members_table: str = "dbo.CMC_MEME_MEMBER",
    limit: int | None = None,
) -> Iterator[dict[str, Any]]:
    """One record per generated claim line, with its claim and member beside it."""
    lines = result.rows(lines_table)
    if not lines:
        return

    by_claim = _index(result.rows(claims_table), "CLCL_ID")
    by_member = _index(result.rows(members_table), "MEME_CK")

    for position, line in enumerate(lines):
        if limit is not None and position >= limit:
            return
        claim = by_claim.get(line.get("CLCL_ID"), {})
        member = by_member.get(claim.get("MEME_CK"), {})

        record = dict(line)
        record.update(
            MEME_CK=claim.get("MEME_CK"),
            PRPR_ID=claim.get("PRPR_ID"),
            PDPD_ID=claim.get("PDPD_ID"),
            CLCL_CUR_STS=claim.get("CLCL_CUR_STS"),
            CLCL_SVC_DT=claim.get("CLCL_SVC_DT"),
            CLCL_RECD_DT=claim.get("CLCL_RECD_DT"),
            CLCL_PAID_DT=claim.get("CLCL_PAID_DT"),
            CLCL_TOT_CHG=claim.get("CLCL_TOT_CHG"),
            IDCD_ID_PRIMARY=claim.get("CLCL_IDCD_ID"),
            IPCD_ID=line.get("CDML_SVC_CD"),
            MEME_SEX=member.get("MEME_SEX"),
            MEME_BIRTH_DT=member.get("MEME_BIRTH_DT"),
            MEME_ID=member.get("MEME_ID"),
            # A remittance names the patient; an 837 does not have to. Carried
            # for both rather than two record shapes, because the cost is two
            # dictionary reads and the alternative is a second join.
            MEME_FIRST_NAME=member.get("MEME_FIRST_NAME"),
            MEME_LAST_NAME=member.get("MEME_LAST_NAME"),
        )
        yield record


# ---------------------------------------------------------------------------
# Delimited and fixed-width output
# ---------------------------------------------------------------------------

# Rows per yielded block. One yield per row makes a syscall per row over HTTP
# and dominates the cost at volume; one yield for everything defeats the point
# of streaming. A few hundred rows is the flat part of that curve.
BLOCK = 256


def stream_delimited(
    records: Iterable[dict[str, Any]],
    columns: list[str],
    *,
    delimiter: str = ",",
    header: bool = True,
    newline: str = "\r\n",
) -> Iterator[str]:
    """Delimited text, a block of rows at a time.

    Values are not quoted: the generated data contains no delimiters, and a
    quoting pass over every field at volume costs more than it is worth here.
    A value that does contain one would corrupt the file, so it is replaced
    rather than silently written.
    """
    if header:
        yield delimiter.join(columns) + newline

    block: list[str] = []
    append = block.append
    for record in records:
        append(
            delimiter.join(
                _text(record.get(column)).replace(delimiter, " ").replace("\n", " ")
                for column in columns
            )
        )
        if len(block) >= BLOCK:
            yield newline.join(block) + newline
            block = []
            append = block.append
    if block:
        yield newline.join(block) + newline


def stream_fixed_width(
    records: Iterable[dict[str, Any]],
    fields: list[dict[str, Any]],
    *,
    newline: str = "\r\n",
) -> Iterator[str]:
    """Fixed-width text, a block of rows at a time.

    Text is padded on the right, numbers on the left, which is the convention
    every mainframe-shaped layout in this domain follows.
    """
    # Resolved once rather than per row: at a hundred thousand rows the
    # difference between reading these dict keys here and reading them inside
    # the loop is seconds.
    # A parsed layout records the widest value it saw as `max_width`; a layout
    # written by hand states `length`. Either is the width of the field.
    # A field read from a sample also carries where it started. Those starts
    # keep the gaps the sample had between its columns; a layout defined by
    # hand has none, and its starts are where the widths already put them.
    # A start behind the row so far would overlap a field, so it is ignored.
    spec = [
        (
            field.get("name", ""),
            int(field.get("length") or field.get("max_width") or 0),
            # A YYYYMMDD date reads as a number in a sample, and is still a
            # date: aligned like text, as the sample had it.
            str(field.get("type") or "text").lower()
            in {"number", "numeric", "decimal", "int"}
            and not field.get("date_format"),
            int(field["start"]) if field.get("start") is not None else None,
        )
        for field in fields
    ]

    block: list[str] = []
    append = block.append
    for record in records:
        parts = []
        at = 0
        for name, width, numeric, start in spec:
            if start is not None and start > at:
                parts.append(" " * (start - at))
                at = start
            value = _text(record.get(name))
            if len(value) > width:
                value = value[:width]
            parts.append(value.rjust(width) if numeric else value.ljust(width))
            at += width
        append("".join(parts))
        if len(block) >= BLOCK:
            yield newline.join(block) + newline
            block = []
            append = block.append
    if block:
        yield newline.join(block) + newline

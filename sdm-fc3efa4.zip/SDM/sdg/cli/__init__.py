"""SDG cli package."""

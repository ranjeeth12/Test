"""SDG command line. Subcommands are added as each build step lands."""

from __future__ import annotations

import json
import os
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from sdg.config import get_settings
from sdg.discovery.connections import ConnectionRegistry

app = typer.Typer(
    add_completion=False,
    help="Synthetic data generation tool (proof of concept).",
    no_args_is_help=True,
)
# A fixed width keeps table output readable when stdout is not a terminal,
# which is how the demo is usually captured.
console = Console(width=int(os.getenv("SDG_CONSOLE_WIDTH", "132")))


@app.callback()
def _main() -> None:
    """Keeps subcommand names visible even when only one command is registered."""


def work_dir() -> Path:
    path = get_settings().work_dir
    path.mkdir(parents=True, exist_ok=True)
    return path


def work_belongs_elsewhere() -> str | None:
    """The database work/ belongs to, when it is not the source in .env.

    The interface records the database being worked on in
    work/working-database.txt. Commands here read the source in .env and write
    into work/, so running one while the interface works on another database
    would put this source's model under that database's name.
    """
    import re

    marker = work_dir() / "working-database.txt"
    if not marker.exists():
        return None
    settings = get_settings()
    source = re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{settings.mssql.server}__{settings.source_db}")
    current = marker.read_text(encoding="utf-8").strip()
    return current if current and current != source else None


def refuse_if_work_belongs_elsewhere() -> None:
    elsewhere = work_belongs_elsewhere()
    if elsewhere:
        elsewhere = elsewhere.split("__", 1)[-1]
        source = get_settings().source_db
        console.print(
            f"[red]work/ belongs to {elsewhere}, the database being worked on in "
            f"the interface.[/red] This would replace its files with {source}'s. "
            f"Choose {source} on Connect first, or read {elsewhere} again there instead."
        )
        raise typer.Exit(code=1)


def write_artifact(name: str, payload: object) -> Path:
    path = work_dir() / name
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    return path


def read_artifact(name: str) -> dict:
    path = work_dir() / name
    if not path.exists():
        raise typer.BadParameter(
            f"missing artifact {path}. Run the earlier step first."
        )
    return json.loads(path.read_text(encoding="utf-8"))


@app.command()
def connect() -> None:
    """Check the configured connections and record them as an artifact."""
    registry = ConnectionRegistry()
    # The store is checked alongside the source: analysis reads it, so a run
    # that cannot reach it fails later rather than here.
    results = [registry.check(name) for name in ("source", "ref", "denorm")]

    table = Table(title="Connections")
    table.add_column("name")
    table.add_column("database")
    table.add_column("server")
    table.add_column("version")
    table.add_column("status")
    for result in results:
        table.add_row(
            result["connection"],
            result.get("db", "-"),
            result.get("server", "-"),
            result.get("version", "-"),
            "[green]ok[/green]" if result["ok"] else f"[red]{result.get('error', '')}[/red]",
        )
    console.print(table)

    path = write_artifact(
        "connections.json",
        {
            "connections": [registry.ref(n).as_dict() for n in ("source", "ref")],
            "checks": results,
        },
    )
    console.print(f"wrote {path}")
    if not all(r["ok"] for r in results):
        raise typer.Exit(code=1)


@app.command("work-check")
def work_check() -> None:
    """Fail if work/ holds another database's files than the source's."""
    refuse_if_work_belongs_elsewhere()


LOCAL_SERVERS = {"", "localhost", ".", "(local)", "127.0.0.1"}


def customer_machine() -> str | None:
    """Why this machine is set up as a customer's, or None for a demo machine.

    SDG_ENV=customer says so outright. Without it, a pattern store on its own
    server (SDG_DENORM_SERVER) is the customer shape: no demo machine has one.
    """
    get_settings()  # loads .env; a name set in the environment wins
    if os.getenv("SDG_ENV", "").strip().lower() == "customer":
        return "SDG_ENV=customer"
    server = os.getenv("SDG_DENORM_SERVER", "").strip()
    if server.lower().split("\\")[0] not in LOCAL_SERVERS:
        return f"SDG_DENORM_SERVER={server}"
    return None


@app.command("demo-check")
def demo_check() -> None:
    """Fail on a customer machine: the demo scripts build and reseed databases."""
    reason = customer_machine()
    if reason:
        console.print(
            f"[red]This machine is set up as a customer's ({reason} in .env).[/red]\n"
            "seed, bootstrap, first-run, upgrade and demo are for demo machines only:\n"
            "they create, reseed and re-extract databases. At a customer use only\n"
            "scripts\\customer\\setup_tables.cmd, scripts\\customer\\extract.cmd,\n"
            "scripts\\ui.cmd and scripts\\customer\\export_patterns.cmd (ENVIRONMENTS.md)."
        )
        raise typer.Exit(code=1)


@app.command()
def extract(
    source: str = typer.Argument(
        None, help="Which source to read. Omit to list what can be read."
    ),
    table: list[str] = typer.Option(
        None, "--table", help="Only these denorm tables. Repeatable."
    ),
    keep_going: bool = typer.Option(
        False, "--keep-going",
        help="If a table cannot be filled, keep its old rows, say why, and go on to the next.",
    ),
) -> None:
    """Read a source into the analysis store.

    Pattern analysis reads the store, never a source directly, so this is what
    stands between a database and being able to analyze it. A refresh is
    complete: every row for this source is replaced. Other sources in the store
    are untouched.
    """
    from sdg.extract import extract as run_extract, sources

    available = sources()
    if not source:
        if not available:
            console.print("[yellow]No extract definitions found.[/yellow]")
            raise typer.Exit(code=1)
        console.print("Sources that can be read:")
        for name in available:
            console.print(f"  {name}")
        return

    if source not in available:
        console.print(
            f"[red]No extract definition for {source}.[/red] "
            f"Found: {', '.join(available) or 'nothing'}"
        )
        raise typer.Exit(code=1)

    console.print(f"reading [cyan]{source}[/cyan] into the analysis store")

    # Rows this tool generated are not part of the landscape. The target is
    # usually the source, so without this a run followed by an extract measures
    # the next patterns partly from data the tool invented.
    from sdg.api.service import Service

    from sdg.extract import keys_from_manifest

    excluded = keys_from_manifest(Service().manifest)
    if excluded:
        console.print(
            f"[dim]excluding the rows of the last run, which has not been "
            f"cleaned up[/dim]"
        )

    def said(name: str, rows: int, done: bool, error: str = "") -> None:
        if error:
            console.print(f"  [red]{name}: FAILED[/red] -- {error} Its previous rows were kept.")
            return
        console.print(f"  {name}: {rows:,} rows{' -- done' if done else ' ...'}")

    result = run_extract(
        source, only=list(table) if table else None, exclude_keys=excluded,
        progress=said, stop_on_error=not keep_going,
    )

    out = Table(title=f"{source} extracted")
    out.add_column("table")
    out.add_column("rows", justify="right")
    out.add_column("generated, skipped", justify="right")
    out.add_column("seconds", justify="right")
    for row in result.tables:
        out.add_row(
            row.table, f"{row.rows:,}" if not row.error else "[red]failed[/red]",
            f"{row.skipped:,}" if row.skipped else "-",
            f"{row.seconds:.1f}",
        )
    console.print(out)
    failed = [row for row in result.tables if row.error]
    for row in failed:
        console.print(f"[red]{row.table}[/red]: {row.error} Its previous rows were kept.")
    if failed:
        raise typer.Exit(code=1)
    console.print(
        f"[green]{result.rows:,} rows in {result.seconds:.1f}s.[/green] "
        f"Patterns found before this read may no longer match; "
        f"the pattern screens report that as a stale pattern."
    )


@app.command("customer-tables")
def customer_tables(
    indexes: bool = typer.Option(
        True, "--indexes/--no-indexes",
        help="Index the denorm tables for the reads pattern analysis makes (default on).",
    ),
) -> None:
    """Create every SDM table in the SDM platform database. Add-only.

    For a new deployment into an empty schema: the denorm tables
    (member_denorm, claims_denorm, and the provider, plan and claim-detail
    tables beside them), the tool's own tables, and the reference lists. Uses
    the store connection only (SDG_DENORM_*, SDG_DB_DENORM, SDG_DENORM_SCHEMA);
    FACETS is not touched and no database is created. Running it again
    creates only what is missing.
    """
    import sys

    import pyodbc

    from sdg.config import get_settings

    sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "seed"))
    from bootstrap import ensure_store

    settings = get_settings()
    schema = settings.denorm_schema
    console.print(f"SDM platform database [cyan]{settings.denorm_db}[/cyan] on "
                  f"[cyan]{settings.store.server}[/cyan], schema [cyan]{schema}[/cyan]")
    try:
        ensure_store(settings, indexes=indexes)
        # The tables the screens otherwise create on first use, made now so a
        # missing permission shows here and not in the middle of a demo.
        from sdg.analyzer.services import baseline, discovery_features, layout_service
        from sdg.analyzer.services import masking_service

        discovery_features.ensure_table()
        layout_service.ensure_table()
        layout_service.ensure_alias_table()
        layout_service._ensure_rule_measures()
        masking_service.ensure_tables()
        baseline.ensure_table()
        from sdg.analyzer.services import sample_gen_configs

        sample_gen_configs.ensure_table()
        from sdg.analyzer.services import report_fields

        report_fields.ensure_table()
        from sdg.extract.run import log_ddl

        with pyodbc.connect(settings.store.connection_string(settings.denorm_db)) as log:
            log.execute(log_ddl(schema))
            log.commit()
    except SystemExit as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1)
    except Exception as exc:
        from sdg.discovery.errors import plain

        console.print(f"[red]Stopped:[/red] {plain(exc)}")
        raise typer.Exit(code=1)

    conn = pyodbc.connect(settings.store.connection_string(settings.denorm_db))
    try:
        rows = conn.cursor().execute(
            "SELECT t.name, SUM(p.rows) FROM sys.tables t JOIN sys.partitions p "
            "ON p.object_id = t.object_id AND p.index_id IN (0, 1) "
            "WHERE SCHEMA_NAME(t.schema_id) = ? GROUP BY t.name ORDER BY t.name",
            schema).fetchall()
    finally:
        conn.close()
    out = Table(title=f"{schema} tables ({len(rows)})")
    out.add_column("table")
    out.add_column("rows", justify="right")
    for name, count in rows:
        out.add_row(name, f"{int(count):,}")
    console.print(out)
    console.print("[green]Tables ready.[/green] Next: scripts\\customer\\extract.cmd")


@app.command()
def landscape(
    source: str = typer.Argument(
        None, help="Which extract to describe; the configured source by default.",
    ),
) -> None:
    """Describe what the store holds, per element.

    A profile is keyed by table and column, which makes it a fact about one
    database. This is the same measurements keyed by element, which makes them
    sayable about any target that carries the same elements -- including one
    that holds no rows at all.
    """
    from sdg.api.service import Service
    from sdg.landscape import derive, save
    from sdg.landscape.derive import unmeasurable

    service = Service()
    source = source or get_settings().source_db
    shape = derive(source=source, catalog=service.catalog, registry=service.registry)
    path = save(shape, service.work / f"landscape-{source}.json")

    out = Table(title=f"{source} landscape")
    out.add_column("")
    out.add_column("", justify="right")
    for key, value in shape.summary().items():
        out.add_row(key, f"{value:,}" if isinstance(value, int) else str(value))
    console.print(out)

    for relationship in shape.relationships:
        console.print(
            f"  [cyan]{relationship.child_element}[/cyan] per "
            f"[cyan]{relationship.parent_element}[/cyan]: "
            f"mean {relationship.mean:.2f}, {relationship.minimum}-{relationship.maximum}"
        )
    missed = unmeasurable()
    if missed:
        console.print(f"[yellow]{len(missed)} relationships could not be measured[/yellow]")
        for line in missed[:3]:
            console.print(f"  {line}")
    if shape.unmatched:
        console.print(
            f"[dim]{len(shape.unmatched)} store columns matched no element; "
            f"a target asking about those will be told nothing is known.[/dim]"
        )
    console.print(f"wrote {path}")


@app.command()
def discover(
    connection: str = typer.Option("source", help="which registered connection to read"),
    schema: list[str] = typer.Option(None, "--schema", help="limit to these schemas"),
    exclude: list[str] = typer.Option(None, "--exclude", help="skip these tables"),
    derivable: list[str] = typer.Option(
        None, "--derivable", help="declare a column as derived from others"
    ),
    no_infer: bool = typer.Option(False, "--no-infer", help="skip foreign-key inference"),
) -> None:
    """Read the structure of a database and classify every column."""
    from sdg.discovery.run import discover as run_discovery

    result = run_discovery(
        ConnectionRegistry(),
        connection,
        include_schemas=schema or None,
        exclude_tables=exclude or None,
        derivable_columns=derivable or (),
        infer_keys=not no_infer,
    )

    table = Table(title=f"Discovered {len(result.model.tables)} tables")
    table.add_column("table", overflow="fold")
    table.add_column("rows", justify="right")
    table.add_column("columns", justify="right")
    table.add_column("keys", overflow="fold")
    table.add_column("triggers", overflow="fold")
    for discovered in result.model.tables:
        declared = sum(1 for fk in discovered.foreign_keys if fk.kind == "declared")
        inferred = sum(1 for fk in discovered.foreign_keys if fk.kind == "inferred")
        keys = f"{declared} declared"
        if inferred:
            keys += f", [yellow]{inferred} inferred[/yellow]"
        table.add_row(
            discovered.name,
            f"{discovered.row_count:,}",
            str(len(discovered.columns)),
            keys,
            ", ".join(discovered.triggers) or "-",
        )
    console.print(table)

    if result.inferred:
        console.print("\n[bold]Inferred foreign keys[/bold]")
        for key in result.inferred:
            console.print(
                f"  {key.child_table}.{key.child_column} -> "
                f"{key.parent_table}.{key.parent_column}  "
                f"[dim]{key.coverage:.1%} of {key.distinct_values:,} distinct values[/dim]"
            )

    buckets = result.summary()["buckets"]
    console.print("\n[bold]Column buckets[/bold]  " + "  ".join(
        f"{name}={count}" for name, count in buckets.items()
    ))

    path = result.model.save(work_dir() / "physical-model.json")
    console.print(f"wrote {path}")


@app.command()
def profile(
    connection: str = typer.Option("source", help="which registered connection to read"),
    sample: int = typer.Option(100_000, help="cap on rows sampled per table"),
    table: list[str] = typer.Option(None, "--table", help="limit to these tables"),
    skip_pairwise: bool = typer.Option(
        False, "--skip-pairwise", help="skip dependency and ordering analysis"
    ),
) -> None:
    """Measure the data: distributions, formats, dependencies, and ratios."""
    from sdg.discovery.model import PhysicalModel
    from sdg.profiling.run import profile as run_profile

    model_path = work_dir() / "physical-model.json"
    if not model_path.exists():
        raise typer.BadParameter(f"missing {model_path}. Run `sdg discover` first.")
    model = PhysicalModel.load(model_path)

    report = run_profile(
        ConnectionRegistry(),
        model,
        connection,
        sample_cap=sample,
        tables=table or None,
        skip_pairwise=skip_pairwise,
    )

    summary = Table(title=f"Profiled {len(report.columns)} columns in {report.seconds:.1f}s")
    summary.add_column("table", overflow="fold")
    summary.add_column("seconds", justify="right")
    summary.add_column("columns", justify="right")
    summary.add_column("formats fitted", justify="right")
    summary.add_column("code columns", justify="right")
    for name, seconds in report.table_seconds.items():
        columns = [c for c in report.columns if c.table == name]
        summary.add_row(
            name,
            f"{seconds:.2f}",
            str(len(columns)),
            str(sum(1 for c in columns if c.fitted_format)),
            str(sum(1 for c in columns if c.looks_like_a_code())),
        )
    console.print(summary)

    if report.dependencies:
        console.print("\n[bold]Functional dependencies[/bold]")
        for dependency in report.dependencies:
            console.print(
                f"  {dependency.table}: {dependency.determinant} determines "
                f"{dependency.dependent} "
                f"[dim]across {dependency.distinct_determinant:,} distinct values[/dim]"
            )

    if report.orderings:
        console.print("\n[bold]Date orderings[/bold]")
        for ordering in report.orderings:
            console.print(
                f"  [{ordering.kind}] {ordering.earlier} <= {ordering.later}  "
                f"[dim]{ordering.share_in_order:.1%} of {ordering.rows_compared:,} rows, "
                f"gap {ordering.gap_min} to {ordering.gap_max} days[/dim]"
            )

    if report.ratios:
        console.print("\n[bold]Children per parent[/bold]")
        for ratio in report.ratios:
            console.print(
                f"  {ratio.child_table} per {ratio.parent_table}  "
                f"[cyan]{ratio.proposal['kind']}[/cyan]"
            )
            console.print(f"    [dim]{ratio.evidence}[/dim]")

    if report.skipped:
        console.print("\n[bold yellow]Skipped[/bold yellow]")
        for skipped in report.skipped:
            console.print(f"  {skipped.table} {skipped.analysis}: {skipped.reason}")

    path = report.save(work_dir() / "profile.json")
    console.print(f"\nwrote {path}")


@app.command(name="map")
def map_command(
    catalog: Path = typer.Option(None, "--catalog", help="catalog YAML to map against"),
) -> None:
    """Match every column to a catalog element, with the evidence behind it."""
    from sdg.catalog.loader import load_catalog
    from sdg.discovery.model import PhysicalModel
    from sdg.mapping.scorer import map_columns
    from sdg.profiling.model import ProfileReport

    model_path = work_dir() / "physical-model.json"
    if not model_path.exists():
        raise typer.BadParameter(f"missing {model_path}. Run `sdg discover` first.")
    model = PhysicalModel.load(model_path)

    profile_path = work_dir() / "profile.json"
    report = ProfileReport.load(profile_path) if profile_path.exists() else None
    if report is None:
        console.print(
            "[yellow]no profile found; mapping on names alone. "
            "Run `sdg profile` for format and check-digit evidence.[/yellow]"
        )

    loaded = load_catalog(catalog)
    store = map_columns(model, loaded, report)
    stats = store.statistics()

    table = Table(title=f"Mapped against {loaded.organization or 'the catalog'}")
    table.add_column("column", overflow="fold")
    table.add_column("element", overflow="fold")
    table.add_column("confidence")
    table.add_column("evidence", overflow="fold")
    for mapping in store.mappings:
        if mapping.bucket == "system":
            continue
        color = {"high": "green", "medium": "yellow", "low": "red"}.get(
            mapping.confidence or "", "dim"
        )
        table.add_row(
            mapping.qualified,
            mapping.element or "-",
            f"[{color}]{mapping.confidence or 'none'}[/{color}]",
            ", ".join(sorted({e["kind"] for e in mapping.evidence})) or "-",
        )
    console.print(table)

    console.print(
        f"\n[bold]Auto-map rate[/bold] "
        f"[green]{stats['auto_map_rate']:.1%}[/green] "
        f"({stats['high']} of {stats['mappable_columns']} mappable columns at high "
        f"confidence; {stats['system_columns']} system columns need no element)"
    )
    console.print(
        f"[bold]Review queue[/bold] "
        f"{stats['medium'] + stats['low'] + stats['unmapped']} columns "
        f"(medium {stats['medium']}, low {stats['low']}, unmapped {stats['unmapped']})"
    )
    console.print(
        "[dim]high-confidence evidence: "
        + ", ".join(f"{k} {v}" for k, v in stats["high_confidence_by_evidence"].items())
        + "[/dim]"
    )

    path = store.save(work_dir() / "mappings.json")
    console.print(f"wrote {path}")


def _load_review_inputs(catalog_path: Path | None, *, detect: bool = True):
    """Everything the proposer and the review page read. Shared by review and plan."""
    from sdg.catalog.loader import load_catalog
    from sdg.discovery.model import PhysicalModel
    from sdg.mapping.scorer import MappingStore
    from sdg.plan.detect import detect_sum_expressions
    from sdg.plan.proposer import propose
    from sdg.profiling.model import ProfileReport

    directory = work_dir()
    for name, step in (
        ("physical-model.json", "discover"),
        ("mappings.json", "map"),
    ):
        if not (directory / name).exists():
            raise typer.BadParameter(f"missing {directory / name}. Run `sdg {step}` first.")

    model = PhysicalModel.load(directory / "physical-model.json")
    mappings = MappingStore.load(directory / "mappings.json")
    profile_path = directory / "profile.json"
    report = ProfileReport.load(profile_path) if profile_path.exists() else None
    catalog = load_catalog(catalog_path)

    sums = detect_sum_expressions(ConnectionRegistry(), model) if detect else []
    proposals = propose(model, report, sums, mappings, catalog)
    return model, report, mappings, catalog, proposals, sums


@app.command()
def review(
    catalog: Path = typer.Option(None, "--catalog", help="catalog YAML to map against"),
    output: Path = typer.Option(None, "--output", help="where to write the HTML page"),
    open_page: bool = typer.Option(False, "--open", help="open the page in a browser"),
) -> None:
    """Propose a rule for every column and build the review page."""
    from sdg.review.page import build_context, write_page
    from sdg.review.queue import build_queue, decisions_template, save_decisions, summarize

    model, report, mappings, loaded, proposals, sums = _load_review_inputs(catalog)
    queue = build_queue(model, mappings, proposals)

    write_artifact("proposals.json", [p.as_dict() for p in proposals])
    write_artifact("review-queue.json", [q.as_dict() for q in queue])

    decisions_path = work_dir() / "review-decisions.json"
    if decisions_path.exists():
        console.print(f"[dim]keeping your edits in {decisions_path}[/dim]")
    else:
        save_decisions(decisions_template(queue), decisions_path)
        console.print(f"wrote {decisions_path} for you to edit")

    by_confidence: dict[str, int] = {}
    for proposal in proposals:
        by_confidence[proposal.confidence] = by_confidence.get(proposal.confidence, 0) + 1

    table = Table(title="Review queue")
    table.add_column("column", overflow="fold")
    table.add_column("bucket")
    table.add_column("why", overflow="fold")
    table.add_column("nearest element")
    table.add_column("proposed rule", overflow="fold")
    for item in queue:
        table.add_row(
            item.qualified, item.bucket, item.explain(),
            item.element or "-", item.generator or "-",
        )
    console.print(table if queue else "[green]Review queue is empty.[/green]")

    console.print(
        "\n[bold]Proposals[/bold]  "
        + "  ".join(f"{k} {v}" for k, v in sorted(by_confidence.items()))
    )
    if sums:
        console.print("[bold]Expressions found[/bold]")
        for found in sums:
            console.print(
                f"  {found.parent_table}.{found.parent_column} = "
                f"[cyan]{found.expression()}[/cyan] [dim]{found.detail()}[/dim]"
            )
    console.print(f"[bold]Queue size[/bold] {summarize(queue)['queued_columns']} columns")

    page_path = Path(output) if output else work_dir() / "review.html"
    context = build_context(
        model, report, mappings, proposals, queue, loaded,
        decisions_path=str(decisions_path),
    )
    write_page(context, page_path)
    console.print(f"wrote {page_path}")

    if open_page:
        import webbrowser

        webbrowser.open(page_path.resolve().as_uri())


@app.command()
def plan(
    catalog: Path = typer.Option(None, "--catalog", help="catalog YAML to resolve against"),
    seed: str = typer.Option("demo-seed-001", help="named seed for the run"),
    name: str = typer.Option("facets-slice", help="plan name, which keys the seed hash"),
    count: list[str] = typer.Option(
        None, "--count", help="root row count, as TABLE=N (repeatable)"
    ),
    reuse: list[str] = typer.Option(
        None, "--reuse", help="set a table to reuse rather than generate (repeatable)"
    ),
    exclude: list[str] = typer.Option(
        None, "--exclude", help="leave a table alone entirely (repeatable)"
    ),
    driving: list[str] = typer.Option(
        None, "--driving", help="override a driving parent, as CHILD=PARENT"
    ),
) -> None:
    """Resolve every column to one rule and compute the row counts."""
    from sdg.plan.build import BuildInputs, build_plan, default_reference_sets
    from sdg.plan.combinations import discover as discover_combinations
    from sdg.plan.hierarchy import HierarchyError, describe
    from sdg.plan.validator import blocking
    from sdg.review.queue import load_decisions

    model, report, mappings, loaded, proposals, _sums = _load_review_inputs(catalog)
    decisions = load_decisions(work_dir() / "review-decisions.json")

    modes = {name_: "reuse" for name_ in (reuse or [])}
    modes.update({name_: "exclude" for name_ in (exclude or [])})

    inputs = BuildInputs(
        model=model,
        catalog=loaded,
        mappings=mappings,
        proposals=proposals,
        report=report,
        decisions=decisions,
        modes=modes,
        root_counts=_parse_pairs(count, as_int=True),
        driving_parents=_parse_pairs(driving),
        seed=seed,
        name=name,
        catalog_path=str(catalog) if catalog else None,
    )
    inputs.reference_sets = default_reference_sets(ConnectionRegistry(), inputs)
    inputs.combinations = discover_combinations(ConnectionRegistry())

    try:
        built, graph = build_plan(inputs)
    except HierarchyError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc

    table = Table(title="Effective counts")
    table.add_column("table", overflow="fold")
    table.add_column("mode")
    table.add_column("level", justify="right")
    table.add_column("driving parent", overflow="fold")
    table.add_column("ratio", justify="right")
    table.add_column("rows", justify="right")
    for plan_table in built.tables:
        node = graph.nodes.get(plan_table.name)
        table.add_row(
            plan_table.name,
            plan_table.mode,
            str(node.level) if node else "-",
            (node.driving_parent or "-") if node else "-",
            f"{node.ratio_mean:.2f}" if node and node.ratio_mean else "-",
            f"{node.effective_count:,}" if node else "-",
        )
    console.print(table)
    console.print(f"[bold]Total rows to generate[/bold] {graph.total_rows():,}")

    console.print("\n[bold]Hierarchy[/bold]")
    for line in describe(graph):
        console.print(f"  {line}")

    if built.meta.reference_sets:
        console.print("\n[bold]Reference sets[/bold]")
        for reference in inputs.reference_sets.values():
            console.print(f"  {reference.table}: [dim]{reference.describe()}[/dim]")

    provenance: dict[str, int] = {}
    for plan_table in built.tables:
        for field_ in plan_table.fields:
            provenance[field_.provenance] = provenance.get(field_.provenance, 0) + 1
    console.print(
        "\n[bold]Rule provenance[/bold]  "
        + "  ".join(f"{k} {v}" for k, v in sorted(provenance.items()))
    )

    stoppers = blocking(built.warnings)
    if built.warnings:
        console.print("\n[bold]Warnings[/bold]")
        for warning in built.warnings:
            color = "red" if warning.severity == "block" else "yellow"
            console.print(f"  [{color}]{warning.severity}[/{color}] {warning.code}: {warning.message}")

    path = built.save(work_dir() / "plan.json")
    console.print(f"\nwrote {path}")

    if stoppers:
        console.print(
            f"[red]{len(stoppers)} blocking warning"
            f"{'s' if len(stoppers) > 1 else ''}; generation will not run until they are cleared.[/red]"
        )
        raise typer.Exit(code=1)


def _parse_pairs(values: list[str] | None, *, as_int: bool = False) -> dict:
    out: dict = {}
    for item in values or []:
        if "=" not in item:
            raise typer.BadParameter(f"expected NAME=VALUE, got {item!r}")
        key, _, value = item.partition("=")
        out[key.strip()] = int(value) if as_int else value.strip()
    return out


@app.command()
def dryrun(
    rows: int = typer.Option(5, help="rows to show per table"),
) -> None:
    """Generate a few rows in memory and show them."""
    from sdg.engine.dryrun import dry_run, format_preview
    from sdg.engine.execute import ReferenceSets
    from sdg.plan.model import Plan as PlanModel
    from sdg.plan.refsets import load_for_plan

    path = work_dir() / "plan.json"
    if not path.exists():
        raise typer.BadParameter(f"missing {path}. Run `sdg plan` first.")
    loaded_plan = PlanModel.load(path)

    reference_sets = ReferenceSets()
    bindings = {
        table.name: {
            "connection": table.source.connection,
            "table": table.source.table,
            "schema": table.source.schema_name,
            "key_column": table.source.key_columns[0],
            "filter": table.source.filter,
            "load": table.source.load or "full",
            "sample_size": table.source.sample_size,
        }
        for table in loaded_plan.tables
        if table.mode == "reuse" and table.source
    }
    if bindings:
        for name_, reference in load_for_plan(
            ConnectionRegistry(), bindings, seed=loaded_plan.meta.seed
        ).items():
            reference_sets.add(name_, reference.keys, reference.attributes)
            console.print(f"[dim]loaded {reference.size:,} keys for {name_}[/dim]")

    result = dry_run(loaded_plan, rows=rows, reference_sets=reference_sets)
    console.print(format_preview(result.frames, rows=rows))
    console.print(
        "[dim]counts: "
        + ", ".join(f"{k.split('.')[-1]}={v:,}" for k, v in result.counts().items())
        + "[/dim]"
    )


def _load_plan_and_reference_sets(seed_override: str | None = None):
    """The plan, plus the keys of every table it reuses."""
    from sdg.engine.execute import ReferenceSets
    from sdg.plan.model import Plan as PlanModel
    from sdg.plan.refsets import load_for_plan

    path = work_dir() / "plan.json"
    if not path.exists():
        raise typer.BadParameter(f"missing {path}. Run `sdg plan` first.")
    loaded = PlanModel.load(path)
    if seed_override:
        loaded.meta.seed = seed_override

    sets = ReferenceSets()
    sizes: dict[str, int] = {}
    bindings = {
        table.name: {
            "connection": table.source.connection,
            "table": table.source.table,
            "schema": table.source.schema_name,
            "key_column": table.source.key_columns[0],
            "filter": table.source.filter,
            "load": table.source.load or "full",
            "sample_size": table.source.sample_size,
        }
        for table in loaded.tables
        if table.mode == "reuse" and table.source
    }
    if bindings:
        for name, reference in load_for_plan(
            ConnectionRegistry(), bindings, seed=loaded.meta.seed
        ).items():
            sets.add(name, reference.keys, reference.attributes)
            sizes[name] = reference.size
    return loaded, sets, sizes


@app.command()
def generate(
    seed: str = typer.Option(None, help="override the plan's seed"),
    target: str = typer.Option("target", help="connection to write to"),
    csv: Path = typer.Option(None, "--csv", help="also write a CSV file per table"),
    dry: bool = typer.Option(False, "--dry", help="generate but do not write to the database"),
    disable_triggers: bool = typer.Option(
        False, "--disable-triggers", help="turn triggers off around the load"
    ),
) -> None:
    """Generate the planned rows and write them to the target."""
    from sdg.discovery.model import PhysicalModel
    from sdg.engine.execute import run_plan
    from sdg.plan.validator import blocking
    from sdg.writers.csvfile import write_run
    from sdg.writers.manifest import build_manifest, save_manifest, summarize
    from sdg.writers.sqlserver import PartialWrite, write

    loaded, sets, sizes = _load_plan_and_reference_sets(seed)

    stoppers = blocking(loaded.warnings)
    if stoppers:
        console.print("[red]The plan has blocking warnings; nothing was generated.[/red]")
        for warning in stoppers:
            console.print(f"  [red]{warning.code}[/red]: {warning.message}")
        raise typer.Exit(code=1)

    for name, size in sizes.items():
        console.print(f"[dim]loaded {size:,} keys for {name}[/dim]")

    console.print(f"generating with seed [cyan]{loaded.meta.seed}[/cyan] ...")
    result = run_plan(loaded, reference_sets=sets)
    console.print(
        f"generated {sum(result.counts().values()):,} rows in {result.seconds:.1f}s"
    )

    if csv:
        written = write_run(result, loaded, csv)
        console.print(f"wrote {len(written)} CSV files to {csv}")

    if dry:
        console.print("[yellow]--dry was given, so nothing was written to the database.[/yellow]")
        return

    model = PhysicalModel.load(work_dir() / "physical-model.json")
    registry = ConnectionRegistry()
    try:
        report = write(
            registry, loaded, result, model,
            connection=target, disable_triggers=disable_triggers,
        )
    except PartialWrite as partial:
        # Whole tables were committed before this failed. Write their manifest
        # so `sdg cleanup` can still find those rows, then report the failure.
        path = save_manifest(
            build_manifest(
                loaded, partial.report,
                connection=target,
                database=registry.database_for(target),
                reference_sizes=sizes,
                disable_triggers=disable_triggers,
            ),
            work_dir() / "run-manifest.json",
        )
        console.print(f"[red]The load stopped partway: {partial.cause}[/red]")
        for record in partial.report.tables:
            console.print(f"  [yellow]{record.table}: {record.rows_written:,} rows are in the database[/yellow]")
        console.print(f"wrote {path}")
        console.print("Run [cyan]sdg cleanup[/cyan] to remove them.")
        raise typer.Exit(code=1)

    table = Table(title=f"Written to {registry.database_for(target)}")
    table.add_column("table", overflow="fold")
    table.add_column("rows", justify="right")
    table.add_column("seconds", justify="right")
    table.add_column("identity insert")
    for record in report.tables:
        table.add_row(
            record.table, f"{record.rows_written:,}", f"{record.seconds:.2f}",
            "yes" if record.identity_insert else "no",
        )
    console.print(table)

    manifest = build_manifest(
        loaded, report,
        connection=target,
        database=registry.database_for(target),
        reference_sizes=sizes,
        disable_triggers=disable_triggers,
    )
    path = save_manifest(manifest, work_dir() / "run-manifest.json")
    console.print(f"\n{summarize(manifest)}")
    console.print(f"wrote {path}")


@app.command(name="validate")
def validate_command(
    target: str = typer.Option("target", help="connection to read back from"),
) -> None:
    """Check the generated data against every rule the plan claimed."""
    from sdg.discovery.model import PhysicalModel
    from sdg.plan.model import Plan as PlanModel
    from sdg.writers.manifest import load_manifest, save_manifest
    from sdg.writers.validate import validate_run

    manifest_path = work_dir() / "run-manifest.json"
    if not manifest_path.exists():
        raise typer.BadParameter(f"missing {manifest_path}. Run `sdg generate` first.")
    manifest = load_manifest(manifest_path)

    loaded = PlanModel.load(work_dir() / "plan.json")
    model = PhysicalModel.load(work_dir() / "physical-model.json")
    _plan, sets, _sizes = _load_plan_and_reference_sets()

    report = validate_run(
        ConnectionRegistry(), loaded, model, manifest,
        connection=target, reference_sets=sets.keys,
    )

    table = Table(title="Post-run validation")
    table.add_column("check", overflow="fold")
    table.add_column("kind")
    table.add_column("result")
    table.add_column("detail", overflow="fold")
    for check in report.checks:
        table.add_row(
            check.name, check.kind,
            "[green]pass[/green]" if check.passed else "[red]FAIL[/red]",
            check.detail,
        )
    console.print(table)

    summary = report.summary()
    console.print(
        f"\n[bold]{summary['checks'] - summary['failed']} of {summary['checks']} checks "
        f"passed[/bold]"
    )
    manifest["validation"] = {
        **summary,
        "checks": [c.as_record() for c in report.checks],
    }
    save_manifest(manifest, manifest_path)

    if not report.passed:
        for check in report.failures():
            console.print(f"  [red]{check.name}[/red]: {check.detail}")
        raise typer.Exit(code=1)
    console.print("[green]Validation passed.[/green]")


@app.command()
def cleanup(
    target: str = typer.Option("target", help="connection to delete from"),
    yes: bool = typer.Option(False, "--yes", help="do not ask before deleting"),
) -> None:
    """Delete exactly the rows the last run wrote."""
    from sdg.writers.manifest import load_manifest
    from sdg.writers.sqlserver import (
        cleanup as run_cleanup,
        manifest_key_columns,
        trigger_side_effects,
    )

    manifest_path = work_dir() / "run-manifest.json"
    if not manifest_path.exists():
        raise typer.BadParameter(f"missing {manifest_path}. There is no run to clean up.")
    manifest = load_manifest(manifest_path)

    planned = [
        (t["table"], t["rows_written"])
        for t in manifest.get("tables", [])
        if manifest_key_columns(t)
    ]
    console.print(f"This will delete rows written by seed {manifest['plan']['seed']}:")
    for name, rows in planned:
        console.print(f"  {name}: up to {rows:,} rows")

    fired = trigger_side_effects(manifest)
    if fired:
        console.print(
            "\n[yellow]These triggers were live during the load:[/yellow] "
            + ", ".join(fired)
        )
        console.print(
            "[yellow]Whatever they wrote into other tables stays. Those rows were "
            "written by the database, not by this run, so cleanup does not remove "
            "them.[/yellow]"
        )

    if not yes:
        confirmed = typer.confirm("Delete these rows?")
        if not confirmed:
            console.print("Nothing was deleted.")
            raise typer.Exit(code=0)

    deleted = run_cleanup(ConnectionRegistry(), manifest, connection=target)
    for name, count in deleted.items():
        console.print(f"  deleted {count:,} rows from {name}")
    console.print(f"[green]removed {sum(deleted.values()):,} rows[/green]")

    # replace() rather than rename(): on Windows a rename onto an existing file
    # fails, and a second cleanup should not error after it has already deleted.
    archived = manifest_path.with_suffix(".cleaned.json")
    manifest_path.replace(archived)
    console.print(f"manifest moved to {archived}")


@app.command()
def demo(
    small: bool = typer.Option(False, "--small", help="use the 1 percent fixture volumes"),
    subscribers: int = typer.Option(None, help="root row count; defaults to the scale"),
    seed: str = typer.Option("demo-seed-001", help="named seed for the run"),
    keep: bool = typer.Option(False, "--keep", help="leave the generated rows in place"),
    catalog: Path = typer.Option(None, "--catalog", help="catalog YAML to use"),
) -> None:
    """Run connect through validate in one go and print the success measures."""
    import time

    from sdg.catalog.loader import load_catalog
    from sdg.discovery.model import PhysicalModel
    from sdg.discovery.run import discover as run_discovery
    from sdg.engine.dryrun import dry_run, format_preview
    from sdg.mapping.scorer import map_columns
    from sdg.plan.build import BuildInputs, build_plan, default_reference_sets
    from sdg.plan.combinations import discover as discover_combinations
    from sdg.plan.detect import detect_sum_expressions
    from sdg.plan.hierarchy import describe
    from sdg.plan.proposer import propose
    from sdg.plan.validator import blocking
    from sdg.profiling.run import profile as run_profile
    from sdg.review.page import build_context, write_page
    from sdg.review.queue import build_queue, decisions_template, load_decisions, save_decisions
    from sdg.writers.manifest import build_manifest, save_manifest
    from sdg.writers.sqlserver import cleanup as run_cleanup, write
    from sdg.writers.validate import validate_run

    refuse_if_work_belongs_elsewhere()

    started = time.perf_counter()
    registry = ConnectionRegistry()
    steps: list[tuple[str, float]] = []

    def step(label: str, mark: float) -> float:
        now = time.perf_counter()
        steps.append((label, now - mark))
        console.print(f"[dim]{label} in {now - mark:.1f}s[/dim]")
        return now

    root_count = subscribers if subscribers is not None else (200 if small else 5_000)

    console.rule("[bold]connect")
    for name in ("source", "ref"):
        result = registry.check(name)
        state = "[green]ok[/green]" if result["ok"] else f"[red]{result.get('error')}[/red]"
        console.print(f"  {name} -> {result.get('db', '?')} {state}")
        if not result["ok"]:
            raise typer.Exit(code=1)
    mark = step("connected", started)

    console.rule("[bold]discover")
    discovery = run_discovery(registry, "source")
    discovery.model.save(work_dir() / "physical-model.json")
    summary = discovery.summary()
    console.print(
        f"  {summary['tables']} tables, {summary['columns']} columns, "
        f"{summary['declared_foreign_keys']} declared and "
        f"{summary['inferred_foreign_keys']} inferred foreign keys"
    )
    for key in discovery.inferred:
        console.print(
            f"  [yellow]inferred[/yellow] {key.child_table}.{key.child_column} -> "
            f"{key.parent_table}.{key.parent_column} [dim]({key.coverage:.1%})[/dim]"
        )
    mark = step("discovered", mark)

    console.rule("[bold]profile")
    report = run_profile(registry, discovery.model)
    report.save(work_dir() / "profile.json")
    console.print(
        f"  {len(report.columns)} columns measured, "
        f"{sum(1 for c in report.columns if c.fitted_format)} formats fitted, "
        f"{len(report.dependencies)} dependencies, {len(report.orderings)} date orderings, "
        f"{len(report.ratios)} ratios"
    )
    mark = step("profiled", mark)

    console.rule("[bold]map")
    loaded_catalog = load_catalog(catalog)
    mappings = map_columns(discovery.model, loaded_catalog, report)
    mappings.save(work_dir() / "mappings.json")
    stats = mappings.statistics()
    console.print(
        f"  [green]{stats['auto_map_rate']:.0%}[/green] of {stats['mappable_columns']} "
        f"mappable columns auto-mapped at high confidence"
    )
    mark = step("mapped", mark)

    console.rule("[bold]review")
    sums = detect_sum_expressions(registry, discovery.model)
    proposals = propose(discovery.model, report, sums, mappings, loaded_catalog)
    queue = build_queue(discovery.model, mappings, proposals)
    decisions_path = work_dir() / "review-decisions.json"
    if not decisions_path.exists():
        save_decisions(decisions_template(queue), decisions_path)
    page = write_page(
        build_context(
            discovery.model, report, mappings, proposals, queue, loaded_catalog,
            decisions_path=str(decisions_path),
        ),
        work_dir() / "review.html",
    )
    high = sum(1 for p in proposals if p.confidence == "high")
    console.print(f"  {high} of {len(proposals)} rules proposed at high confidence")
    console.print(f"  review queue: [cyan]{len(queue)}[/cyan] columns")
    for found in sums:
        console.print(f"  [cyan]expression[/cyan] {found.parent_table}.{found.parent_column} = {found.expression()}")
    console.print(f"  page: {page}")
    mark = step("reviewed", mark)

    console.rule("[bold]plan")
    inputs = BuildInputs(
        model=discovery.model, catalog=loaded_catalog, mappings=mappings,
        proposals=proposals, report=report,
        decisions=load_decisions(decisions_path),
        modes={
            "dbo.CMC_PRPR_PROV": "reuse",
            "dbo.CMC_PDPD_PRODUCT": "reuse",
            # The enrollment hierarchy and the clinical code sets are reference
            # data: a run points generated rows at the groups, plans and codes that
            # already exist rather than inventing employers of its own.
            "dbo.CMC_GRGR_GROUP": "reuse",
            "dbo.CMC_SGSG_SUBGROUP": "reuse",
            "dbo.CMC_CSPD_CAT_DESC": "reuse",
            "dbo.CMC_CSPI_CS_PLAN": "reuse",
            "dbo.CMC_PLDS_PLAN_DESC": "reuse",
            "dbo.CMC_PDDS_PROD_DESC": "reuse",
            "dbo.CMC_IDCD_DIAG_CODE": "reuse",
            "dbo.CMC_IPCD_PROC_CODE": "reuse",
            "dbo.CMC_NWNW_NETWORK": "reuse",
            "dbo.CMC_NWPR_RELATION": "reuse",
            "dbo.CMC_NWST_NET_SET": "reuse",
            # Who a member's PCP is comes from the store; assigning PCPs
            # to new members is not generated yet.
            "dbo.CMC_MEPR_PRIM_PROV": "exclude",
            "dbo.CMC_CLCL_AUDIT": "exclude",
        },
        root_counts={"dbo.CMC_SBSB_SUBSC": root_count},
        seed=seed, name="facets-slice-demo",
        catalog_path=str(catalog) if catalog else None,
    )
    inputs.reference_sets = default_reference_sets(registry, inputs)
    inputs.combinations = discover_combinations(registry)
    built, graph = build_plan(inputs)
    built.save(work_dir() / "plan.json")
    for line in describe(graph):
        console.print(f"  {line}")
    for reference in inputs.reference_sets.values():
        console.print(f"  [dim]{reference.table}: {reference.describe()}[/dim]")
    stoppers = blocking(built.warnings)
    if stoppers:
        for warning in stoppers:
            console.print(f"  [red]{warning.code}[/red]: {warning.message}")
        raise typer.Exit(code=1)
    mark = step("planned", mark)

    console.rule("[bold]dry run")
    preview = dry_run(built, rows=3, reference_sets=_sets_from(inputs))
    console.print(format_preview(preview.frames, rows=3))
    mark = step("dry run", mark)

    console.rule("[bold]generate")
    from sdg.engine.execute import run_plan

    result = run_plan(built, reference_sets=_sets_from(inputs))
    model = PhysicalModel.load(work_dir() / "physical-model.json")
    write_report = write(registry, built, result, model, connection="target")
    manifest = build_manifest(
        built, write_report,
        connection="target", database=registry.database_for("target"),
        reference_sizes={t: r.size for t, r in inputs.reference_sets.items()},
    )
    manifest_path = save_manifest(manifest, work_dir() / "run-manifest.json")
    for record in write_report.tables:
        console.print(f"  {record.table}: {record.rows_written:,} rows")
    console.print(f"  total [green]{write_report.total_rows():,}[/green] rows")
    mark = step("generated", mark)

    console.rule("[bold]validate")
    validation = validate_run(
        registry, built, model, manifest,
        connection="target", reference_sets=_sets_from(inputs).keys,
    )
    validation_summary = validation.summary()
    for check in validation.failures():
        console.print(f"  [red]{check.name}[/red]: {check.detail}")
    console.print(
        f"  [green]{validation_summary['checks'] - validation_summary['failed']}"
        f"[/green] of {validation_summary['checks']} checks passed"
    )
    manifest["validation"] = validation_summary
    save_manifest(manifest, manifest_path)
    mark = step("validated", mark)

    if not keep:
        console.rule("[bold]cleanup")
        deleted = run_cleanup(registry, manifest, connection="target")
        console.print(f"  removed {sum(deleted.values()):,} rows; the fixture is as it was")
        manifest_path.replace(manifest_path.with_suffix(".cleaned.json"))
        mark = step("cleaned up", mark)

    elapsed = time.perf_counter() - started
    console.rule("[bold]summary")
    table = Table(title="Proof-of-concept success measures")
    table.add_column("measure", overflow="fold")
    table.add_column("target")
    table.add_column("result")
    table.add_row(
        "auto-map rate at high confidence", "60% or more",
        f"[green]{stats['auto_map_rate']:.0%}[/green]",
    )
    table.add_row(
        "review queue size", "under 20 columns",
        f"[green]{len(queue)}[/green]",
    )
    claims_ratio = report.ratio_for("dbo.CMC_CLCL_CLAIM", "dbo.CMC_MEME_MEMBER")
    table.add_row(
        "claims per member, share with none", "within 2 points of 30%",
        f"[green]{claims_ratio.zero_share:.0%}[/green]" if claims_ratio else "-",
    )
    table.add_row(
        "claims per member, median among those with claims", "5",
        f"[green]{claims_ratio.median_nonzero:g}[/green]" if claims_ratio else "-",
    )
    table.add_row(
        "post-run validation", "passes",
        "[green]passed[/green]" if validation.passed
        else f"[red]{validation_summary['failed']} failed[/red]",
    )
    table.add_row("rows generated", "-", f"{write_report.total_rows():,}")
    table.add_row(
        "end to end", "under 10 minutes",
        f"[green]{elapsed:.0f}s[/green]" if elapsed < 600 else f"[red]{elapsed:.0f}s[/red]",
    )
    console.print(table)
    console.print("\n[bold]Timings[/bold]  " + "  ".join(f"{n} {s:.1f}s" for n, s in steps))
    console.print(f"\nReview page: {page}")

    if not validation.passed:
        raise typer.Exit(code=1)


@app.command()
def ui(
    port: int = typer.Option(8777, help="port to serve on"),
    host: str = typer.Option("127.0.0.1", help="address to bind"),
    open_browser: bool = typer.Option(True, "--open/--no-open", help="open a browser"),
    reload: bool = typer.Option(False, "--reload", help="restart when the code changes"),
) -> None:
    """Serve the web interface."""
    import uvicorn

    from sdg.api.app import UI_DIST

    if not UI_DIST.exists():
        console.print(
            f"[red]The interface has not been built.[/red]\n"
            f"Run [bold]npm install && npm run build[/bold] in {UI_DIST.parent}, "
            f"then try again."
        )
        raise typer.Exit(code=1)

    # Each session starts from fresh working files. The query and clustering
    # results held under sdg/analyzer/cache are rebuilt on first use and kept
    # for the rest of the session; carried across sessions they would describe
    # data that may have been reseeded or generated into since.
    from sdg.analyzer.services import disk_cache

    swept = disk_cache.clear()
    if swept.get("removed_files"):
        console.print(
            f"[dim]cleared {swept['removed_files']} working files "
            f"({swept['freed_bytes'] / 2**20:.0f} MB) from the last session[/dim]"
        )

    address = f"http://{host}:{port}"
    console.print(f"[bold]SDM[/bold] on [cyan]{address}[/cyan]")
    console.print(f"[dim]reading {get_settings().source_db}; the API is at {address}/api/docs[/dim]")

    if open_browser:
        import threading
        import webbrowser

        threading.Timer(1.0, lambda: webbrowser.open(address)).start()

    uvicorn.run(
        "sdg.api.app:app" if reload else _import_app(),
        host=host,
        port=port,
        reload=reload,
        log_level="warning",
    )


@app.command()
def patterns(
    file: Path = typer.Argument(None, help="analyzer output, as JSON"),
    catalog: Path = typer.Option(None, "--catalog", help="catalog YAML to match labels against"),
    as_of: str = typer.Option(
        None, "--as-of", help="reference date for ages, as YYYY-MM-DD"
    ),
    only: str = typer.Option(None, "--id", help="resolve just this pattern from the file"),
    apply_: bool = typer.Option(
        False, "--apply", help="write the resolved targets into review-decisions.json"
    ),
    clear: bool = typer.Option(
        False, "--clear", help="remove entries a pattern wrote, leaving hand-made ones"
    ),
) -> None:
    """Map an analyzer pattern onto the columns it governs.

    Where a pattern parameter maps to a column, the pattern supplies the value.
    Every other column keeps the rule the tool worked out. Nothing is written
    until `--apply`, and `sdg plan` is what picks the result up.
    """
    from sdg.catalog.loader import load_catalog
    from sdg.discovery.model import PhysicalModel
    from sdg.mapping.scorer import MappingStore
    from sdg.plan.model import Plan
    from sdg.plan.patterns import (
        PatternError,
        apply_to_decisions,
        clear_from_decisions,
        load_document,
        resolve_document,
    )
    from sdg.review.queue import load_decisions, save_decisions

    directory = work_dir()
    decisions_path = directory / "review-decisions.json"

    if clear:
        document, removed = clear_from_decisions(load_decisions(decisions_path))
        save_decisions(document, decisions_path)
        console.print(f"removed {removed} pattern entries from {decisions_path}")
        if not file:
            return

    if not file:
        raise typer.BadParameter("name the analyzer JSON to resolve, or pass --clear")

    for name, step in (("physical-model.json", "discover"), ("mappings.json", "map"),
                       ("plan.json", "plan")):
        if not (directory / name).exists():
            raise typer.BadParameter(f"missing {directory / name}. Run `sdg {step}` first.")

    model = PhysicalModel.load(directory / "physical-model.json")
    mappings = MappingStore.load(directory / "mappings.json")
    plan_ = Plan.load(directory / "plan.json")
    loaded = load_catalog(catalog) if catalog else load_catalog()

    try:
        found = load_document(file)
        if only:
            found.patterns = [p for p in found.patterns if p.id == only]
            if not found.patterns:
                raise PatternError(f"{file} holds no pattern called {only}")
        resolutions = resolve_document(
            found, catalog=loaded, mappings=mappings, plan=plan_, model=model, as_of=as_of
        )
    except PatternError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc

    loose = 0
    for resolution in resolutions:
        heading = f"{resolution.pattern} - {resolution.label or resolution.kind}"
        support = (
            f"  [dim]support {resolution.support:.1%}[/dim]"
            if resolution.support is not None else ""
        )
        console.print(f"\n[bold]{heading}[/bold]{support}")
        console.print(
            f"[dim]subject {resolution.subject}; "
            f"{resolution.bound()} of "
            f"{resolution.bound() + len(resolution.rejections)} parameters bound[/dim]"
        )

        if resolution.targets:
            table = Table(title="Where the pattern supplies the value")
            table.add_column("column", overflow="fold")
            table.add_column("from")
            table.add_column("rule", overflow="fold")
            table.add_column("replaces")
            table.add_column("where")
            for target in resolution.targets:
                where = (
                    "the subject" if target.relation == "subject"
                    else f"{target.depth} below"
                )
                if target.apply == "at_least_one":
                    loose += 1
                    where += ", one row"
                table.add_row(
                    target.qualified,
                    target.parameter,
                    f"{target.generator} {json.dumps(target.params, default=str)[:60]}",
                    target.replaces.get("generator", "-"),
                    where,
                )
            console.print(table)

        for rejection in resolution.rejections:
            console.print(f"  [yellow]not bound[/yellow] {rejection.parameter}")
            console.print(f"    [dim]{rejection.reason}[/dim]")
            if rejection.candidates:
                console.print(f"    [dim]nearest: {', '.join(rejection.candidates)}[/dim]")

    path = write_artifact(
        "pattern-targets.json",
        [r.model_dump(mode="json") for r in resolutions],
    )
    console.print(f"\nwrote {path}")

    if loose:
        console.print(
            f"[yellow]{loose} target(s) the analyzer meant for one row only will be "
            f"applied to every row[/yellow] [dim]- a share of the population is not "
            f"something this mode can express yet[/dim]"
        )

    if not apply_:
        console.print("[dim]nothing written to the plan; pass --apply to do that[/dim]")
        return

    usable = [r for r in resolutions if r.is_usable()]
    if not usable:
        console.print("[red]nothing to apply: no parameter bound to a column[/red]")
        raise typer.Exit(code=1)

    document, written = apply_to_decisions(usable, load_decisions(decisions_path))
    save_decisions(document, decisions_path)
    console.print(f"wrote {len(written)} column overrides into {decisions_path}")
    console.print("[dim]run `sdg plan` to build with them, then `sdg generate`[/dim]")


def _import_app():
    from sdg.api.app import app as api_app

    return api_app


def _sets_from(inputs):
    """Reference sets in the shape the engine wants."""
    from sdg.engine.execute import ReferenceSets

    sets = ReferenceSets()
    for name, reference in inputs.reference_sets.items():
        if not name.startswith("element:"):
            sets.add(name, reference.keys, reference.attributes)
    return sets


if __name__ == "__main__":
    app()

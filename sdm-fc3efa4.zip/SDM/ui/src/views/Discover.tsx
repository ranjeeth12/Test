/**
 * Discover, and the patterns kept from it.
 *
 * The Patterns screen asks you to choose a scope first. This one does not: it
 * walks the hierarchy itself and ranks what it finds by how much of the book
 * each cohort covers. That is the difference worth preserving between the two
 * — one answers "what is in this group", the other "what is in this book at
 * all", and only the second can surface something nobody thought to look for.
 *
 * The first walk is slow and the result is cached, so the wait is stated
 * rather than hidden behind a spinner that implies it will be quick.
 */

import { useCallback, useEffect, useState } from "react";
import {
  Banner,
  Button,
  Chip,
  Empty,
  Share,
  formatCount,
} from "../components/primitives";
import {
  ApiError,
  api,
  type DiscoveredRow,
  type DiscoveryPayload,
  type Domain,
  type SavedPattern,
} from "../lib/api";
import "./Discover.css";

interface Props {
  domain: Domain;
}

export function Discover({ domain }: Props) {
  const [depth, setDepth] = useState(1);
  const [found, setFound] = useState<DiscoveryPayload | null>(null);
  const [saved, setSaved] = useState<SavedPattern[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  // Kept patterns chosen for export, and the file type.
  const [chosen, setChosen] = useState<Set<number>>(new Set());
  const [format, setFormat] = useState<"xlsx" | "csv">("xlsx");

  // Kept patterns, counted on one sheet: every field and value, every scenario.
  const exportKept = async (ids: number[]) => {
    setBusy("export");
    setError(null);
    try {
      await api.patternReportSheet(
        { domain, filters: {}, k: null, pattern_ids: ids, format },
        `saved-patterns.${format}`,
      );
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  };
  const pick = (id: number) =>
    setChosen((previous) => {
      const next = new Set(previous);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const loadSaved = useCallback(async () => {
    try {
      setSaved((await api.saved()).patterns);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    }
  }, []);

  useEffect(() => {
    void loadSaved();
  }, [loadSaved]);

  useEffect(() => {
    setFound(null);
  }, [domain]);

  const walk = useCallback(async () => {
    setBusy("walk");
    setError(null);
    try {
      setFound(await api.discovery(domain, depth));
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
      setFound(null);
    } finally {
      setBusy(null);
    }
  }, [domain, depth]);

  const keep = useCallback(
    async (row: DiscoveredRow) => {
      setBusy(`keep-${row.pattern_id}`);
      setError(null);
      try {
        // The walk stored every pattern it found; keeping one marks that row
        // saved. Saving through the member analyzer instead turned a kept
        // claims pattern into a member pattern of the same scope.
        if (row.pattern_id != null) {
          await api.bookmark(row.pattern_id);
        } else if (domain === "members") {
          await api.savePattern(row.combo, null, row.cluster_id);
        } else {
          throw new Error(
            "This claims pattern was not stored by the walk, so it cannot be kept. Walk the book again.",
          );
        }
        await loadSaved();
      } catch (e) {
        setError(e instanceof ApiError ? e.message : String(e));
      } finally {
        setBusy(null);
      }
    },
    [loadSaved, domain],
  );

  const drop = useCallback(
    async (patternId: number) => {
      setBusy(`drop-${patternId}`);
      try {
        await api.unsave(patternId);
        await loadSaved();
      } catch (e) {
        setError(e instanceof ApiError ? e.message : String(e));
      } finally {
        setBusy(null);
      }
    },
    [loadSaved],
  );

  // By id first: a claims pattern is stored as "[Claims] <name>", so its name
  // never matched the row's. The name still catches a member pattern saved
  // through the analyzer before the walk stored it.
  const keptIds = new Set(saved.map((s) => s.pattern_id));
  const keptNames = new Set(saved.map((s) => s.name));

  return (
    <div className="discover">
      <header className="discover__head">
        <div>
          <h2>
            {domain === "claims" ? "Claim cohorts by size" : "Cohorts by size"}
          </h2>
          <p className="discover__lede">
            Every combination of group, product category, plan and product, clustered
            and ranked by its share of the population.
          </p>
        </div>
      </header>

      <section className="discover__controls">
        <label>
          <span>Depth</span>
          <select value={depth} onChange={(e) => setDepth(Number(e.target.value))}>
            <option value={1}>Groups</option>
            <option value={2}>Groups and categories</option>
            <option value={3}>Down to plans</option>
            <option value={4}>Down to products</option>
          </select>
        </label>

        <Button variant="primary" onClick={walk} busy={busy === "walk"}>
          Walk the book
        </Button>
        <p className="discover__warning">
          The first walk at a given depth takes a while and is cached after.
          Deeper means more combinations, not more detail per pattern.
        </p>
      </section>

      {error && <Banner tone="alarm">{error}</Banner>}

      {found && (
        <>
          <p className="discover__summary">
            <strong className="num">{found.n_discovered}</strong> cohorts across{" "}
            <strong className="num">{found.combinations_processed}</strong>{" "}
            combinations, out of{" "}
            <strong className="num">{formatCount(found.total_population)}</strong>{" "}
            {domain}.
          </p>

          <table className="discover__table">
            <thead>
              <tr>
                <th>Pattern</th>
                <th>Where</th>
                <th className="right">Size</th>
                <th>Share of book</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {found.patterns.map((row) => {
                const kept = keptIds.has(row.pattern_id) || keptNames.has(row.name);
                return (
                  <tr key={`${row.pattern_id}-${row.cluster_id}-${row.name}`}>
                    <td className="discover__name">{row.name}</td>
                    <td className="discover__where">
                      {[row.group, row.plan_category, row.plan, row.product]
                        .filter((part) => part && part !== "All")
                        .join(" › ") || "Whole book"}
                    </td>
                    <td className="right num">{formatCount(row.size)}</td>
                    <td>
                      <Share value={row.pct_of_population} />
                    </td>
                    <td className="right">
                      {kept ? (
                        <Chip tone="affirm">kept</Chip>
                      ) : (
                        <Button
                          onClick={() => keep(row)}
                          busy={busy === `keep-${row.pattern_id}`}
                        >
                          Keep
                        </Button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </>
      )}

      {!found && !busy && (
        <Empty title="The book has not been walked yet">
          Walking it finds the cohorts nobody thought to look for.
        </Empty>
      )}

      <section className="discover__kept">
        <div className="kept__head">
          <h3>Kept patterns</h3>
          {saved.length > 0 && (
            <div className="kept__export">
              <select
                aria-label="Export kept patterns as"
                value={format}
                onChange={(e) => setFormat(e.target.value as "xlsx" | "csv")}
              >
                <option value="xlsx">Excel (one tab)</option>
                <option value="csv">CSV</option>
              </select>
              <Button
                onClick={() => void exportKept([...chosen])}
                busy={busy === "export"}
                disabled={chosen.size === 0}
              >
                Export {chosen.size || ""} chosen
              </Button>
              <Button
                onClick={() => void exportKept(saved.map((s) => s.pattern_id))}
                busy={busy === "export"}
              >
                Export all
              </Button>
            </div>
          )}
        </div>
        {saved.length === 0 ? (
          <p className="discover__none">
            Nothing kept yet. A kept pattern is what Story to Data matches
            against, so this list is the vocabulary a requirement can be written
            in.
          </p>
        ) : (
          <ul className="kept">
            {saved.map((row) => (
              <li key={row.pattern_id} className="kept__row">
                <input
                  type="checkbox"
                  aria-label={`Choose ${row.name} for export`}
                  checked={chosen.has(row.pattern_id)}
                  onChange={() => pick(row.pattern_id)}
                />
                <span className="kept__name">{row.name}</span>
                <Chip tone={row.entity === "claims" ? "catalog" : "learned"} fill="outline">
                  {row.entity}
                </Chip>
                {row.origin === "user_defined" && (
                  <Chip tone="user" fill="outline">defined</Chip>
                )}
                <span className="kept__where">
                  {[row.group, row.plan_category].filter((p) => p && p !== "All").join(" › ")}
                </span>
                <span className="kept__size num">{formatCount(row.member_count)}</span>
                <Button
                  onClick={() => drop(row.pattern_id)}
                  busy={busy === `drop-${row.pattern_id}`}
                >
                  Remove
                </Button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

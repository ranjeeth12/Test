/**
 * Algorithms: each business element, and the generation rule that makes it.
 *
 * One framework makes every value (sdg/engine/rules.py): a business element's
 * rule names an algorithm and its settings, and files, EDI and database loads
 * all run it. This is where those are read and changed, outside the workflow.
 */

import { Rules } from "./Rules";

export function Algorithms() {
  return (
    <div className="algorithms">
      <p className="panel__hint">
        Each business element and the algorithm that generates it. A column or
        layout field given a business element is made by that element&rsquo;s
        algorithm, wherever it is written. Edit one to change it everywhere; Try
        it shows the values it makes.
      </p>
      <Rules />
    </div>
  );
}

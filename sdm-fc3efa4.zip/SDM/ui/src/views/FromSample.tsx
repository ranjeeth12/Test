/**
 * A file from a sample: the file is the sample, except the places a config names.
 *
 * The format (X12, FHIR, HL7 v2, CDA) is read off the sample; nothing here depends on it
 * beyond the facts the server sends back (kind, summary, subject, validation).
 *
 * Two parts, top to bottom, the way a person goes through it:
 *
 * 1. Read a sample against a master config -- the masking tool's config, or a
 *    generation config saved here. Every position of the sample is listed with
 *    the algorithm the master proposes for it; the person accepts or changes
 *    each and saves the result under a new name. The master is never changed.
 * 2. Pick a saved config and write the file: an 834 is new members, an 837 is
 *    claims for the members of the pattern chosen above.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Banner, Button, Chip } from "../components/primitives";
import {
  ApiError,
  api,
  type FilePattern,
  type GenConfigSummary,
  type SamplePosition,
  type SampleReading,
  type SnipReport,
} from "../lib/api";
import { SnipResult } from "./EdiFormats";
import "./EdiFormats.css";

const PREVIEW_LINES = 40;
const COPY = "";
// What a format's checks are called on the button.
const CHECKS: Record<string, string> = { snip: "SNIP", fhir: "FHIR", cda: "CDA", hl7v2: "HL7" };

interface Props {
  extra: Record<string, unknown>;
  pattern: FilePattern | null;
}

function message(e: unknown): string {
  return e instanceof ApiError ? e.message : String(e);
}

export function FromSample({ extra, pattern }: Props) {
  const [configs, setConfigs] = useState<GenConfigSummary[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  // 1. Modeling a config on a sample.
  const [sample, setSample] = useState<{ name: string; text: string } | null>(null);
  const [master, setMaster] = useState<{ name: string; text: string } | null>(null);
  const [startFrom, setStartFrom] = useState<string>("file"); // file | none | <config id>
  const [reading, setReading] = useState<SampleReading | null>(null);
  const [rows, setRows] = useState<SamplePosition[]>([]);
  const [everything, setEverything] = useState(false);
  const [name, setName] = useState("");
  const [saved, setSaved] = useState<string | null>(null);
  const sampleInput = useRef<HTMLInputElement>(null);
  const masterInput = useRef<HTMLInputElement>(null);

  // 2. Writing from a saved config.
  const [chosen, setChosen] = useState<number | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [report, setReport] = useState<SnipReport | null>(null);

  const loadConfigs = useCallback(async () => {
    try {
      const payload = await api.sampleConfigs();
      setConfigs(payload.configs);
      return payload.configs;
    } catch (e) {
      setError(message(e));
      return [];
    }
  }, []);

  useEffect(() => {
    void loadConfigs();
  }, [loadConfigs]);

  const readFile = (file: File, set: (v: { name: string; text: string }) => void) => {
    file.text().then((text) => set({ name: file.name, text }));
  };

  const read = useCallback(async () => {
    setBusy("read");
    setError(null);
    setSaved(null);
    try {
      const fromSaved = startFrom !== "file" && startFrom !== "none";
      const result = await api.sampleRead({
        sample: sample?.text ?? null,
        sampleName: sample?.name ?? null,
        master: startFrom === "file" ? (master?.text ?? null) : null,
        masterName: startFrom === "file" ? (master?.name ?? null) : null,
        configId: fromSaved ? Number(startFrom) : null,
      });
      setReading(result);
      setRows(result.rows);
      const base = (result.sampleName ?? "sample").replace(/\.[^.]+$/, "");
      setName(`${result.kind} ${base}`);
    } catch (e) {
      setError(message(e));
      setReading(null);
    } finally {
      setBusy(null);
    }
  }, [sample, master, startFrom]);

  const choose = (index: number, algorithm: string) =>
    setRows((current) =>
      current.map((r, i) => (i === index ? { ...r, algorithm: algorithm || null } : r)),
    );

  const acceptSuggestions = () =>
    setRows((current) => current.map((r) => ({ ...r, algorithm: r.algorithm ?? r.suggested })));

  const save = useCallback(async () => {
    if (!reading) return;
    setBusy("save");
    setError(null);
    try {
      // The sample travels with the config: read from a saved config, it is
      // that config's sample unless another was chosen.
      const fromSaved = startFrom !== "file" && startFrom !== "none";
      const result = await api.sampleConfigSave({
        name,
        sample: sample?.text ?? null,
        sampleName: reading.sampleName,
        basedOn: reading.basedOn,
        rows,
        fromConfigId: fromSaved && !sample ? Number(startFrom) : null,
      });
      setSaved(result.name);
      await loadConfigs();
      setChosen(result.id);
      setPreview(null);
      setReport(null);
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(null);
    }
  }, [reading, sample, startFrom, name, rows, loadConfigs]);

  const config = configs.find((c) => c.id === chosen) ?? null;
  const format = config ? `sample:${config.id}` : "";
  const subject = config?.subject ?? "claims";

  const showFirst = useCallback(async () => {
    if (!config) return;
    setBusy("preview");
    setError(null);
    try {
      setPreview(await api.exportText(format, subject, 6, extra));
    } catch (e) {
      setError(message(e));
      setPreview(null);
    } finally {
      setBusy(null);
    }
  }, [config, format, subject, extra]);

  const write = useCallback(async () => {
    if (!config) return;
    setBusy("write");
    setError(null);
    try {
      await api.exportDownload(format, subject, `${config.kind}-${config.name}${config.extension}`, extra);
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(null);
    }
  }, [config, format, subject, extra]);

  const check = useCallback(async () => {
    if (!config) return;
    setBusy("check");
    setError(null);
    try {
      const exportRequest = { format, subject, rows: 200, ...extra };
      setReport(
        config.validation === "snip"
          ? await api.snipCheck(exportRequest, null)
          : await api.sampleCheck(exportRequest),
      );
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(null);
    }
  }, [config, format, subject, extra]);

  const remove = useCallback(async () => {
    if (!config) return;
    setBusy("remove");
    setError(null);
    try {
      await api.sampleConfigDelete(config.id);
      setChosen(null);
      setPreview(null);
      setReport(null);
      await loadConfigs();
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(null);
    }
  }, [config, loadConfigs]);

  const shown = useMemo(
    () =>
      rows
        .map((row, index) => ({ row, index }))
        .filter(({ row }) => everything || row.algorithm || row.config_name || row.suggested),
    [rows, everything],
  );
  const generated = rows.filter((r) => r.algorithm).length;
  const unanswered = rows.filter((r) => r.config_name && !r.algorithm).length;
  const suggestions = rows.filter((r) => !r.algorithm && r.suggested).length;
  const savedFrom = startFrom !== "file" && startFrom !== "none";
  const canRead = Boolean(sample || savedFrom);

  return (
    <section className="panel edi edi-sample">
      {error && <Banner tone="alarm">{error}</Banner>}

      <div className="edi-sample__step">
        <h3>1. Model a config on a sample</h3>
        <p className="panel__hint">
          The file written is the sample — its structure, codes, order and every value — except the
          places given an algorithm here. An X12 834 or 837, a FHIR R4 Bundle or resource and an HL7 v2
          ADT or DFT message are read
          the same way. The config you start from is never changed: what you
          choose is saved as a new config.
        </p>
        <div className="edi__pick">
          <label className="named">
            <span>Sample file</span>
            <Button onClick={() => sampleInput.current?.click()}>
              {sample ? sample.name : "Choose a sample…"}
            </Button>
            <input
              ref={sampleInput}
              type="file"
              hidden
              aria-label="Sample file"
              onChange={(e) => e.target.files?.[0] && readFile(e.target.files[0], setSample)}
            />
          </label>
          <label className="named">
            <span>Start from</span>
            <select value={startFrom} onChange={(e) => setStartFrom(e.target.value)}>
              <option value="file">a config file (masking or generation)</option>
              {configs.map((c) => (
                <option key={c.id} value={String(c.id)}>
                  saved: {c.name}
                </option>
              ))}
              <option value="none">no config (suggestions only)</option>
            </select>
          </label>
          {startFrom === "file" && (
            <label className="named">
              <span>Config file</span>
              <Button onClick={() => masterInput.current?.click()}>
                {master ? master.name : "Choose a config…"}
              </Button>
              <input
                ref={masterInput}
                type="file"
                hidden
                aria-label="Config file"
                accept=".json"
                onChange={(e) => e.target.files?.[0] && readFile(e.target.files[0], setMaster)}
              />
            </label>
          )}
          <Button variant="primary" onClick={read} busy={busy === "read"} disabled={!canRead}>
            Read the sample
          </Button>
        </div>

        {reading && (
          <>
            <div className="edi__facts">
              <Chip tone="catalog">
                {reading.kind} {reading.version}
              </Chip>
              <Chip tone="learned">{reading.summary}</Chip>
              {reading.basedOn && <Chip tone="user">from {reading.basedOn}</Chip>}
              <Chip tone={unanswered ? "caution" : "affirm"}>
                {generated} generated
                {unanswered ? ` · ${unanswered} need an algorithm` : ""}
              </Chip>
            </div>

            <div className="edi-sample__tools">
              <label className="check">
                <input
                  type="checkbox"
                  checked={everything}
                  onChange={(e) => setEverything(e.target.checked)}
                />{" "}
                Show every position of the sample
              </label>
              {suggestions > 0 && (
                <Button onClick={acceptSuggestions}>Accept {suggestions} suggestions</Button>
              )}
            </div>

            <table className="edi-sample__table">
              <thead>
                <tr>
                  <th>Place</th>
                  <th>Sample value</th>
                  <th>Config says</th>
                  <th>Algorithm</th>
                </tr>
              </thead>
              <tbody>
                {shown.map(({ row, index }) => (
                  <tr key={index} className={row.algorithm ? "edi-sample__row--on" : ""}>
                    <td className="mono">{row.label}</td>
                    <td className="mono edi-sample__value">{row.example}</td>
                    <td className="mono">{row.config_name ?? ""}</td>
                    <td>
                      <select
                        aria-label={`Algorithm for ${row.label}`}
                        value={row.algorithm ?? COPY}
                        onChange={(e) => choose(index, e.target.value)}
                      >
                        <option value={COPY}>copy from the sample</option>
                        {row.suggested && (
                          <option value={row.suggested}>{row.suggested} (suggested)</option>
                        )}
                        {reading.algorithms
                          .filter((a) => a !== row.suggested)
                          .map((a) => (
                            <option key={a} value={a}>
                              {a}
                            </option>
                          ))}
                      </select>
                      <div className="edi-sample__why">{row.reason}</div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="panel__actions">
              <label className="named">
                <span>New config name</span>
                <input value={name} onChange={(e) => setName(e.target.value)} />
              </label>
              <Button
                variant="primary"
                onClick={save}
                busy={busy === "save"}
                disabled={!name.trim() || generated === 0}
              >
                Save config as
              </Button>
              {saved && <Chip tone="affirm">saved as {saved}</Chip>}
            </div>
          </>
        )}
      </div>

      <div className="edi-sample__step">
        <h3>2. Write from a saved config</h3>
        {configs.length === 0 ? (
          <p className="panel__hint">No generation config saved yet: model one above.</p>
        ) : (
          <>
            <div className="edi__pick">
              <label className="named">
                <span>Generation config</span>
                <select
                  aria-label="Generation config"
                  value={chosen ?? ""}
                  onChange={(e) => {
                    setChosen(e.target.value ? Number(e.target.value) : null);
                    setPreview(null);
                    setReport(null);
                  }}
                >
                  <option value="">choose…</option>
                  {configs.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </label>
              {config && (
                <div className="edi__facts">
                  <Chip tone="catalog">
                    {config.kind} {config.version}
                  </Chip>
                  <Chip tone="learned">{config.positions} generated positions</Chip>
                  {config.based_on && <Chip tone="user">from {config.based_on}</Chip>}
                  {config.sample_name && <Chip tone="physical">sample {config.sample_name}</Chip>}
                </div>
              )}
            </div>
            {config && (
              <div className="panel__actions">
                <Button onClick={showFirst} busy={busy === "preview"}>
                  Show the start of the file
                </Button>
                <Button variant="primary" onClick={write} busy={busy === "write"}>
                  Write the file
                </Button>
                {config.validation && (
                  <Button onClick={check} busy={busy === "check"}>
                    Run {CHECKS[config.validation] ?? config.validation} checks
                  </Button>
                )}
                <Button variant="danger" onClick={remove} busy={busy === "remove"}>
                  Remove config
                </Button>
                <p className="panel__hint">
                  {config.subject === "members"
                    ? pattern
                      ? `New members carrying the values of "${pattern.name}", each a copy of one of the sample's members, in turn.`
                      : "New members from the plan's run, each a copy of one of the sample's members, in turn."
                    : pattern
                      ? `Claims for the members "${pattern.name}" holds, shaped as the sample's members, claims and lines, in turn.`
                      : "Claims from the plan's run, shaped as the sample's members, claims and lines, in turn."}{" "}
                  Everything not generated is the sample's.
                </p>
              </div>
            )}
          </>
        )}
        {report && <SnipResult report={report} />}
        {preview && (
          <pre className="edi__sample">
            {preview.split("\n").filter(Boolean).slice(0, PREVIEW_LINES).join("\n")}
          </pre>
        )}
      </div>
    </section>
  );
}

/**
 * Story to data.
 *
 * A requirement arrives as prose — a test case, a user story, a line in a
 * spreadsheet — and the question is which of the cohorts already found it is
 * asking for. The matching is done against *kept* patterns only, so this screen
 * says so plainly when nothing has been kept: an empty vocabulary matching
 * nothing looks identical to a story nobody understood, and the two want very
 * different responses.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { Banner, Button, Chip, Empty, formatPercent } from "../components/primitives";
import {
  ApiError,
  api,
  type FilePattern,
  type PatternCondition,
  type PatternFeature,
  type StoryMatchPayload,
  type StoryReading,
  type StoryToPlanPayload,
} from "../lib/api";
import { rulesToFilters } from "./DefinePattern";
import { PatternsAnalyze } from "./Patterns";
import "./Story.css";

interface StoryProps {
  onApplied: (destination: "file" | "db", pattern?: FilePattern, note?: string) => void;
}

export function Story({ onApplied }: StoryProps) {
  // The requirement being analyzed: read into rules, then measured and looked inside.
  const [analyzing, setAnalyzing] = useState<string | null>(null);
  const [written, setWritten] = useState("");
  const [stories, setStories] = useState<string[]>([]);
  const [matches, setMatches] = useState<StoryMatchPayload | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [chosen, setChosen] = useState<Set<number>>(new Set());
  const [volume, setVolume] = useState(1000);
  const [planned, setPlanned] = useState<StoryToPlanPayload | null>(null);
  const input = useRef<HTMLInputElement>(null);

  const upload = useCallback(async (file: File) => {
    setBusy("parse");
    setError(null);
    setNotice(null);
    setMatches(null);
    try {
      const payload = await api.storyParse(file);
      setStories(payload.stories);
      setFileName(file.name);
      if (payload.warning) setNotice(payload.warning);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
      setStories([]);
    } finally {
      setBusy(null);
    }
  }, []);

  const match = useCallback(async () => {
    setBusy("match");
    setError(null);
    try {
      const payload = await api.storyMatch(stories);
      setMatches(payload);
      setChosen(new Set());
      setPlanned(null);
      if (payload.warning) setNotice(payload.warning);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }, [stories]);

  const toPlan = useCallback(
    async (apply: boolean) => {
      setBusy("plan");
      setError(null);
      try {
        setPlanned(await api.storyToPlan([...chosen], volume, apply));
        if (apply) setNotice("Written as cohorts. Under DB Generation the plan is rebuilt with them; look at the sample rows, then write.");
      } catch (e) {
        setError(e instanceof ApiError ? e.message : String(e));
      } finally {
        setBusy(null);
      }
    },
    [chosen, volume],
  );

  const toggle = useCallback((patternId: number) => {
    setChosen((previous) => {
      const next = new Set(previous);
      next.has(patternId) ? next.delete(patternId) : next.add(patternId);
      return next;
    });
    setPlanned(null);
  }, []);

  return (
    <div className="story">
      <header className="story__head">
        <h2>Requirement matching</h2>
        <p className="story__lede">
          Write a requirement, or upload test cases or user stories (text, CSV,
          spreadsheet, JSON or Word). Find Patterns shows the patterns the requirement
          describes. Match compares a file of them against the saved patterns.
        </p>
      </header>

      <section className="story__write">
        <label className="named story__written">
          <span>Requirement</span>
          <textarea
            rows={2}
            value={written}
            onChange={(e) => setWritten(e.target.value)}
            placeholder="e.g. 500 professional claims for female members aged 40 to 60 with type 2 diabetes on a PPO plan"
          />
        </label>
        <Button
          variant="primary"
          onClick={() => setAnalyzing(written.trim())}
          disabled={!written.trim()}
        >
          Find Patterns
        </Button>
      </section>

      {analyzing && (
        <StoryAnalysis
          key={analyzing}
          story={analyzing}
          onApplied={onApplied}
          onClose={() => setAnalyzing(null)}
        />
      )}

      <section className="story__upload">
        <input
          ref={input}
          type="file"
          accept=".txt,.csv,.xlsx,.json,.docx"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void upload(file);
          }}
          hidden
        />
        <Button variant="primary" onClick={() => input.current?.click()} busy={busy === "parse"}>
          Choose a file
        </Button>
        {fileName && (
          <span className="story__file">
            {fileName} — <strong className="num">{stories.length}</strong> stories read
          </span>
        )}
        {stories.length > 0 && (
          <Button onClick={match} busy={busy === "match"}>
            Match against kept patterns
          </Button>
        )}
      </section>

      {error && <Banner tone="alarm">{error}</Banner>}
      {notice && <Banner tone="caution">{notice}</Banner>}

      {!fileName && !busy && (
        <Empty title="No requirements uploaded">
          A file of test cases or stories, and this will say which cohort each
          one is describing.
        </Empty>
      )}

      {stories.length > 0 && !matches && (
        <ul className="story__list">
          {stories.slice(0, 20).map((story, index) => (
            <li key={index} className="story__row">
              <span className="story__index num">{index + 1}</span>
              <span className="story__text">{story}</span>
              <Button onClick={() => setAnalyzing(story)}>Find Patterns</Button>
            </li>
          ))}
          {stories.length > 20 && (
            <li className="story__more">
              and {stories.length - 20} more, all of which will be matched
            </li>
          )}
        </ul>
      )}

      {matches && (
        <div className="story__matches">
          {matches.stories.map((entry) => (
            <article key={entry.index} className="match">
              <p className="match__story">
                {entry.story}{" "}
                <Button onClick={() => setAnalyzing(entry.story)}>Find Patterns</Button>
              </p>
              {entry.candidates.length === 0 ? (
                <p className="match__none">
                  Nothing kept resembles this. Either the cohort has not been
                  found yet, or the requirement is about something the data does
                  not carry.
                  {entry.keywords.length > 0 && (
                    <> Matched on: {entry.keywords.join(", ")}.</>
                  )}
                </p>
              ) : (
                <ul className="match__candidates">
                  {entry.candidates.map((candidate) => (
                    <li key={candidate.pattern_id}>
                      <label className="match__pick">
                        <input
                          type="checkbox"
                          checked={chosen.has(candidate.pattern_id)}
                          onChange={() => toggle(candidate.pattern_id)}
                        />
                        <span className="match__name">{candidate.name}</span>
                      </label>
                      <Chip
                        tone={candidate.match_score >= 0.6 ? "learned" : "caution"}
                        fill={candidate.match_score >= 0.6 ? "solid" : "outline"}
                      >
                        {formatPercent(candidate.match_score)} match
                      </Chip>
                      {candidate.group && (
                        <span className="match__why">{candidate.group}</span>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </article>
          ))}
        </div>
      )}

      {matches && (
        <section className="story__plan">
          <h3>Turn this into data</h3>
          <p className="panel__hint">
            The patterns you tick become cohorts on the plan, each taking its
            share of the volume. Nothing is generated here: the plan engine
            does that, which is what gives the result a manifest, the checks,
            and a cleanup.
          </p>
          <div className="story__controls">
            <label className="named">
              <span>Rows wanted</span>
              <input
                type="number"
                min={1}
                value={volume}
                onChange={(e) => setVolume(Math.max(1, Number(e.target.value) || 1))}
              />
            </label>
            <Button
              onClick={() => toPlan(false)}
              busy={busy === "plan"}
              disabled={chosen.size === 0}
            >
              Split {volume.toLocaleString()} across {chosen.size || "no"}{" "}
              {chosen.size === 1 ? "pattern" : "patterns"}
            </Button>
            {planned && (
              <Button
                variant="primary"
                onClick={() => toPlan(true)}
                busy={busy === "plan"}
                disabled={!planned.patterns.some((p) => p.targets.length)}
              >
                Write them to the plan
              </Button>
            )}
          </div>

          {planned && (
            <table className="story__allocation">
              <thead>
                <tr>
                  <th>Pattern</th>
                  <th className="right">Rows</th>
                  <th className="right">Share</th>
                  <th className="right">Columns</th>
                </tr>
              </thead>
              <tbody>
                {planned.patterns.map((entry) => (
                  <tr key={entry.pattern_id}>
                    <td>{entry.pattern}</td>
                    <td className="right num">{entry.rows.toLocaleString()}</td>
                    <td className="right num">
                      {entry.share !== null ? formatPercent(entry.share) : "—"}
                    </td>
                    <td className="right num">{entry.targets.length}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      )}
    </div>
  );
}

/**
 * One requirement, analyzed: read into the rules it states, and the patterns
 * inside them found straight away. What was read is shown with the words it
 * came from, because a reading can be wrong.
 */
function StoryAnalysis({
  story, onApplied, onClose,
}: {
  story: string;
  onApplied: StoryProps["onApplied"];
  onClose: () => void;
}) {
  const [reading, setReading] = useState<StoryReading | null>(null);
  const [features, setFeatures] = useState<PatternFeature[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    api
      .storyRead(story)
      .then(async (read) => {
        const catalog = await api.patternFeatures(read.entity);
        if (!live) return;
        setReading(read);
        setFeatures(catalog.features);
      })
      .catch((e) => live && setError(e instanceof ApiError ? e.message : String(e)));
    return () => {
      live = false;
    };
  }, [story]);

  if (error) return <Banner tone="alarm">{error}</Banner>;
  if (!reading) return <p className="panel__hint">Analyzing…</p>;

  const valueLabel = (key: string, value: string) =>
    features.find((f) => f.key === key)?.options?.find((o) => o.value === value)?.label ?? value;
  const describe = (key: string, rule: PatternCondition) =>
    rule.in
      ? rule.in.map((v) => valueLabel(key, v)).join(", ")
      : rule.min !== undefined && rule.max !== undefined
        ? `${rule.min} to ${rule.max}`
        : rule.min !== undefined
          ? `${rule.min} or more`
          : `up to ${rule.max}`;
  const filters = rulesToFilters(features, reading.rules);
  const name = story.length > 80 ? `${story.slice(0, 77)}...` : story;
  const population = reading.entity === "claims" ? "claims" : "members";

  return (
    <section className="story__analysis" aria-label="Requirement analysis">
      <header className="story__analysis-head">
        <div>
          <h3>Patterns for this requirement</h3>
          <p className="panel__hint">{story}</p>
        </div>
        <Button onClick={onClose}>Close</Button>
      </header>
      {reading.found.length === 0 ? (
        <p className="panel__hint">
          No rules were read from it, so these are the patterns across all {population}.
        </p>
      ) : (
        <ul className="story__rules">
          {reading.found.map((found) => (
            <li key={found.feature}>
              <strong>{found.label}</strong>
              <span>{describe(found.feature, found.rule)}</span>
              <Chip fill="outline" title="The words this was read from">
                {`"${found.from}"`}
              </Chip>
            </li>
          ))}
        </ul>
      )}
      <PatternsAnalyze
        domain={reading.entity}
        onApplied={onApplied}
        defined={{ name, filters }}
        autoRun
      />
    </section>
  );
}

/**
 * The rows a pattern was derived from.
 *
 * Everything else about a pattern is a summary: a mean age, a share of the
 * book, a band. This is the thing those summaries are about, and being able to
 * look at it is what makes the claim checkable rather than asserted. It is the
 * same argument as the evidence on a mapping — the number is only worth
 * something if you can get to what produced it.
 *
 * These are real source rows, not generated ones. On this fixture they are
 * synthetic, but the tool is pointed at production-shaped databases and the
 * server sends names, dates of birth and SSNs exactly as they are stored. So
 * the columns the server marks as PHI are covered by default and opening them
 * is a deliberate act. Masking lives on the Output screen for data on its
 * way out; this is the same concern at the other end, where data is on its way
 * onto a screen.
 *
 * Paged from the server, because rebuilding a pattern's subset means loading
 * and clustering again. Twenty-five rows of a few thousand is the point.
 *
 * Records can be chosen here, across pages, and a file generated from just
 * those: they are saved as a pattern of their own -- their values, their
 * members -- and File Generation opens with it chosen.
 */

import { useCallback, useEffect, useState } from "react";
import { Banner, Button, Chip, formatCount } from "../components/primitives";
import {
  ApiError,
  api,
  type Domain,
  type KeptPattern,
  type PatternFilters,
  type PatternRowsPayload,
} from "../lib/api";
import "./PatternRows.css";
import { columnName } from "../lib/names";

const PAGE = 25;

interface Props {
  domain: Domain;
  filters: PatternFilters;
  k: number | null;
  clusterId: number;
  claimType: string | null;
  // Chosen records were saved as a pattern, for a file or for the database.
  onKept?: (kept: KeptPattern, destination: "file" | "db") => void | Promise<void>;
}

export function PatternRows({ domain, filters, k, clusterId, claimType, onKept }: Props) {
  const [page, setPage] = useState<PatternRowsPayload | null>(null);
  const [offset, setOffset] = useState(0);
  const [showPhi, setShowPhi] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Row names, kept across pages, so a choice survives paging.
  const [chosen, setChosen] = useState<Set<string>>(new Set());
  const [keeping, setKeeping] = useState<"file" | "db" | null>(null);

  const toggle = (key: string) =>
    setChosen((previous) => {
      const next = new Set(previous);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });

  const generate = async (destination: "file" | "db") => {
    setKeeping(destination);
    setError(null);
    try {
      const kept = await api.keepPattern({
        domain, filters, k, cluster_id: clusterId, claim_type: claimType,
        record_keys: [...chosen],
      });
      await onKept?.(kept, destination);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setKeeping(null);
    }
  };

  const load = useCallback(
    async (at: number) => {
      setBusy(true);
      setError(null);
      try {
        setPage(
          await api.patternRows(domain, filters, k, clusterId, claimType, PAGE, at),
        );
        setOffset(at);
      } catch (e) {
        // 409 means the pattern is still a valid record but what it points at
        // has moved. That is worth saying plainly rather than as a status code.
        setError(
          e instanceof ApiError && e.status === 409
            ? "The data underneath this pattern has changed since it was found. Analyze again to see the rows it describes now."
            : e instanceof ApiError
              ? e.message
              : String(e),
        );
        setPage(null);
      } finally {
        setBusy(false);
      }
    },
    [domain, filters, k, clusterId, claimType],
  );

  useEffect(() => {
    void load(0);
  }, [load]);

  if (error) return <Banner tone="alarm">{error}</Banner>;
  if (!page) return <p className="rows__loading">Rebuilding the subset…</p>;

  const phi = new Set(page.phi_columns);
  const last = Math.min(offset + page.returned, page.total);
  const keys = page.keys ?? [];
  const pageChosen = keys.length > 0 && keys.every((key) => chosen.has(key));
  const togglePage = () =>
    setChosen((previous) => {
      const next = new Set(previous);
      for (const key of keys) {
        if (pageChosen) next.delete(key);
        else next.add(key);
      }
      return next;
    });
  const noun = domain === "claims" ? "claim line" : "member";

  return (
    <div className="rows">
      <div className="rows__head">
        <span className="rows__count">
          <span className="num">{formatCount(offset + 1)}</span>–
          <span className="num">{formatCount(last)}</span> of{" "}
          <span className="num">{formatCount(page.total)}</span>{" "}
          {domain === "claims" ? "claim lines" : "members"} this pattern describes
        </span>

        {page.phi_columns.length > 0 && (
          <label className="rows__phi-toggle">
            <input
              type="checkbox"
              checked={showPhi}
              onChange={(e) => setShowPhi(e.target.checked)}
            />
            <span>
              Show the {page.phi_columns.length} PHI columns
            </span>
          </label>
        )}

        <span className="rows__timing">rebuilt in {page.rebuild_ms} ms</span>
      </div>

      {page.phi_columns.length > 0 && !showPhi && (
        <p className="rows__phi-note">
          Names, dates of birth and identifiers are covered. These are the real
          rows from the source, not generated ones.
        </p>
      )}

      {onKept && (
        <div className="rows__choose">
          <span className="rows__chosen">
            {chosen.size === 0
              ? `Tick ${noun}s to generate from only those records.`
              : `${formatCount(chosen.size)} ${noun}${chosen.size === 1 ? "" : "s"} chosen`}
          </span>
          {chosen.size > 0 && (
            <>
              <Button
                variant="primary"
                onClick={() => generate("db")}
                busy={keeping === "db"}
                disabled={keeping !== null}
              >
                Generate into the database
              </Button>
              <Button
                onClick={() => generate("file")}
                busy={keeping === "file"}
                disabled={keeping !== null}
              >
                Generate a file
              </Button>
              <Button onClick={() => setChosen(new Set())} disabled={keeping !== null}>
                Clear
              </Button>
              <span className="rows__choose-note">
                Saved as a pattern of their own. Into the database: their values
                become the rules for every row of the run, and DB Generation
                opens with the plan rebuilt, ready to generate. As a file: a member file
                carries their values, a claim file is for their members.
              </span>
            </>
          )}
        </div>
      )}

      <div className="rows__scroll">
        <table className="rows__table">
          <thead>
            <tr>
              {onKept && (
                <th className="rows__pick">
                  <input
                    type="checkbox"
                    checked={pageChosen}
                    onChange={togglePage}
                    aria-label="Choose every record on this page"
                  />
                </th>
              )}
              {page.columns.map((column) => (
                <th key={column} className={phi.has(column) ? "rows__th--phi" : ""} title={column}>
                  {columnName(column)}
                  {phi.has(column) && (
                    <Chip tone="caution" fill="outline">
                      PHI
                    </Chip>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {page.rows.map((row, index) => (
              <tr
                key={keys[index] ?? offset + index}
                className={keys[index] && chosen.has(keys[index]) ? "rows__tr--chosen" : undefined}
              >
                {onKept && (
                  <td className="rows__pick">
                    {keys[index] && (
                      <input
                        type="checkbox"
                        checked={chosen.has(keys[index])}
                        onChange={() => toggle(keys[index])}
                        aria-label={`Choose ${noun} ${keys[index]}`}
                      />
                    )}
                  </td>
                )}
                {page.columns.map((column) => {
                  const hidden = phi.has(column) && !showPhi;
                  const value = row[column];
                  return (
                    <td
                      key={column}
                      className={hidden ? "rows__cell--hidden" : undefined}
                    >
                      {hidden
                        ? "••••"
                        : value === null || value === undefined
                          ? "—"
                          : String(value)}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="rows__pager">
        <Button onClick={() => load(Math.max(0, offset - PAGE))} disabled={offset === 0 || busy}>
          Previous
        </Button>
        <Button onClick={() => load(offset + PAGE)} disabled={!page.has_more || busy}>
          Next
        </Button>
        {page.truncated && (
          <span className="rows__truncated">
            The subset was capped before paging, so this is part of what the
            pattern covers.
          </span>
        )}
      </div>
    </div>
  );
}

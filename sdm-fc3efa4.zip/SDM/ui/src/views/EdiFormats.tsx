/**
 * EDI transaction sets: pick one, write it.
 *
 * The formats are descriptions on disk, one file per transaction set, listing
 * segments and the element positions within them. That is the same shape the
 * masking tool this organization already runs uses to address EDI — segment,
 * position, and what goes there — with a rule in place of an algorithm,
 * because one tool changes a value that exists and the other produces one that
 * does not. A position names an element; it never names a column.
 *
 * So this screen does not know about 837 or 835. It lists what is described and
 * writes what is chosen, and a format somebody adds appears here without
 * anything being rebuilt.
 *
 * The file is streamed, not built and then sent: an extract is the one thing
 * here whose size is not bounded by what fits on a screen.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { Banner, Button, Chip, Empty } from "../components/primitives";
import {
  ApiError,
  api,
  type EdiFormatSummary,
  type FilePattern,
  type SnipReport,
  type SnipRules,
} from "../lib/api";
import "./EdiFormats.css";

const SAMPLE_ROWS = 40;

interface Props {
  /** The pattern part of the request, from the screen above. */
  extra: Record<string, unknown>;
  pattern: FilePattern | null;
}

export function EdiFormats({ extra, pattern }: Props) {
  const [formats, setFormats] = useState<EdiFormatSummary[]>([]);
  const [chosen, setChosen] = useState<string>("");
  const [sample, setSample] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  // Groups per ST/SE set. A whole book in one transaction is valid and
  // nobody sends it; trading partners cap the size.
  const [perTransaction, setPerTransaction] = useState(0);
  const [error, setError] = useState<string | null>(null);
  // SNIP-style checks: the rules in effect, a trading partner, the report.
  const [snip, setSnip] = useState<SnipRules | null>(null);
  const [partner, setPartner] = useState<string>("");
  const [report, setReport] = useState<SnipReport | null>(null);
  const [checkRows, setCheckRows] = useState<number>(200);
  const upload = useRef<HTMLInputElement>(null);

  useEffect(() => {
    api.snipRules().then(setSnip).catch(() => setSnip(null));
  }, []);

  useEffect(() => {
    let live = true;
    api
      .ediFormats()
      .then((payload) => {
        if (!live) return;
        setFormats(payload.formats);
        if (payload.formats.length) setChosen(payload.formats[0].id);
      })
      .catch((e) => live && setError(e instanceof ApiError ? e.message : String(e)));
    return () => {
      live = false;
    };
  }, []);

  const format = formats.find((f) => f.id === chosen);

  const preview = useCallback(async () => {
    if (!format) return;
    setBusy("preview");
    setError(null);
    try {
      setSample(
        await api.exportText(`edi:${format.id}`, format.subject, 6, {
          per_transaction: perTransaction || null,
          ...extra,
        }),
      );
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
      setSample(null);
    } finally {
      setBusy(null);
    }
  }, [format, perTransaction, extra]);

  const write = useCallback(async () => {
    if (!format) return;
    setBusy("write");
    setError(null);
    try {
      // Streamed to the browser as a download rather than held in memory
      // here: the point of the writer is that it never holds the whole file.
      await api.exportDownload(
        `edi:${format.id}`,
        format.subject,
        `${format.id.toLowerCase()}.txt`,
        { per_transaction: perTransaction || null, ...extra },
      );
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }, [format, perTransaction, extra]);

  const check = useCallback(async () => {
    if (!format) return;
    setBusy("check");
    setError(null);
    try {
      setReport(
        await api.snipCheck(
          {
            format: `edi:${format.id}`,
            subject: format.subject,
            rows: checkRows || null,
            per_transaction: perTransaction || null,
            ...extra,
          },
          partner || null,
        ),
      );
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }, [format, checkRows, perTransaction, extra, partner]);

  const checkFile = useCallback(
    async (file: File) => {
      setBusy("check-file");
      setError(null);
      try {
        setReport(await api.snipCheckFile(file, partner || null));
      } catch (e) {
        setError(e instanceof ApiError ? e.message : String(e));
      } finally {
        setBusy(null);
        if (upload.current) upload.current.value = "";
      }
    },
    [partner],
  );

  if (!formats.length && !error) {
    return (
      <Empty title="No transaction sets described">
        A format is a file in <code className="mono">sdg/writers/edi_formats</code>.
        Nothing is compiled in, so adding one needs no rebuild.
      </Empty>
    );
  }

  return (
    <section className="panel edi">
      {error && <Banner tone="alarm">{error}</Banner>}

      <div className="edi__pick">
        <label className="named">
          <span>Transaction set</span>
          <select value={chosen} onChange={(e) => setChosen(e.target.value)}>
            {formats.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        </label>

        <label className="named">
          <span>{format?.subject === "claims" ? "Claims" : "Members"} per transaction</span>
          <select
            value={perTransaction}
            onChange={(e) => setPerTransaction(Number(e.target.value))}
          >
            <option value={0}>all in one</option>
            <option value={100}>100</option>
            <option value={500}>500</option>
            <option value={1000}>1,000</option>
            <option value={5000}>5,000</option>
          </select>
        </label>

        {format && (
          <div className="edi__facts">
            <Chip tone="catalog">{format.version}</Chip>
            <Chip tone="learned">from {format.subject}</Chip>
          </div>
        )}
      </div>

      {format?.description && <p className="panel__hint">{format.description}</p>}

      <div className="panel__actions">
        <Button onClick={preview} busy={busy === "preview"}>
          Show the first segments
        </Button>
        <Button variant="primary" onClick={write} busy={busy === "write"}>
          Write the file
        </Button>
        <p className="panel__hint">
          {pattern === null
            ? "Built from the plan this tool already has, so the file describes the same population the database load would. "
            : format?.subject === "claims"
              ? `Claims for the members "${pattern.name}" holds — people who exist, read from the database. `
              : `New members carrying the values of "${pattern.name}". `}
          The preview takes a handful of records; the file takes them all.
          {perTransaction
            ? ` Split into transactions of ${perTransaction.toLocaleString()}, never through the middle of one.`
            : " Everything in one transaction, which is valid and larger than most trading partners accept."}
        </p>
      </div>

      <div className="snip">
        <div className="snip__head">
          <h3>SNIP checks</h3>
          <p className="panel__hint">
            Levels 1–5 from the rule files in effect, and 6–7 where those files carry
            rules. SNIP-style checking, not certification. Rules, code sets and
            trading-partner rules are configured in{" "}
            <code className="mono">{snip?.customerDir ?? "work/snip"}</code> with no
            change to code.
          </p>
        </div>
        <div className="snip__controls">
          <label className="named">
            <span>Records checked</span>
            <select value={checkRows} onChange={(e) => setCheckRows(Number(e.target.value))}>
              <option value={50}>50</option>
              <option value={200}>200</option>
              <option value={1000}>1,000</option>
              <option value={0}>the whole file</option>
            </select>
          </label>
          <label className="named">
            <span>Trading partner</span>
            <select value={partner} onChange={(e) => setPartner(e.target.value)}>
              <option value="">none (levels 1–6)</option>
              {(snip?.partners ?? []).map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </label>
          <Button variant="primary" onClick={check} busy={busy === "check"} disabled={!format}>
            Run SNIP checks
          </Button>
          <Button onClick={() => upload.current?.click()} busy={busy === "check-file"}>
            Check a file…
          </Button>
          <input
            ref={upload}
            type="file"
            hidden
            onChange={(e) => e.target.files?.[0] && void checkFile(e.target.files[0])}
          />
        </div>
        {report && <SnipResult report={report} />}
        {snip && (
          <details className="snip__rules">
            <summary>Rule files in effect ({snip.rules.length})</summary>
            <ul>
              {snip.rules.map((r) => (
                <li key={r.file}>
                  <Chip tone={r.origin === "shipped" ? "physical" : "user"}>{r.origin}</Chip>{" "}
                  <span className="mono">{r.id}</span> {r.version ?? r.name ?? ""} ·{" "}
                  {r.rules} rules · <span className="mono snip__path">{r.file}</span>
                </li>
              ))}
            </ul>
          </details>
        )}
      </div>

      {sample && (
        <pre className="edi__sample">
          {/* Segments already end with a line break, so splitting on
              lines is enough: adding one per segment double-spaces it. */}
          {sample.split("\n").filter(Boolean).slice(0, SAMPLE_ROWS).join("\n")}
        </pre>
      )}
    </section>
  );
}


const STATUS_WORDS: Record<string, string> = {
  pass: "passed",
  fail: "failed",
  warn: "warnings",
  partial: "partly checked",
  not_checked: "not checked",
};

const STATUS_TONE: Record<string, "learned" | "alarm" | "caution" | "physical"> = {
  pass: "learned",
  fail: "alarm",
  warn: "caution",
  partial: "caution",
  not_checked: "physical",
};

/** One report: a row per SNIP level, findings under the ones that have them. */
export function SnipResult({ report }: { report: SnipReport }) {
  const [open, setOpen] = useState<number | null>(
    report.levels.find((l) => l.status === "fail")?.level ?? null,
  );
  return (
    <div className="snip__report">
      <p className="snip__summary">
        <strong>{report.passed ? "No errors" : "Errors found"}</strong>
        {" — "}
        {report.summary ? (
          report.summary
        ) : (
          <>
            {report.file ? <span className="mono">{report.file}</span> : "the file this screen writes"},{" "}
            {report.transaction} {report.version}, {report.transactions} transaction
            {report.transactions === 1 ? "" : "s"}, {report.segments.toLocaleString()} segments
            {report.partner ? `, partner ${report.partner}` : ""}.
          </>
        )}
      </p>
      <table className="snip__levels">
        <tbody>
          {report.levels.map((level) => (
            <tr
              key={level.level}
              className={level.findings.length || level.notes.length ? "snip__row--open" : ""}
              onClick={() => setOpen(open === level.level ? null : level.level)}
            >
              <td className="num">{level.level}</td>
              <td>
                {level.name}
                {open === level.level && (level.findings.length > 0 || level.notes.length > 0) && (
                  <ul className="snip__findings" onClick={(e) => e.stopPropagation()}>
                    {grouped(level.findings).map((g) => (
                      <SnipFinding key={g.rule} group={g} />
                    ))}
                    {level.notes.map((n, i) => (
                      <li key={`n${i}`} className="snip__note">{n}</li>
                    ))}
                  </ul>
                )}
              </td>
              <td>
                <Chip tone={STATUS_TONE[level.status]}>{STATUS_WORDS[level.status]}</Chip>
              </td>
              <td className="num snip__counts">
                {level.rules ? `${level.rules} rules` : ""}
                {level.errors ? ` · ${level.errors} errors` : ""}
                {level.warnings ? ` · ${level.warnings} warnings` : ""}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="panel__hint">{report.disclaimer}</p>
    </div>
  );
}


type FindingRow = SnipReport["levels"][number]["findings"][number];

/** One entry per rule: the first finding, and how many there were. */
function grouped(findings: FindingRow[]): { rule: string; items: FindingRow[] }[] {
  const out = new Map<string, FindingRow[]>();
  for (const f of findings) {
    out.set(f.rule, [...(out.get(f.rule) ?? []), f]);
  }
  return [...out.entries()].map(([rule, items]) => ({ rule, items }));
}

function SnipFinding({ group }: { group: { rule: string; items: FindingRow[] } }) {
  const [all, setAll] = useState(false);
  const [first, ...rest] = group.items;
  const shown = all ? group.items : [first];
  return (
    <li>
      <span className="mono snip__rule">{group.rule}</span> {first.message}
      {group.items.length > 1 && (
        <button className="snip__more" onClick={() => setAll(!all)}>
          {all ? "show one" : `+${rest.length} more like it`}
        </button>
      )}
      {shown.map((f, i) => (
        <span key={i} className="snip__occurrence">
          {all && i > 0 ? <span className="snip__again">{f.message}</span> : null}
          {f.segment ? <span className="snip__where">segment {f.segment}</span> : null}
          {f.raw ? <code className="mono snip__raw">{f.raw}</code> : null}
        </span>
      ))}
    </li>
  );
}

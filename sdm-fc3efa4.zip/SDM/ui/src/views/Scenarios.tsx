/**
 * A pattern's scenarios, and all of the chosen ones generated together.
 *
 * One pattern is usually several test scenarios: the same kind of member on
 * different plans, or of each gender and age band; the same kind of claim of
 * each type and diagnosis. The pattern's own rows say which combinations of
 * the chosen features occur in it and how often. The ones chosen go into one
 * output -- one database load, each a cohort at its share of the volume, or
 * one file holding every scenario's records, each tagged with its scenario.
 */

import { useCallback, useEffect, useState } from "react";
import { Banner, Button, Empty, formatCount, formatPercent } from "../components/primitives";
import {
  ApiError,
  api,
  type Domain,
  type FilePattern,
  type PatternFilters,
  type ScenarioList,
} from "../lib/api";
import "./Scenarios.css";

interface Props {
  domain: Domain;
  name: string;
  filters: PatternFilters;
  k: number | null;
  clusterId: number;
  claimType: string | null;
  onApplied: (destination: "file" | "db", pattern?: FilePattern, note?: string) => void;
}

export function Scenarios({ domain, name, filters, k, clusterId, claimType, onApplied }: Props) {
  const [dimensions, setDimensions] = useState<{ key: string; label: string }[]>([]);
  const [keys, setKeys] = useState<string[]>([]);
  const [list, setList] = useState<ScenarioList | null>(null);
  const [picked, setPicked] = useState<Set<number>>(new Set());
  const [volume, setVolume] = useState(1000);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    api
      .scenarioDimensions(domain)
      .then((d) => {
        if (!live) return;
        setDimensions(d.dimensions);
        setKeys(domain === "claims" ? ["claim_type", "diagnosis"] : ["gender", "age_band"]);
      })
      .catch((e) => live && setError(e instanceof ApiError ? e.message : String(e)));
    return () => {
      live = false;
    };
  }, [domain]);

  const address = { domain, filters, k, cluster_id: clusterId, claim_type: claimType };

  const load = useCallback(async () => {
    setBusy("list");
    setError(null);
    try {
      const found = await api.scenarios({ ...address, dimensions: keys });
      setList(found);
      setPicked(new Set(found.scenarios.map((_, i) => i)));
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [keys, domain, filters, k, clusterId, claimType]);

  const chosen = list ? list.scenarios.filter((_, i) => picked.has(i)) : [];
  const chosenRows = chosen.reduce((n, s) => n + s.rows, 0) || 1;
  // Each scenario's share of the volume: its share of the chosen rows.
  const counts = chosen.map((s) => Math.max(1, Math.round((volume * s.rows) / chosenRows)));

  const keep = useCallback(async () => {
    const kept = await api.keepScenarios({
      ...address, dimensions: keys, name,
      scenarios: chosen.map((s) => s.values),
    });
    return kept.kept;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [keys, chosen, name, domain, filters, k, clusterId, claimType]);

  const toDatabase = useCallback(async () => {
    setBusy("db");
    setError(null);
    try {
      const kept = await keep();
      const payload = await api.storyToPlan(kept.map((p) => p.pattern_id), volume, true);
      onApplied(
        "db",
        undefined,
        `${kept.length} scenarios of ${name} set as cohorts of one load, ` +
          `${payload.applied?.length ?? 0} column rules written. The plan is rebuilt ` +
          `with them below; look at the sample rows, then write.`,
      );
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }, [keep, volume, name, onApplied]);

  const toFile = useCallback(async () => {
    setBusy("file");
    setError(null);
    try {
      const kept = await keep();
      onApplied("file", {
        kind: "scenarios",
        name: `${kept.length} scenarios of ${name}`,
        entity: domain,
        scenarios: kept.map((p, i) => ({
          pattern_id: p.pattern_id, label: p.label, count: counts[i] ?? 1,
        })),
        members: volume,
      });
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }, [keep, onApplied, name, domain, counts, volume]);

  return (
    <section className="scenarios" aria-label="Scenarios">
      <h4>Scenarios</h4>
      {error && <Banner tone="alarm">{error}</Banner>}
      <div className="scenarios__dims" role="group" aria-label="Split by">
        <span className="panel__hint">Split by</span>
        {dimensions.map((d) => (
          <label key={d.key} className="scenarios__dim">
            <input
              type="checkbox"
              checked={keys.includes(d.key)}
              onChange={() =>
                setKeys((previous) =>
                  previous.includes(d.key)
                    ? previous.filter((key) => key !== d.key)
                    : [...previous, d.key],
                )
              }
            />
            {d.label}
          </label>
        ))}
        <Button onClick={load} busy={busy === "list"} disabled={!keys.length}>
          List the scenarios
        </Button>
      </div>

      {list &&
        (list.scenarios.length === 0 ? (
          <Empty title="No scenarios">None of this pattern&apos;s rows carry those features.</Empty>
        ) : (
          <>
            <table className="panel__table scenarios__table">
              <thead>
                <tr>
                  <th>
                    <input
                      type="checkbox"
                      aria-label="Every scenario"
                      checked={picked.size === list.scenarios.length}
                      onChange={() =>
                        setPicked(
                          picked.size === list.scenarios.length
                            ? new Set()
                            : new Set(list.scenarios.map((_, i) => i)),
                        )
                      }
                    />
                  </th>
                  <th>Scenario</th>
                  <th className="right">Rows</th>
                  <th className="right">Share</th>
                </tr>
              </thead>
              <tbody>
                {list.scenarios.map((scenario, index) => (
                  <tr key={scenario.label}>
                    <td>
                      <input
                        type="checkbox"
                        aria-label={scenario.label}
                        checked={picked.has(index)}
                        onChange={() =>
                          setPicked((previous) => {
                            const next = new Set(previous);
                            if (next.has(index)) next.delete(index);
                            else next.add(index);
                            return next;
                          })
                        }
                      />
                    </td>
                    <td>{scenario.label}</td>
                    <td className="right num">{formatCount(scenario.rows)}</td>
                    <td className="right num">{formatPercent(scenario.share, 1)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {list.more > 0 && (
              <p className="panel__hint">
                {formatCount(list.more)} rarer scenarios are not listed.
              </p>
            )}
            <div className="panel__actions">
              <label className="named">
                <span>{domain === "claims" ? "Claims" : "Members"}, in all</span>
                <input
                  type="number"
                  min={chosen.length || 1}
                  value={volume}
                  onChange={(e) => setVolume(Math.max(1, Number(e.target.value) || 1))}
                />
              </label>
              <Button
                variant="primary"
                onClick={toDatabase}
                busy={busy === "db"}
                disabled={!chosen.length || busy !== null}
              >
                {`Generate ${chosen.length} into the database`}
              </Button>
              <Button onClick={toFile} busy={busy === "file"} disabled={!chosen.length || busy !== null}>
                {`Write ${chosen.length} as one file`}
              </Button>
              <span className="panel__hint">
                Each chosen scenario gets its share of the volume, as its share of the
                chosen rows.
              </span>
            </div>
          </>
        ))}
    </section>
  );
}

/**
 * Which features system discovered patterns are found on.
 *
 * The clustering groups members (or claim lines) on the features ticked here:
 * the patterns it finds differ by those and by nothing else. Provider features
 * come from the tables beside the denorm -- a member's primary care provider,
 * a claim's provider type and network -- and are offered beside the rest.
 */

import { useCallback, useEffect, useState } from "react";
import { Banner, Button, Chip } from "../components/primitives";
import { ApiError, api, type DiscoveryFeature, type Domain } from "../lib/api";
import "./DiscoveryConfig.css";

const GROUPS: ReadonlyArray<readonly [string, (f: DiscoveryFeature) => boolean]> = [
  ["Plan and group", (f) => f.scope],
  ["Provider and network", (f) => !f.scope && (f.joined || /provider|network|pcp/i.test(f.key))],
  ["Member and claim", (f) => !f.scope && !(f.joined || /provider|network|pcp/i.test(f.key))],
];

export function DiscoveryConfig() {
  const [features, setFeatures] = useState<Record<Domain, DiscoveryFeature[]> | null>(null);
  const [picked, setPicked] = useState<Record<Domain, Set<string>>>({
    members: new Set(), claims: new Set(),
  });
  const [busy, setBusy] = useState<Domain | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const found = await api.discoveryFeatures();
      setFeatures(found);
      setPicked({
        members: new Set(found.members.filter((f) => f.chosen).map((f) => f.key)),
        claims: new Set(found.claims.filter((f) => f.chosen).map((f) => f.key)),
      });
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const toggle = (entity: Domain, key: string) =>
    setPicked((previous) => {
      const next = new Set(previous[entity]);
      next.has(key) ? next.delete(key) : next.add(key);
      return { ...previous, [entity]: next };
    });

  const save = useCallback(
    async (entity: Domain) => {
      setBusy(entity);
      setError(null);
      setNote(null);
      try {
        await api.chooseDiscoveryFeatures(entity, [...picked[entity]]);
        await load();
        const labels = (features?.[entity] ?? [])
          .filter((f) => picked[entity].has(f.key))
          .map((f) => f.label);
        setNote(`${entity === "claims" ? "Claim" : "Member"} patterns are now found on ${labels.join(", ")}.`);
      } catch (e) {
        setError(e instanceof ApiError ? e.message : String(e));
      } finally {
        setBusy(null);
      }
    },
    [picked, features, load],
  );

  const reset = (entity: Domain) =>
    setPicked((previous) => ({
      ...previous,
      [entity]: new Set((features?.[entity] ?? []).filter((f) => f.default).map((f) => f.key)),
    }));

  return (
    <section className="panel discoveryconfig" aria-label="Pattern discovery features">
      <header>
        <h2>System discovered patterns</h2>
        <p className="panel__hint">
          System discovered patterns are found on the features ticked here: the
          clustering groups members, or claim lines, that are alike on these. Tick
          provider features to find patterns that differ by provider and network.
        </p>
      </header>
      {error && <Banner tone="alarm">{error}</Banner>}
      {note && <Banner tone="affirm">{note}</Banner>}

      <div className="discoveryconfig__entities">
        {(["members", "claims"] as const).map((entity) => (
          <div key={entity} className="discoveryconfig__entity">
            <h3>{entity === "claims" ? "Claims" : "Members"}</h3>
            {GROUPS.map(([title, belongs]) => {
              const shown = (features?.[entity] ?? []).filter(belongs);
              if (!shown.length) return null;
              return (
                <fieldset key={title}>
                  <legend>{title}</legend>
                  {shown.map((feature) => (
                    <label key={feature.key} className="discoveryconfig__feature">
                      <input
                        type="checkbox"
                        checked={picked[entity].has(feature.key)}
                        onChange={() => toggle(entity, feature.key)}
                      />
                      <span>{feature.label}</span>
                      {feature.kind === "range" && (
                        <Chip fill="outline" tone="neutral">number</Chip>
                      )}
                    </label>
                  ))}
                </fieldset>
              );
            })}
            <div className="panel__actions">
              <Button
                variant="primary"
                onClick={() => void save(entity)}
                busy={busy === entity}
                disabled={!picked[entity].size}
              >
                Save
              </Button>
              <Button onClick={() => reset(entity)}>Defaults</Button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

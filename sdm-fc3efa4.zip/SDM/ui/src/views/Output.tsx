/**
 * File Generation: the shape data leaves in.
 *
 * A layout says how a row is written — fixed-width columns, a delimiter, which
 * rule fills each field. A rule says what fills one. Together they are
 * everything needed to write a file.
 *
 * Every file is written for someone: the plan's run, or a pattern. For a
 * pattern, members are new people carrying its values and claims belong to
 * the members it holds. The choice sits above the tabs because it applies to
 * every format beneath them.
 *
 * Only an approved layout is selectable downstream, and the approval is shown
 * with who did it: approving your own layout is allowed here, and saying so is
 * better than pretending there was a second pair of eyes.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { Banner, Button, Chip, Empty } from "../components/primitives";
import { EdiFormats } from "./EdiFormats";
import { FromSample } from "./FromSample";
import { LayoutDesigner } from "./LayoutDesigner";
import { LayoutEditor, aliasNote } from "./LayoutEditor";
import { FieldsTable } from "./LayoutFields";
import { Rules } from "./Rules";
import {
  ApiError,
  api,
  patternRequest,
  type FilePattern,
  type GenerationRule,
  type Layout,
  type FilePatternOption,
  type LayoutParsePayload,
} from "../lib/api";
import "./Output.css";

interface OutputProps {
  pattern: FilePattern | null;
  onPattern: (pattern: FilePattern | null) => void;
}

/**
 * Map & Review, for files: the shape of a file and the rule behind each field.
 *
 * Defining a layout -- from a sample, or by hand -- and choosing what fills
 * each field is mapping, the same job Map & Review does for a database's
 * columns. So it sits there, beside the rule repository it draws on.
 */
export function FileMapping() {
  const [tab, setTab] = useState<"layouts" | "rules">("layouts");
  return (
    <div className="output">
      <header className="output__head">
        <h2>File layouts</h2>
        <p className="output__lede">
          Layouts read from a sample or defined by hand, and the generation rule for
          each field.
        </p>
      </header>
      <nav className="tabs" role="tablist">
        {(
          [
            ["layouts", "Layouts"],
            ["rules", "Rules"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            role="tab"
            aria-selected={tab === id}
            className={"tabs__tab" + (tab === id ? " tabs__tab--on" : "")}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
      </nav>
      {tab === "layouts" && <Layouts writing={false} onRules={() => setTab("rules")} extra={{}} />}
      {tab === "rules" && <Rules />}
    </div>
  );
}

/**
 * Generation, for files: writing them, for the plan's run or for a pattern.
 *
 * Every file is written for someone: the plan's run, or a pattern. For a
 * pattern, members are new people carrying its values and claims belong to
 * the members it holds. The choice sits above the tabs because it applies to
 * every format beneath them.
 */
export function FileGeneration({ pattern, onPattern }: OutputProps) {
  const [tab, setTab] = useState<"layouts" | "edi" | "edi-sample">("layouts");
  // How many new members a member file for a pattern carries. Claims are not
  // counted here: they belong to the members the pattern already holds.
  const [newMembers, setNewMembers] = useState(100);
  const extra = patternRequest(pattern, newMembers);

  return (
    <div className="output">
      <header className="output__head">
        <h2>File generation</h2>
        <p className="output__lede">
          Write files through an approved layout, as EDI transactions, or modeled on a sample
          file (X12 EDI, FHIR or HL7 v2).
        </p>
      </header>

      <ForWhom
        pattern={pattern}
        onPattern={onPattern}
        newMembers={newMembers}
        onNewMembers={setNewMembers}
      />

      <nav className="tabs" role="tablist">
        {(
          [
            ["layouts", "Through a layout"],
            ["edi", "EDI"],
            ["edi-sample", "From a sample"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            role="tab"
            aria-selected={tab === id}
            className={"tabs__tab" + (tab === id ? " tabs__tab--on" : "")}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
      </nav>

      {tab === "layouts" && <Layouts writing extra={extra} />}
      {tab === "edi" && <EdiFormats extra={extra} pattern={pattern} />}
      {tab === "edi-sample" && <FromSample extra={extra} pattern={pattern} />}
    </div>
  );
}

/* ------------------------------------------------------------------ */

function ForWhom({
  pattern, onPattern, newMembers, onNewMembers,
}: {
  pattern: FilePattern | null;
  onPattern: (pattern: FilePattern | null) => void;
  newMembers: number;
  onNewMembers: (count: number) => void;
}) {
  const [saved, setSaved] = useState<FilePatternOption[]>([]);

  useEffect(() => {
    let live = true;
    api
      .patternsForFiles()
      .then((payload) => live && setSaved(payload.patterns))
      .catch(() => live && setSaved([]));
    return () => {
      live = false;
    };
  }, []);

  const value =
    pattern === null
      ? ""
      : pattern.kind === "saved"
        ? `saved:${pattern.id}`
        : pattern.kind === "scenarios"
          ? "scenarios"
          : "live";
  const claimLines = pattern?.kind === "live" && pattern.domain === "claims";

  return (
    <section className="forwhom">
      <label className="named">
        <span>Written for</span>
        <select
          value={value}
          onChange={(e) => {
            const chosen = e.target.value;
            if (!chosen) return onPattern(null);
            if (chosen === "live" || chosen === "scenarios") return;
            const id = Number(chosen.split(":")[1]);
            const row = saved.find((p) => p.pattern_id === id);
            if (row) {
              onPattern({
                kind: "saved",
                id,
                name: row.name,
                entity: row.domain,
                members: row.member_count,
              });
            }
          }}
        >
          <option value="">the plan&apos;s run</option>
          {pattern?.kind === "live" && (
            <option value="live">{pattern.name} (just analyzed)</option>
          )}
          {pattern?.kind === "scenarios" && (
            <option value="scenarios">{pattern.name}</option>
          )}
          {saved.length > 0 && (
            <optgroup label="Saved patterns">
              {saved.map((p) => (
                <option key={p.pattern_id} value={`saved:${p.pattern_id}`}>
                  {p.name} ({p.domain})
                </option>
              ))}
            </optgroup>
          )}
        </select>
      </label>

      {pattern && (
        <label className="named">
          <span>New members</span>
          <input
            type="number"
            min={1}
            max={100000}
            value={newMembers}
            onChange={(e) => onNewMembers(Math.max(1, Number(e.target.value) || 1))}
          />
        </label>
      )}

      <p className="panel__hint forwhom__hint">
        {pattern === null
          ? "Members and claims as the plan generates them: the same people a database load would write."
          : `A member file is ${newMembers.toLocaleString()} new members carrying this pattern's values. ` +
            `A claim file is claims for the members this pattern holds` +
            (claimLines ? "" : ` (${pattern.members.toLocaleString()} of them)`) +
            ". Anything the pattern does not name keeps its rule."}
      </p>
    </section>
  );
}

/* ------------------------------------------------------------------ */

function Layouts({
  onRules, extra, writing,
}: {
  onRules?: () => void;
  extra: Record<string, unknown>;
  // Writing files through layouts (Generation), or defining them (Map & Review).
  writing: boolean;
}) {
  const [layouts, setLayouts] = useState<Layout[]>([]);
  const [rules, setRules] = useState<GenerationRule[]>([]);
  const [parsed, setParsed] = useState<LayoutParsePayload | null>(null);
  const [name, setName] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);
  // Members or claims: what one row of the file is.
  const [subject, setSubject] = useState<"members" | "claims">("members");
  // The saved layout open for editing, if any.
  const [editing, setEditing] = useState<number | null>(null);
  // The saved layout whose Drop is waiting to be confirmed.
  const [dropping, setDropping] = useState<number | null>(null);
  // The files in the folder named under Connect, any of which is a sample.
  const [folderFiles, setFolderFiles] = useState<string[]>([]);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (writing) return;
    let live = true;
    api
      .fileSource()
      .then((source) => live && setFolderFiles(source.files.map((f) => f.name)))
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, [writing]);

  const readFromFolder = useCallback(async (fileName: string) => {
    if (!fileName) return;
    setBusy("parse");
    setError(null);
    setSaved(null);
    try {
      const payload = await api.layoutParseFolderFile(fileName);
      setParsed(payload);
      setName(fileName.replace(/\.[^.]+$/, ""));
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }, []);

  const load = useCallback(async () => {
    try {
      const [l, r] = await Promise.all([api.layouts(), api.layoutRules()]);
      setLayouts(l.layouts);
      setRules(r.rules);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const upload = useCallback(async (file: File) => {
    setBusy("parse");
    setError(null);
    setSaved(null);
    try {
      const payload = await api.layoutParse(file);
      setParsed(payload);
      // A name is needed to save, and the file's own name is the one the
      // person already has in mind. They can change it before saving.
      setName(payload.sample_name?.replace(/\.[^.]+$/, "") ?? "");
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }, []);

  const save = useCallback(async () => {
    if (!parsed || !name.trim()) return;
    setBusy("save");
    setError(null);
    try {
      const result = await api.saveLayout({
        name: name.trim(),
        kind: parsed.kind,
        delimiter: parsed.delimiter ?? null,
        fields: parsed.fields,
        sample_name: parsed.sample_name ?? null,
        purpose: "generation",
      });
      setSaved(
        `Saved "${result.name}" as ${result.status.replace("_", " ")}, ` +
        `${result.n_fields} fields` +
        (result.n_default ? `, ${result.n_default} written blank` : "") +
        `. It has to be approved before anything can be generated through it.` +
        aliasNote(result),
      );
      setParsed(null);
      await load();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }, [parsed, name, load]);

  const approve = useCallback(
    async (id: number) => {
      setBusy(`approve-${id}`);
      try {
        await api.approveLayout(id);
        await load();
      } catch (e) {
        setError(e instanceof ApiError ? e.message : String(e));
      } finally {
        setBusy(null);
      }
    },
    [load],
  );

  const drop = useCallback(
    async (layout: Layout) => {
      setBusy(`drop-${layout.id}`);
      setError(null);
      setSaved(null);
      try {
        const result = await api.dropLayout(layout.id);
        setSaved(
          result.action === "archived"
            ? `${layout.name} dropped. It was approved, so it is archived with ` +
                `its approval rather than deleted; it no longer shows here.`
            : `${layout.name} deleted.`,
        );
        if (editing === layout.id) setEditing(null);
        setDropping(null);
        await load();
      } catch (e) {
        setError(e instanceof ApiError ? e.message : String(e));
      } finally {
        setBusy(null);
      }
    },
    [editing, load],
  );

  // A layout that cannot be written through is a description of a file nobody
  // can produce. The export already took a layout id; nothing offered one.
  const writeFile = useCallback(
    async (layout: Layout) => {
      setBusy(`write-${layout.id}`);
      setError(null);
      setSaved(null);
      try {
        // Only a comma-separated file is a .csv; pipe or tab is plain text.
        const comma = layout.kind !== "fixed" && (layout.delimiter ?? ",") === ",";
        const extension = comma ? "csv" : "txt";
        await api.exportDownload(
          layout.kind === "fixed" ? "fixed" : "csv",
          subject,
          `${layout.name.replace(/[^A-Za-z0-9._-]+/g, "-").toLowerCase()}.${extension}`,
          { layout_id: layout.id, ...extra },
        );
        setSaved(
          `Written through ${layout.name}, one row per ` +
            `${subject === "claims" ? "claim line" : "member"}.`,
        );
      } catch (e) {
        setError(e instanceof ApiError ? e.message : String(e));
      } finally {
        setBusy(null);
      }
    },
    [subject, extra],
  );

  return (
    <section className="panel">
      {error && <Banner tone="alarm">{error}</Banner>}
      {saved && <Banner tone="affirm">{saved}</Banner>}

      {!writing && (
      <>
      <div className="panel__actions">
        <input
          ref={input}
          type="file"
          accept=".txt,.csv,.dat"
          hidden
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void upload(file);
          }}
        />
        {folderFiles.length > 0 && (
          <label className="named">
            <span>A file from the folder</span>
            <select value="" onChange={(e) => void readFromFolder(e.target.value)}>
              <option value="">choose a file to read</option>
              {folderFiles.map((file) => (
                <option key={file} value={file}>
                  {file}
                </option>
              ))}
            </select>
          </label>
        )}
        <Button variant="primary" onClick={() => input.current?.click()} busy={busy === "parse"}>
          {folderFiles.length > 0 ? "Or upload a sample" : "Read a sample file"}
        </Button>
        <p className="panel__hint">
          A fixed-width or delimited sample. The structure is inferred — for CSV
          the delimiter is sniffed and the header gives the names; for fixed
          width the boundaries come from the columns that are always blank.
        </p>
      </div>

      <LayoutDesigner onSaved={load} />

      {parsed && (
        <div className="parsed">
          <h3>
            Read as {parsed.kind}
            {parsed.delimiter ? ` delimited by "${parsed.delimiter}"` : ""} —{" "}
            <span className="num">{parsed.fields.length}</span> fields
          </h3>
          <FieldsTable
            kind={parsed.kind}
            fields={parsed.fields}
            rules={rules}
            onChange={(fields) =>
              setParsed({
                ...parsed,
                fields,
                n_default: fields.filter((f) => f.is_default).length,
              })
            }
          />
          <p className="panel__hint">
            Each field is filled by the rule beside it. A name that matched no
            rule is written blank until a rule is picked for it; picking one
            also teaches the repository that name, so the next sample calling
            it the same binds by itself.
            {parsed.n_default
              ? ` ${parsed.n_default} of ${parsed.fields.length} will be written blank.`
              : ""}
          </p>
          {/* A field falls to the default because no rule carries its name.
              Saying so, next to the count, is the difference between a number
              and something a person can act on. */}
          {(parsed.n_default ?? 0) > 0 && rules.length === 0 && (
            <Banner tone="caution">
              Nothing is in the rule repository yet, which is why every field
              above is blank.{" "}
              <button className="linked" onClick={onRules}>
                Fill it from the plan
              </button>{" "}
              and read this file again.
            </Banner>
          )}

          <div className="panel__actions">
            <label className="named">
              <span>Name</span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="What this layout is called"
              />
            </label>
            <Button
              variant="primary"
              onClick={save}
              busy={busy === "save"}
              disabled={!name.trim()}
            >
              Save this layout
            </Button>
          </div>
        </div>
      )}
      </>
      )}

      <div className="layouts__head">
        <h3 className="panel__title">
          Saved layouts <span className="num">{layouts.length}</span>
        </h3>
        {writing && (
        <label className="named">
          <span>One row per</span>
          <select
            value={subject}
            onChange={(e) => setSubject(e.target.value as "members" | "claims")}
          >
            <option value="members">member</option>
            <option value="claims">claim line</option>
          </select>
        </label>
        )}
      </div>
      {layouts.length === 0 ? (
        <Empty title="No layouts yet">
          {writing
            ? "Read or define one under Map & Review, then approve it there."
            : "Read a sample file to infer one, or define one by hand. Only approved layouts can be written through."}
        </Empty>
      ) : (
        <table className="panel__table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Kind</th>
              <th>Purpose</th>
              <th>Status</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {layouts.map((layout) => (
              <tr key={layout.id}>
                <td>{layout.name}</td>
                <td className="mono">{layout.kind}</td>
                <td>{layout.purpose}</td>
                <td>
                  <Chip tone={layout.status === "approved" ? "affirm" : "caution"}>
                    {layout.status.replace("_", " ")}
                  </Chip>
                  {layout.approved_by && (
                    <span className="panel__by"> by {layout.approved_by}</span>
                  )}
                </td>
                <td className="right">
                  {/* Approving is what an unapproved layout needs; writing a
                      file through it is what an approved one is for. A layout
                      that could only ever be approved described a file nobody
                      could produce. */}
                  {writing ? (
                    layout.status === "approved" ? (
                      <Button
                        onClick={() => writeFile(layout)}
                        busy={busy === `write-${layout.id}`}
                      >
                        Write a file
                      </Button>
                    ) : (
                      <span className="panel__hint">approve it under Map &amp; Review</span>
                    )
                  ) : dropping === layout.id ? (
                    <>
                      <Button
                        variant="primary"
                        onClick={() => drop(layout)}
                        busy={busy === `drop-${layout.id}`}
                      >
                        {`Drop ${layout.name}`}
                      </Button>{" "}
                      <Button onClick={() => setDropping(null)}>Keep it</Button>
                    </>
                  ) : (
                    <>
                      <Button
                        onClick={() => setEditing(editing === layout.id ? null : layout.id)}
                      >
                        {editing === layout.id ? "Close" : "Edit"}
                      </Button>{" "}
                      <Button onClick={() => setDropping(layout.id)}>Drop</Button>
                      {layout.status !== "approved" && (
                        <>
                          {" "}
                          <Button
                            onClick={() => approve(layout.id)}
                            busy={busy === `approve-${layout.id}`}
                          >
                            Approve
                          </Button>
                        </>
                      )}
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {!writing && editing !== null && (
        <LayoutEditor
          key={editing}
          layoutId={editing}
          rules={rules}
          onClose={() => setEditing(null)}
          onSaved={(note) => {
            setSaved(note);
            setEditing(null);
            void load();
          }}
        />
      )}

      <p className="panel__hint">
        <span className="num">{rules.length}</span> elements have rules. A
        field names an element, and the element&apos;s rule fills it, so two
        layouts naming the same element write the same value.
      </p>
    </section>
  );
}

/* ------------------------------------------------------------------ */

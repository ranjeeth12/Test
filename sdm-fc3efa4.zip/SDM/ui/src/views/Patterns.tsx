/**
 * Patterns.
 *
 * The analyzer finds groups of members who resemble each other. This screen
 * shows what it found and, for any one of them, what generating that cohort
 * would actually mean: which columns would carry which rules, and which parts
 * of the finding could not be expressed.
 *
 * The second half is the point. A pattern is a claim about a population, and a
 * claim nobody can act on is decoration — so every pattern here is one click
 * away from the rules it implies, and those rules are shown before they are
 * applied rather than after.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Banner,
  Button,
  Chip,
  Empty,
  Share,
  formatCount,
  formatPercent,
} from "../components/primitives";
import {
  ApiError,
  api,
  type AnalyzePayload,
  type CategoricalDist,
  type ClaimsAnalyzePayload,
  type ClaimsOverview,
  type CodeCount,
  type Domain,
  type DiscoveredPattern,
  type FilePattern,
  type HierarchyOverview,
  type Option,
  type KeptPattern,
  type PatternFilters,
  type ScopeDistribution,
  type ToPlanPayload,
} from "../lib/api";
import "./Patterns.css";
import { DefinePattern } from "./DefinePattern";
import { Discover } from "./Discover";
import { PatternDistributions, PatternOverview, seriesColor } from "./PatternCharts";
import { PatternCounts } from "./PatternCounts";
import { PatternRows } from "./PatternRows";
import { Scenarios } from "./Scenarios";
import { Story } from "./Story";
import { columnName } from "../lib/names";

/** The reference date ages and tenures are measured from. Never the clock:
 *  a pattern found today has to mean the same thing when it is replayed. */
const AS_OF = "2026-06-30";

interface Props {
  // A file is written for a pattern; a database load is planned from one.
  // Only the second writes anything here, so only the first carries the
  // pattern along.
  onApplied: (destination: "file" | "db", pattern?: FilePattern, note?: string) => void;
  domain: Domain;
}

/** A pattern somebody defined by its rules: the scope it states, and its name. */
interface DefinedScope {
  name: string;
  filters: PatternFilters;
}

export function PatternsAnalyze({
  onApplied,
  domain,
  defined,
  autoRun = false,
  onConfig,
}: Props & { defined?: DefinedScope; autoRun?: boolean; onConfig?: () => void }) {
  // What the clustering finds patterns on, as chosen on the Config tab.
  const [foundOn, setFoundOn] = useState<string[]>([]);
  useEffect(() => {
    let live = true;
    api
      .discoveryFeatures()
      .then((all) => live && setFoundOn(all[domain].filter((f) => f.chosen).map((f) => f.label)))
      .catch(() => live && setFoundOn([]));
    return () => {
      live = false;
    };
  }, [domain]);
  const [overview, setOverview] = useState<HierarchyOverview | null>(null);
  const [groups, setGroups] = useState<Option[]>([]);
  const [categories, setCategories] = useState<Option[]>([]);

  const [group, setGroup] = useState<number | null>(null);
  const [category, setCategory] = useState<string | null>(null);
  const [k, setK] = useState<number | null>(null);
  const [claimType, setClaimType] = useState<string | null>(null);
  const [claimTypes, setClaimTypes] = useState<Option[]>([]);
  const [clinical, setClinical] = useState<{ diagnoses: CodeCount[]; procedures: CodeCount[] } | null>(null);
  const [claims, setClaims] = useState<ClaimsOverview | null>(null);

  const [analysis, setAnalysis] = useState<AnalyzePayload | ClaimsAnalyzePayload | null>(
    null,
  );
  const [opened, setOpened] = useState<number | null>(null);
  const [plans, setPlans] = useState<Record<number, ToPlanPayload>>({});

  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [applied, setApplied] = useState<string | null>(null);

  const filters = useMemo<PatternFilters>(() => {
    if (defined) return defined.filters;
    const out: PatternFilters = {};
    if (group !== null) out.grgr_ck = [group];
    if (category !== null) out.cspd_cat = [category];
    return out;
  }, [group, category, defined]);
  // What the analysis on screen was run with. Its patterns are rebuilt from
  // exactly this -- not from whatever the controls say after it ran.
  const [ranWith, setRanWith] = useState<{
    filters: PatternFilters;
    k: number | null;
    claimType: string | null;
  }>({ filters: {}, k: null, claimType: null });

  useEffect(() => {
    let live = true;
    Promise.all([api.hierarchyOverview(), api.groups()])
      .then(([o, g]) => {
        if (!live) return;
        setOverview(o);
        setGroups(g);
      })
      .catch((e) => live && setError(e instanceof ApiError ? e.message : String(e)));
    return () => {
      live = false;
    };
  }, []);

  useEffect(() => {
    setAnalysis(null);
    setPlans({});
    setClaimType(null);
  }, [domain]);

  // What the claims half of the book holds. Loaded only when it is being asked
  // about: three queries nobody looking at members needs.
  useEffect(() => {
    if (domain !== "claims") {
      setClinical(null);
      setClaims(null);
      return;
    }
    let live = true;
    Promise.all([api.claimsOverview(), api.topDiagnoses(6), api.topProcedures(6)])
      .then(([overviewRow, diagnoses, procedures]) => {
        if (!live) return;
        setClaims(overviewRow);
        setClinical({ diagnoses, procedures });
      })
      .catch((e) => live && setError(e instanceof ApiError ? e.message : String(e)));
    return () => {
      live = false;
    };
  }, [domain]);

  useEffect(() => {
    if (domain !== "claims") return;
    let live = true;
    api
      .claimTypes(group !== null ? [group] : [])
      .then((types) => live && setClaimTypes(types))
      .catch(() => live && setClaimTypes([]));
    return () => {
      live = false;
    };
  }, [domain, group]);

  useEffect(() => {
    if (group === null) {
      setCategories([]);
      setCategory(null);
      return;
    }
    let live = true;
    api
      .planCategories([group])
      .then((c) => live && setCategories(c))
      .catch(() => live && setCategories([]));
    return () => {
      live = false;
    };
  }, [group]);

  // k of 1 is the whole scope as one pattern: a defined pattern, measured.
  const analyze = useCallback(async (only?: number) => {
    const runK = only ?? k;
    setBusy(only === 1 ? "measure" : "analyze");
    setError(null);
    setApplied(null);
    setPlans({});
    setOpened(null);
    try {
      setAnalysis(
        domain === "claims"
          ? await api.analyzeClaims(filters, runK, claimType)
          : await api.analyze(filters, runK),
      );
      setRanWith({ filters, k: runK, claimType });
      if (only === 1) setOpened(0);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
      setAnalysis(null);
    } finally {
      setBusy(null);
    }
  }, [filters, k, domain, claimType]);
  const measured = analysis?.method === "whole_scope";

  // Every pattern on screen, its values and scenarios counted, on one sheet.
  const downloadSheet = async () => {
    setBusy("sheet");
    setError(null);
    try {
      await api.patternReportSheet(
        {
          domain,
          filters: ranWith.filters,
          k: ranWith.k,
          claim_type: ranWith.claimType,
        },
        `${domain}-patterns.xlsx`,
      );
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  };

  // Handed a scope to analyze straight away, as a requirement is: the patterns
  // inside it, found once, with nothing to press first.
  const started = useRef(false);
  useEffect(() => {
    if (!autoRun || started.current) return;
    started.current = true;
    void analyze();
  }, [autoRun, analyze]);

  // Chosen records into the database: their values become the run's rules
  // for the columns they reach, and DB Generation opens -- the same move a
  // file makes to File Generation. Errors go back to the rows view, where the
  // button was pressed, rather than to the top of a long page.
  const recordsToDb = useCallback(
    async (kept: KeptPattern) => {
      const payload = await api.toPlan(
        kept.profile, domain === "claims" ? "claim" : "member", AS_OF, true, false,
      );
      if (payload.applied.length === 0) {
        throw new Error(
          "None of these records' values reached a column of the database being " +
            "worked on, so nothing was set. Its columns may carry no matching " +
            "elements, or their types cannot hold these values.",
        );
      }
      onApplied(
        "db",
        undefined,
        `${kept.records ?? "The chosen"} records set the rules for ${payload.applied.length} ` +
          `column${payload.applied.length === 1 ? "" : "s"}, for every row of the run. ` +
          `The plan is rebuilt with them below; look at the sample rows, then write.`,
      );
    },
    [domain, onApplied],
  );

  const resolve = useCallback(
    async (
      pattern: DiscoveredPattern,
      apply: boolean,
      asCohort = false,
      destination: "file" | "db" = "db",
    ) => {
      if (apply && destination === "file") {
        // A file for a pattern needs no plan changed: the pattern's elements
        // replace their rules when the file is written. Members in it are
        // new people with these values; claims in it are for the members
        // this pattern actually holds.
        onApplied("file", {
          kind: "live",
          name: measured && defined?.name ? defined.name : pattern.name,
          domain,
          pattern,
          filters: ranWith.filters,
          k: ranWith.k,
          claimType: ranWith.claimType,
          members: pattern.size,
        });
        return;
      }
      setBusy(`pattern-${pattern.cluster_id}`);
      setError(null);
      try {
        const payload = await api.toPlan(
          pattern, domain === "claims" ? "claim" : "member", AS_OF, apply, asCohort,
        );
        setPlans((previous) => ({ ...previous, [pattern.cluster_id]: payload }));
        setOpened(pattern.cluster_id);
        if (apply) {
          // Nothing written is said here, where it was tried; something
          // written goes on to the load, where the plan rebuilds with it.
          if (!payload.applied.length) {
            setApplied("Nothing was written: no part of this pattern reached a column.");
            return;
          }
          onApplied(
            destination,
            undefined,
            `${payload.applied.length} column rules set${
              asCohort ? " for this pattern's share of the population" : " for every row"
            }. The plan is rebuilt with them below; look at the sample rows, then write.`,
          );
        }
      } catch (e) {
        setError(e instanceof ApiError ? e.message : String(e));
      } finally {
        setBusy(null);
      }
    },
    [onApplied, domain, ranWith, measured, defined],
  );

  if (defined && autoRun) {
    return (
      <div className="patterns">
        {busy === "analyze" && <p className="panel__hint">Analyzing…</p>}
        {error && <Banner tone="alarm">{error}</Banner>}
        {applied && <Banner tone="affirm">{applied}</Banner>}
        {results()}
      </div>
    );
  }

  if (defined) {
    // Defining a pattern has its own header and rules above; what is left is
    // to measure it or look inside it.
    return (
      <div className="patterns">
        <section className="define__run">
          <Button variant="primary" onClick={() => analyze(1)} busy={busy === "measure"}>
            Measure it
          </Button>
          <label className="named">
            <span>Clusters inside</span>
            <select
              value={k ?? ""}
              onChange={(e) => setK(e.target.value ? Number(e.target.value) : null)}
            >
              <option value="">Chosen for me</option>
              {[2, 3, 4, 5, 6, 8, 10].map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </label>
          <Button onClick={() => analyze()} busy={busy === "analyze"}>
            Find patterns inside
          </Button>
        </section>
        {error && <Banner tone="alarm">{error}</Banner>}
        {applied && <Banner tone="affirm">{applied}</Banner>}
        {results()}
      </div>
    );
  }

  return (
    <div className="patterns">
      <header className="patterns__head">
        <div>
          <h2>
            {domain === "claims"
              ? "System discovered patterns: claims"
              : "System discovered patterns"}
          </h2>
          <p className="patterns__lede">
            The analyzer clusters the {domain === "claims" ? "claim lines" : "members"} underneath
            {foundOn.length ? <> on <strong>{foundOn.join(", ")}</strong></> : null}, and names
            each group by what makes it distinct.
            {onConfig && (
              <>
                {" "}
                <button type="button" className="linklike" onClick={onConfig}>
                  Change the features
                </button>
              </>
            )}
          </p>
        </div>
        {domain === "claims"
          ? claims && (
              <dl className="patterns__scope">
                <div>
                  <dt>Claims</dt>
                  <dd className="num">{formatCount(claims.n_claims)}</dd>
                </div>
                <div>
                  <dt>Lines</dt>
                  <dd className="num">{formatCount(claims.n_claim_lines)}</dd>
                </div>
                <div>
                  <dt>Diagnoses</dt>
                  <dd className="num">{formatCount(claims.n_diagnoses)}</dd>
                </div>
              </dl>
            )
          : overview && (
              <dl className="patterns__scope">
                <div>
                  <dt>Members</dt>
                  <dd className="num">{formatCount(overview.n_members)}</dd>
                </div>
                <div>
                  <dt>Groups</dt>
                  <dd className="num">{overview.n_groups}</dd>
                </div>
                <div>
                  <dt>Plans</dt>
                  <dd className="num">{overview.n_plans}</dd>
                </div>
              </dl>
            )}
      </header>

      <section className="patterns__filters">
        <label>
          <span>Group</span>
          <select
            value={group ?? ""}
            onChange={(e) => setGroup(e.target.value ? Number(e.target.value) : null)}
          >
            <option value="">Every group</option>
            {groups.map((g) => (
              <option key={g.key} value={g.key}>
                {g.label}
              </option>
            ))}
          </select>
        </label>

        {domain === "claims" ? (
          <label>
            <span>Claim type</span>
            <select
              value={claimType ?? ""}
              onChange={(e) => setClaimType(e.target.value || null)}
              disabled={!claimTypes.length}
            >
              <option value="">Every type</option>
              {claimTypes.map((c) => (
                <option key={c.key} value={c.key}>
                  {c.label}
                </option>
              ))}
            </select>
          </label>
        ) : (
          <label>
            <span>Product category</span>
            <select
              value={category ?? ""}
              onChange={(e) => setCategory(e.target.value || null)}
              disabled={!categories.length}
            >
              <option value="">Every category</option>
              {categories.map((c) => (
                <option key={c.key} value={c.key}>
                  {c.label}
                </option>
              ))}
            </select>
          </label>
        )}

        <label>
          <span>Clusters</span>
          <select
            value={k ?? ""}
            onChange={(e) => setK(e.target.value ? Number(e.target.value) : null)}
          >
            <option value="">Chosen for me</option>
            {[2, 3, 4, 5, 6, 8, 10].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </label>

        <Button variant="primary" onClick={() => analyze()} busy={busy === "analyze"}>
          Find patterns
        </Button>
      </section>

      {error && <Banner tone="alarm">{error}</Banner>}
      {applied && <Banner tone="affirm">{applied}</Banner>}

      {clinical && (
        <section className="clinical">
          <div>
            <h3>Most common diagnoses</h3>
            <ul>
              {clinical.diagnoses.map((code) => (
                <li key={code.code}>
                  <code className="mono">{code.code}</code>
                  <span className="clinical__desc">{code.description ?? "-"}</span>
                  <span className="clinical__n num">{formatCount(code.n)}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3>Most common procedures</h3>
            <ul>
              {clinical.procedures.map((code) => (
                <li key={code.code}>
                  <code className="mono">{code.code}</code>
                  <span className="clinical__desc">{code.description ?? "-"}</span>
                  <span className="clinical__n num">{formatCount(code.n)}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {!analysis && !busy && (
        <Empty title="Nothing analyzed yet">
          Choose how much of the book to look at, then find the patterns in it.
        </Empty>
      )}

      {results()}
    </div>
  );

  function results() {
    if (!analysis) return null;
    // A measured definition is named what its author called it.
    const shown =
      measured && defined?.name
        ? analysis.patterns.map((p) => ({ ...p, name: defined.name }))
        : analysis.patterns;
    return (
        <>
          {measured ? (
            <p className="patterns__summary">
              <strong className="num">
                {formatCount(
                  "subset_claims" in analysis
                    ? analysis.subset_claims
                    : analysis.subset_members,
                )}
              </strong>{" "}
              {domain === "claims" ? "claims" : "members"} meet these rules
              {defined?.name ? ` — ${defined.name}` : ""}. Save it to keep it as a
              pattern of your own.
            </p>
          ) : (
          <p className="patterns__summary">
            <strong className="num">
              {formatCount(
                "subset_claims" in analysis
                  ? analysis.subset_claims
                  : analysis.subset_members,
              )}
            </strong>{" "}
            {domain === "claims" ? "claims" : "members"} in scope, split into{" "}
            <strong className="num">{analysis.n_patterns}</strong>{" "}
            patterns by {analysis.method}
            {analysis.silhouette !== null && (
              <>
                {" "}
                <span className="patterns__sil">
                  separation {analysis.silhouette.toFixed(2)}
                </span>
              </>
            )}
            .
          </p>
          )}

          <div className="patterns__export">
            <Button onClick={downloadSheet} busy={busy === "sheet"}>
              Download counts (one sheet)
            </Button>
            <span className="patterns__export-note">
              Every pattern: each field's values with counts and %, each scenario as one row,
              and whether generation uses it.
            </span>
          </div>

          <PatternOverview
            patterns={shown}
            distributions={analysis.distributions}
            unit={domain === "claims" ? "claim lines" : "members"}
            selected={opened}
            onSelect={(cid) => {
              setOpened(cid);
              // Selecting in a chart opens the card; bring it into view so the
              // detail is where the eye goes next.
              if (cid !== null) {
                requestAnimationFrame(() =>
                  document
                    .getElementById(`pattern-${cid}`)
                    ?.scrollIntoView({ behavior: "smooth", block: "nearest" }),
                );
              }
            }}
          />

          <ul className="patterns__list">
            {shown.map((pattern, index) => (
              <PatternCard
                key={pattern.cluster_id}
                pattern={pattern}
                index={index}
                patterns={shown}
                distributions={analysis.distributions}
                plan={plans[pattern.cluster_id] ?? null}
                open={opened === pattern.cluster_id}
                busy={busy === `pattern-${pattern.cluster_id}`}
                onToggle={() =>
                  setOpened(opened === pattern.cluster_id ? null : pattern.cluster_id)
                }
                onResolve={(apply, asCohort, destination, subject) =>
                  resolve(subject ?? pattern, apply, asCohort, destination)
                }
                onRecordsToDb={recordsToDb}
                domain={domain}
                filters={ranWith.filters}
                k={ranWith.k}
                claimType={ranWith.claimType}
                onApplied={onApplied}
                keepAs={
                  measured && defined
                    ? { name: defined.name || undefined, origin: "user_defined" }
                    : undefined
                }
                onKept={(kept, open) => {
                  if (!open) return;
                  onApplied("file", {
                    kind: "saved",
                    id: kept.pattern_id,
                    name: kept.name,
                    entity: kept.domain,
                    members: kept.member_count,
                  });
                }}
              />
            ))}
          </ul>
        </>
    );
  }
}

interface CardProps {
  pattern: DiscoveredPattern;
  // Its place in the analysis, which is its color in every chart.
  index: number;
  patterns: DiscoveredPattern[];
  distributions?: Record<string, ScopeDistribution>;
  domain: "members" | "claims";
  // What addresses this pattern's subset. A pattern from the profiler has no
  // id -- it is the output of an analysis -- so the analysis is the address.
  filters: PatternFilters;
  k: number | null;
  claimType: string | null;
  plan: ToPlanPayload | null;
  open: boolean;
  busy: boolean;
  onToggle: () => void;
  onResolve: (
    apply: boolean,
    asCohort?: boolean,
    destination?: "file" | "db",
    // The pattern to resolve, when it is not the card's own: chosen records.
    subject?: DiscoveredPattern,
  ) => void;
  // A pattern was saved; `open` asks for File Generation with it chosen.
  onKept: (kept: KeptPattern, open: boolean) => void;
  // Chosen records, saved, applied to the run and on to DB Generation.
  onRecordsToDb: (kept: KeptPattern) => Promise<void>;
  // Saved under this name and origin: a pattern somebody defined.
  keepAs?: { name?: string; origin: string };
  // Scenarios of this pattern, generated together, go on to a file or a load.
  onApplied: (destination: "file" | "db", pattern?: FilePattern, note?: string) => void;
}

function PatternCard({
  pattern, index, patterns, distributions,
  plan, open, busy, onToggle, onResolve, onKept, onRecordsToDb, domain, filters, k, claimType,
  keepAs, onApplied,
}: CardProps) {
  const [showRows, setShowRows] = useState(false);
  const [showScenarios, setShowScenarios] = useState(false);
  const [showCounts, setShowCounts] = useState(false);
  const [saved, setSaved] = useState<KeptPattern | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Keeps the whole pattern, so it is listed under File Generation next time.
  const save = async () => {
    setSaving(true);
    setSaveError(null);
    try {
      const kept = await api.keepPattern({
        domain, filters, k, cluster_id: pattern.cluster_id, claim_type: claimType,
        ...(keepAs ?? {}),
      });
      setSaved(kept);
      onKept(kept, false);
    } catch (e) {
      setSaveError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setSaving(false);
    }
  };
  // Defaulting to the share rather than the whole run: a pattern that
  // describes a fifth of the book applied to every row describes nothing.
  const [asCohort, setAsCohort] = useState(Boolean(pattern.pct_of_total));
  // The two analyzers name the same ideas differently, because one measures
  // over members and the other over claim lines.
  const age = pattern.continuous?._age ?? pattern.continuous?.member_age;
  const tenure = pattern.continuous?._tenure;
  const charge = pattern.continuous?.charge_amount;

  return (
    <li id={`pattern-${pattern.cluster_id}`} className={"pattern" + (open ? " pattern--open" : "")}>
      <button className="pattern__head" onClick={onToggle} aria-expanded={open}>
        <span className="pattern__key" style={{ background: seriesColor(index) }} aria-hidden="true" />
        <span className="pattern__name">{pattern.name}</span>
        <span className="pattern__size num">
          {formatCount(pattern.size)} {domain === "claims" ? "claim lines" : "members"}
        </span>
        <Share value={pattern.pct_of_subset} />
        <Chip tone={pattern.rare ? "caution" : "learned"}>{pattern.weight_band}</Chip>
      </button>

      <div className="pattern__facts">
        {age && (
          <Fact label="Age">
            {Math.round(age.min)}–{Math.round(age.max)}
            <span className="pattern__mean"> mean {age.mean.toFixed(1)}</span>
          </Fact>
        )}
        {tenure && (
          <Fact label="Tenure">
            {Math.round(tenure.min)}–{Math.round(tenure.max)}
            <span className="pattern__mean"> months</span>
          </Fact>
        )}
        {charge && (
          <Fact label="Charge">
            {Math.round(charge.min)}–{Math.round(charge.max)}
            <span className="pattern__mean"> mean {charge.mean.toFixed(0)}</span>
          </Fact>
        )}
        {(pattern.geography?.length ?? 0) > 0 && (
          <Fact label="Places">
            {pattern.geography!.length.toLocaleString()} ZIPs
            <span className="pattern__mean">
              {" "}top {String(pattern.geography![0].ADDRESS_CITY ?? "")}{" "}
              {String(pattern.geography![0].ADDRESS_STATE ?? "")}
            </span>
          </Fact>
        )}
        {Object.entries(pattern.categorical ?? {}).map(([feature, dist]) => (
          <Fact key={feature} label={featureLabel(feature)}>
            {topShares(dist)}
          </Fact>
        ))}
      </div>

      {open && (
        <PatternDistributions
          pattern={pattern}
          index={index}
          patterns={patterns}
          distributions={distributions}
        />
      )}

      {open && (
        <div className="pattern__plan">
          {!plan && (
            <div className="pattern__actions">
              <Button onClick={() => onResolve(true, asCohort, "file")} busy={busy}>
                Generate a file
              </Button>
              <Button onClick={() => onResolve(false)} busy={busy}>
                Generate into the database…
              </Button>
              <Button onClick={() => setShowRows(!showRows)}>
                {showRows ? "Hide the rows underneath" : "The rows underneath"}
              </Button>
              <Button onClick={() => setShowScenarios(!showScenarios)}>
                {showScenarios ? "Hide scenarios" : "Scenarios"}
              </Button>
              <Button onClick={() => setShowCounts(!showCounts)}>
                {showCounts ? "Hide counts" : "Counts and %"}
              </Button>
              <Button onClick={save} busy={saving} disabled={saved !== null}>
                {saved ? "Saved" : "Save pattern"}
              </Button>
              <p className="pattern__caveat">
                {saved
                  ? "Saved. It is listed under File Generation, ready to write files for."
                  : "A file is built from the pattern store alone -- no database needs to be onboarded. Into the database shows first which columns of the database being worked on this pattern would set, and needs that database's plan. The rows underneath are the real rows it was read from; saving keeps it ready under File Generation."}
              </p>
            </div>
          )}
          {saveError && <Banner tone="alarm">{saveError}</Banner>}

          {showCounts && (
            <PatternCounts
              domain={domain}
              name={pattern.name}
              filters={filters}
              k={k}
              clusterId={pattern.cluster_id}
              claimType={claimType}
            />
          )}

          {showScenarios && (
            <Scenarios
              domain={domain}
              name={pattern.name}
              filters={filters}
              k={k}
              clusterId={pattern.cluster_id}
              claimType={claimType}
              onApplied={onApplied}
            />
          )}

          {showRows && (
            <PatternRows
              domain={domain}
              filters={filters}
              k={k}
              clusterId={pattern.cluster_id}
              claimType={claimType}
              onKept={async (kept, destination) => {
                if (destination === "file") return onKept(kept, true);
                await onRecordsToDb(kept);
              }}
            />
          )}

          {plan && (
            <>
              <h4>Where this pattern supplies the value</h4>
              {plan.resolution.targets.length === 0 && (
                <p className="pattern__none">
                  Nothing in this pattern has a column in the database being worked on,
                  so there is nothing to generate into it
                  {plan.resolution.rejections.length > 0
                    ? ` -- it needs ${plan.resolution.rejections
                        .map((r) => fromWords(r.parameter).split(":")[0].toLowerCase())
                        .join(", ")}, and that database has none of them`
                    : ""}
                  . A file does not need those columns, so Generate a file still works.
                </p>
              )}
              {plan.resolution.targets.length > 0 && (
                <table className="pattern__targets">
                  <thead>
                    <tr>
                      <th>Column</th>
                      <th>From</th>
                      <th>Rule</th>
                      <th>Replaces</th>
                    </tr>
                  </thead>
                  <tbody>
                    {plan.resolution.targets.map((t) => (
                      <tr key={`${t.table}.${t.column}`}>
                        <td title={`${t.table}.${t.column}`}>{columnName(t.column)}</td>
                        <td>{fromWords(t.parameter)}</td>
                        <td>
                          <Chip tone="user">{t.generator}</Chip>
                        </td>
                        <td className="pattern__replaces">
                          {t.replaces?.generator ?? "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {plan.resolution.rejections.length > 0 && (
                <div className="pattern__rejected">
                  <h4>Not carried across</h4>
                  <ul>
                    {plan.resolution.rejections.map((r) => (
                      <li key={r.parameter}>
                        <strong>{fromWords(r.parameter)}</strong>
                        <span>{r.reason}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* How much of the population, and then where it goes. Both
                  questions are answered here because both are answered by
                  looking at the pattern, and neither is answered by the screen
                  you would otherwise have to find afterwards. */}
              <div className="pattern__how">
                <span className="pattern__how-label">Apply to</span>
                {(
                  [
                    [true, `${formatPercent(pattern.pct_of_total)} of the population`],
                    [false, "every row"],
                  ] as const
                ).map(([cohort, label]) => (
                  <button
                    key={String(cohort)}
                    className={
                      "pattern__how-option" +
                      (asCohort === cohort ? " pattern__how-option--on" : "")
                    }
                    onClick={() => setAsCohort(cohort)}
                    disabled={cohort && !pattern.pct_of_total}
                    title={
                      cohort && !pattern.pct_of_total
                        ? "This pattern states no share of the population"
                        : undefined
                    }
                  >
                    {label}
                  </button>
                ))}
              </div>

              <div className="pattern__actions">
                <Button
                  variant="primary"
                  onClick={() => onResolve(true, asCohort, "db")}
                  busy={busy}
                  disabled={plan.resolution.targets.length === 0}
                  title={
                    plan.resolution.targets.length === 0
                      ? "None of this pattern's elements is a column in the database being worked on"
                      : undefined
                  }
                >
                  Generate into the database
                </Button>
                <Button onClick={() => onResolve(true, asCohort, "file")} busy={busy}>
                  Generate a file
                </Button>
                <p className="pattern__caveat">
                  Into the database: a cohort is this pattern&apos;s own share,
                  with everyone else generated as measured; every row applies it
                  to the whole run. As a file: an enrollment is new members with
                  this pattern&apos;s values, and a claim file is claims for the
                  members it holds. Either way, an element the pattern does not
                  name keeps its rule.
                </p>
              </div>
            </>
          )}
        </div>
      )}
    </li>
  );
}

function Fact({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="fact">
      <span className="fact__label">{label}</span>
      <span className="fact__value num">{children}</span>
    </div>
  );
}

const FEATURE_WORDS: Record<string, string> = {
  MEME_SEX: "Sex",
  MEME_MARITAL_STATUS: "Marital",
  MEME_REL: "Relationship",
  gender: "Sex",
  claim_status: "Status",
  claim_type: "Type",
  network: "Network",
};

// What the plan calls a pattern's value, where it is not a person's word. The
// plan matches on these names, so they are reworded only where they are shown.
const FROM_WORDS: Record<string, string> = {
  "Group Key": "Group",
  "Coverage Plan Id": "Plan ID",
  "Product Code": "Product ID",
  "Address Zip": "ZIP",
  "Address City": "City",
  "Address State": "State",
};

/** "Coverage Plan Id: 3 combinations" as "Plan ID: 3 combinations"; a FACETS
 *  column named by its code ("CSPI_ID: ...") by its business name. */
function fromWords(stated: string): string {
  const at = stated.indexOf(":");
  const label = at < 0 ? stated : stated.slice(0, at);
  const rest = at < 0 ? "" : stated.slice(at);
  const word = FROM_WORDS[label] ?? (/^[A-Z0-9_]+$/.test(label) ? columnName(label) : label);
  return word + rest;
}

function featureLabel(feature: string): string {
  return FEATURE_WORDS[feature] ?? columnName(feature);
}

/** The two largest shares, which is what distinguishes one cluster from another.
 *
 *  The member analyzer nests them under `pct`; the claims analyzer gives a flat
 *  mapping of value to share. Both mean the same thing, and reading only the
 *  first left every claims pattern showing a label with nothing beside it. */
function topShares(dist: CategoricalDist | Record<string, number>): string {
  const shares: Record<string, number> =
    (dist as CategoricalDist)?.pct ??
    (Object.fromEntries(
      Object.entries(dist ?? {}).filter(([, v]) => typeof v === "number"),
    ) as Record<string, number>);
  const total = Object.values(shares).reduce((sum, v) => sum + v, 0) || 1;
  return Object.entries(shares)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([key, share]) => `${key} ${Math.round((share / total) * 100)}%`)
    .join("  ");
}


/**
 * The three ways into a pattern, behind one step.
 *
 * They are tabs rather than separate rail steps because the rail is the
 * pipeline and these are not three stages of it — they are three routes to the
 * same answer, and which one fits depends on whether you already know where to
 * look.
 */
export function Patterns({
  onApplied,
  domain,
  onConfigure,
}: Props & { onDomain?: (domain: Domain) => void; onConfigure?: () => void }) {
  const [tab, setTab] = useState<"analyze" | "define" | "discover" | "story">(
    "analyze",
  );

  return (
    <div className="patterns-shell">
      <nav className="tabs" role="tablist">
        {(
          [
            ["analyze", "Analyze a scope"],
            ["define", "Define a pattern"],
            ["discover", "Walk the book"],
            ["story", "From a requirement"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            role="tab"
            aria-selected={tab === id}
            className={"tabs__tab" + (tab === id ? " tabs__tab--on" : "")}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
      </nav>

      {tab === "analyze" && (
        <PatternsAnalyze onApplied={onApplied} domain={domain} onConfig={onConfigure} />
      )}
      {tab === "define" && (
        <DefinePattern key={domain} onApplied={onApplied} domain={domain} />
      )}
      {tab === "discover" && <Discover domain={domain} />}
      {tab === "story" && (
        <Story onApplied={onApplied} />
      )}
    </div>
  );
}

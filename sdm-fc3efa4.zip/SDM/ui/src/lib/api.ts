/**
 * Talking to the engine.
 *
 * Every pipeline step is a POST that runs real work against a real database, so
 * failures are expected and are surfaced with whatever the server said rather
 * than a generic message.
 */

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!response.ok) {
    let detail = `${response.status} ${response.statusText}`;
    try {
      const body = await response.json();
      if (body?.detail) detail = body.detail;
    } catch {
      /* the body was not JSON; the status line is what we have */
    }
    throw new ApiError(detail, response.status);
  }
  return response.json() as Promise<T>;
}

export const api = {
  state: () => request<AppState>("/api/state"),
  connect: () => request<ConnectResult>("/api/connect", { method: "POST" }),
  discover: () => request<DiscoverResult>("/api/discover", { method: "POST" }),
  profile: () => request<ProfileResult>("/api/profile", { method: "POST" }),
  map: () => request<MapResult>("/api/map", { method: "POST" }),
  review: () => request<ReviewResult>("/api/review", { method: "POST" }),

  schema: () => request<SchemaPayload>("/api/schema"),
  queue: () => request<QueuePayload>("/api/queue"),
  catalog: () => request<CatalogPayload>("/api/catalog"),
  generators: () => request<GeneratorsPayload>("/api/generators"),
  ratioShapes: () => request<RatioShapesPayload>("/api/ratio-shapes"),

  decide: (decision: DecisionInput) =>
    request<unknown>("/api/decisions", {
      method: "POST",
      body: JSON.stringify(decision),
    }),

  saveSettings: (values: Partial<Settings>) =>
    request<Settings>("/api/settings", {
      method: "PUT",
      body: JSON.stringify(values),
    }),

  buildPlan: () => request<PlanPayload>("/api/plan", { method: "POST" }),
  getPlan: () => request<PlanPayload>("/api/plan"),

  dryRun: (rows = 6) =>
    request<DryRunPayload>(`/api/dryrun?rows=${rows}`, { method: "POST" }),
  generate: () => request<GenerateResult>("/api/generate", { method: "POST" }),
  validate: () => request<ValidateResult>("/api/validate", { method: "POST" }),
  cleanup: () => request<CleanupResult>("/api/cleanup", { method: "POST" }),
  run: () => request<RunPayload>("/api/run"),

  /* The pattern analyzer. Hierarchy first, then the clusters underneath it,
     then what a chosen cluster would mean for generation. */
  hierarchyOverview: () => request<HierarchyOverview>("/api/hierarchy/overview"),
  groups: () => request<Option[]>("/api/hierarchy/groups"),
  planCategories: (groups: number[]) =>
    request<Option[]>(`/api/hierarchy/plan-categories${listQuery("grgr_ck", groups)}`),
  plans: (groups: number[], categories: string[]) =>
    request<Option[]>(
      `/api/hierarchy/plans${listQuery("grgr_ck", groups)}${listQuery("cspd_cat", categories, true)}`,
    ),
  analyze: (filters: PatternFilters, k: number | null) =>
    request<AnalyzePayload>("/api/patterns/analyze", {
      method: "POST",
      body: JSON.stringify({ filters, k }),
    }),
  /* The claims analyzer takes its filters flat rather than nested, because it
     clusters over claim lines rather than over members. */
  analyzeClaims: (filters: PatternFilters, k: number | null, claimType?: string | null) =>
    request<ClaimsAnalyzePayload>("/api/claims/analyze", {
      method: "POST",
      body: JSON.stringify({
        grgr_ck: filters.grgr_ck ?? null,
        cspi_id: filters.cspi_id ?? null,
        pdpd_id: filters.pdpd_id ?? null,
        claim_type: claimType ? [claimType] : null,
        conditions: filters.conditions ?? null,
        k,
      }),
    }),
  // What a pattern can be defined by, and the values each feature takes.
  /** Every feature of members and claims, and which ones patterns are found on. */
  discoveryFeatures: () =>
    request<Record<Domain, DiscoveryFeature[]>>("/api/discovery-features"),
  chooseDiscoveryFeatures: (entity: Domain, features: string[]) =>
    request<Record<string, DiscoveryFeature[]>>("/api/discovery-features", {
      method: "PUT",
      body: JSON.stringify({ entity, features }),
    }),
  // Which fields a pattern's counts are made on: built-in, and denorm columns.
  reportFields: () => request<Record<Domain, ReportField[]>>("/api/report-fields"),
  chooseReportFields: (entity: Domain, fields: string[], reset = false) =>
    request<Record<string, ReportField[]>>("/api/report-fields", {
      method: "PUT",
      body: JSON.stringify({ entity, fields, reset }),
    }),
  patternFeatures: (entity: Domain) =>
    request<{ entity: Domain; features: PatternFeature[] }>(
      `/api/patterns/features?entity=${entity}`,
    ),
  toPlan: (
    pattern: DiscoveredPattern,
    kind: string,
    asOf: string,
    apply: boolean,
    asCohort = false,
  ) =>
    request<ToPlanPayload>("/api/patterns/to-plan", {
      method: "POST",
      body: JSON.stringify({ pattern, kind, as_of: asOf, apply, as_cohort: asCohort }),
    }),
  analyzerHealth: () => request<AnalyzerHealth>("/api/analyzer/health"),

  /* The claims domain. Same questions as the member one, counted over claim
     lines, so the screens ask whichever is selected rather than duplicating. */
  claimsOverview: () => request<ClaimsOverview>("/api/claims/overview"),
  claimsAvailable: () => request<{ available: boolean }>("/api/claims/available"),
  claimsGroups: () => request<Option[]>("/api/claims/groups"),
  claimTypes: (groups: number[]) =>
    request<Option[]>(`/api/claims/types${listQuery("grgr_ck", groups)}`),
  topDiagnoses: (n = 8) => request<CodeCount[]>(`/api/claims/diagnoses?n=${n}`),
  topProcedures: (n = 8) => request<CodeCount[]>(`/api/claims/procedures?n=${n}`),

  /* System discovery: the largest patterns across the whole book, found
     without anyone choosing a scope first. */
  discovery: (entity: "members" | "claims", maxDepth: number) =>
    request<DiscoveryPayload>(
      `/api/discovery?entity=${entity}&max_depth=${maxDepth}`,
    ),
  savePattern: (filters: PatternFilters, k: number | null, clusterId: number) =>
    request<SaveResult>("/api/patterns/save", {
      method: "POST",
      body: JSON.stringify({ filters, k, cluster_id: clusterId }),
    }),
  saved: () => request<{ patterns: SavedPattern[] }>("/api/discovery/saved"),
  // Every stored pattern, bookmarked or not: what a file can be written for.
  patternsForFiles: () =>
    request<{ patterns: FilePatternOption[] }>("/api/patterns/for-files"),
  onboarded: () =>
    request<{ databases: OnboardedDatabase[] }>("/api/databases/onboarded"),
  offboard: (key: string) =>
    request<{ offboarded: string; workingOn: { database: string; server: string } }>(
      "/api/databases/offboard",
      { method: "POST", body: JSON.stringify({ key }) },
    ),
  snipRules: () => request<SnipRules>("/api/edi/snip"),
  snipCheck: (exportRequest: Record<string, unknown>, partner: string | null) =>
    request<SnipReport>("/api/edi/snip/check", {
      method: "POST",
      body: JSON.stringify({ export: exportRequest, partner }),
    }),
  // A file from a sample checked as its format checks (FHIR: models, references, codes).
  sampleCheck: (exportRequest: Record<string, unknown>) =>
    request<SnipReport>("/api/samples/check", {
      method: "POST",
      body: JSON.stringify({ export: exportRequest }),
    }),
  snipCheckFile: (file: File, partner: string | null) => {
    const form = new FormData();
    form.append("file", file);
    if (partner) form.append("partner", partner);
    return fetch("/api/edi/snip/check-file", { method: "POST", body: form }).then(
      unwrap<SnipReport>,
    );
  },
  keepPattern: (body: KeepPatternRequest) =>
    request<KeptPattern>("/api/patterns/keep", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  // Marks a pattern the walk already stored as saved, members or claims alike.
  bookmark: (patternId: number) =>
    request<unknown>("/api/discovery/save", {
      method: "POST",
      body: JSON.stringify({ pattern_id: patternId }),
    }),
  unsave: (patternId: number) =>
    request<unknown>("/api/discovery/unsave", {
      method: "POST",
      body: JSON.stringify({ pattern_id: patternId }),
    }),

  /* Story to data: a requirement in prose, matched against saved patterns. */
  storyParse: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return fetch("/api/story/parse", { method: "POST", body: form }).then(unwrap<StoryParsePayload>);
  },
  // A pattern's scenarios: the combinations of chosen features its rows hold.
  scenarioDimensions: (entity: Domain) =>
    request<{ dimensions: { key: string; label: string }[] }>(
      `/api/patterns/scenario-dimensions?entity=${entity}`,
    ),
  scenarios: (body: ScenarioRequest) =>
    request<ScenarioList>("/api/patterns/scenarios", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  // A pattern's counts: every field and value, every scenario, with %.
  patternReport: (body: PatternReportRequest) =>
    request<PatternReport>("/api/patterns/report", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  // Every pattern of an analysis on one sheet (.xlsx), downloaded.
  patternReportSheet: async (body: PatternReportRequest, filename: string) => {
    const response = await fetch("/api/patterns/report.xlsx", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!response.ok) {
      let detail = `${response.status} ${response.statusText}`;
      try {
        const parsed = await response.json();
        if (parsed?.detail) detail = parsed.detail;
      } catch {
        /* not JSON */
      }
      throw new ApiError(detail, response.status);
    }
    const url = URL.createObjectURL(await response.blob());
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  },
  keepScenarios: (body: ScenarioRequest & { name: string; scenarios: Record<string, string>[] }) =>
    request<{ kept: (KeptPattern & { label: string })[] }>("/api/patterns/scenarios/keep", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  // A requirement read into the rules of a pattern, to analyze like one.
  storyRead: (story: string) =>
    request<StoryReading>("/api/story/read", {
      method: "POST",
      body: JSON.stringify({ story }),
    }),
  storyMatch: (stories: string[]) =>
    request<StoryMatchPayload>("/api/story/match", {
      method: "POST",
      body: JSON.stringify({ stories }),
    }),

  storyToPlan: (patternIds: number[], totalVolume: number, apply: boolean) =>
    request<StoryToPlanPayload>("/api/story/to-plan", {
      method: "POST",
      body: JSON.stringify({
        pattern_ids: patternIds, total_volume: totalVolume, apply,
      }),
    }),

  /* Layouts and masking: the shape data leaves in, and what is hidden in it. */
  layouts: () => request<{ layouts: Layout[] }>("/api/layouts"),
  layoutRules: () => request<{ rules: GenerationRule[] }>("/api/layouts/rules"),

  // The rule repository. Layouts bind to these by column name, so an empty
  // repository is why a parsed layout falls to blanks.
  // The denominator every weight band is read against, and the background
  // walk that computes it.
  // The real rows a pattern describes. Both domains answer in the same shape,
  // so one call serves both and the domain picks the path.
  patternRows: (
    domain: Domain,
    filters: PatternFilters,
    k: number | null,
    clusterId: number,
    claimType: string | null,
    limit = 25,
    offset = 0,
  ) =>
    domain === "claims"
      ? request<PatternRowsPayload>("/api/claims/rows", {
          method: "POST",
          body: JSON.stringify({
            grgr_ck: filters.grgr_ck ?? null,
            cspi_id: filters.cspi_id ?? null,
            pdpd_id: filters.pdpd_id ?? null,
            claim_type: claimType ? [claimType] : null,
            conditions: filters.conditions ?? null,
            k,
            cluster_id: clusterId,
            limit,
            offset,
          }),
        })
      : request<PatternRowsPayload>("/api/patterns/rows", {
          method: "POST",
          body: JSON.stringify({ filters, k, cluster_id: clusterId, limit, offset }),
        }),

  // Which database generation writes to. Any on this server; the roles all
  // resolve against the one SQL Server this installation is configured for.
  // EDI transaction sets, described on disk rather than compiled in.
  ediFormats: () => request<{ formats: EdiFormatSummary[] }>("/api/edi/formats"),
  // A file modeled on a sample: read it against a master config, save as new.
  // The format is read off the sample.
  sampleRead: (body: {
    sample?: string | null;
    sampleName?: string | null;
    master?: string | null;
    masterName?: string | null;
    configId?: number | null;
  }) =>
    request<SampleReading>("/api/samples/read", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  sampleConfigs: () => request<{ configs: GenConfigSummary[] }>("/api/samples/configs"),
  sampleConfigSave: (body: {
    name: string;
    sample: string | null;
    sampleName: string | null;
    basedOn: string | null;
    rows: SamplePosition[];
    fromConfigId: number | null;
  }) =>
    request<{ id: number; name: string; created: boolean }>("/api/samples/configs", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  sampleConfigDelete: (id: number) =>
    request<{ deleted: number }>(`/api/samples/configs/${id}`, { method: "DELETE" }),
  exportText: (
    format: string,
    subject: string,
    rows = 6,
    extra: Record<string, unknown> = {},
  ) =>
    fetch("/api/export", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ format, subject, rows, root_limit: 40, packaged: false, ...extra }),
    }).then(async (r) => {
      if (!r.ok) throw new ApiError(await r.text(), r.status);
      return r.text();
    }),
  exportDownload: async (
    format: string,
    subject: string,
    filename: string,
    extra: Record<string, unknown> = {},
  ) => {
    const response = await fetch("/api/export", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ format, subject, ...extra }),
    });
    if (!response.ok) throw new ApiError(await response.text(), response.status);
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  },

  databases: () => request<DatabasesPayload>("/api/databases"),
  // A target somewhere other than the configured server. Tested before it is
  // saved, because a server and a password typed into a form are usually
  // nearly right rather than right.
  testTarget: (config: TargetConnection) =>
    request<{ db: string; server: string }>("/api/target/test", {
      method: "POST",
      body: JSON.stringify(config),
    }),
  saveTarget: (config: TargetConnection) =>
    request<{ target: string; server: string; trusted: boolean }>(
      "/api/target/connection",
      { method: "POST", body: JSON.stringify(config) },
    ),
  readTarget: () => request<StoredTarget>("/api/target/connection"),
  forgetTarget: () =>
    request<{ target: string; server: string }>("/api/target/connection", {
      method: "DELETE",
    }),
  setTarget: (database: string) =>
    request<{ target: string; server?: string }>("/api/target", {
      method: "POST",
      body: JSON.stringify({ database }),
    }),

  baseline: (entity?: Domain) =>
    request<BaselinePayload>(
      "/api/baseline" + (entity ? `?entity=${entity}` : ""),
    ),
  baselineEstimate: (entity: Domain, maxDepth: number) =>
    request<BaselineEstimate>(
      `/api/baseline/estimate?entity=${entity}&max_depth=${maxDepth}`,
    ),
  startBaseline: (entity: Domain, maxDepth: number) =>
    request<Job>("/api/baseline/jobs", {
      method: "POST",
      body: JSON.stringify({ entity, max_depth: maxDepth }),
    }),
  baselineJob: (jobId: string) => request<Job>(`/api/baseline/jobs/${jobId}`),
  latestBaselineJob: () =>
    request<Job | { state: "none" }>("/api/baseline/jobs/latest"),
  cancelBaseline: (jobId: string) =>
    request<unknown>(`/api/baseline/jobs/${jobId}/cancel`, { method: "POST" }),

  rules: () => request<RulesPayload>("/api/rules"),
  seedPreview: () => request<SeedPayload>("/api/rules/seed"),
  seedRules: () =>
    request<SeedPayload & { ok: boolean; added: string[]; failed: string[] }>(
      "/api/rules/seed",
      { method: "POST", body: JSON.stringify({ created_by: "ui" }) },
    ),
  createRule: (body: NewRule) =>
    request<GenerationRule>("/api/rules", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  updateRule: (ruleId: number, changes: Partial<NewRule>) =>
    request<GenerationRule>(`/api/rules/${ruleId}`, {
      method: "PUT",
      body: JSON.stringify(changes),
    }),
  /** A few values of a rule as it stands, made the way a file makes them. */
  sampleRule: (rule: Partial<NewRule> & { field_name: string; rows?: number }) =>
    request<{ values: string[] }>("/api/rules/sample", {
      method: "POST",
      body: JSON.stringify(rule),
    }),
  setRuleActive: (ruleId: number, active: boolean) =>
    request<unknown>(`/api/rules/${ruleId}/active`, {
      method: "POST",
      body: JSON.stringify({ active }),
    }),
  addAlias: (ruleId: number, columnName: string) =>
    request<unknown>(`/api/rules/${ruleId}/aliases`, {
      method: "POST",
      body: JSON.stringify({ column_name: columnName }),
    }),
  dropAlias: (columnName: string) =>
    request<unknown>(`/api/rules/aliases/${encodeURIComponent(columnName)}`, {
      method: "DELETE",
    }),
  layoutParse: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return fetch("/api/layouts/parse", { method: "POST", body: form }).then(unwrap<LayoutParsePayload>);
  },
  saveLayout: (body: SaveLayoutBody) =>
    request<SavedLayoutResult>("/api/layouts/save", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  layout: (layoutId: number) => request<LayoutDetail>(`/api/layouts/${layoutId}`),
  // Files as a source: the folder they are read from, and each file read.
  fileSource: () => request<FileSource>("/api/files/source"),
  setFileSource: (folder: string) =>
    request<FileSource>("/api/files/source", {
      method: "PUT",
      body: JSON.stringify({ folder }),
    }),
  fileProfiles: () => request<{ folder: string | null; files: FileProfile[] }>("/api/files/profile"),
  // A file in the folder read as a layout sample, as an upload would be.
  layoutParseFolderFile: (name: string) =>
    request<LayoutParsePayload>("/api/files/parse", {
      method: "POST",
      body: JSON.stringify({ name }),
    }),
  // Any edit sends the layout back to review: its approval was of the fields
  // as they were.
  updateLayout: (layoutId: number, body: LayoutEditBody) =>
    request<LayoutEditResult>(`/api/layouts/${layoutId}`, {
      method: "PUT",
      body: JSON.stringify(body),
    }),
  // Approved layouts are archived, keeping their approval; others are deleted.
  // The answer says which.
  dropLayout: (layoutId: number) =>
    request<{ action: "archived" | "deleted"; name?: string }>(`/api/layouts/${layoutId}`, {
      method: "DELETE",
    }),
  approveLayout: (layoutId: number) =>
    request<unknown>("/api/layouts/approve", {
      method: "POST",
      body: JSON.stringify({ layout_id: layoutId }),
    }),
  maskingAlgorithms: () => request<{ algorithms: MaskingAlgorithm[] }>("/api/masking/algorithms"),
  maskingRules: () => request<{ rules: MaskingRule[] }>("/api/masking/rules"),
  maskingLookups: () => request<{ lookups: MaskingLookup[] }>("/api/masking/lookups"),
};

/** An upload goes out as multipart, so it cannot use the JSON helper. */
async function unwrap<T>(response: Response): Promise<T> {
  if (!response.ok) {
    let detail = `${response.status} ${response.statusText}`;
    try {
      const body = await response.json();
      if (body?.detail) detail = body.detail;
    } catch {
      /* not JSON */
    }
    throw new ApiError(detail, response.status);
  }
  return response.json() as Promise<T>;
}

/** Repeated query parameters, which is how the analyzer takes multi-selects. */
function listQuery(name: string, values: (string | number)[], more = false): string {
  if (!values.length) return more ? "" : "";
  const joined = values.map((v) => `${name}=${encodeURIComponent(String(v))}`).join("&");
  return more ? `&${joined}` : `?${joined}`;
}

/* ------------------------------------------------------------------ */
/* Shapes                                                              */
/* ------------------------------------------------------------------ */

export type StepId =
  | "connect"
  | "discover"
  | "profile"
  | "map"
  | "review"
  | "patterns"
  | "output"
  | "run";

export interface Step {
  id: StepId;
  label: string;
  done: boolean;
  detail: string;
  value?: number | null;
  /** Discover and Profile: whether the structure was read, and measured. */
  read?: boolean;
  measured?: boolean;
  /** Map & Review: whether columns were matched, and rules proposed. */
  mapped?: boolean;
  proposed?: boolean;
}

export interface RatioSetting {
  kind?: string;
  value?: unknown;
  min?: unknown;
  max?: unknown;
  zero_share?: unknown;
}

export interface Settings {
  rootCounts: Record<string, number>;
  modes: Record<string, string>;
  drivingParents: Record<string, string>;
  /** Children per parent, where someone replaced what was measured. */
  ratios: Record<string, RatioSetting | null>;
  seed: string;
  planName: string;
}

export interface AppState {
  version: string;
  database: string;
  referenceDatabase: string;
  /** The database the analysis store, and so every pattern, was read from. */
  landscape?: string;
  server: string;
  steps: Step[];
  settings: Settings;
}

export interface ConnectResult {
  checks: { connection: string; ok: boolean; db?: string; error?: string }[];
}

export interface InferredKey {
  childTable: string;
  childColumn: string;
  parentTable: string;
  parentColumn: string;
  coverage: number;
  distinctValues: number;
  evidence: string[];
}

export interface DiscoverResult {
  tables: number;
  columns: number;
  declared_foreign_keys: number;
  inferred_foreign_keys: number;
  buckets: Record<string, number>;
  inferred: InferredKey[];
  seconds: number;
}

export interface ProfileResult {
  columns: number;
  formatsFitted: number;
  dependencies: number;
  orderings: number;
  ratios: number;
  skipped: { table: string; analysis: string; reason: string }[];
  seconds: number;
}

export interface MapResult {
  auto_map_rate: number;
  high: number;
  medium: number;
  low: number;
  unmapped: number;
  mappable_columns: number;
  system_columns: number;
  high_confidence_by_evidence: Record<string, number>;
  seconds: number;
}

export interface ReviewResult {
  proposals: number;
  byConfidence: Record<string, number>;
  queued: number;
  seconds: number;
}

export type Provenance =
  | "structural"
  | "catalog"
  | "learned"
  | "user"
  | "physical";
export type Confidence = "high" | "medium" | "low";
export type Bucket =
  | "system"
  | "reference"
  | "code"
  | "derivable"
  | "business_key"
  | "free";

export interface Evidence {
  kind: string;
  detail: string;
  coverage?: number | null;
  score?: number | null;
}

export interface TopValue {
  value: string | number | boolean | null;
  count: number;
  share: number;
}

export interface ColumnProfile {
  rowCount: number;
  nullRate: number;
  distinctCount: number;
  distinctRatio: number;
  cardinality: string;
  minimum: string | number | null;
  maximum: string | number | null;
  mean: number | null;
  stddev: number | null;
  minLength: number | null;
  maxLength: number | null;
  format: { regex: string; coverage: number; kind: string } | null;
  checkDigit: { scheme: string; share: number } | null;
  sequence: { is_sequence: boolean; step: number; max: number; gaps: number } | null;
  distribution: Record<string, unknown> | null;
  topValues: TopValue[];
}

export interface SchemaColumn {
  table: string;
  name: string;
  type: string;
  nullable: boolean;
  bucket: Bucket;
  bucketReason: string;
  isPrimaryKey: boolean;
  isIdentity: boolean;
  isComputed: boolean;
  profile: ColumnProfile | null;
  element: string | null;
  /** What a person has already said about this column, if anything. */
  decision: DecisionInput | null;
  mappingConfidence: Confidence | null;
  mappingAccepted: boolean;
  mappingReason: string;
  mappingEvidence: Evidence[];
  alternatives: string[];
  generator: string | null;
  params: Record<string, unknown>;
  /** What the tool worked out, kept whole so an override can be undone. */
  proposedElement: string | null;
  proposedGenerator: string | null;
  proposedParams: Record<string, unknown>;
  provenance: Provenance | null;
  confidence: Confidence | null;
  coverage: number | null;
  evidence: Evidence[];
  note: string;
}

export interface ForeignKeyInfo {
  kind: "declared" | "inferred";
  name: string | null;
  columns: string[];
  parentTable: string;
  parentColumns: string[];
  coverage: number | null;
  evidence: string[];
}

export interface SchemaTable {
  name: string;
  schema: string;
  table: string;
  rowCount: number;
  primaryKey: string[];
  triggers: string[];
  foreignKeys: ForeignKeyInfo[];
  columns: SchemaColumn[];
}

export interface RatioProfile {
  child_table: string;
  child_column: string;
  parent_table: string;
  parent_column: string;
  kind: string;
  parents: number;
  children: number;
  minimum: number;
  maximum: number;
  mean: number;
  stddev: number;
  median: number;
  p90: number;
  median_nonzero: number;
  p90_nonzero: number;
  zero_share: number;
  histogram: { children: number; weight: number }[];
  proposal: { kind: string; value?: number; reason: string };
  evidence: string;
}

export interface SchemaPayload {
  tables: SchemaTable[];
  dependencies: {
    table: string;
    determinant: string;
    dependent: string;
    distinct_determinant: number;
  }[];
  orderings: {
    kind: string;
    table: string;
    earlier: string;
    later: string;
    share_in_order: number;
    gap_min: number | null;
    gap_max: number | null;
  }[];
  ratios: RatioProfile[];
}

export interface QueueItem {
  table: string;
  column: string;
  bucket: Bucket;
  qualified: string;
  reasons: string[];
  explanation: string;
  element: string | null;
  mapping_confidence: Confidence | null;
  alternatives: string[];
  generator: string | null;
  params: Record<string, unknown>;
  proposal_confidence: Confidence | null;
  mappingEvidence: Evidence[];
  proposalEvidence: Evidence[];
  decision: DecisionInput | null;
}

export interface QueuePayload {
  items: QueueItem[];
  decided: number;
}

export interface DecisionInput {
  table: string;
  column: string;
  approved?: boolean;
  element?: string | null;
  generator?: string | null;
  params?: Record<string, unknown> | null;
  /** Drop the override and go back to what the tool worked out. */
  reset?: boolean;
}

export interface ParamField {
  name: string;
  label: string;
  type: "text" | "number" | "integer" | "boolean" | "select" | "lines" | "numbers";
  required?: boolean;
  help?: string;
  placeholder?: string;
  options?: string[];
}

export interface GeneratorSpec {
  name: string;
  label: string;
  summary: string;
  fields: ParamField[];
}

export interface GeneratorsPayload {
  generators: GeneratorSpec[];
  structuralWarning: string;
}

export interface RatioShapesPayload {
  shapes: GeneratorSpec[];
}

export interface PlanField {
  name: string;
  bucket: Bucket;
  element: string | null;
  generator: string;
  params: Record<string, unknown>;
  provenance: Provenance;
  confidence: Confidence | null;
  coverage: number | null;
  userOverride: boolean;
  nullRate: number | null;
  dataType: string | null;
  evidence: Evidence[];
  overrode: { provenance: Provenance; generator: string; reason: string }[];
}

export interface PlanTable {
  name: string;
  mode: "generate" | "reuse" | "exclude";
  level: number | null;
  drivingParent: string | null;
  /** Every parent this table could be driven by, the builder's own list. */
  parents: string[];
  count: number | null;
  effectiveCount: number | null;
  ratioMean: number | null;
  /** True when the shape was stated by hand rather than measured. */
  ratioOverride: boolean;
  ratio: {
    parent: string;
    kind: string;
    value?: number;
    zero_share?: number;
    min?: number;
    max?: number;
    histogram?: { children: number; weight: number }[];
    evidence?: Evidence[];
    provenance?: Provenance;
  } | null;
  fields: PlanField[];
}

export interface PlanWarning {
  code: string;
  severity: "block" | "warn";
  message: string;
  table?: string;
  field?: string;
}

export interface ReferenceSetInfo {
  table: string;
  size: number;
  available: number;
  strategy: string;
  filter: string | null;
  describe: string;
}

export interface PlanPayload {
  built: boolean;
  /** Built before a rule, a pattern or a count changed; rebuilt on arrival. */
  stale?: boolean;
  meta?: { name: string; version: string; seed: string; created: string };
  generationOrder?: string[];
  tables?: PlanTable[];
  warnings?: PlanWarning[];
  blocking?: number;
  provenance?: Record<string, number>;
  totalRows?: number;
  references?: Record<string, ReferenceSetInfo>;
}

export interface DryRunPayload {
  tables: {
    name: string;
    columns: string[];
    rows: Record<string, unknown>[];
    generated: number;
  }[];
  seconds: number;
}

export interface GenerateResult {
  tables: { table: string; rows_written: number; identity_insert: boolean }[];
  rowsWritten: number;
  seconds: number;
  triggersFired: string[];
}

export interface ValidateResult {
  checks: number;
  failed: number;
  passed: boolean;
  by_kind: Record<string, { passed: number; failed: number }>;
  results: {
    name: string;
    kind: string;
    passed: boolean;
    detail: string;
    table: string | null;
    column: string | null;
  }[];
}

export interface CleanupResult {
  deleted: Record<string, number>;
  total: number;
  triggersFired: string[];
}

export interface RunPayload {
  hasRun: boolean;
  manifest: {
    run: { rows_written: number; seconds: number; database: string; finished: string };
    plan: { seed: string; name: string; version: string };
    tables: {
      table: string;
      rows_written: number;
      identity_insert: boolean;
      triggers_fired: string[];
    }[];
    validation?: { checks: number; failed: number; passed: boolean };
  } | null;
}

export interface CatalogElement {
  name: string;
  description: string;
  domain: string;
  rule: "generate" | "reuse" | "copy";
  generator: string | null;
  format: string | null;
  pii: "none" | "identifier" | "sensitive";
  consistencyScope: string;
  aliases: string[];
  checkDigit: string | null;
  reuseDomain: Record<string, unknown> | null;
  usedBy: string[];
  valueCount: number;
}

export interface CatalogPayload {
  organization: string;
  version: string;
  summary: Record<string, unknown>;
  elements: CatalogElement[];
}


/* ------------------------------------------------------------------ */
/* The pattern analyzer                                                */
/* ------------------------------------------------------------------ */

export interface Option {
  key: string;
  label: string;
}

export interface HierarchyOverview {
  n_members: number;
  n_groups: number;
  n_plan_categories: number;
  n_plans: number;
  n_products: number;
}

export interface PatternFilters {
  grgr_ck?: number[];
  cspd_cat?: string[];
  cspi_id?: string[];
  pdpd_id?: string[];
  /** A defined pattern's rules beyond the hierarchy. */
  conditions?: Record<string, PatternCondition>;
}

/** One of a list of values, or a range. */
export interface PatternCondition {
  in?: string[];
  min?: number;
  max?: number;
}

/** A feature a pattern can be defined by. `scope` ones are the hierarchy. */
/** A feature the clustering can find patterns on, as the Config screen lists it. */
export interface ReportField {
  key: string;
  label: string;
  column: string | null;
  /** One of the fields every pattern is described by; else a denorm column. */
  builtin: boolean;
  chosen: boolean;
}

export interface DiscoveryFeature {
  key: string;
  label: string;
  kind: "in" | "range";
  scope: boolean;
  /** Joined from the tables beside the denorm (provider, network, PCP). */
  joined: boolean;
  chosen: boolean;
  default: boolean;
}

export interface PatternFeature {
  key: string;
  label: string;
  kind: "in" | "range";
  scope?: boolean;
  unit?: string;
  options?: { value: string; label: string | null; count: number }[];
  min?: number | null;
  max?: number | null;
}

export interface ContinuousStats {
  mean: number;
  std: number;
  min: number;
  max: number;
  median: number;
}

export interface CategoricalDist {
  counts: Record<string, number>;
  pct: Record<string, number>;
}

export interface DiscoveredPattern {
  cluster_id: number;
  name: string;
  size: number;
  pct_of_subset: number;
  pct_of_total: number;
  rare: boolean;
  weight_band: string;
  continuous: Record<string, ContinuousStats>;
  categorical: Record<string, CategoricalDist>;
  family: Record<string, number | null>;
  descriptions: Record<string, string[]>;
  /** Counts per bin of the analysis's `distributions`, feature by feature.
   *  Absent on patterns analyzed before histograms were recorded. */
  histograms?: Record<string, number[]>;
  /** Where the members live: address records with their shares. */
  geography?: Array<Record<string, string | number>>;
}

/** A continuous feature over the whole scope: round bin edges, the scope's
 *  count in each, and whether the last bin is open (values beyond the 99th
 *  percentile are counted into it rather than stretching the axis). */
export interface ScopeDistribution {
  edges: number[];
  counts: number[];
  open_top: boolean;
}

export interface AnalyzePayload {
  total_members: number;
  subset_members: number;
  pct_of_total: number;
  n_patterns: number;
  method: string;
  silhouette: number | null;
  patterns: DiscoveredPattern[];
  scope_label: string;
  distributions?: Record<string, ScopeDistribution>;
}

export interface PatternTarget {
  table: string;
  column: string;
  element: string | null;
  generator: string;
  params: Record<string, unknown>;
  parameter: string;
  relation: "subject" | "descendant";
  depth: number;
  apply: "all" | "at_least_one";
  confidence: string | null;
  replaces: { generator?: string; params?: Record<string, unknown> };
  note: string | null;
}

export interface PatternRejection {
  parameter: string;
  reason: string;
  candidates: string[];
}

export interface ToPlanPayload {
  pattern: {
    id: string;
    kind: string;
    label: string;
    support: number | null;
    parameters: { label: string; value?: unknown; min?: number; max?: number;
                  values?: string[]; weights?: number[]; unit?: string | null }[];
  };
  resolution: {
    pattern: string;
    subject: string | null;
    targets: PatternTarget[];
    rejections: PatternRejection[];
  };
  applied: string[];
}

export interface AnalyzerHealth {
  server: string;
  database: string;
  schema: string;
  ok: boolean;
  tables?: number;
  error?: string;
}


/* ------------------------------------------------------------------ */
/* Discovery, saved patterns, stories, layouts, masking                */
/* ------------------------------------------------------------------ */

export interface DiscoveredRow {
  pattern_id: number;
  entity: string;
  cluster_id: number;
  name: string;
  size: number;
  pct_of_population: number;
  silhouette: number;
  combo: PatternFilters;
  group: string;
  plan_category: string;
  plan: string;
  product: string;
  saved?: boolean;
}

export interface DiscoveryPayload {
  total_population: number;
  combinations_processed: number;
  n_discovered: number;
  patterns: DiscoveredRow[];
}

/**
 * Who a file is for. Nothing: the plan's run. A pattern: new members carrying
 * its values, or claims for the members it holds. Saved patterns are named by
 * id; one an analysis just found is named by the analysis that found it.
 */
export interface ScenarioRequest {
  domain: Domain;
  filters: PatternFilters;
  k: number | null;
  cluster_id: number;
  claim_type: string | null;
  dimensions: string[];
}

export interface PatternReportRequest {
  domain: Domain;
  filters: PatternFilters;
  k: number | null;
  cluster_id?: number;
  claim_type?: string | null;
  pattern_id?: number;
  scenario_keys?: string[];
  /** A download: the pattern's name, saved patterns by id ([] = all), the file type. */
  name?: string;
  pattern_ids?: number[];
  format?: "xlsx" | "csv";
}

export interface PatternReportRow {
  field: string;
  field_label: string;
  value: string;
  value_label: string;
  count: number;
  basis: string;
  of: number;
  pct: number;
  generation: string;
}

export interface PatternReport {
  entity: Domain;
  size: number;
  size_basis: string;
  rows: PatternReportRow[];
  scenario_keys: { key: string; label: string }[];
  scenarios: { values: Record<string, string>; label: string; count: number; pct: number }[];
}

export interface ScenarioList {
  dimensions: { key: string; label: string }[];
  rows: number;
  scenarios: { values: Record<string, string>; label: string; rows: number; share: number }[];
  more: number;
}

export type FilePattern =
  | { kind: "saved"; id: number; name: string; entity: string; members: number }
  | {
      // Several scenarios of one pattern, written into one file.
      kind: "scenarios";
      name: string;
      entity: string;
      scenarios: { pattern_id: number; label: string; count: number }[];
      members: number;
    }
  | {
      kind: "live";
      name: string;
      domain: Domain;
      pattern: DiscoveredPattern;
      filters: PatternFilters;
      k: number | null;
      claimType: string | null;
      members: number;
    };

/** The part of an export request that names a pattern. */
export function patternRequest(
  chosen: FilePattern | null,
  newMembers: number,
): Record<string, unknown> {
  if (!chosen) return {};
  if (chosen.kind === "saved") return { pattern_id: chosen.id, members: newMembers };
  if (chosen.kind === "scenarios") return { scenarios: chosen.scenarios };
  return {
    members: newMembers,
    pattern: {
      profile: chosen.pattern,
      domain: chosen.domain,
      filters: chosen.filters,
      k: chosen.k,
      cluster_id: chosen.pattern.cluster_id,
      claim_type: chosen.claimType,
    },
  };
}

export interface FilePatternOption {
  pattern_id: number;
  name: string;
  domain: Domain;
  member_count: number;
  saved: boolean;
  origin?: string;
}

export interface SavedPattern {
  pattern_id: number;
  name: string;
  entity: string;
  member_count: number;
  pct_of_population: number;
  silhouette: number;
  group: string;
  plan_category: string;
  plan: string;
  product: string;
  saved_at: string;
  /** "user_defined" for a pattern somebody defined by its rules. */
  origin?: string;
}

export interface SaveResult {
  pattern_id: number;
  saved: boolean;
  name: string;
}

/** The rules a requirement states, and the words each was read from. */
export interface StoryReading {
  story: string;
  entity: Domain;
  rules: Record<string, PatternCondition>;
  found: { feature: string; label: string; rule: PatternCondition; from: string }[];
  count: number | null;
}

/** A story is a line of prose. The analyzer reads and matches them as text. */
export interface StoryParsePayload {
  stories: string[];
  column_used?: string | null;
  filename?: string | null;
  warning?: string;
}

export interface StoryCandidate {
  pattern_id: number;
  name: string;
  match_score: number;
  match_count?: number;
  member_count?: number;
  group?: string | null;
  plan_category?: string | null;
}

export interface StoryMatched {
  index: number;
  story: string;
  data_type: string;
  volume: number | null;
  keywords: string[];
  confidence: number;
  matched: boolean;
  candidates: StoryCandidate[];
}

export interface StoryMatchPayload {
  stories: StoryMatched[];
  warning?: string;
}

export interface Layout {
  id: number;
  name: string;
  kind: string;
  delimiter: string | null;
  status: string;
  purpose: string;
  sample_name: string | null;
  created_by: string | null;
  created_at: string;
  approved_by: string | null;
  approved_at: string | null;
  n_fields?: number;
}

export interface LayoutField {
  name: string;
  is_default?: boolean;
  index?: number;
  start?: number;
  length?: number;
  max_width?: number;
  rule_label?: string;
  type?: string;
  rule_id?: number | null;
  rule_name?: string | null;
  gen_method?: string;
  /** How the rule was found: by its name, an alias, or picked by a person. */
  matched_by?: "exact" | "alias" | "unmatched" | "chosen" | "blank";
  /** Chosen to be written empty, whatever the field is called. */
  blank?: boolean;
  /** The sample's date format, which the written file keeps. */
  date_format?: string | null;
  samples?: string[];
}

export interface FileSource {
  folder: string | null;
  files: { name: string; size: number; modified: string }[];
}

export interface FileProfile {
  name: string;
  kind: string;
  delimiter?: string | null;
  row_count: number;
  error?: string;
  fields: (LayoutField & { empty_rate?: number; distinct?: number })[];
}

/** Picking a rule for a field remembers its name as an alias where it can. */
export interface AliasOutcome {
  aliased?: string[];
  not_aliased?: { name: string; reason: string }[];
}

/** Saving reports what was written, not an id: the name is the identity. */
export interface SavedLayoutResult extends AliasOutcome {
  name: string;
  status: string;
  purpose: string;
  n_fields: number;
  n_default: number;
}

export interface LayoutDetail extends Layout {
  fields: LayoutField[];
  n_default?: number;
}

export interface LayoutEditBody {
  name?: string;
  delimiter?: string | null;
  fields?: LayoutField[];
}

export interface LayoutEditResult extends AliasOutcome {
  id: number;
  name: string;
  status: string;
  n_fields: number;
  n_default: number;
  reapproval_required: boolean;
}

export interface SaveLayoutBody {
  name: string;
  kind: string;
  delimiter?: string | null;
  fields: LayoutField[];
  sample_name?: string | null;
  purpose?: string;
  /** Refuse rather than replace a layout already called this. */
  as_new?: boolean;
}

export interface LayoutParsePayload {
  kind: string;
  delimiter?: string | null;
  fields: LayoutField[];
  sample_name?: string;
  n_default?: number;
}

export interface GenerationRule {
  id: number;
  field_name: string;
  field_label?: string;
  field_category?: string;
  gen_method?: string;
  data_type?: string;
  length?: number | null;
  prefix?: string | null;
  postfix?: string | null;
  start_value?: number | null;
  domain?: string;
  format_pattern?: string | null;
  lookup_source?: string | null;
  /** The element this rule produces; its name is the same. */
  element?: string | null;
  /** A number's measured range and places, for a `range` rule. */
  min_value?: number | null;
  max_value?: number | null;
  decimals?: number | null;
  /** How often each value of `domain` occurs, comma separated, in its order. */
  weights?: string | null;
  /** How a `range` rule's numbers fall between its bounds, as the plan
   *  measured them; mean and deviation are of the underlying normal. */
  distribution?: string | null;
  mean_value?: number | null;
  stddev_value?: number | null;
  active?: boolean;
  /** Names of the layouts that point at this rule. */
  used_by?: string[];
  /** Other column names that mean this element. */
  aliases?: string[];
}

/**
 * The source rows behind one pattern.
 *
 * Not generated data: these are the rows the pattern was derived from, which
 * is what makes its claim about the book checkable. `phi_columns` names the
 * ones carrying personal data — the server sends their real values, so
 * whatever displays them decides whether to show them.
 */
export interface PatternRowsPayload {
  pattern_id: number | null;
  name: string;
  entity: string;
  columns: string[];
  phi_columns: string[];
  rows: Array<Record<string, unknown>>;
  /** Each row's name, aligned with `rows`: what a choice of records sends. */
  keys: string[];
  total: number;
  offset: number;
  limit: number;
  returned: number;
  has_more: boolean;
  truncated: boolean;
  rebuild_ms: number;
}

/** One SNIP level's outcome. */
export interface SnipLevel {
  level: number;
  name: string;
  status: "pass" | "fail" | "warn" | "partial" | "not_checked";
  rules: number;
  errors: number;
  warnings: number;
  notes: string[];
  findings: { level: number; rule: string; message: string; segment?: number; raw?: string; severity: string }[];
}

export interface SnipReport {
  transaction: string;
  version: string;
  segments: number;
  transactions: number;
  partner: string | null;
  passed: boolean;
  levels: SnipLevel[];
  disclaimer: string;
  file?: string;
  /** Another format's report says what it checked in a sentence (no segments, no partner). */
  summary?: string;
}

export interface SnipRules {
  rules: { origin: string; file: string; id: string; transaction?: string; version?: string; name?: string; rules: number }[];
  partners: string[];
  customerDir: string;
}

/** A database onboarded here: read, and perhaps planned and generated into. */
export interface OnboardedDatabase {
  key: string;
  server: string;
  database: string;
  current: boolean;
  planned: boolean;
  /** Rows generated into it that have not been cleaned up. */
  rowsInIt: boolean;
}

/** A pattern to save: the whole of an analyzed one, or chosen records of it. */
export interface KeepPatternRequest {
  domain: Domain;
  filters: PatternFilters;
  k: number | null;
  cluster_id: number;
  claim_type: string | null;
  record_keys?: string[];
  name?: string;
  /** "user_defined" for a pattern somebody defined by its rules. */
  origin?: string;
}

export interface KeptPattern {
  pattern_id: number;
  name: string;
  domain: Domain;
  member_count: number;
  records: number | null;
  /** The saved pattern itself, in the shape an analysis gives one, so it can
   *  be resolved onto the plan for the database route. */
  profile: DiscoveredPattern;
}

/** A target on a server of its own. */
export interface TargetConnection {
  database: string;
  server?: string;
  port?: number;
  /** Windows authentication: no password is stored anywhere. */
  trusted?: boolean;
  user?: string;
  password?: string;
  driver?: string;
  trustCert?: boolean;
}

export interface StoredTarget {
  configured: boolean;
  database?: string;
  server?: string;
  trusted?: boolean;
  user?: string;
  hasPassword?: boolean;
}

/** One EDI transaction set this installation can write. */
/**
 * One place in a sample file, and what generation does with it. How the place
 * is addressed (X12: segment_id, qualifier, position...) is the format's own,
 * carried back unread when the config is saved.
 */
export interface SamplePosition {
  [address: string]: unknown;
  label: string;
  example: string;
  count: number;
  /** What the master config names here, as it names it. */
  config_name: string | null;
  /** The SDM algorithm that makes this position's value; null copies the sample. */
  algorithm: string | null;
  reason: string;
  suggested: string | null;
}

/** What a file is written for: new members, or claims. */
export type SampleSubject = "members" | "claims";

export interface SampleReading {
  /** How the sample is read: x12. */
  format: string;
  /** What it is within that format: 834, 837. */
  kind: string;
  version: string;
  sampleName: string | null;
  basedOn: string | null;
  counts: Record<string, number>;
  /** The counts as one line for the screen. */
  summary: string;
  subject: SampleSubject;
  /** The checks a written file can be run through ("snip"), or none. */
  validation: string | null;
  rows: SamplePosition[];
  algorithms: string[];
}

export interface GenConfigSummary {
  id: number;
  name: string;
  format: string;
  kind: string;
  subject: SampleSubject | null;
  validation: string | null;
  /** The written file's extension, with its dot. */
  extension: string;
  version: string | null;
  based_on: string | null;
  sample_name: string | null;
  created_by: string | null;
  created_at: string;
  positions: number;
}

export interface EdiFormatSummary {
  id: string;
  name: string;
  transaction: string;
  subject: string;
  version: string;
  description: string;
}

export interface DatabaseRow {
  name: string;
  online: boolean;
  isSource: boolean;
  isStore: boolean;
  isTarget: boolean;
}

export interface DatabasesPayload {
  databases: DatabaseRow[];
  source: string;
  store: string;
  target: string;
  server: string;
}

/** A unit of work too long to hold a request open for. */
export interface Job {
  id: string;
  kind: string;
  label: string;
  state: "running" | "done" | "failed" | "canceled" | "none";
  done: number;
  /** Null until the worker knows how much there is to do. */
  total: number | null;
  note: string;
  elapsed_seconds: number;
  /** Null until enough has finished to measure a rate. */
  eta_seconds: number | null;
  result?: BaselineResult | null;
  error?: string | null;
}

export interface BaselineResult {
  entity: string;
  combinations_enumerated: number;
  combinations_processed: number;
  combinations_skipped: number;
  combinations_failed: number;
  total_patterns: number;
  total_count: number;
  thresholds: BandThresholds | null;
  capped: boolean;
}

export interface BandThresholds {
  n_patterns: number;
  p20: number;
  p50: number;
  p80: number;
  p95: number;
  max: number;
}

export interface BaselineRow {
  entity: string;
  scope_key: string;
  scope_label?: string;
  n_patterns: number;
  total_count: number;
  computed_at?: string;
  [key: string]: unknown;
}

export interface BaselinePayload {
  baselines: BaselineRow[];
  computed: boolean;
  note: string;
}

export interface BaselineEstimate {
  entity: string;
  max_depth: number;
  combinations: number;
  seconds_per_combination: number;
  estimated_seconds: number;
}

export interface RulesPayload {
  rules: GenerationRule[];
  n_active: number;
  lookups: string[];
  /** method -> what it does, in the server's words. */
  methods: Record<string, string>;
}

/** One generated column, as the plan describes it, before it has a rule. */
export interface SeedColumn {
  column: string;
  table: string;
  element: string | null;
  generator: string;
  method: string;
  data_type: string;
  label: string;
  category: string;
}

export interface SeedPayload {
  columns: SeedColumn[];
  missing: SeedColumn[];
  n_columns: number;
  n_existing: number;
  n_missing: number;
}

export interface NewRule {
  field_name: string;
  field_label?: string | null;
  field_category?: string;
  gen_method: string;
  data_type?: string;
  length?: number | null;
  prefix?: string | null;
  postfix?: string | null;
  start_value?: number | null;
  domain?: string | null;
  format_pattern?: string | null;
  lookup_source?: string | null;
  min_value?: number | null;
  max_value?: number | null;
  decimals?: number | null;
  weights?: string | null;
  distribution?: string | null;
  element?: string | null;
  mean_value?: number | null;
  stddev_value?: number | null;
}

export interface MaskingAlgorithm {
  id: string;
  label: string;
  description: string;
  needs: string[];
}

export interface MaskingRule {
  id: number;
  name?: string;
  algorithm?: string;
  [key: string]: unknown;
}

export interface MaskingLookup {
  id: number;
  name?: string;
  [key: string]: unknown;
}


/** A claims pattern describes claim lines, so it counts and names differently. */
export interface ClaimsPattern extends DiscoveredPattern {
  n_claims?: number;
  n_members?: number;
  pct_of_lines?: number;
  approval_rate?: number;
  in_network_rate?: number;
  top_diagnoses?: Record<string, number>;
  top_procedures?: Record<string, number>;
  diagnosis_descriptions?: Record<string, string>;
  procedure_descriptions?: Record<string, string>;
}

export interface ClaimsAnalyzePayload {
  subset_claims: number;
  subset_claim_lines: number;
  book_claims: number;
  n_patterns: number;
  method: string;
  silhouette: number | null;
  scope_label: string;
  patterns: ClaimsPattern[];
  distributions?: Record<string, ScopeDistribution>;
}


export interface StoryPlanned {
  pattern_id: number;
  rows: number;
  pattern: string;
  subject: string | null;
  share: number | null;
  targets: PatternTarget[];
  rejections: PatternRejection[];
}

export interface StoryToPlanPayload {
  allocation: Record<string, number>;
  total_volume: number;
  patterns: StoryPlanned[];
  unreadable: number[];
  applied: string[];
}


/** What the book holds, counted the way the claims domain counts. */
export interface ClaimsOverview {
  n_claim_lines: number;
  n_claims: number;
  n_members: number;
  n_diagnoses: number;
  n_procedures: number;
}

export interface CodeCount {
  code: string;
  description: string | null;
  n: number;
}

/** Which half of the data a screen is asking about. Held by the shell, so one
 *  choice follows you across the screens rather than being made on each. */
export type Domain = "members" | "claims";

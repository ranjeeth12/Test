/**
 * What a person calls a FACETS column ("Product ID" for PDPD_ID), from the
 * FACETS data dictionary (scripts/build_facets_names.py writes the list).
 * The column itself where the dictionary has no name for it.
 */
import names from "../facetsNames.json";

const NAMES: Record<string, string> = names;

export function columnName(column: string): string {
  return NAMES[column] ?? NAMES[column.toUpperCase()] ?? column;
}

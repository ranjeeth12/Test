/**
 * The pipeline rail.
 *
 * This product is a sequence — read the database, measure it, match it, decide,
 * plan, generate — so the navigation is that sequence, and the connector line
 * fills as far as the work has actually got. Each step carries its own headline
 * number, which makes the rail a status display as much as a menu.
 */

import type { Domain, Step, StepId } from "../lib/api";
import "./Rail.css";

interface Props {
  steps: Step[];
  active: StepId;
  onSelect: (id: StepId) => void;
  database: string;
  server: string;
  theme: "light" | "dark";
  onToggleTheme: () => void;
  domain: Domain;
  onDomain: (domain: Domain) => void;
  claimsAvailable: boolean;
}

export function Rail({
  steps,
  active,
  onSelect,
  database,
  server,
  theme,
  onToggleTheme,
  domain,
  onDomain,
  claimsAvailable,
}: Props) {
  const reached = steps.filter((s) => s.done).length;
  const progress = steps.length > 1 ? reached / steps.length : 0;

  return (
    <nav className="rail" aria-label="Pipeline">
      <div className="rail__head">
        <div className="rail__mark">SDM</div>
        <p className="rail__tagline">Synthetic Data Management</p>
      </div>

      {/* Shown where it governs something, which is the Patterns step and
          nowhere else. It sat here on every screen, and a control that does
          nothing on eight of nine screens reads as broken rather than as
          scoped -- the first thing anyone did was click it on Plan and
          conclude the switch was dead. */}
      {active === "patterns" && (
      <div className="rail__domain" role="group" aria-label="Domain">
        {(["members", "claims"] as const).map((option) => (
          <button
            key={option}
            className={
              "rail__domain-option" +
              (domain === option ? " rail__domain-option--on" : "")
            }
            onClick={() => onDomain(option)}
            disabled={option === "claims" && !claimsAvailable}
            title={
              option === "claims" && !claimsAvailable
                ? "No claims data in this database"
                : undefined
            }
          >
            {option === "members" ? "Members" : "Claims"}
          </button>
        ))}
      </div>
      )}

      <ol className="rail__steps" style={{ ["--reached" as string]: progress }}>
        {steps.map((step) => {
          const isActive = step.id === active;
          return (
            <li key={step.id}>
              <button
                className={
                  "rail__step" +
                  (isActive ? " rail__step--active" : "") +
                  (step.done ? " rail__step--done" : "")
                }
                onClick={() => onSelect(step.id)}
                aria-current={isActive ? "page" : undefined}
              >
                <span className="rail__dot" aria-hidden="true" />
                <span className="rail__body">
                  <span className="rail__label">{step.label}</span>
                  <span className="rail__detail num">
                    {step.detail || (step.done ? "done" : "not run")}
                  </span>
                </span>
              </button>
            </li>
          );
        })}
      </ol>

      <div className="rail__foot">
        <button className="rail__target" onClick={() => onSelect("connect")}>
          <span className="rail__target-db mono">{database}</span>
          <span className="rail__target-server">{server}</span>
        </button>
        <button
          className="rail__theme"
          onClick={onToggleTheme}
          title={theme === "light" ? "Switch to dark" : "Switch to light"}
        >
          {theme === "light" ? "Dark" : "Light"}
        </button>
      </div>
    </nav>
  );
}

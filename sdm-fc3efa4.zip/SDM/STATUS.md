# STATUS — where SDM stands

**The only current-state doc. Read this first, then `README.md` for how the
thing works.**

Last updated 2026-10-15, on branch `merge-pattern-analyzer`.

**Resume here (2026-10-15, later): customer feedback on patterns.** (1) the
analysis must speak to age, demographics, claim amount, procedure and
diagnosis codes, plan and product, with **counts and %** at pattern and
scenario level, exported on **one tab**; (2) generation must follow the
pattern (same plan, product, group, demographics); (3) customers cannot tell
what the pattern fields are or how generation uses them. User decisions: a
scenario is **one row** (count, % of pattern), never a breakdown; **nothing
hidden**, not even a scenario of one (rare can be important), unless it is
a performance problem. Done for (1) and (3): `pattern_report.py` (every
field and value with count, out of, basis members/claims/claim lines, %, and
a `GENERATION` note of what generation does today; a member pattern also
counts its members' claims in aggregate -- has claims, amount bands, claim
type, diagnosis, procedure; a claims pattern its patients and plan; codes
described via `CODE_NAMES`); member home ZIP/city/state from
`sdm.member_address` (HOME) joined in `data_loader._home_addresses` (empty
locally: the 837 extract fills it at a customer); `POST /api/patterns/report`
and `/api/patterns/report.xlsx` (one sheet, `SHEET_COLUMNS`); Patterns
screen "Download counts (one sheet)" + card "Counts and %"
(`PatternCounts.tsx`); `export_patterns.cmd` now writes the same single tab
for saved patterns (tags as rows). Fixed: scenarios were counted from the
rows view capped at 20,000 rows (`pattern_data.every_row`, uncapped). Tests
`tests/test_pattern_report.py` (6), browser 2c. Run guide rebuilt. Then
(user) the fields counted are chosen on the Config screen: "Fields counted
in patterns" (`ReportFieldsConfig.tsx`, `report_fields.py`, table
`sdm.report_fields`, `GET/PUT /api/report-fields`): defaults are the built-in
fields, any can be switched off, any denorm column added (`col:<COLUMN>`;
personal columns not offered; a date counted by year, a number with >30
values in ten quantile bands; marked "No: counted only"; read back for the
pattern's rows by MEME_CK / CLCL_ID+CDML_SEQ_NO). Tests now 8, browser 2h. Then
(2) generation follows the pattern: a member pattern carries `enrollment`
(GROUP_KEY + COVERAGE_PLAN_ID + PRODUCT_CODE records with shares,
`profiler._enrollment`; bridge record_group "enrollment", so the scope's
even plan list no longer applies) and every number its `deciles`
(member profiler and claims profile); bridge `_slices` makes ten [low, high,
share] `bands` on PatternParameter; files (`elements.pattern_rules`) and DB
plans (`plan.patterns`) put them on the date window (DOB, effective date)
or number range (charge); `engine/rules.py` passes `bands`; generators
`number` and `date_relative` draw a slice by its share, then within it.
Measured: 3,000 members' age deciles match the pattern's within a year,
plan/product pairs always a real pair in the pattern's shares, claim line
charges at the pattern's deciles. `GENERATION` notes and the run guide
updated. `tests/test_pattern_follows.py` (7). Still not followed: family
(dependents, spouse rate), a member pattern's claims mix (a member
pattern's file has one claim per member), allowed/paid/copay/coinsurance and
place of service (no catalog elements), claims patterns' member age/sex
(claims go to existing members). Patterns saved before this keep the old
even draws until saved again. Then (user) export from the screen:
Counts and % panel "Export" (Excel one tab or CSV, exactly what the panel
shows) and Discover > Kept patterns checkboxes + "Export N chosen" / "Export
all" (`/api/patterns/report.xlsx` now takes `cluster_id`/`pattern_id` + `name`
for one pattern, `pattern_ids` for kept ones, `format` xlsx|csv;
`pattern_report.csv_text`); `export_patterns.cmd` stays for use without the
tool running. A member pattern's enrollment is set only on the member's own
table in a DB plan (`plan.patterns`: record_group enrollment refused below
the subject -- it had drawn PDPD_ID afresh on each claim). **Next:
(2), generation follows the pattern** -- plan/product/group by their shares
(file and DB), age and claim amount by their spread (not even between min
and max), location, family, a member pattern's claims mix, allowed/paid/
copay/place of service; as each lands, update `GENERATION` and the guide's
table.

**Resume here (2026-10-15): synthetic files from a sample -- X12, FHIR,
HL7 v2 and CDA on one engine.** CDA built: `cda.py` (XML reader on lxml:
masking-config XPath-shaped paths, `//`, `@attr`, `valuePrefix`, `where` on
an element's other attributes; URI schemes kept, HL7 v3 timestamps keep the
sample's precision/time/zone, displayName follows a code or is written from
the profile's `display`) + `profiles/cda.json` (structural elements and
attributes, `qualified` id/@extension by root, `member.under`/`except`,
places, `checks.required`/`checks.codes`, SEX codes M/F/UN),
`cda-document.json` (a document per member, rename id and setId) and
`cda-ccd.json` (LOINC 34133-9). Master = edi-mask CDAR2Config.json as is;
sample = edi-mask ccd-example.xml (`tests/fixtures/cda`). A written CCD
differs from the sample only at the chosen places. Download = zip of
documents (format modules may now provide `package` + `TEXT_MEDIA`;
ExportRequest `packaged`, false for the preview and `/api/samples/check`).
`cda.check` + button "Run CDA checks". JSON-with-comments reading moved to
`base.without_comments` (was duplicated in segments/fhir). lxml declared in
pyproject (already in requirements via python-docx: no new wheels). Tests
`tests/test_sample_cda.py` (9), browser 5d. Then (user: documents share the
sample's layout, same rules for all, however many): a member gets a document
per claim (`member` unit grouping `document` units by CLAIM_ID; subject
claims); new generic engine piece `Values.levels` -- a unit's places can be
filled from an enclosing unit's record and row -- used by the CDA profile's
`levels` (recordTarget = the member's) so all of a member's documents agree;
header dates = that day's SERVICE_DATE. How many documents (user: one
claim can have several; the data is synthetic, so the count must follow
from the claim, never be configured or come from an invented field): one per
day of service -- a unit's `group` may name several elements (engine `by`:
runs of the first split by the others, in first-seen order), and the document
unit groups by ["CLAIM_ID", "SERVICE_DATE"]. Office visit 1, five-day stay 5;
no dates 1; member records 1 per member. (A DOCUMENT_ID field was tried and
dropped: CDA identifies a document itself, and claims data never has one.)
Then procedures from the pattern: the document unit has a `line` unit `in`
the procedures section's entries (`where` section code 47519-4): an entry per
claim line of the day, the sample's entries taken in turn, with the line's
PROCEDURE_CODE (profile `codes` `systems`: HCPCS if it starts with a letter,
else CPT), the line's date, a new UUID id (engine `rename` `{uuid}`, derive
rules may name a `unit`); a generated code drops the sample's displayName,
translations and originalText. New profile key `within`: places inside a
section carry `section=<LOINC>`, so the same path in two sections takes
different algorithms. Then the procedures table: the line unit's
`narrative` (`reference` = the entry's text/reference, `cells` said from the
entry, null = the sample's) -- the sample's rows come out with their entries
and are written again per entry, ids numbered (Procedure1..n) and the entry's
reference pointing at its row: `99213 (CPT)`, `05 Mar 2026 10:30am`.
`tests/test_sample_cda.py` now 13. X12 still byte-identical on the 66 cases.
Then a procedure entry no longer carries the sample's procedure details:
derive rules (unit line) drop methodCode/targetSiteCode and the observation
value's code, and a new engine op `set` (fixed value; `on` = the element that
must be there; CDA adds a missing attribute) makes it nullFlavor UNK; a code
left empty is written `<code .../>`.
**CDA gaps:** diagnoses (the sample's problems section is empty); the table
names a code, not its description (claims have none); other sections keep
the sample's dates; the
patient's telecom has no SDM algorithm (phone/email); not
schema/Schematron validated.

**Earlier 2026-10-14, late: HL7 v2.** HL7 v2 built: `segments.py` now holds
what X12 and HL7 v2 share (the masking tool's segment config, proposals,
filling, the segment reader); `x12.py` and `hl7v2.py` are syntax only
(parse, envelope, field numbering: HL7's MSH counts MSH-1, labels PID-5.1;
repetitions `~` filled, the first from the record). Profiles `hl7v2.json`
(places, `member.segments` PID/IN1, codes for PID-8 and IN1-17),
`hl7v2-adt.json` (a message per member), `hl7v2-dft.json` (a message per
claim, FT1 per line; new unit key `while`, and the engine's `after`: a
unit's segments after its children, written once). X12 moved onto
`segments.py` still byte-identical on the 66 cases. Master = edi-mask
HL7v251Config.json as is; samples edi-mask adt_a01 / dft_p03 / oru_r01
(ORU refused: no profile). Tests `tests/test_sample_hl7v2.py` (6, incl. a
pattern's members as ADT via the API). FHIR checks added the same day:
`fhir.check` (fhir.resources 8.3 R4B models + references + profile
`checks.codes`), `/api/samples/check`, button "Run FHIR checks";
fhir.resources/fhir_core added to pyproject, requirements-runtime.txt and
requirements.lock (pure Python; wheel parts rebuilt 2026-10-15, both sets, with fhir.resources, fhir_core and lxml in them; built
with scripts/package_wheels.py). HL7 checks added 2026-10-15: `hl7v2.check`
(structure: segment ids, delimiters, `message.required` segments per kind,
`checks.fields`, batch counts; MSH-10 unique; `checks.dates` as HL7 DTM;
`checks.codes` tables 0001/0063/0103), button "Run HL7 checks", browser 5e,
`tests/test_sample_hl7v2.py` now 8. **HL7 gaps:** the edi-mask
DFT sample leaves FT1 procedure/amount empty, so a DFT from it generates
only dates (a real sample would carry them); PID-3's first repetition
takes the member id whatever its CX.5 type says; no ORM/SIU profiles.
ORU added 2026-10-15 (`hl7v2-oru.json`, profile only, no code): a message
per claim, an order (ORC..CTI) per claim line, OBR-1 indexed, ORC/OBR-2/3
renamed per order, OBR-7/OBX-14 = SERVICE_DATE, OBR-4 = PROCEDURE_CODE where
the sample has one (edi-mask's has not); OBX-5 values the sample's. Tests
`tests/test_sample_hl7v2.py` now 9. Customer zip `dist/sdm-e031ca1.zip`
built (before ORU).

**Earlier 2026-10-14: X12 and FHIR on one engine.** FHIR R4 built: `fhir.py` (JSON
reader: masking-config paths + `where`, Bundle entries, references,
JSON types, Coding display dropped when its code is generated) +
`profiles/fhir.json`, `fhir-members.json` (Patient + what follows),
`fhir-claims.json` (Patient > Claim|EOB > item[*]); new generic engine ops
`rename` (new id per resource written; Type/id refs and fullUrls follow)
and `drop` (sample narrative, name/address .text); `engine.fit` also
writes ISO dates. Structural fields are profile config too. Samples
`tests/fixtures/fhir` (built from edi-mask examples: Organization, Patient,
Coverage, Claim linked; master = edi-mask FHIRR4Config.json as is). Tests
`tests/test_sample_fhir.py` (10, incl. pattern export via API), browser 5c.
Tab now "From a sample", labels neutral, SNIP button only for X12. X12
still byte-identical on the 66 recorded cases. **Gaps:** no FHIR validator
(fhir.resources is not installed; adding it means new wheels for the
customer -- ask); name.text/address.text are said again from the parts
written (fhir.json `texts`, 2026-10-15) where the sample has one; a
second given name or maiden name takes a rule value, not the record's;
EOB totals (an array) are not summed; the client's own FHIR samples not yet
seen. Next: HL7 v2 (segment reader; master edi-mask HL7v251Config.json
`maskSegments`, samples edi-mask samples/hl7), then CDA (XML reader).

**Earlier 2026-10-14: refactor done, FHIR next.** From the client meeting (Data Masking and
Synthetic Data demo): they run Synthea (open source; member/provider/claim
only) and their own tool (HL7 v2/v3 built, FHIR basic, template/LLM based);
Safe Harbor audit findings push them to synthetic data. What interested them:
no LLM, volume, and file formats -- HL7 v3 (XML) and FHIR (JSON) -- with
consistent data. The user's design: the same as EDI -- a sample file, a config
of path + algorithm, everything else copied. Decided 2026-10-14: refactor
first (done), master configs are the masking tool's (edi-mask
`configs/FHIRR4Config.json` `maskResources`/`maskPaths` with `where`,
`HL7v251Config.json` `maskSegments`, `CDAR2Config.json` XPath `maskPaths`),
no client samples -- use edi-mask `samples/fhir`, `samples/hl7`,
`samples/cda`. The user's requirement: the SAME framework for EDI, HL7 and
FHIR, only config differing. Done for X12 (2026-10-14): `engine.py` (one
engine: units, records, derive), `x12.py` (reader: syntax only),
`profiles/x12.json` + `x12-834.json` + `x12-837.json` (loops, places,
units, derive: sequence/index/sum) + `masking-names.json`. Proven
byte-identical to the code it replaced on 66 recorded cases (proposals,
configs, files, errors); a profile edit alone removes CLM02's sum or adds a
kind. Before that, the first refactor: `sdg/writers/samples/` (`__init__`
registry + `detect`, `base.py`, `x12.py` = the former `edi_sample.py`); table
`sdm.sample_gen_configs` (format, kind) replaces `sdm.edi_gen_configs`
(empty everywhere; the old table is left where it exists, unused); API
`/api/samples/read`, `/api/samples/configs`; export format `sample:<id>`;
screen `ui/src/views/FromSample.tsx` (labels unchanged: "EDI from a sample");
tests `tests/test_sample_x12.py` (15). Next, in order: FHIR R4 = a JSON
reader (paths + `where` as edi-mask FHIRR4Config) + a profile (CARIN Blue
Button: Patient, Coverage, ExplanationOfBenefit; units = Bundle entries;
new derive ops as needed -- references by fullUrl regenerated together,
codings' display following the code, totals from items; validation via
`fhir.resources`), then HL7 v2 (segment reader close to X12's), then CDA /
HL7 v3 (XML reader: XPath, namespaces). Any new derive op goes in the engine,
never in a reader. Rename the tab "From a sample" when FHIR lands.

**Before that (2026-10-12): phase 2, EDI from a sample, built (local only).**
Generation > Files > *EDI from a sample*: (1) choose a sample 834/837 and a
master (the masking tool's config, a saved generation config, or none);
*Read the sample* lists every position with the algorithm proposed from the
master's name or the position's place; accept or change; *Save config as*
(new name, master never changed; `genSegments`, stored with its sample in
`sdm.edi_gen_configs`). (2) choose a saved config: show, write, SNIP-check,
remove. Everything not generated is copied from the sample; HL/LX renumbered,
CLM02 summed, SE counted, X12 codes from the shipped descriptions (INS01/02,
DMG). Code `sdg/writers/edi_sample.py`, `sdg/analyzer/services/edi_gen_configs.py`,
`ui/src/views/EdiFromSample.tsx`; tests `tests/test_edi_sample.py` (12) and
browser 5b. The new table is in `customer-tables` and `setup_tables.sql`.
**Known gaps:** a dependent's 837 (patient HL 23) writes the patient's own
values into the subscriber (IL) loop -- a claim record carries only the
patient; only the first transaction and the first billing provider of a
sample are modeled; 835 is not modeled on a sample; a customer sample has not
been tried yet (fixtures are the masking tool's demo 837s and an SDM 834).
Next: try it with a real sample from the customer, then the open items below.

**Before that (2026-10-11): environments baselined.** `ENVIRONMENTS.md` is
now the one page for this machine (local), the demo laptop (the other
laptop) and the customer: what each runs, its `.env` template, which scripts
are allowed, how an update reaches it, and the customer baseline (tag
`customer-baseline-2026-10-09` = `049b0c3`). The demo scripts (seed,
bootstrap, first-run, upgrade, demo) now refuse on a customer machine
(`SDG_ENV=customer`, or a pattern store on its own server):
`sdg.cli.main demo-check`, install scenario 5. `.env` templates:
`.env.example` (local / laptop, `SDG_ENV`), `scripts/customer/customer.env.example`.
Every zip carries `VERSION.txt`. A build for the demo laptop was made from
this commit (see `dist/`); the customer gets whole zips from now on, never
`upgrade.cmd`. Next: ask how the laptop upgrade went and what came back from
the customer, then the open items below.

**Before that (2026-10-09): the customer is live for pattern analysis. FACETS loaded into all 23 denorm tables, UI working, patterns being found, saved and exported.**

- **Customer setup (as of 2026-10-09):** FACETS database `FACPRDDB` on
  server `INT_69` (production: only ever read); SDM platform database
  `TDMCFG`, schema `sdm`. Configured for **pattern analysis only**: no
  Connect / Read the database, no generation. `SDG_DB_TARGET` must never be
  FACPRDDB; until a test database is agreed it names one that does not exist.
  At the customer: only `setup_tables.cmd`, `extract.cmd`, `ui.cmd`,
  `export_patterns.cmd`; never `upgrade.cmd`, `first-run.cmd`, `seed.cmd`,
  `bootstrap.cmd`. The user takes updated scripts directly (no zip, no build
  there); send files with SendUserFile.
- **Python there:** the first machine is 3.14 free-threaded (parts
  `dist\sdm-wheels-cp314t.*`); a second machine is regular 3.14.3 (parts
  `dist\sdm-wheels-cp314.*`, rebuilt 2026-10-15; cp314t too). "Missing wheels" = wrong set
  for that Python; `scripts/package_wheels.py --python 3.14 [--free-threaded]`.
- **Fixed for their FACETS release (2026-10-08/09):** COB reason codes
  (`CLCB_`/`CDCB_COB_REAS_CD`) not in their release, left NULL; provider_network
  only the networks of plans in scope (the full roster dropped the connection);
  `claims_header_ext_denorm` values longer than the SDM columns cut
  (`CLCL_PA_ACCT_NO` to 35, `CLMF_EXT_REFRAL_NO` / `CLMF_EXT_PREATH_NO` to 18).
  UI was blank: their Windows registry maps .js to text/plain; `app.py` now
  registers the real types. README: set `SDG_DB_REF` / `SDG_DB_TARGET` (the
  .env.example names FACETS_QA / MDM_REF do not exist there).
- **Added 2026-10-09:** `scripts\customer\export_patterns.cmd` writes every
  saved pattern to Excel -- since 2026-10-15 one sheet (`pattern_report`):
  values with counts and %, scenarios one row each, tags. Customer run guide (pattern analysis only, from `ui.cmd`):
  `docs\customer\SDM Pattern Analysis - Run Guide.docx`, built by
  `docs\customer\make_run_guide.py`; rebuild it when a Patterns screen
  changes. Walk the book: Keep on Claims saved a member pattern (it went
  through the member analyzer); it now marks saved the row the walk stored
  (`/api/discovery/save`). Sent them `ui\dist`; member patterns kept by
  mistake are theirs to Remove.
- **Teammate copy:** copy the SDM folder without `.venv`, `wheels`, `dist`,
  `exports`, `.git`; blank the user/password lines in `.env` (they are the
  user's credentials). The teammate runs `setup_offline.cmd` with the parts for
  their Python, then `ui.cmd`; never `extract.cmd` or `setup_tables.cmd`.
  Patterns live in TDMCFG, so everyone sees everyone's saved patterns.
- **What a saved pattern holds:** scope, profile (value mix, ranges, codes,
  places, counts) and member keys, in `sdm.patterns.profile_json`; not the
  rows. After a refresh the profile stays; rows are re-read and members no
  longer eligible drop out. No tracking of who requested what (user said no).
- **Open, waiting on the user (do not act unasked):** `plan_benefit_denorm`
  (4.5M rows) and `plan_accumulator` (4.2M) cuts, pending the breakdown
  query result; providers cut to those on claims plus PCPs (provider tables
  1M+), yes/no; "(blank)" label on pattern cards; phase 2 EDI from a sample
  file built locally 2026-10-12 (above), not yet at the customer.
- **Ship:** `dist\sdm-<commit>.zip` from `python scripts/package.py`. The
  user's laptop was set up from the 2026-10-03 zip; it moves to this version
  with `scripts\upgrade.cmd` (DEPLOY.md, "Upgrading a machine already set
  up"). Whether that upgrade has been run there, and any errors from it, is
  the first thing to ask.
- **This machine:** work/ is on `MaskingDemo`, read and planned by the user
  (4 tables, 46 rows planned, 14 columns waiting in Review). MaskBench's files
  are set aside under work/databases; FACETS_QA was offboarded and needs Read
  the database if chosen. Saved patterns 84, 85, 86, 87 are the user's.
- **Next, if wanted:** a target on a second SQL Server (never exercised),
  matching by hand on an empty target in Review, auth before anyone else uses
  it. GitHub push still waits on the user (below).
- **Rules learned the hard way today:** never run a setup script against the
  live machine to try it; tests delete only rows they created; the suite
  fails if a saved pattern it did not create is touched.

**Latest, 2026-10-07 (night): ready for the customer install (2026-10-08).**
Runbook: `scripts/customer/README.md` (settings for two servers, scripts
00-03, `extract.cmd`, checks; never `upgrade.cmd`/`first-run.cmd` there --
an extract empties the denorm). FACETS is on another server: the tool's
extract reads FACETS (SDG_MSSQL_* / SDG_DB_SOURCE) and writes the SDM
platform database (SDG_DENORM_*). `sdg/extract/definitions/FACETS.sql`: one
SELECT per table over real FACETS tables only (64 tables, 1,178 column refs,
all in the data dictionary) for member_denorm (member x product category,
span in force today else latest), claims_denorm (claim line) and the 21 `03`
tables. Extract: TRUNCATE (DELETE fallback) + fill in one transaction per
table, `--keep-going` keeps a failed table's rows and reports it, progress
every 100k rows, `sdm.extract_log` stamped and folded into the cache
fingerprint. Test of the whole path: `tests/test_facets_extract.py` with
`tests/facets_dd.py` (FACETS built from `tests/fixtures/facets_dictionary_tables.json`).
Generation now keeps the member's plan: claim combinations are conditioned on
ancestors up to four levels (the subscriber's plan) and the engine carries a
row's ancestors; an empty network passes key checks (out of network). Checked
on a run: product = plan's 100%, in-network provider in the plan's network
100%, out of network 15% with no network. Also: plan schema accepts ranged
histogram bins; validation value lists de-duplicated and capped under SQL
Server's 2,100 parameters; error messages skip SQL warnings (`plain()`).
Network tables are reuse; CMC_MEPR_PRIM_PROV excluded from generation (PCP
assignment for new members not generated yet). Tests: quick 725 + touched slow
40 green; the user agreed to run the full suite only before a zip.

**Earlier, 2026-10-07 (later): Configure and Algorithms; provider and
network features.** Top menu (app bar, apart from the rail): **Configure**
chooses the features system discovered patterns are clustered on, per
entity (`sdm.discovery_features`, `sdg/analyzer/services/discovery_features.py`,
defaults age/tenure/gender/marital and member age/charge/gender/claim type;
the choice is folded into the cache fingerprint and clears memory caches);
**Algorithms** is the rule repository (each business element and its
algorithm). Provider features are joined, never added to the customer's
denorms (`sdg/analyzer/provider_features.py`): members get PCP / PCP
specialty / PCP type from `member_pcp` + `provider_denorm`; claims get
provider type, network name and type from `provider_denorm` /
`provider_network`, plus PRPR_ID, specialty, NWNW_ID, in/out. Demo FACETS now
has networks (`seed/networks.py`: CMC_NWNW_NETWORK, CMC_NWPR_RELATION,
CMC_NWST_NET_SET, CSPI.NWST_PFX, CLCL.NWNW_ID, CMC_MEPR_PRIM_PROV): a claim is
in network exactly when its provider is in one of the member's plan's networks
on the service date (verified: 100% / 0%). The store creates the 837 tables
from scripts/customer/03 and the demo extract fills provider_denorm,
provider_network, plan_network, plan_denorm, member_pcp. Generation:
NETWORK_ID element; combinations tie PROVIDER_ID + COVERAGE_PLAN_ID +
NETWORK_INDICATOR + NETWORK_ID (empty network kept as None = out of network);
kept combinations are re-weighted (IPF, `_raked`) so each feature's mix is
the store's -- before this the kept head was 93% dental and 1% out of network.

**Earlier, 2026-10-07: phase 1 of the four asks (2, 3, 4; EDI-from-sample
is phase 2).** (2) Map & Review's editor: a column is given a business
element and the element's rule is used (the editor sends generator null, so
the catalog rule wins in `resolve_column`); only "Custom (no business
element)" shows the algorithms. "Change" is offered on columns with no rule
yet. Layout fields: "Custom — a rule of its own…" makes a repository rule
named for the field and opens the shared `RuleForm` (lifted out of Rules.tsx)
under it; a bound field has a Rule button. (4) `sdg/discovery/errors.py`
`plain()` turns SQL Server errors into sentences (login, certificate, missing
database/table/column, driver, network, permission, truncation...) and is
used by every API error path, a catch-all handler, and connection checks;
a dropped (archived) layout's name can be reused (the archived row is renamed
"<name> (archived <id>)"); one unreadable file no longer fails a folder's
profile; a folder pasted in quotes is accepted. (3) FACETS sources for an
837-consistent store: docs/facets-837-sources.md, scripts/customer/03 and 04.

**Earlier, 2026-10-06 (later): one generation framework.** The engine's
generators (`sdg/engine/generators`) are the only algorithms. A repository
rule is read as one of them by `sdg/engine/rules.py` (constant->constant,
sequential->sequence with prefix/width, random->pattern \d{n}, lookup->lookup
or street_address, range->number, pattern->pattern, date->date_relative with
days either side, formatted->template, default->blank); `rule_values.produce`
is a thin wrapper, so files, EDI and layouts run the same code as a database
load. New engine generators `street_address` and `template` (in the plan
vocabulary too). Fixed: STREET_1, first/last names, ZIP/city/state/county
(lookup tables were never read for files), combo: rules (diagnosis+procedure,
claim type, group/plan/product, marital+relationship -- read from the store's
combinations), forward date windows (seeded as min/max days), formats with
classes/alternation/ranges ([MDSP] came out "[MDSP]"), zero-filled counters,
integer ranges, claim totals (`sum:ELEMENT`, totalled over a claim's lines in
`elements.claims_for`). Removed the dead duplicates `rule_fields.py` and
`generation_rules.generate_*`; `generation_rules` now only reads the lkp_
lists. Rules screen: prefix/width, template/email domain, date From/To days,
and Try it (`POST /api/rules/sample`). Tests: `tests/test_rule_framework.py`
(every method; the engine is the only implementation; every active rule in
the repository makes a value) and browser 2e. Java algorithm service parked
by the user.

**Earlier, 2026-10-06: Find Patterns; American English.** On Requirement
matching, "Find Patterns" reads the requirement and runs pattern analysis at
once (`PatternsAnalyze autoRun`); no Measure / Clusters / Edit-as-defined steps.
With no rules read it analyzes the whole population. British spellings were
changed to American across UI, API, code, docs and tests (analyze, canceled --
job state too --, enrollment, catalog...); `CancelledError` kept.

**Earlier, 2026-10-05 (night): the store is the customer's SDM platform
database.** The customer's `sdm.member_denorm` / `sdm.claims_denorm`
(SDM_Platform.txt; copy in `tests/fixtures/customer_sdm_platform.sql`) are
the store's shape, column for column, and are never altered there. (1)
Settings: `SDG_DB_DENORM`, `SDG_DENORM_SCHEMA`, `SDG_DENORM_SERVER/PORT/USER/
PASSWORD/DRIVER/TRUSTED/TRUST_CERT`, each falling back to `SDG_MSSQL_*`;
`settings.store`, the registry's "denorm" role and every `sdm.` in SQL go
through them. A store on another server is only checked as reachable, never
created. (2) `seed/ddl_denorm.sql` is the customer DDL, guarded; a table with
a `source` column (the previous version's own extract) is replaced. Indexes
are separate (`seed/denorm_indexes.sql`), applied only to a store of our own.
`ddl_sdm.sql` is add-only. (3) No source column: an extract empties and
refills. No MEME_ID or addresses in the store: a member ID is SBSB_ID +
2-digit MEME_SFX, and ZIP/city/state come whole from `lkp_zip_city_state`
(files and `to-plan`, up to 1,000 spread across the list). (4) The platform's
tables have plain int ids and no defaults: `db.insert_row` assigns the id
under UPDLOCK/HOLDLOCK and stamps created_at/updated_at. (5) Demo seed now
uses Facets codes: MEME_REL M/S/D/P, CSPD_CAT M/D, SSN 9 digits, MEME_SFX,
MEME_ID = SBSB_ID + suffix. `upgrade.cmd` rebuilds a previous-version
FACETS_QA at its own size (`bootstrap.py --previous-source`). (6) Catalog
aliases SVC_CD and IPCD_ID for PROCEDURE_CODE (the customer names it IPCD_ID),
MCTR_SPEC, LOW_SVC_DT. (7) Customer scripts: `scripts/customer/` (00 check,
01 add-only upgrade, 02 optional indexes, README with .env). The test
`tests/test_customer_store.py` builds the customer DDL, runs 01 and drives the
tool against it.

**Earlier, 2026-10-05 (evening, second pass): every dependent combination; a
requirement analyzed; a pattern's scenarios.** (1) `sdg/plan/combinations.py`
measures the pattern store: for each pair of coded features in claims_denorm
or member_denorm, the share of an independent draw that would land on pairs
never held (cells expected >= 5); > 5% is dependent; dependent pairs are
union-found into groups, DIAGNOSIS_CODE+PROCEDURE_CODE always together. Found
in this store: claim type + plan + group + diagnosis + procedure + product;
marital status + relationship; plan + group + product + subgroup.
Diagnosis/procedure on their own are NOT dependent here (11,995 of 12,000
pairs occur) -- the earlier "99,592 unseen" was the plan inventing procedure
codes from a regex. Each group keeps its 2,000 commonest combinations plus the
commonest one holding each value (`_covering`, so no value becomes
unreachable). The plan build (`_draw_combinations`, builder revision 4) draws
each group where its free columns sit in one table or a table and its parents
(two levels), deepest table first; the child draws `given` the parent's
values; `within` keeps reference columns to their table's keys; columns chosen
by hand or tied to their parent row are left. `points_at()` makes a
combination column count as pointing into its table (excluded-table check,
attribute narrowing, attribute loading); the engine applies filter_attribute
to such draws. Patterns carry `combinations` (hierarchy keys left to the
scope); validation's `combination` check reads every group back (joined to
the parent) against the store. Measured groups are cached per store and size.
(2) `story_reading.py` reads a requirement locally into a pattern's rules
(names of plans/groups/diagnoses/procedures by their distinctive words, codes,
gender/marital/claim type/network words, state names, ages and age words,
charges, counts); `/api/story/read`; Requirement matching has Analyze, which
shows the rules with their source words, measures them, finds patterns
inside, or opens them in User defined pattern. (3) `scenarios.py`: a pattern
card's Scenarios lists the combinations of chosen dimensions its rows hold
(age as bands; rows missing a value are a "(none)" scenario); chosen ones are
kept as patterns of their rows and generated together -- one DB load as
cohorts (story to-plan), or one file (`ExportRequest.scenarios`, each
scenario's records completed from its own rules and tagged SCENARIO).
Tests: test_combinations.py, test_story_and_scenarios.py, browser 2d.

**Earlier, 2026-10-06 (later): five steps, each for a database or files.**
The user asked for Map and Review merged, and for files to be a parallel
workflow through the same steps. The rail is now Connect, Discover and
Profile, Map & Review, Patterns, Generation (step ids connect, discover, map,
patterns, run; the map step reports `mapped`/`proposed` for Connect's
stages). Every step but Patterns has Database | Files tabs (`SideTabs` in
App.tsx; the choice is kept from screen to screen). Database: as before, with
Map & Review showing the open review decisions above the mapping table.
Files: Connect names a folder on this machine (`/api/files/source`, kept in
work/files-source.json, which stays when another database is chosen and is not
a plan input); Discover & Profile reads and measures every .txt/.csv/.dat/.tsv
file in it (`/api/files/profile`: kind, delimiter, fields, widths, types, date
format, empty rate, distinct, samples, from the first 4 MB / 20,000 rows); Map
& Review is the layout work and the rule repository (`FileMapping`), reading a
sample from the folder (`/api/files/parse`, by bare name only) or an upload;
Generation's Files tab writes through approved layouts and EDI
(`FileGeneration`). Patterns still come only from the pattern store.
Known gap: an empty onboarded database's CDML_SVC_CD is not matched to
PROCEDURE_CODE, so diagnosis/procedure pairing cannot reach it there.
Headings were rewritten plainly at the user's request (Data source, Column
profile, Column map, System discovered patterns, User defined pattern, Volume
and shape, Generation rules, Generate, File source/profile/layouts/generation).
The review queue section and the "What bands mean" tab were removed (Review.tsx,
Baseline.tsx deleted); open decisions are the Column map's Needs a look filter,
and weight bands still show on pattern cards.

**Earlier, 2026-10-06: demo feedback -- clinical pairs, variants, reference data.**
From the Essentra demo (Natarajan, Vijayakrishna, Dev). (1) A diagnosis and a
procedure were drawn apart: in a plain load the procedure was invented from
its format ([A-Z]\d{4}) and 99,592 of 99,617 lines carried a pair the history
never has. Now the plan build (`_pair_clinical_codes`, builder revision 3)
draws the claim's diagnosis and the line's procedure from the top 2,000 pairs
in `sdm.claims_denorm` (`Service.clinical_pairs`, deterministic order),
limited to diagnoses the target's diagnosis table holds (`within`); the line's
procedure is drawn `given` its claim's diagnosis (engine `lookup`). A column
whose rule was chosen by hand is left alone; approving only its element is
not that. A claims pattern keeps its `clinical` combinations (top 300) and the
bridge draws them as `record_group="clinical"` records, never as the two top
lists apart; files narrow by what the claim already holds. Validation adds a
`clinical` check: every pair written, joined line to claim, occurs in the
history. Result: 0 unseen pairs. Saved claims patterns from before this carry
no combinations and still draw the two apart -- re-save them. (2) Define a
pattern > "One scenario, many": vary by one or two list features, each
variant measured, save one or all. (3) The plan says which tables are
transactional (generated), reference (kept as is) and not touched, and why.
Tests: `tests/test_clinical_pairs.py`, pattern routes now assert the clinical
check, browser 2c (variants) and 3 (table kinds).

**Earlier, 2026-10-05 (night): text-column dates; Discover and Profile merged.**
Generating into MaskingDemo failed with ODBC 22001 "String data, right
truncation": DOB and SERVICE_DATE (catalog elements, `date_relative`) made
dates, and char(8) columns holding 20250828 received 2025-08-28. Nothing was
written (checked: row counts as profiled, no manifest). Now the plan build
(`_write_text_dates_as_measured`) gives a date into a text column a `format`
param from the column's fitted format (\d{8} -> %Y%m%d, etc.), or by width;
`date_relative` writes it with strftime and reads such text back as an anchor;
the SQL writer runs `check_widths` over every table before writing anything
and refuses with the table, column, width, value and rule (`TooLong`). Plans
carry `meta.builder` (`BUILDER_REVISION`, now 2); a plan from an earlier
builder is stale, so DB Generation rebuilds it on arrival after an upgrade.
Discover and Profile are one rail step, "Discover and Profile" (id
`discover`; the step also reports `read` and `measured` for Connect's stages),
one screen showing type, role, empty rate, distinct values and format. Tests:
`tests/test_text_dates.py`, `tests/test_generation_flow.py`.

**Earlier, 2026-10-05 (evening): discovery to a database load, step by step.**
The user found the way to a load was a round trip: a pattern could not go to
the database until a plan existed, and every rule changed left the plan on
disk stale with nothing saying so. Now `/api/patterns/to-plan` builds the plan
when there is none or it is stale; `GET /api/plan` says `stale` (anything the
plan reads -- model, profile, mappings, proposals, decisions, settings -- is
newer than plan.json; `Service.plan_stale`); and DB Generation builds the plan
itself on arrival when it is missing or stale (not retried after a failure).
DB Generation is a step strip -- the plan, sample rows, write, check -- each
marked done, the next one outlined, with "Next: look at sample rows" under the
plan. Discover, Profile, Schema and Review each have a "Next:" button in the
header; Review's is "Next: generate into the database". A pattern that reaches
no column stays on Patterns with the message instead of moving on. Tests:
`tests/test_generation_flow.py`; browser tests 3 and 4 now walk the Next
buttons and never press Build or Rebuild.

**Earlier, 2026-10-05 (later): patterns defined by rules; layouts saved as
and dropped.** Patterns > *Define a pattern*: choose features (members:
group, plan category, plan, product, age, tenure, gender, marital status,
state; claims: group, plan, product, claim type, claim status, diagnosis,
procedure, network, charge, member age, gender) and set a rule on each -- one
of a list, or a range. *Measure it* analyses the scope with k=1 (the whole
scope as one pattern, `method: "whole_scope"`); *Find patterns inside* is the
normal analysis of the same scope. The hierarchy goes in the usual filters;
everything else rides as `filters.conditions`, which `service._load` and
`claims_service._load` apply to the loaded rows (`defined_patterns.py`), so
rows, keep, files, DB generation and requirement matching all work unchanged.
Saved with `origin: "user_defined"` (shown as *defined* in Kept patterns and in
`/api/patterns/for-files`). The earlier `/api/patterns/define` endpoints
(hierarchy only, no profile) are still there, unused. Saved layouts: *Edit* >
*Save as a new layout* (refused if the name is taken) and *Drop* (deletes an
unapproved layout, archives an approved one). Tests:
`tests/test_defined_patterns.py`, `tests/test_layout_rules.py`, browser 2b/2c.

**Earlier, 2026-10-05: a rule for every layout field.** The user found that
layouts had no way to assign a rule to a field: a sample's field whose name
matched no rule or alias was written blank, saved layouts could not be opened,
and the tests had only ever covered name matching through the API. Now every
field has a rule choice -- when a sample is read, in the designer, and in a
saved layout's editor (File Generation > Layouts > Edit). A field can be chosen
blank on purpose (`blank: true`, a filler). Picking a rule for a field of
another name teaches it as an alias, unless the name already means another
element (reported, not forced). Editing an approved layout sends it back to
review. Also fixed on the way: a delimited layout's delimiter was ignored (every
file came out comma-separated); a sample's start positions were ignored (the
gaps between fixed-width columns were dropped); the sample's date format was
ignored; a YYYYMMDD date was right-aligned as a number. Covered by
`tests/test_layout_rules.py` and browser test 2b. The tagline under SDM and the
page title now read "Synthetic Data Management".

**Where it was left, earlier on 2026-10-04.** Choosing a database on Connect
onboards it -- its model analysis is its own and only the pattern store is
shared -- and an empty database is onboarded from the pattern store within
its own column types; databases can be offboarded; records chosen under a
pattern go into the database as well as a file (*How it behaves*: "The
working database", "An empty database", "Offboarding", "Generating from
chosen records"). Before that: saving patterns, fast claims discovery, the
pattern charts.

**Latest, 2026-10-04 evening.** A machine set up from an earlier zip upgrades
with `scripts\upgrade.cmd` (DEPLOY.md, "Upgrading a machine already set up"):
packages, new store columns, the source's extract views, then first-run. It
keeps saved patterns, layouts and rule edits and never reseeds the source.
`first-run.cmd`, `upgrade.cmd`, `demo` and `seed/decisions.py` refuse while
work/ belongs to a database other than the source (`sdg work-check`) -- after
an upgrade test run on this machine wrote FACETS_QA's model into MaskingDemo's
working files mid-onboarding (moved aside, the user's dbo.claim decision kept).

**Testing.** The user asked for scenario tests covering what a person
actually does, not only units. `tests/test_install_scenarios.py` drives the
real .cmd scripts on throwaway SDMT_* databases and a temp work dir: bare
install, everything twice, upgrade from the previous version keeping user
data, scripts refusing while another database is onboarded. Proven to fail
with the guard switched off. `tests/test_pattern_routes.py`: live, saved and
chosen-record patterns (members and claims) to CSV/834/837P/835 -- every SNIP
level clean, values the pattern's own (sexes, places as whole records,
diagnoses, members) -- and into the source, an empty onboarded database and
one too narrow for the store's cities; saved patterns unchanged throughout.
It found and fixed two bugs: member files carried no address (834 now has
N3/N4 from the pattern; the member CSV has city/state/ZIP), and a pattern's
address into a narrow column stopped the load partway (check_fits now
measures record fields, and an address that does not fit is refused whole).
`tests/test_browser.py` drives the real screens in headless Edge/Chrome
(Playwright, installed browser, no download) against a server of its own on a
copy of the suite's work dir: Connect facts, every screen opens clean,
onboarding a throwaway database from Connect through read/plan/generate/
validate/cleanup, chosen records into it, a saved pattern to an 834 that
passes SNIP, back to the source and offboarding. Any console error, 5xx or
alarm banner fails it. Proven to catch the Connect-label bug.

**Saved patterns are protected by the suite.** On 2026-10-04 the browser test
deleted the user's pattern 85 (saving an identical pattern returned theirs).
It was restored under id 85 from the same inputs. Now `/api/patterns/keep`
returns `created`, never rewrites an existing saved pattern, tests delete only
what they created, and conftest fails the run if any saved pattern present at
the start is changed or deleted (proven with a probe). Never test a script on
the user's live work/.

The repository installs on a machine with nothing on it -- proved by unpacking
the zip into an empty folder and building into three new, empty databases --
and `python scripts/package.py` builds the zip to ship.

**Pending, waiting on the user:**

- **GitHub push.** Tried 2026-10-03 and refused: `gh` is signed in as
  `ranjeeth12` with a fine-grained token that cannot create repositories.
  Nothing was created and no remote is set. Once the user runs
  `gh auth login --web --git-protocol https --scopes repo`, the agreed plan is
  a **private** repository `ranjeeth12/SDM`, both branches pushed, and
  `merge-pattern-analyzer` made the default branch. `master` is 44 commits
  behind it with nothing of its own; it is left as it is unless the user asks
  to fast-forward it.
- **The target laptop.** Set up from the 2026-10-03 zip by the user; to be
  upgraded with `scripts\upgrade.cmd` from the latest zip. Errors from there
  are the next thing to fix.

---

## The shape of the thing

    source DBs ──scoop──► central denorm store (SQL Server, SDM_DENORM)
                                  │
                                  ├─ pattern analysis: what is in the landscape
                                  │
                                  └─ patterns ──┬──► files (EDI 834/837, fixed, delimited)
                                                │
                                                └──► target DBs, onboarded on demand

A target is onboarded by pointing the pipeline at it: its model is read, its
columns are matched to elements, generation rules are derived, and rows are
written into it. A pattern reaches a target through the **element** it names,
not through a column name, which is why a pattern found in one landscape can
generate into a target that shares no naming with it.

## In one paragraph

SDM reads a SQL Server database, measures it, matches every column to a
business element, proposes a generation rule for each one with the evidence
behind it, and writes synthetic rows that keep the shape of the real data. The
pattern analyzer is now part of it: the same database is clustered to find the
cohorts inside it, and a chosen cohort becomes generation rules through the
plan this tool already builds. One process, one interface, one database.

## State

| | |
|---|---|
| Repository | `C:\Users\ranje\Desktop\SDM`, branch `merge-pattern-analyzer`. No remote yet; ready for GitHub (history checked: no password ever committed) |
| Tests | **683 passing**, about 8m15s, 2 warnings, idempotent against the fixture |
| Interface | built and served by the same Python process, `http://127.0.0.1:8777` |
| API | 91 paths: this tool's 23, the analyzer's 58, ten bridging them |
| Database | SQL Server on `localhost`; `FACETS_QA` is the fixture, `SDM_DENORM` the analysis store, `MDM_REF` the reference data |
| Python / Node | 3.13.5 / v24.19.0 |

Demo state as left: 15 tables discovered, 94 columns profiled, 90 percent
auto-mapped, 24 columns in the review queue, a 231,645-row plan built.

## Getting back to a running system

```
scripts\ui.cmd             build the interface if needed, then serve it
```

Setting it up on another machine is `DEPLOY.md`, written for a machine with
no SQL Server, no databases and no Python. `python scripts/package.py` builds
the zip for that from git's own file list, 0.8MB, and refuses to write if a
password or a virtual environment ever ends up in it. **Commit first**: only
committed files go in.

From nothing, on any machine, including this one if `work/` is ever lost:

```
scripts\setup.cmd          venv, exact package versions from requirements.lock, .env
scripts\seed.cmd           create the three databases and the full fixture, ~20s
scripts\first-run.cmd      extract, landscape, pipeline once, decisions, rules, ~2 min
scripts\ui.cmd             serve it
scripts\test.cmd           run the suite
```

`seed/decisions.py` holds Review answers already given on this project
(`CDML_SVC_CD` is `PROCEDURE_CODE`), since `work/` is never shipped. Add to it
when the user settles another.

**After changing `ui/src`, rebuild and commit `ui/dist`.** The built interface
is tracked so neither a clone nor the zip needs Node.

**After adding or upgrading a package**, refresh `requirements.lock` once the
suite passes; `setup.cmd` installs within it.

At the prompt, `python -m sdg.cli.main <command>` runs any step:
`connect discover profile map review patterns plan dryrun generate validate
cleanup demo ui`.

> The installed `sdg` console script is blocked by this machine's Application
> Control policy. `python -m sdg.cli.main` and the `scripts\*.cmd` wrappers work.

> `index.html` is served `no-store`, so a rebuilt interface is picked up on the
> next load. The asset filenames carry a content hash and are cached normally.
> A browser that visited before that header existed may still hold a stale copy;
> one hard reload clears it for good.

## The merge

The SDM Pattern Analyzer was a separate project — React, FastAPI on its own
port, reading a `SDM_Platform` database on another machine. It is now part of
this tool.

**Where the code went.** `cluster_profiler` is `sdg/analyzer/`; its services are
`sdg/analyzer/services/`; its eleven routers are `sdg/api/routers/`, mounted on
the app this tool already serves. The Streamlit shells (`app.py`, `_pages/`,
`styles.py`, `paginator.py`, `generation_ui.py`) were dropped, and the two
modules that still imported Streamlit for caching now use the analyzer's own
TTL cache. Nothing imports Streamlit any more.

**One collision.** Both halves defined `POST /api/generate`. Registered as they
arrived, the analyzer's would have been shadowed by ours and never called. Its
generation routes are under `/api/patterns/generate` instead.

**One database.** The analyzer reads `sdm.member_denorm` and `sdm.claims_denorm`
in `FACETS_QA`, beside the `dbo` tables they describe. Both are **views**, not
copied tables, so there is no refresh step and no moment when the analyzer is
describing data the generator has already moved past. A pattern found here is
about the rows this tool writes.

**What the fixture grew.** From 7 tables to 15. The enrollment hierarchy — group,
subgroup, plan category, coverage plan, plan and product descriptions — plus
diagnosis and procedure code sets, member demographics (sex, marital status,
SSN, middle initial, status), and claim type, network indicator and primary
diagnosis on claims. The catalog grew from 30 elements to 55 to cover them,
which brought the auto-map rate back to 90 percent on a schema 2.4 times the
size.

**What the groups are for.** Each of the eight employer groups carries a
different workforce: a university that is young and single, a transit authority
older and married, a senior care provider largely widowed. Without that the
clusters would be arbitrary cuts of one undifferentiated cloud and a pattern
named after them would mean nothing. `seed/verify.py` checks the spread holds —
about 38 years between the youngest group and the oldest, about 50 points of
sex balance.

**From a pattern to data.** `sdg/analyzer/bridge.py` translates what the
analyzer measures into what the generator runs, and refuses three lossy
shortcuts: a band stays a band (a cluster spanning 18 to 32 is not a population
of 25-year-olds), a distribution stays a distribution (54/46 crosses as weights,
not as the majority value), and a prevalence is never invented. `POST
/api/patterns/to-plan` resolves a pattern onto the columns it governs and, when
asked, writes them as ordinary review decisions — so `sdg plan` picks them up
exactly as it picks up an edit made by hand.

## One generator

The analyzer arrived with a second generator -- its own synthetic engine and its
own validator -- and two generators meant two definitions of a valid row. They
are gone. The plan engine generates; `POST /api/export` writes what it produced
in whichever shape another system reads.

`sdg/writers/edi.py` and `sdg/writers/export.py` keep the analyzer's EDI segment
knowledge and put it on a generator rather than a list. The analyzer built every
line of a transaction in memory and joined it at the end; these yield blocks, so
peak memory is a block whatever the row count -- measured at 0.1 MB for 160,000
rows, and asserted in the suite rather than taken on trust.

Two measurements worth keeping. The 834 ran at 6,700 rows a second until a
profile showed 79 percent of the time inside `pandas.to_datetime`, called once
per date per row to parse a date the caller already held as a date. A fast path
for `date` and ISO strings took it to **121,000 rows a second**; the 837 went
from 25,000 to **282,000**. And a run is held between exports keyed on the
plan's seed, so exporting an 834 and then an 837 of the same population costs
one generation rather than two -- 3.0 seconds, then 0.02.

What the removal cost: twelve endpoints (`/api/patterns/generate*`,
`/api/claims/generate|edi|export|layout`, `/api/story/generate|export`) and the
eight tests that covered them. The capabilities they carried -- EDI, layout
output, row limits, agreement between exports -- are covered again in
`tests/test_export.py` against the engine that replaced them.

## Story to Data

A requirement that names cohorts and how much of each it wants is a description
of a population, and the plan engine makes populations -- so Story to Data no
longer needs a generator of its own. `POST /api/story/to-plan` splits a volume
across the matched patterns by their size and writes each as a cohort with that
share. Asking for a thousand rows across two patterns gives a plan where one is
58 per cent and the other 42, generated through the same engine with the same
manifest, checks and cleanup as everything else.

## The end-to-end suite

`tests/test_e2e.py` runs the sequence a person runs and asserts the handover
between each step: connect, discover, profile, map, review, find a pattern,
apply it as a cohort, turn a requirement into shares, rebuild the schema, plan,
dry run, generate, validate, measure the cohort, export every format, clean up,
and confirm the seed checks still pass. Seventeen steps in about twenty-five
seconds.

It works in a directory of its own and writes under its own seed, and its
teardown removes both the rows and the patterns it created -- a suite that
leaves either behind would poison the fixture for everything after it.

## Claims patterns

The analyzer finds claim patterns as well as member ones, and both now reach
generation. A claims pattern binds what a claim can carry: status, type,
network, the diagnosis, the procedure, and the line amount. Its member-level
features -- age, sex -- are refused, and the reason names the cause rather than
the symptom: parents are generated before their children, so picking a share of
the claims cannot reach back and change the members they belong to.

Two of those bindings needed new machinery. A **diagnosis is a reference** into
a reused table, so it is narrowed to the codes the pattern named rather than
replaced -- the column still points at real rows, just fewer of them. And a
**charge measured over lines** no longer stops at the claim total it maps to:
that column is computed from the lines, so stating it would contradict the sum,
and the resolver now falls through to the column the value was measured on.

Measured: a pattern covering 10.8 per cent of claims generated 11.0 per cent,
drawing from exactly the ten diagnoses it named while the rest of the book drew
from all thirty.

## A pattern as a share of the population

A pattern describes part of a book, not all of it. Applied to the whole run it
generates a population the analyzer never saw, so a pattern can now be applied
as a **cohort**: its own measured share, with everyone else generated as the
source was measured.

Membership is a bitmask on each row, drawn from the seed at the cohort's subject
table and inherited down the cascade — so a member in a cohort has all of their
claims in it, which is what lets a pattern span two tables and still mean
something. A bitmask rather than a set of names because it is read once per
field per row, and because a child inherits by copying one integer.

Measured on the real plan: a pattern covering 2.59 percent of members produced
2.54 percent, aged 51 to 75 and 69 percent female, while everyone outside it
stayed at 0 to 85 and 52 percent female. `measure_cohorts` reports asked against
actual from the membership the engine already holds, so the claim is checked
rather than assumed.

It costs about three percent on a run that uses one, and **nothing at all on a
plan that declares none** — every cohort path is behind one boolean, and a test
asserts that no tags are built when there are no cohorts.

## Table modes

The enrollment hierarchy and the clinical code sets are **reference data**: a run
points generated rows at the groups, plans and codes that already exist rather
than inventing employers of its own. Ten tables are set to reuse, one
(`CMC_CLCL_AUDIT`) to exclude, and four are generated — the same subscriber →
member → claim → line cascade as before. Set them otherwise and the foreign keys
form a cycle the planner refuses, naming the tables involved.

Discovery skips the `sdm` schema by default. It is the tool's own working state;
profiling it put 70 columns of application metadata into the review queue.

## The interface

The rail gained two steps. **Patterns**, between Review and Plan, holds three
ways into the same answer behind one set of tabs — analyze a chosen scope, walk
the whole book, or start from a written requirement. They are tabs rather than
three rail steps because the rail is the pipeline and these are not three
stages of it. A fourth, **What bands mean**, holds the baseline those tabs'
weight bands are read against. **Output**, between Plan and Generate, holds layouts, rules and
masking: all three are about the boundary where generated data stops being
ours. A layout is the shape of a written row, a rule is what fills one of its
fields, masking is what must not carry a real value.

Every screen was built from the existing tokens and primitives rather than
ported from the analyzer's own React.

## What is open

Short on purpose. Everything else that was here described things that work;
those moved to *How it behaves* below, because a list of defects that is mostly
not defects is a list nobody reads twice.

- **A target on another server is parked, by choice.** The connection is
  configurable, the registry carries per-role servers and the tests cover the
  resolution, but every run so far has been against `localhost`. Exercising it
  needs a second SQL Server and is deferred until there is one; it is not
  believed broken, it is simply unproven.
- **Element matching on an empty target is name-only.** With no rows to profile,
  a column matches an element by its name or not at all, so `born_on` does not
  read as DOB though `date_of_birth` does. A person can state the match in
  Review, but Review assumes rows to show beside each decision and has no shape
  for a database that has none.
- **No UI for claims profiling detail or baseline compute beyond what exists.**
  Some analyzer endpoints are mounted and tested with nothing calling them.
- **`FACETS_QA` holds only the two extract views now.** The nineteen analyzer
  tables beside them, left over from before the store moved, were dropped once
  their contents were confirmed present in `SDM_DENORM`. The views stay: they
  are the extract definition, and without them the store cannot be refilled.
  `seed/build.py` takes only the view half of `ddl_sdm.sql`, so a reseed does
  not bring the tables back.
- **`pandas.read_sql` is called through `sdg/analyzer/sql.py`**, which silences
  the pyodbc notice by message and nothing else. pandas is right that pyodbc is
  untested by them; it has worked here for the life of the project, and
  forty-five lines of the same notice per run was enough to bury a warning
  worth reading. Moving to SQLAlchemy is the other answer and a larger change
  than it sounds -- the registry, the analyzer's connection handling and every
  `with get_connection()` move together -- so it is worth doing deliberately
  rather than as a side effect of tidying.
- **Seven tests assume the default database names.** Installed under other
  names (`SDMT_*`, to prove the install beside the real ones), 639 of 646
  passed; the seven name `FACETS_QA` outright or measure the store against it.
  With the defaults `DEPLOY.md` tells a new machine to keep, all pass. A source
  under another name also needs its extract definition copied to
  `sdg/extract/definitions/<name>.sql`.
- **Element matching on an empty target is still name-only** (above): a
  column the catalog cannot place by name gets no element, so the pattern
  store cannot reach it, and it is generated from its type.
- **No auth**, inherited from the analyzer. The API is open. Fine on a laptop.
- **No remote yet.** Ready for GitHub, not pushed. Until it is, the work has
  no second copy.
- **The target machine has not been tried by a person.** The install was
  proved here, in an empty folder against empty databases, on the same
  Windows and SQL Server 2025. A different SQL Server edition or a locked-down
  machine may still surprise; `DEPLOY.md` lists the errors seen most often.
- **Trigger output is never cleaned up.** `TR_CMC_CLCL_CLAIM_AUDIT` writes one
  `CMC_CLCL_AUDIT` row per generated claim. Cleanup announces this and leaves
  them, by design -- the database wrote them, not the run.

## How it behaves

The decisions worth knowing before changing anything, and the defects that are
already fixed, so the same ground is not re-walked.

### Where data goes

- **Pattern analysis reads an extract store, not a source.** `SDM_DENORM` holds
  the denormalized tables every source is read into, centralized across sources
  with a `source` column, and this tool's own tables beside them. `sdg extract
  <source>` does a complete refresh of one source. Definitions live in
  `sdg/extract/definitions/<source>.sql`.
- **An extract leaves behind what this tool generated.** Generation writes to
  `target`, which is usually the source, so a run's rows would otherwise become
  part of the landscape. The manifest records the keys a run wrote and the
  extract skips them: measured at 173,890 rows skipped, the store unmoved.
- **A target is chosen on the Connect screen**, from the databases on this
  server or configured against another one. The analysis store is never
  offered. Windows authentication stores no password; SQL authentication writes
  one to the working directory in plain text, and the form says so.
- **Key starts are read from the target, not remembered.** A sequence proposal
  records the highest value seen at profiling time; the run resolves it against
  the table immediately before writing. Three consecutive runs go 51, 71, 91
  with no orphan.
- **A manifest carries an uncleaned run forward**, so a second run does not
  strand the first run's rows beyond cleanup's reach.

### What the tool knows

- **A target is never read for its shape.** The landscape (`sdg landscape`)
  describes the store per **element** rather than per column, and is projected
  onto a target's columns through whatever elements they carry. Relationships
  are measured directly, because extracts declare no keys between them.
- **A subject mapping is stated, not guessed.** `subjects` maps a target table
  to the store table holding the same kind of thing, beside `rootCounts`.
- **Onboarding a target samples it.** Reading its data is how every field gets
  a value rule: a learned regex for strings, ranges for numbers, anchors and
  orderings for dates, a key sequence past the rows already there. A pattern
  then overrides a few fields; the rest keep what sampling found.
- **Most columns are not the landscape's job.** Where there is nothing to
  measure, `_from_model` proposes from the declaration alone.
- **The clustering is reproducible.** k-means is seeded, and the subsets it
  clusters are now ordered -- without that, a reindex moved every pattern.

### The interface

- **Two destinations, named for what comes out**: File Generation and DB
  Generation, with the plan inside the second. A pattern says which it is for
  and takes you there.
- **Discover, Profile and Map are one screen under three lenses**; the domain
  switch shows only on Patterns, the one step that reads it.
- **EDI transaction sets are described, not coded.** One JSON file per set in
  `sdg/writers/edi_formats/` -- 834, 837P, 835. A position names a **rule**,
  never a column; the only literals are X12's own vocabulary (qualifiers,
  envelope values). HL and LX number themselves (`counter`), and a claim total
  is its lines added up (`sum`). The hand-written writers remain only as the
  reference the older tests compare against.
- **A rule is an element.** The repository holds one rule per element -- DOB,
  SEX, CLAIM_STATUS -- named for it. The columns that mean an element are its
  aliases, so a sample naming SBSB_ID still resolves. A rule carries what the
  plan measured: a range and its places, a list and how often each value
  occurs, a date window. Seeded rules nobody edited are refreshed from the plan
  on every seed; an edited one is left alone. `seed_elements.rekey` converted
  the old column-keyed repository once, retiring the duplicates rather than
  deleting them.
- **A range rule carries the shape the plan measured** -- `distribution`,
  `mean_value`, `stddev_value` -- and draws with the plan engine's own
  log-normal, so a file's charges sit where the real ones do: median 90 and
  mean 133 against 90 and 135 in the data, where an even draw gave 275. The
  Rules editor offers it as Spread. A pattern's own range still replaces the
  rule, and draws evenly within it.
- **Patterns are drawn, not only listed.** Above the list, every pattern at
  once: how the scope divides (a share bar), where each sits on age, tenure or
  charge (range, middle two-thirds and mean on one axis, against everyone), and
  what sets each apart (each categorical share, colored by how far it is from
  everyone's). Selecting a pattern in any chart highlights it in all three and
  opens its card, which shows its own distributions: histograms laid over
  everyone's on the same bins, its categorical mix with everyone's share
  marked, and for claims its top diagnoses. The bins come from the analysis
  (`sdg/analyzer/histograms.py`), cut at the 99th percentile with an open last
  bin. The charts draw a fresh analysis, which always carries them; saved
  patterns are not drawn anywhere yet, so the 24 stored before this need no
  backfill until a screen shows them. Color is the
  pattern's place in the list, from eight validated series tokens; past eight
  a pattern is gray and named. `ui/src/views/PatternCharts.tsx`.
- **Saving a pattern.** Each pattern card has **Save pattern**, for members
  and claims alike. A saved pattern stores its elements and values, where it
  came from (filters, k, cluster) and the members it holds, so a claim file
  made from it later goes to the same people whatever a fresh clustering would
  do (`sdg/analyzer/services/saved_patterns.py`, `POST /api/patterns/keep`).
  Its key is a digest of what was saved, so saving twice adds nothing.
  File Generation's "Written for" offers only saved patterns -- the 24 a
  discovery walk stored on its own are working state and no longer listed.
- **Generating from chosen records.** Under "The rows underneath", records can
  be ticked across pages (each row carries a stable key: a member by MEME_CK,
  a claim line by claim and line number). Either button saves them as a
  pattern of their own -- measured from just those rows, holding just their
  members. **Generate a file** opens File Generation with it chosen.
  **Generate into the database** applies their values as the run's rules for
  the columns they reach, for every row, and opens DB Generation with a note
  saying how many columns they set; an error stays beside the button.
- **The working database.** Choosing a database on Connect is onboarding it.
  Its model analysis -- structure, profile, mappings, review, plan -- is its
  own, read from it; only the pattern store (the denorm extracts and the
  patterns found in them) stays the same. Every step works on it: reading,
  profiling, the reference rows a plan points at, generating, validating and
  cleanup. The "source" connection
  follows the choice; a fixed "landscape" connection keeps naming the
  database the analysis store was read from, for the one thing that must
  read it -- a pattern's existing members. Each database's working files
  (schema, profile, mappings, decisions, plan, manifest) live in work/ while
  it is chosen and under `work\databases\<server>__<db>\` while it is not,
  and `work\working-database.txt` names whose files are in work/. A
  manifest therefore can never be applied to a database it was not written
  to. Nothing from another database's model analysis is ever borrowed.
- **An empty database** is onboarded from the pattern store and its own column
  types. The store's description (`sdg landscape`, run by first-run) now
  measures which thing per which parent inside the flat extracts -- members
  per subscriber 2.30, claims per member 4.58 with 29.7% having none (zeros
  counted exactly from the extract holding every member), lines per claim
  3.08 -- and which totals are sums of their parts (a claim's total, 210,603
  of 210,603). A target's key is matched by the thing its table holds, read
  from its primary key's element, so a claim key gets claims per member and
  not lines per member. A key nobody declared (claims to members in Facets)
  is added during Map when the column carries another table's key element and
  the store measured that relationship. Every value the store would put in a
  column is checked against the column's own type first -- width, whole
  number, range, precision, date -- and where it cannot be stored the store is
  not used for that column, the reason is recorded, and the column is
  generated from its type. Catalog rules are held to the same check, in the
  proposer and the resolver. Proved on an empty Facets copy with reference
  rows only and one column narrowed to 4 characters: 231,609 rows, members
  per subscriber 2.28, claims per member 4.63 with 29.5% none, lines per
  claim 3.08, longest name 4, validation passed (`tests/test_onboarding.py`).
- **Offboarding.** Connect lists the databases onboarded here, each with
  Offboard: it forgets that database's schema, profile, mappings, decisions
  and plan. Patterns and the analysis store are untouched. Refused while rows
  generated into it are still there (the manifest is what cleanup needs);
  offboarding the database being worked on moves work back to the one in
  `.env` first.
- **Several databases, one after another** (`tests/test_onboarding_e2e.py`,
  through the API the screens call): onboard A and generate, onboard B (one
  column narrower) and generate, switch back to A -- its plan comes back as
  left, it validates and cleans up without touching B -- switch back to B and
  clean up, offboard both (refused while rows remain), and the pattern store
  is unchanged throughout. Builds and drops its own Facets copies
  (`tests/facets_copies.py`). The suite builds the source's working state for
  itself when work/ has none to copy (`tests/conftest.py`).
- **Top-level tables without a stated count** -- the ordinary case for a
  database just onboarded -- start at their current size, or 1,000 when empty,
  with a warning naming each; the counts are changed on the plan. Before, the
  plan refused to build, which left nowhere to state one.
- **Working files.** Query and clustering results are kept as files under
  `sdg/analyzer/cache/api/` for the session, and `scripts\ui.cmd` clears them
  at every start. Frames are stored with repeated text as categories (the
  claims book: 230 MB to 73 MB, written in 0.07 s instead of 3.3) and restored
  exactly on read; memory is checked before disk; the claims cluster count is
  chosen on a fixed 50,000-line sample (same k as the full search in every
  scope tried). Claims discovery over every group: 39 s cold to 20, and 16 s
  on a repeat to under 1. The cold remainder is mostly the 8.5 s SQL read.
- **SNIP-style checks of EDI files**, on the EDI tab of File Generation: **Run
  SNIP checks** validates exactly the file the screen would write (a sample of
  50/200/1,000 records or the whole file), **Check a file...** validates any
  X12 file. The report is one row per SNIP level -- passed, failed, partly
  checked, not checked -- with findings grouped by rule. Driven entirely by
  files: the engine (`sdg/writers/snip/engine.py`) knows a fixed vocabulary of
  rule kinds and nothing about any transaction set; `sdg/writers/snip/rules/
  <set>.json` describe 834, 837P and 835 (005010), `codesets/` holds public
  code lists. A customer changes them in `work\snip\` (or `SDG_SNIP_DIR`) with
  no code: add rules, replace one by id, switch one off, replace a code set,
  add a file for another set, or add trading-partner rules (level 7) in
  `partners\`. ICD-10-CM and HCPCS lists are not shipped (large, annual); put
  CMS's files in `work\snip\codesets\` and membership is checked, otherwise
  the report says it was not. CPT is AMA-licensed and never shipped. Not a
  certification, and the report says so. Rules reference:
  `sdg/writers/snip/rules/README.md`.
- **SDM's EDI passes SNIP levels 1-4** (whole files: 834 32,496 segments,
  837P 360,862, 835 203,573), held by `tests/test_snip.py`. Getting there: the
  834 gained its sponsor and payer loops (N1*P5, N1*IN), lost INS's trailing
  empty elements, writes SSNs as nine digits and a coverage level in HD05; the
  837P gained the submitter contact, receiver, billing provider loop (valid
  NPI, address, tax id) and a payer per subscriber; the 835's BPR02 is now
  every claim's payment added up (a header `total`, worked out after the
  claims are built), with payer address and contact, a valid payee NPI, CLP02
  as an X12 status (1) and CLP06 as CI. Names and ids of the trading parties
  are constants in the format files, to be set for a real relationship.
- **Code sets come from the pattern store.** Procedure codes, diagnosis
  codes and the other vocabularies an EDI needs are facts about the sources,
  held in the store, not about whichever target is onboarded. An element
  marked `code_set: true` in the catalog (`examples/catalog.yaml`: today
  PROCEDURE_CODE, DIAGNOSIS_CODE, RELATIONSHIP_CODE, SEX, MARITAL_STATUS,
  COVERAGE_PLAN_ID) is read whole by the
  store's description (`sdg landscape`), with exact counts -- 400 procedure
  codes, 30 diagnoses -- and the service's catalog makes its rule a lookup of
  those codes in their proportions. A target's own declared reference to a
  code table comes first (the diagnosis column references CMC_IDCD_DIAG_CODE);
  otherwise the store's codes. The plan, the rule repository and every EDI
  file follow, so the 837P and 835 pass SNIP levels 1-5 with no errors (5 is
  partial only where ICD-10/HCPCS lists are not installed). Marking another
  element is a line in the catalog. `seed/decisions.py` approves CDML_SVC_CD's
  element and leaves its rule to the catalog, instead of the invented pattern
  the proposal fitted.
- **A file from a pattern comes from the pattern store alone.** No target
  needs to be onboarded or planned: the pattern's members are read from the
  store's `member_denorm` (one row per member, the latest enrollment, mapped
  to elements by the store's own description), codes come from the store's
  code sets, which elements a claim carries once and which each line carries
  is recorded in the store's description (`line_elements`: charge, line
  number, procedure, units), plan scope comes from the store, and the seed
  from settings. The database route still needs the working database's plan;
  the pattern card offers **Generate a file** directly and **Generate into
  the database...** beside it. To make this possible the member extract now
  carries `MEME_ID` (view, extract definition and store table, with a guarded
  ALTER for an existing store), and the catalog gained AGE_AT_SERVICE, so a
  claim's member age stops sitting under CLAIM_ID.
- **A member pattern carries where its members live**, as whole address
  records (ZIP, city, state) with their shares -- `GEOGRAPHY_COLUMNS` in
  `sdg/analyzer/config.py` names the extract's address columns. The bridge
  turns them into one parameter per address element, all holding the same
  records, so a target with only city and zip (MaskBench) is reached through
  them, and every address column -- in a database load or a file -- draws
  the same record: a ZIP is never paired with another place's city. Checked
  in a dry run of 645 members: every address one of the pattern's places.
  The fixture spreads each group across the whole book's 600 ZIPs, so on the
  demo a pattern's places are as wide as the book; real data concentrates.
- **Every file record is keyed by element** (`sdg/writers/elements.py`). Rows
  from a run are translated once, through the plan's own bindings; nothing
  downstream knows a column.
- **A file is written for the plan's run or for a pattern**, chosen at the top
  of File Generation. A pattern is a saved list of elements and their values,
  and it replaces the rules for the elements it names:
  - a **member file** (834, or a layout) is new members carrying those values,
    in the pattern's group and plans;
  - a **claim file** (837, 835, or a layout) is claims for the members the
    pattern actually holds -- rebuilt from its seeded clustering, read from
    the database. Claims per member and lines per claim are what the pattern
    measured.
  Generating a file from a pattern writes nothing to the plan.
- **A layout can be defined, not only read from a sample**, and written
  through once approved, one row per member or per claim line. Fields name
  elements.
- **Every layout field has a rule picked for it**, read, defined or edited. A
  field is bound by `rule_id` when one is set, otherwise by its own name; a
  field marked `blank` writes nothing whatever it is called. A chosen rule
  under another name becomes that name's alias where the name is free. A
  delimited file uses the layout's delimiter; a fixed-width row keeps the
  sample's starts; dates keep the sample's format.
- **The baseline runs as a background job**, because a full walk is ten minutes
  to three quarters of an hour. Nothing is stored until it completes.

### Defects found and fixed

Kept because each was invisible until something specific was tried.

- **A test double stayed installed for the rest of the run.**
  `test_analyzer_integration.py` started its in-memory database patches and
  never stopped them, so every later test calling those functions reached the
  fake instead of SQL Server. Found when a new test failed only in the full
  suite; an autouse fixture now stops them after each test.
- **Choosing a target only redirected the writes.** Reading, profiling and
  the plan's reference rows all stayed on the source, so a plan built for
  FACETS_QA was written into whichever database was chosen.
- **The suite worked in the user's own work/.** Tests that import the app
  wrote plans and decisions into it and ran against whatever was chosen on
  Connect. `tests/conftest.py` now gives every run a copy of the source's
  working state and removes it afterwards.
- **Two tables holding the same keys became a cycle.** Key inference tested
  each direction alone, so two copies of one member list (MaskBench's
  parcheck and seqcheck) were each other's parent and DB Generation refused
  the plan. A key the data shows both ways now keeps one direction: the
  larger table is the parent, ties by name; a key reversing a declared one is
  dropped (`one_way` in `sdg/discovery/inference.py`).
- **An empty table's profile blocked the landscape.** Profiling an empty
  table still lists every column, with zero rows, and that list stopped the
  landscape filling any of them. Measurements of nothing now give way.
- **The landscape's one relationship was the wrong one.** "Per member" was
  claim lines per member (20), offered to the claim table's key, which wants
  claims per member (4.6). Relationships now name the child thing.
- **The store matched empty columns to elements by name alone.** Thirteen
  columns in the extracts hold no value at all (MEME_HICN, CSPI_HIOS_ID_NVL,
  race, ethnicity, several term dates); an empty Medicare-number column sat
  under marital status and an empty HIOS id under coverage plan. They added
  no values -- an earlier note here calling those lists polluted was wrong --
  but the labels were. The store's description now keeps a column with no
  values out of every element and lists it as `empty`, and the catalog gained
  MEDICARE_ID and HIOS_PLAN_ID (57 elements) so a target's columns of those
  kinds have somewhere right to go.
- **The claims frame was cached nowhere.** At 300 MB it was over both the
  memory tier's per-entry cap and the disk tier's, so every claims analysis
  read 648,128 lines from SQL Server again -- and spent 3.3 s pickling a file
  it then threw away. The two-tier wrapper also read the disk before memory,
  despite its docstring.
- **The member analysis response drops any field it does not declare.**
  Histograms were computed and never arrived; `AnalyzeResponse` in
  `sdg/analyzer/services/schemas.py` has to name every new field. The claims
  analysis has no response model and was unaffected.
- **`setup.cmd` reported success having installed nothing**, when `python`
  was the Microsoft Store stub -- which it is on this machine and on most new
  Windows. It now finds Python through the `py` launcher and stops if it cannot.
  Found by installing the zip into an empty folder.
- **The `.cmd` scripts were stored with LF endings**, which cmd misreads around
  labels; a clone elsewhere would have had them. `.gitattributes` pins CRLF.
- **A fresh install took the newest of everything**, a few patch versions past
  what the suite passed on. `requirements.lock` holds the tested set.
- **The schema-rebuild test was rebuilding the wrong database.** It ran all of
  `ddl_sdm.sql` against `FACETS_QA`, so it checked for a pattern in a database
  patterns no longer live in, and every run put twelve analyzer tables back
  into the customer database. It now runs the store's half against
  `SDM_DENORM`, and checks that an edited rule survives as well as a pattern.
  The same script dropped `sdm.generation_rules` on every run; it is now
  created once, with its later columns added by guard.
- **Every subscriber loop in the described 837 was `HL*2`**, the patient's
  last name was their member ID, and CLM02 was the first line's charge rather
  than the claim's. Found by generating an 837 for a pattern and reading it.
- **Editing a lookup rule's label wiped its list of values**: the editor sent
  `domain: null` for every method but constant.
- **CLM05 was written flat** by the hand-written 837 -- a composite with the
  element separator, shifting every element after it by two positions. Found by
  describing the format and comparing.
- **A mode that breaks a foreign key** built a clean plan and failed on the
  first row. It blocks at plan time now.
- **A reviewed override could not settle `derivable_without_expression`**, so a
  plan stayed permanently unbuildable. Found by pointing the tool at a schema
  it had not seen.
- **`AnalyzeResponse` dropped `band_thresholds`**, so the member profiler could
  not say what its bands were measured against.
- **A bare `except` hid a SQL error** and reported zero relationships, which
  reads exactly like a landscape that has none.
- **Fixed-width samples with a header** produced `FIELD_1`, `FIELD_2` and a
  blank extract with a 200 beside it.

## Ground rules on this project

- **Do not touch the `edi-mask` repository.** It is a separate project at
  `C:\Users\ranje\Desktop\EDI\edi-mask` and was explicitly ruled out of scope.
- The SQL Server password lives in `.env`, which is gitignored along with
  `work/`. Neither is ever committed.
- Nothing writes to the source except the writer, and only tables the plan
  marks `generate`. Discovery, profiling and the whole analyzer are read-only.

# Environments: this machine, the demo laptop, the customer

SDM runs in three places, each set up differently. This page says which is
which, what each one runs, how an update reaches it, and which scripts are
allowed there. `STATUS.md` is the current state of the work; `DEPLOY.md`
installs a demo laptop; `scripts/customer/README.md` installs at the customer.

| | **Local** (development) | **Demo laptop** (the other laptop) | **Customer** |
|---|---|---|---|
| What it is | Where SDM is built and tested (`Desktop\SDM`, git repo) | The user's own laptop for demos, with its own SQL Server and demo data | The customer's FACETS, pattern analysis only |
| `SDG_ENV` in `.env` | `local` | `laptop` | `customer` |
| Python | 3.13 (`.venv`) | 3.13, internet (`setup.cmd`) | 3.14, no internet: offline parts (`setup_offline.cmd`) |
| SQL Server | `localhost`, Windows login | `localhost`, Windows login | FACETS on `INT_69`; SDM platform database on its own server |
| Source | `FACETS_QA` (demo, seeded) | `FACETS_QA` (demo, seeded) | `FACPRDDB` (production: read only, ever) |
| Pattern store | `SDM_DENORM`, schema `sdm` | `SDM_DENORM`, schema `sdm` | `TDMCFG`, schema `sdm` |
| Generation | yes | yes | **no** (`SDG_DB_TARGET` names a database that does not exist) |
| `.env` from | `.env.example` | `.env.example` | `scripts/customer/customer.env.example` |
| Gets a new version by | `git commit` | the zip, unpacked over `C:\SDM`, then `scripts\upgrade.cmd` | the zip, unpacked over the SDM folder; **no** upgrade script (below) |

## Which scripts run where

| Script | Local | Demo laptop | Customer |
|---|---|---|---|
| `scripts\setup.cmd` | yes | yes (first install) | no (company mirror has no packages) |
| `scripts\setup_offline.cmd` | - | - | yes, with the parts for that machine's Python |
| `scripts\seed.cmd`, `bootstrap.cmd`, `first-run.cmd`, `upgrade.cmd`, `demo.cmd` | yes | yes | **refused** |
| `scripts\customer\setup_tables.cmd` / `.sql` | tests only | - | yes, once (and after an update that adds tables) |
| `scripts\customer\extract.cmd` | tests only | - | yes: loads FACETS into the denorm; on the refresh schedule |
| `scripts\customer\truncate_extract_tables.sql` | - | - | only to empty the 23 extract tables before a reload |
| `scripts\customer\export_patterns.cmd` | yes | yes | yes |
| `scripts\ui.cmd` | yes | yes | yes |
| `scripts\test.cmd` | yes (full suite before every zip) | optional | no |

**The refusal is enforced.** The demo scripts build, reseed and re-extract
databases; at the customer, `upgrade.cmd` or `first-run.cmd` would load demo
data over their store. Each of them first runs
`sdg.cli.main demo-check`, which stops when `.env` (or the environment) has
`SDG_ENV=customer`, or names a pattern store on its own server
(`SDG_DENORM_SERVER` other than localhost). The customer's `.env` already has
`SDG_DENORM_SERVER`, so it is protected even before `SDG_ENV=customer` is
added. Tested in `tests/test_install_scenarios.py` (scenario 5).

## Which build each runs

Every zip carries `VERSION.txt` (commit, date). The zip name is
`dist\sdm-<commit>.zip`.

| | Version | Since |
|---|---|---|
| Local | `HEAD` of `merge-pattern-analyzer` | - |
| Demo laptop | the 2026-10-03 zip, until this build is unpacked and `upgrade.cmd` run | 2026-10-03 |
| Customer | baseline tag `customer-baseline-2026-10-09` (commit `049b0c3`): see below | 2026-10-09 |

## Customer baseline (2026-10-08 / 09)

What was actually done at the customer, and what the repository now holds for it.

**Machines**

- **User's VDI**: Python 3.14 free-threaded, parts `dist\sdm-wheels-cp314t.001`-`.006`.
  Runs `ui.cmd` and `extract.cmd`; its `.env` uses the user's own login.
- **Teammate's laptop**: Python 3.14.3 (regular), parts `dist\sdm-wheels-cp314.001`-`.006`.
  Copy of the SDM folder without `.venv`, `wheels`, `dist`, `exports`, `.git`,
  with the user/password lines in `.env` blanked; runs `setup_offline.cmd`, then
  `ui.cmd` only. Never `extract.cmd` or `setup_tables.cmd`.
- **Tidal agent** (only if the jobs are scheduled): same offline install,
  `.env` with `SDG_MSSQL_TRUSTED=yes` and `SDG_DENORM_TRUSTED=yes`; jobs
  `cmd /c C:\SDM\scripts\customer\extract.cmd` (exit code 1 on any failure).

"Missing wheels" means the wrong set of parts for that Python:
`scripts/package_wheels.py --python 3.14 [--free-threaded]` builds another.

**Database**

- The user's login has no create/alter rights. `setup_tables.sql` (the same
  statements as `setup_tables.cmd`, as plain T-SQL) creates every `sdm` table
  in `TDMCFG`; it is add-only. After that, the screens need only read and
  write; the extract needs read on FACETS and read/write on `sdm` (TRUNCATE
  when ALTER is granted, DELETE otherwise).
- **Extract scope, as the user set it on 2026-10-08:** members with an
  eligible span in force today; their claims with service date in the last 24
  months; plans, products, benefits and accumulators in force today; active
  networks and providers; member eligibility, PCP, COB and address rows in
  force today. Nothing expired, terminated or future. Spelled out at the top of
  `sdg/extract/definitions/FACETS.sql`.
- All 23 denorm tables loaded. Fixed for their FACETS release on the way:
  `CSPI_PDPD_BEG_MMDD` and the COB reason codes are not in it (left NULL);
  three `claims_header_ext_denorm` values are longer than the SDM columns (cut to
  35 / 18 / 18); `provider_network` limited to networks of plans in scope (the
  full roster dropped the connection); `plan_benefit_denorm` limited to the
  product, payment prefix and Service ID combinations billed on claims in scope.

**Screens**

- The page was blank: their Windows registry maps `.js` to `text/plain`;
  `app.py` now serves `.js`/`.css` with their real types.
- Walk the book, Keep on Claims saved a member pattern; fixed (`298fe33`),
  `ui\dist` sent. Member patterns kept by mistake are theirs to Remove.
- Patterns are shared: they live in `TDMCFG`, so everyone sees everyone's.
- `export_patterns.cmd` writes every saved pattern to Excel; run guide
  `docs\customer\SDM Pattern Analysis - Run Guide.docx`.
- Never press **Read the database** on Connect there (a full profile of production FACETS).

**How files reached the customer.** During the install, single files were
sent as they were fixed (`FACETS.sql`, `app.py`, `ui\dist`, the SQL scripts,
`export_patterns`), not whole builds. Every one of them is committed, and
`customer-baseline-2026-10-09` is the commit that holds all of them. From now
on the customer gets whole zips, so `VERSION.txt` there says exactly what
runs.

**Open, waiting on the user:** `plan_benefit_denorm` / `plan_accumulator` cuts
(pending the breakdown query result), providers cut to those on claims plus
PCPs, the "(blank)" label on pattern cards. Phase 2 (EDI from a sample) is
built locally and not deployed there; it needs `sdm.sample_gen_configs`
(in `setup_tables.sql`) and a sample from them.

**Next update for the customer (after `customer-baseline-2026-10-09`):**
pattern counts and % (one sheet, from the screen), fields counted chosen on
Configure, generation following the pattern, files from a sample (X12, FHIR,
HL7 v2, CDA). It needs: new wheel parts (`requirements.lock` added
fhir.resources and fhir_core) -- `cp314t` for the VDI, `cp314` for the
teammate; `setup_tables.sql` run by the DBA (adds `sdm.sample_gen_configs`
and `sdm.report_fields`, add-only); no extract (`FACETS.sql` unchanged).
Check `SELECT COUNT(*) FROM sdm.member_address WHERE ADDR_ROLE = 'HOME'`:
above 0, locations work in patterns; 0, run `extract.cmd --table
member_address`.

## Updating each one

**Demo laptop.** Close the interface; unpack `sdm-<commit>.zip` over `C:\SDM`
(replacing files; `.env`, `.venv` and `work\` are not in the zip, so they are
kept); run `scripts\upgrade.cmd`; it ends with "Upgrade complete". Add
`SDG_ENV=laptop` to `.env`. Details in `DEPLOY.md`, "Upgrading a machine
already set up".

**Customer.** Close the interface; unpack the zip over the SDM folder
(`.env`, `.venv`, `wheels` and `exports` are not in it, so they are kept). Then:

1. Only if `requirements.lock` changed in that build: copy the new parts and
   rerun `scripts\setup_offline.cmd`.
2. Only if the build adds tables: run `setup_tables.sql` (add-only).
3. Only if `FACETS.sql` changed and the data should follow: `extract.cmd`
   (or only the tables named in the release note, `--table ...`).
4. `scripts\ui.cmd`.

Never `upgrade.cmd` or `first-run.cmd` (they refuse anyway).

**Teammate.** Copy the user's updated SDM folder as above; nothing else to run.

## Settings by environment

`.env` is never in git or in a zip. The templates:

- `.env.example`: local and demo laptop (`FACETS_QA`, `MDM_REF`, `SDM_DENORM`
  on `localhost`).
- `scripts/customer/customer.env.example`: the customer, with the database
  names the customer uses and no credentials.

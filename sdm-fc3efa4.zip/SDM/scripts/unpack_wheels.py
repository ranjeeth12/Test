"""Join the parts sdm-wheels-<tag>.001, .002, ... in the SDM folder and unpack
them into wheels\\. Run by setup_offline.cmd with the new .venv's Python, so
it uses the standard library only.
"""

from __future__ import annotations

import io
import shutil
import sys
import sysconfig
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    machine = sysconfig.get_platform()
    if machine == "win32":
        print("\nThis Python is the 32-bit build; the tool needs 64-bit Python "
              "(pandas has no 32-bit build). Install the 64-bit Python from "
              "python.org, delete the .venv folder, and run this again.")
        return 1
    tag = f"cp{sys.version_info[0]}{sys.version_info[1]}"
    if sysconfig.get_config_var("Py_GIL_DISABLED"):
        tag += "t"  # the free-threaded build (python3.14t) has its own set
    if machine == "win-arm64":
        tag += "-arm64"
    parts = sorted(ROOT.glob(f"sdm-wheels-{tag}.[0-9][0-9][0-9]"))
    if not parts:
        others = sorted(p.name for p in ROOT.glob("sdm-wheels-*.[0-9][0-9][0-9]"))
        print(f"\nNo sdm-wheels-{tag}.001 in {ROOT}. This Python is "
              f"{sys.version_info[0]}.{sys.version_info[1]} ({machine}); copy the "
              "parts for it (sdm-wheels-" + tag + ".001, .002, ...) into this folder.")
        if others:
            print("Found parts for another Python: " + ", ".join(others))
        return 1
    numbers = [int(p.suffix[1:]) for p in parts]
    missing = sorted(set(range(1, max(numbers) + 1)) - set(numbers))
    if missing:
        print("\nMissing part(s): " + ", ".join(f"sdm-wheels-{tag}.{n:03d}" for n in missing))
        return 1

    data = b"".join(p.read_bytes() for p in parts)
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            bad = zf.testzip()
            if bad:
                print(f"\n{bad} is damaged. Copy the parts again.")
                return 1
            # A wheels folder from an earlier run may hold another machine's set.
            shutil.rmtree(ROOT / "wheels", ignore_errors=True)
            zf.extractall(ROOT)
    except zipfile.BadZipFile:
        print(f"\nThe parts do not make a whole zip: one is missing after "
              f"sdm-wheels-{tag}.{max(numbers):03d}, or one is damaged. Copy them again.")
        return 1
    print(f"Unpacked {len(parts)} parts into wheels")
    return 0


if __name__ == "__main__":
    sys.exit(main())

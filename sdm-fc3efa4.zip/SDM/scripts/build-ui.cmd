@echo off
setlocal
cd /d "%~dp0..\ui"
call npm install
call npm run build

"""Build a zip somebody can set this up from.

What goes in is exactly what git tracks, the built interface included. Using
git's own list rather than a set of exclude patterns means the zip can never
carry the things `.gitignore` exists to keep out -- the password in `.env`
above all, but also the 400MB virtual environment, the query cache, and one
installation's working state.

Commit first: a change that is not committed is not in the zip.

    python scripts/package.py            dist/sdm-<commit>.zip
    python scripts/package.py --out X    somewhere else
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Tracked, and checked for: without it the far machine needs Node.
REQUIRED = ["ui/dist/index.html"]

# A sanity check rather than a filter. If any of these ever appear in the list,
# something has gone wrong with .gitignore and the zip should not be written.
NEVER = (".env", ".venv/", "node_modules/", "sdg/analyzer/cache/", "work/")

LIMIT_MB = 25


def tracked() -> list[str]:
    out = subprocess.run(
        ["git", "ls-files"], cwd=ROOT, capture_output=True, text=True, check=True
    )
    return [line for line in out.stdout.splitlines() if line.strip()]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args(argv)

    commit = subprocess.run(
        ["git", "rev-parse", "--short", "HEAD"],
        cwd=ROOT, capture_output=True, text=True, check=True,
    ).stdout.strip()

    files = tracked()
    missing = [name for name in REQUIRED if name not in files]
    if missing:
        print(f"REFUSING: not committed: {', '.join(missing)}")
        print("  build the interface (scripts\\build-ui.cmd) and commit ui/dist")
        return 1

    # Exact names or directory prefixes, never a bare startswith: `.env.example`
    # is the template a person copies and must ship, and it starts with `.env`.
    forbidden = [
        f for f in files
        if any(f == n or (n.endswith("/") and f.startswith(n)) for n in NEVER)
    ]
    if forbidden:
        print("REFUSING: these should never be packaged:")
        for name in forbidden:
            print(f"  {name}")
        return 1

    out = args.out or (ROOT / "dist" / f"sdm-{commit}.zip")
    out.parent.mkdir(parents=True, exist_ok=True)

    # Which build a machine runs, readable there without git: the customer and
    # the demo laptop have no .git (ENVIRONMENTS.md, "Which build each runs").
    when = subprocess.run(
        ["git", "show", "-s", "--format=%ci", "HEAD"],
        cwd=ROOT, capture_output=True, text=True, check=True,
    ).stdout.strip()
    version = f"SDM build {commit}\ncommitted {when}\n"

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        zf.writestr("SDM/VERSION.txt", version)
        for name in files:
            path = ROOT / name
            if path.is_file():
                zf.write(path, f"SDM/{name}")

    size_mb = out.stat().st_size / 1_048_576
    print(f"{out}")
    print(f"  {len(files):,} files, {size_mb:.1f} MB")
    if size_mb > LIMIT_MB:
        print(f"  OVER the {LIMIT_MB} MB limit")
        return 1
    print(f"  under the {LIMIT_MB} MB limit")
    print("  no .env, no .venv, no node_modules, no cache, no work/")
    return 0


if __name__ == "__main__":
    sys.exit(main())

-- truncate_extract_tables.sql: empty the 23 tables extract.cmd loads.
--
-- Run it IN THE SDM PLATFORM DATABASE (pick it in SSMS, or sqlcmd -d <db>).
-- It empties only the extract's tables in schema sdm. The tool's own tables
-- (patterns, generation_rules, layouts, discovery_features, extract_log, the
-- reference lists, ...) are not touched.
--
-- TRUNCATE needs ALTER on the table. Without that right, the table is emptied
-- with DELETE instead (slower on big tables, same result). A table that does
-- not exist is skipped. Each line printed says what happened.

SET NOCOUNT ON;

DECLARE @tables TABLE (n int IDENTITY(1, 1), name sysname);
INSERT INTO @tables (name) VALUES
    ('member_denorm'), ('claims_denorm'),
    ('member_elig'), ('subscriber_denorm'), ('member_address'), ('member_pcp'), ('member_cob'),
    ('plan_denorm'), ('plan_network'), ('plan_benefit_denorm'), ('plan_accumulator'),
    ('service_code_map'), ('place_of_service'),
    ('claims_header_ext_denorm'), ('claims_detail_denorm'), ('claims_diag'),
    ('claims_icd_proc'), ('claims_ub_code'), ('claims_auth'),
    ('provider_relation'), ('provider_denorm'), ('provider_address'), ('provider_network');

DECLARE @i int = 1, @max int = (SELECT MAX(n) FROM @tables), @name sysname, @full nvarchar(300);
WHILE @i <= @max
BEGIN
    SELECT @name = name FROM @tables WHERE n = @i;
    SET @full = N'[sdm].' + QUOTENAME(@name);
    IF OBJECT_ID(@full, 'U') IS NULL
        PRINT @name + N': not found, skipped';
    ELSE
    BEGIN
        BEGIN TRY
            EXEC (N'TRUNCATE TABLE ' + @full);
            PRINT @name + N': truncated';
        END TRY
        BEGIN CATCH
            EXEC (N'DELETE FROM ' + @full);
            PRINT @name + N': emptied with DELETE (' + ERROR_MESSAGE() + N')';
        END CATCH
    END
    SET @i += 1;
END
PRINT 'Done. Next: scripts\customer\extract.cmd';

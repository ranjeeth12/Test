-- 01_sdm_upgrade.sql: add-only. Columns and tables the tool needs.
--
-- For the customer's SDM platform database. Written for schema sdm; if the
-- tool is configured for another schema (SDG_DENORM_SCHEMA), replace "sdm."
-- and 'sdm' throughout before running.
--
-- Nothing is dropped, renamed, retyped or deleted, and member_denorm and
-- claims_denorm are not touched. Each statement checks before it acts, so the
-- script can be run again safely.
--
-- 1. Columns added to the platform's own tables (patterns, pattern_rules,
--    pattern_tags, generation_rules). All are NULL or carry a default, so
--    existing rows and existing inserts are unaffected.
-- 2. Tables the tool keeps that the platform does not have: layouts, column
--    aliases for rules, masking (4 tables) and the pattern baseline. Their ids
--    are IDENTITY.
--
-- The tool also works on the platform's tables as they are where ids are plain
-- ints and created_at has no default: it assigns ids under a lock and stamps
-- the times itself.

-- patterns: what the tool records about a pattern beyond the platform's columns.
IF COL_LENGTH('sdm.patterns', 'sgsg_ck') IS NULL
    ALTER TABLE sdm.patterns ADD sgsg_ck NVARCHAR(500) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'lobd_id') IS NULL
    ALTER TABLE sdm.patterns ADD lobd_id NVARCHAR(500) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'sgsg_name') IS NULL
    ALTER TABLE sdm.patterns ADD sgsg_name NVARCHAR(200) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'entity') IS NULL
    ALTER TABLE sdm.patterns ADD entity NVARCHAR(20) NOT NULL CONSTRAINT DF_patterns_entity DEFAULT 'members';
GO

IF COL_LENGTH('sdm.patterns', 'origin') IS NULL
    ALTER TABLE sdm.patterns ADD origin NVARCHAR(20) NOT NULL CONSTRAINT DF_patterns_origin DEFAULT 'discovered';
GO

IF COL_LENGTH('sdm.patterns', 'combo_key') IS NULL
    ALTER TABLE sdm.patterns ADD combo_key NVARCHAR(400) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'created_by') IS NULL
    ALTER TABLE sdm.patterns ADD created_by NVARCHAR(100) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'certified_at') IS NULL
    ALTER TABLE sdm.patterns ADD certified_at DATETIME2 NULL;
GO

IF COL_LENGTH('sdm.patterns', 'certified_by') IS NULL
    ALTER TABLE sdm.patterns ADD certified_by NVARCHAR(100) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'certified_against_id') IS NULL
    ALTER TABLE sdm.patterns ADD certified_against_id INT NULL;
GO

-- pattern_rules
IF COL_LENGTH('sdm.pattern_rules', 'member_count') IS NULL
    ALTER TABLE sdm.pattern_rules ADD member_count INT NULL;
GO

IF COL_LENGTH('sdm.pattern_rules', 'created_by') IS NULL
    ALTER TABLE sdm.pattern_rules ADD created_by NVARCHAR(100) NULL;
GO

-- pattern_tags
IF COL_LENGTH('sdm.pattern_tags', 'confidence') IS NULL
    ALTER TABLE sdm.pattern_tags ADD confidence DECIMAL(5,4) NULL;
GO

-- generation_rules: the element a rule produces, and the measured shape of a number.
IF COL_LENGTH('sdm.generation_rules', 'element') IS NULL
    ALTER TABLE sdm.generation_rules ADD element NVARCHAR(80) NULL;
GO

IF COL_LENGTH('sdm.generation_rules', 'min_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD min_value FLOAT NULL;
GO

IF COL_LENGTH('sdm.generation_rules', 'max_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD max_value FLOAT NULL;
GO

IF COL_LENGTH('sdm.generation_rules', 'decimals') IS NULL
    ALTER TABLE sdm.generation_rules ADD decimals INT NULL;
GO

IF COL_LENGTH('sdm.generation_rules', 'weights') IS NULL
    ALTER TABLE sdm.generation_rules ADD weights NVARCHAR(MAX) NULL;
GO

IF COL_LENGTH('sdm.generation_rules', 'distribution') IS NULL
    ALTER TABLE sdm.generation_rules ADD distribution NVARCHAR(20) NULL;
GO

IF COL_LENGTH('sdm.generation_rules', 'mean_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD mean_value FLOAT NULL;
GO

IF COL_LENGTH('sdm.generation_rules', 'stddev_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD stddev_value FLOAT NULL;
GO

-- New tables
IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.layouts') AND type = N'U')
CREATE TABLE sdm.layouts (
    id           INT IDENTITY(1,1) PRIMARY KEY,
    name         NVARCHAR(200) NOT NULL,
    kind         NVARCHAR(10)  NOT NULL,          -- 'csv' or 'fixed'
    delimiter    NVARCHAR(5)   NULL,              -- csv only
    status       NVARCHAR(20)  NOT NULL DEFAULT 'pending_review',
    field_spec   NVARCHAR(MAX) NOT NULL,          -- parsed fields + assignments
    sample_name  NVARCHAR(400) NULL,
    created_by   NVARCHAR(100) NULL,
    created_at   DATETIME2     NOT NULL DEFAULT GETDATE(),
    approved_by  NVARCHAR(100) NULL,
    approved_at  DATETIME2     NULL,
    -- What the layout is for. A generation layout assigns generation rules to
    -- its fields; a masking layout assigns masking rules. The two catalogs are
    -- separate, so a layout has to declare which one it draws from.
    purpose      NVARCHAR(20)  NOT NULL DEFAULT 'generation',
    CONSTRAINT UQ_layouts_name UNIQUE (name)
);
GO

IF COL_LENGTH('sdm.layouts', 'purpose') IS NULL
    ALTER TABLE sdm.layouts
        ADD purpose NVARCHAR(20) NOT NULL DEFAULT 'generation';
GO

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.generation_rule_aliases') AND type = N'U')
CREATE TABLE sdm.generation_rule_aliases (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    rule_id     INT           NOT NULL,
    -- One column name can only ever mean one element. The constraint is the
    -- point: without it two rules could both claim MEME_FIRST_NAME and
    -- resolution would pick whichever row came back first, which is a bug that
    -- only shows up as quietly wrong data.
    column_name NVARCHAR(200) NOT NULL UNIQUE,
    created_by  NVARCHAR(100) NULL,
    created_at  DATETIME2     NOT NULL DEFAULT GETDATE()
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.masking_config') AND type = N'U')
CREATE TABLE sdm.masking_config (
    setting  NVARCHAR(60)  NOT NULL PRIMARY KEY,
    value    NVARCHAR(400) NOT NULL,
    set_at   DATETIME2     NOT NULL DEFAULT GETDATE()
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.masking_lookups') AND type = N'U')
CREATE TABLE sdm.masking_lookups (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    name        NVARCHAR(120) NOT NULL UNIQUE,
    -- 'pool'  : one column of candidate values, chosen from by hash
    -- 'map'   : two columns, value -> replacement, matched exactly
    kind        NVARCHAR(10)  NOT NULL,
    -- Either a registered sdm.lkp_* table or a file on this machine.
    source_kind NVARCHAR(10)  NOT NULL,      -- 'table' | 'file'
    source      NVARCHAR(400) NOT NULL,
    value_col   NVARCHAR(120) NULL,          -- pool: which column to draw from
    n_rows      INT           NULL,
    created_by  NVARCHAR(100) NULL,
    created_at  DATETIME2     NOT NULL DEFAULT GETDATE()
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.masking_rules') AND type = N'U')
CREATE TABLE sdm.masking_rules (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    name        NVARCHAR(120) NOT NULL UNIQUE,
    algorithm   NVARCHAR(30)  NOT NULL,
    -- The instance's own configuration, shaped by its algorithm.
    config      NVARCHAR(MAX) NOT NULL,
    description NVARCHAR(400) NULL,
    created_by  NVARCHAR(100) NULL,
    created_at  DATETIME2     NOT NULL DEFAULT GETDATE(),
    updated_at  DATETIME2     NULL
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.layout_masking') AND type = N'U')
CREATE TABLE sdm.layout_masking (
    id         INT IDENTITY(1,1) PRIMARY KEY,
    layout_id  INT           NOT NULL,
    field_name NVARCHAR(200) NOT NULL,
    rule_id    INT           NOT NULL,
    assigned_by NVARCHAR(100) NULL,
    assigned_at DATETIME2    NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_layout_masking UNIQUE (layout_id, field_name)
);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.objects
    WHERE object_id = OBJECT_ID(N'sdm.pattern_baseline') AND type = N'U'
)
CREATE TABLE sdm.pattern_baseline (
    id            INT IDENTITY(1,1) PRIMARY KEY,
    entity        NVARCHAR(20)  NOT NULL,   -- 'members' or 'claims'
    scope_key     NVARCHAR(200) NOT NULL,   -- 'ALL', or 'GRGR:10042'
    scope_label   NVARCHAR(300) NULL,
    n_patterns    INT           NOT NULL DEFAULT 0,
    total_count   BIGINT        NOT NULL DEFAULT 0,
    detail_json   NVARCHAR(MAX) NULL,
    computed_at   DATETIME2     NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_pattern_baseline UNIQUE (entity, scope_key)
);
GO

-- Which features system discovered patterns are found on (the Configure
-- screen). Empty means the defaults. The tool also creates it if missing.
IF OBJECT_ID(N'sdm.discovery_features', N'U') IS NULL
CREATE TABLE sdm.discovery_features (
    entity     NVARCHAR(20)  NOT NULL,
    feature    NVARCHAR(60)  NOT NULL,
    chosen_by  NVARCHAR(100) NULL,
    chosen_at  DATETIME2     NULL,
    CONSTRAINT PK_discovery_features PRIMARY KEY (entity, feature)
);
GO

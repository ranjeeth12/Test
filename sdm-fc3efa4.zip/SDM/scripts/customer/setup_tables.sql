-- setup_tables.sql: everything scripts\customer\setup_tables.cmd does, as
-- plain T-SQL, for a DBA or a Tidal SQL job. No Python needed.
--
-- Run it IN THE SDM PLATFORM DATABASE (pick it in SSMS, or sqlcmd -d <db>).
-- It creates schema sdm and, in it: the denorm tables, the provider, plan
-- and claim-detail tables, their indexes, the tool's own tables, and the
-- reference lists (names, streets, ZIP/city/state sample, default rules).
--
-- Add-only: every statement creates or seeds only what is missing, and
-- running it again changes nothing. It never empties a table that has rows.
-- The one DROP in it replaces a member_denorm or claims_denorm that has a
-- "source" column, which only old SDM demo versions had; the customer's
-- tables have none, so on the customer's database it never runs.
-- Recorded from setup_tables.cmd on an empty database, statement for
-- statement; GO separates the batches.

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
SET NOCOUNT ON;
GO

IF SCHEMA_ID('sdm') IS NULL EXEC('CREATE SCHEMA [sdm]')
GO

-- What this script may and may not destroy
--
-- The lookup tables below are reference data this script owns: it drops and
-- reloads them, because nothing else writes them and the seed rows would
-- otherwise double on every run.
--
-- The tables holding a person's work -- saved patterns, their rules and tags,
-- generation history, validation rules -- are created only if absent. Rebuilding
-- the fixture runs this script, and a rebuild emptying the pattern catalog is
-- the kind of data loss nobody reports because it looks like nothing happened.

-- The pattern analyzer's own tables.
--
-- Adapted from the analyzer's SDM_SQL_Server_Setup.sql. The original created a
-- separate SDM_Platform database and switched into it; here the schema is
-- created in whichever database the connection is already pointed at, which is
-- the same one holding the FACETS tables it describes. A pattern found by the
-- analyzer is then about the rows this tool generates, not about a copy of
-- them in another database.
--
-- Everything below the header is the analyzer's own definition, unchanged.

-- Add-only. Nothing here drops a table, a key or a row: the store may be a
-- customer's, holding tables and rows that are not this tool's. Every table is
-- created only if absent, every index only if missing, and seed rows go only
-- into a table that is empty.

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'sdm')
    EXEC('CREATE SCHEMA sdm');
GO

-- ============================================================================
-- LOOKUP TABLES — Governed reference data for synthetic generation
-- ============================================================================

-- First names (gender-tagged)
IF OBJECT_ID('sdm.lkp_first_names', 'U') IS NULL
CREATE TABLE sdm.lkp_first_names (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    name        NVARCHAR(50)    NOT NULL,
    gender      CHAR(1)         NOT NULL,  -- M or F
    created_at  DATETIME2       NOT NULL DEFAULT GETDATE()
);

-- Last names
IF OBJECT_ID('sdm.lkp_last_names', 'U') IS NULL
CREATE TABLE sdm.lkp_last_names (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    name        NVARCHAR(50)    NOT NULL,
    created_at  DATETIME2       NOT NULL DEFAULT GETDATE()
);

-- Street names
IF OBJECT_ID('sdm.lkp_street_names', 'U') IS NULL
CREATE TABLE sdm.lkp_street_names (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    street      NVARCHAR(50)    NOT NULL,
    type        NVARCHAR(10)    NOT NULL,  -- St, Ave, Dr, Blvd, etc.
    created_at  DATETIME2       NOT NULL DEFAULT GETDATE()
);

-- ZIP / City / State / County (CareSource service area)
IF OBJECT_ID('sdm.lkp_zip_city_state', 'U') IS NULL
CREATE TABLE sdm.lkp_zip_city_state (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    zip         CHAR(5)         NOT NULL,
    city        NVARCHAR(50)    NOT NULL,
    state       CHAR(2)         NOT NULL,
    county      NVARCHAR(50)    NOT NULL,
    created_at  DATETIME2       NOT NULL DEFAULT GETDATE()
);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_lkp_zip_state' AND object_id = OBJECT_ID('sdm.lkp_zip_city_state'))
CREATE INDEX IX_lkp_zip_state ON sdm.lkp_zip_city_state (state);


-- ============================================================================
-- PATTERN METADATA — Discovered patterns, tags, and vocabulary
-- ============================================================================

-- Patterns (system-discovered)
IF OBJECT_ID('sdm.patterns', 'U') IS NULL
CREATE TABLE sdm.patterns (
    id                  INT IDENTITY(1,1) PRIMARY KEY,
    pattern_key         NVARCHAR(200)   NOT NULL UNIQUE,
    contextual_name     NVARCHAR(200)   NOT NULL,
    grgr_ck             NVARCHAR(500),          -- JSON array of group keys
    sgsg_ck             NVARCHAR(500),          -- JSON array of subgroup keys
    cspd_cat            NVARCHAR(500),          -- JSON array of plan categories
    lobd_id             NVARCHAR(500),          -- JSON array of LOB IDs
    grgr_name           NVARCHAR(200),
    sgsg_name           NVARCHAR(200),
    cspd_cat_desc       NVARCHAR(200),
    plds_desc           NVARCHAR(200),
    cluster_id          INT             NOT NULL,
    member_count        INT             NOT NULL,
    pct_of_pop          DECIMAL(8,6),
    silhouette          DECIMAL(8,6),
    profile_json        NVARCHAR(MAX),          -- Full profile data
    ai_summary          NVARCHAR(MAX),
    created_at          DATETIME2       NOT NULL DEFAULT GETDATE(),
    updated_at          DATETIME2       NOT NULL DEFAULT GETDATE()
);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_patterns_name' AND object_id = OBJECT_ID('sdm.patterns'))
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_patterns_name' AND object_id = OBJECT_ID('sdm.patterns'))
CREATE INDEX IX_patterns_name ON sdm.patterns (contextual_name);

-- Pattern rules (user-saved pattern configurations)
IF OBJECT_ID('sdm.pattern_rules', 'U') IS NULL
CREATE TABLE sdm.pattern_rules (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    pattern_id      INT             REFERENCES sdm.patterns(id),
    rule_name       NVARCHAR(200)   NOT NULL,
    rule_text       NVARCHAR(MAX)   NOT NULL,
    member_count    INT,
    created_by      NVARCHAR(100)   DEFAULT 'system',
    created_at      DATETIME2       NOT NULL DEFAULT GETDATE()
);

-- Pattern tags
IF OBJECT_ID('sdm.pattern_tags', 'U') IS NULL
CREATE TABLE sdm.pattern_tags (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    pattern_id      INT             NOT NULL REFERENCES sdm.patterns(id),
    tag             NVARCHAR(100)   NOT NULL,
    tag_source      NVARCHAR(50)    NOT NULL DEFAULT 'auto',
    confidence      DECIMAL(5,4)    DEFAULT 1.0,
    confirmed_by    NVARCHAR(100),
    confirmed_at    DATETIME2,
    created_at      DATETIME2       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_pattern_tag UNIQUE (pattern_id, tag)
);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_pattern_tags_tag' AND object_id = OBJECT_ID('sdm.pattern_tags'))
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_pattern_tags_tag' AND object_id = OBJECT_ID('sdm.pattern_tags'))
CREATE INDEX IX_pattern_tags_tag ON sdm.pattern_tags (tag);

-- Tag vocabulary (synonyms for keyword search)
IF OBJECT_ID('sdm.tag_vocabulary', 'U') IS NULL
CREATE TABLE sdm.tag_vocabulary (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    canonical_tag   NVARCHAR(100)   NOT NULL,
    synonym         NVARCHAR(100)   NOT NULL,
    category        NVARCHAR(50),
    sme_confirmed   BIT             DEFAULT 0,
    confirmed_by    NVARCHAR(100),
    confirmed_at    DATETIME2,
    created_at      DATETIME2       NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_tag_synonym UNIQUE (canonical_tag, synonym)
);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_tag_vocab_synonym' AND object_id = OBJECT_ID('sdm.tag_vocabulary'))
CREATE INDEX IX_tag_vocab_synonym ON sdm.tag_vocabulary (synonym);


-- ============================================================================
-- GENERATION — Rules, configuration, and audit log
-- ============================================================================

-- Generation rules (per-field configuration)
-- Created once and never dropped: a person edits these, and a rebuild that
-- recreated the table lost every edit without saying so. The aliases table
-- also holds a foreign key to it, so a drop would fail outright.
IF OBJECT_ID('sdm.generation_rules', 'U') IS NULL
CREATE TABLE sdm.generation_rules (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    field_name      NVARCHAR(100)   NOT NULL UNIQUE,
    field_label     NVARCHAR(200)   NOT NULL,
    field_category  NVARCHAR(50)    NOT NULL DEFAULT 'denorm',
    -- What a rule produces, as the catalog names it. A rule is referred to by
    -- this and not by its column: a column is a fact about one database, and
    -- anything naming a rule should work against any of them.
    element         NVARCHAR(80)    NULL,
    gen_method      NVARCHAR(50)    NOT NULL DEFAULT 'sequential',
    data_type       NVARCHAR(50)    NOT NULL DEFAULT 'alphanumeric',
    length          INT             DEFAULT 10,
    prefix          NVARCHAR(50)    DEFAULT '',
    postfix         NVARCHAR(50)    DEFAULT '',
    start_value     INT             DEFAULT 1,
    -- A value set is as long as it is: six hundred first names is an ordinary
    -- lookup and did not fit a short column, so those rules failed to seed.
    domain          NVARCHAR(MAX)   NULL,
    format_pattern  NVARCHAR(200)   DEFAULT '',
    lookup_source   NVARCHAR(200)   DEFAULT '',
    -- The range a number was measured in, its places, and how often each
    -- value of a list occurs: a measurement, not only its shape.
    min_value       FLOAT           NULL,
    max_value       FLOAT           NULL,
    decimals        INT             NULL,
    weights         NVARCHAR(MAX)   NULL,
    -- How a number falls between its bounds, as the plan measured it: most
    -- charges are near a hundred and a few reach thousands, which an even
    -- draw between the two cannot say. Mean and deviation are of the
    -- underlying normal for a log-normal, as the profiler reports them.
    distribution    NVARCHAR(20)    NULL,
    mean_value      FLOAT           NULL,
    stddev_value    FLOAT           NULL,
    active          BIT             DEFAULT 1,
    updated_by      NVARCHAR(100)   DEFAULT 'system',
    updated_at      DATETIME2       NOT NULL DEFAULT GETDATE()
);

-- Columns added after the table was first created, for a store that predates them.
IF COL_LENGTH('sdm.generation_rules', 'element') IS NULL
    ALTER TABLE sdm.generation_rules ADD element NVARCHAR(80) NULL;
IF COL_LENGTH('sdm.generation_rules', 'min_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD min_value FLOAT NULL;
IF COL_LENGTH('sdm.generation_rules', 'max_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD max_value FLOAT NULL;
IF COL_LENGTH('sdm.generation_rules', 'decimals') IS NULL
    ALTER TABLE sdm.generation_rules ADD decimals INT NULL;
IF COL_LENGTH('sdm.generation_rules', 'weights') IS NULL
    ALTER TABLE sdm.generation_rules ADD weights NVARCHAR(MAX) NULL;
IF COL_LENGTH('sdm.generation_rules', 'distribution') IS NULL
    ALTER TABLE sdm.generation_rules ADD distribution NVARCHAR(20) NULL;
IF COL_LENGTH('sdm.generation_rules', 'mean_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD mean_value FLOAT NULL;
IF COL_LENGTH('sdm.generation_rules', 'stddev_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD stddev_value FLOAT NULL;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_gen_rules_field'
               AND object_id = OBJECT_ID('sdm.generation_rules'))
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_gen_rules_field' AND object_id = OBJECT_ID('sdm.generation_rules'))
CREATE INDEX IX_gen_rules_field ON sdm.generation_rules (field_name);

-- Generation log (audit trail)
IF OBJECT_ID('sdm.generation_log', 'U') IS NULL
CREATE TABLE sdm.generation_log (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    pattern_ids     NVARCHAR(MAX)   NOT NULL,   -- JSON array
    data_type       NVARCHAR(50)    NOT NULL,   -- members, claims, enrollments
    volume          INT             NOT NULL,
    output_path     NVARCHAR(500),
    weighting       NVARCHAR(MAX),              -- JSON
    requested_by    NVARCHAR(100)   DEFAULT 'user',
    created_at      DATETIME2       NOT NULL DEFAULT GETDATE()
);


-- ============================================================================
-- SOURCE DATA — Member denorm (current POC structure)
-- Replace with Config Denorm + direct source reads when redesigning
-- ============================================================================

-- member_denorm is a view over the FACETS tables; see the end of this file.


-- ============================================================================
-- SEED DATA — Lookup tables and tag vocabulary
-- ============================================================================

-- First names

IF NOT EXISTS (SELECT 1 FROM sdm.lkp_first_names)
BEGIN
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'James', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'John', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Robert', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Michael', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'William', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'David', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Richard', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Joseph', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Thomas', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Charles', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Christopher', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Daniel', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Matthew', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Anthony', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Mark', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Donald', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Steven', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Andrew', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Paul', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Joshua', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Kenneth', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Kevin', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Brian', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'George', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Timothy', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Ronald', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Edward', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jason', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jeffrey', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Ryan', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jacob', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Gary', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Nicholas', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Eric', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jonathan', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Stephen', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Larry', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Justin', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Scott', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Brandon', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Benjamin', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Samuel', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Raymond', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Gregory', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Frank', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Alexander', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Patrick', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jack', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Dennis', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jerry', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Tyler', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Aaron', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Nathan', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Henry', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Peter', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Adam', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Douglas', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Zachary', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Walter', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Kyle', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Harold', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Carl', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Arthur', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Gerald', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Roger', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Keith', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Lawrence', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Terry', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Sean', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Albert', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jesse', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Austin', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Bruce', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Willie', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Ralph', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Roy', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Eugene', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Randy', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Philip', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Russell', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Bobby', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Howard', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Louis', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Wayne', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Dylan', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Ethan', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jordan', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Christian', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Mason', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Logan', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Caleb', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Luke', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Isaac', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Connor', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Elijah', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Gabriel', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Owen', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Liam', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Noah', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Aiden', N'M');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Mary', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Patricia', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jennifer', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Linda', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Barbara', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Elizabeth', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Susan', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jessica', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Sarah', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Karen', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Lisa', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Nancy', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Betty', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Margaret', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Sandra', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Ashley', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Dorothy', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Kimberly', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Emily', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Donna', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Michelle', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Carol', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Amanda', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Melissa', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Deborah', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Stephanie', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Rebecca', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Sharon', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Laura', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Cynthia', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Kathleen', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Amy', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Angela', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Shirley', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Anna', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Brenda', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Pamela', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Emma', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Nicole', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Helen', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Samantha', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Katherine', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Christine', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Debra', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Rachel', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Carolyn', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Janet', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Catherine', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Maria', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Heather', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Diane', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Ruth', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Julie', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Olivia', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Joyce', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Virginia', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Victoria', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Kelly', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Lauren', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Christina', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Joan', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Evelyn', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Judith', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Megan', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Andrea', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Cheryl', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Hannah', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jacqueline', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Martha', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Gloria', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Teresa', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Ann', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Sara', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Madison', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Frances', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Kathryn', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Janice', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Jean', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Abigail', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Alice', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Judy', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Sophia', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Grace', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Denise', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Amber', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Doris', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Marilyn', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Danielle', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Beverly', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Isabella', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Theresa', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Diana', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Natalie', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Brittany', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Charlotte', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Marie', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Kayla', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Alexis', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Lori', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Ava', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Mia', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Chloe', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Ella', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Lily', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Zoe', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Leah', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Allison', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Savannah', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Audrey', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Brooklyn', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Claire', N'F');
INSERT INTO sdm.lkp_first_names (name, gender) VALUES (N'Addison', N'F');
END;

-- Last names

IF NOT EXISTS (SELECT 1 FROM sdm.lkp_last_names)
BEGIN
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Smith');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Johnson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Williams');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Brown');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Jones');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Garcia');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Miller');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Davis');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Rodriguez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Martinez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Hernandez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Lopez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Gonzalez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Wilson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Anderson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Thomas');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Taylor');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Moore');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Jackson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Martin');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Lee');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Perez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Thompson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'White');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Harris');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Sanchez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Clark');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Ramirez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Lewis');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Robinson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Walker');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Young');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Allen');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'King');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Wright');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Scott');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Torres');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Nguyen');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Hill');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Flores');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Green');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Adams');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Nelson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Baker');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Hall');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Rivera');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Campbell');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Mitchell');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Carter');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Roberts');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Gomez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Phillips');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Evans');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Turner');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Diaz');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Parker');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Cruz');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Edwards');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Collins');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Reyes');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Stewart');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Morris');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Morales');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Murphy');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Cook');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Rogers');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Gutierrez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Ortiz');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Morgan');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Cooper');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Peterson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Bailey');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Reed');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Kelly');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Howard');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Ramos');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Kim');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Cox');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Ward');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Richardson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Watson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Brooks');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Chavez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Wood');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'James');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Bennett');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Gray');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Mendoza');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Ruiz');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Hughes');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Price');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Alvarez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Castillo');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Sanders');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Patel');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Myers');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Long');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Ross');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Foster');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Jimenez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Powell');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Jenkins');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Perry');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Russell');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Sullivan');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Bell');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Coleman');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Butler');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Henderson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Barnes');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Gonzales');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Fisher');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Vasquez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Simmons');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Graham');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Murray');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Ford');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Castro');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Marshall');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Owens');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Harrison');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Fernandez');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Patterson');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Wallace');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'West');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Webb');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Tucker');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Burns');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Crawford');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Mason');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Hunt');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Warren');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Bishop');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Dixon');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Wagner');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Spencer');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Freeman');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Stone');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Horton');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Hoffman');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Carpenter');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'May');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Knight');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Hart');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Ray');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Armstrong');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Day');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Montgomery');
INSERT INTO sdm.lkp_last_names (name) VALUES (N'Andrews');
END;

-- Street names

IF NOT EXISTS (SELECT 1 FROM sdm.lkp_street_names)
BEGIN
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Main', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Oak', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Maple', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Cedar', N'Ln');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Elm', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Pine', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Washington', N'Blvd');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Park', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Lake', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Hill', N'Rd');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Church', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Spring', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'High', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Market', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Center', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Union', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Bridge', N'Rd');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Broad', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'River', N'Rd');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Walnut', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Cherry', N'Ln');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Meadow', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Forest', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Summit', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Valley', N'Rd');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Lincoln', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Franklin', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Jefferson', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Madison', N'Blvd');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Adams', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Monroe', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Harrison', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Jackson', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Grant', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Garfield', N'Rd');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Cleveland', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Wilson', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Roosevelt', N'Blvd');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Kennedy', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Reagan', N'Ct');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Sunset', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Sunrise', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Country', N'Ln');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Heritage', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Liberty', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Eagle', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Cardinal', N'Ln');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Willow', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Birch', N'Ct');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Sycamore', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Dogwood', N'Ln');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Magnolia', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Chestnut', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Hickory', N'Ln');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Ash', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Beech', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Poplar', N'St');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Spruce', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Holly', N'Ln');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Ivy', N'Ct');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Laurel', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Orchard', N'Ln');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Garden', N'Ave');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Vineyard', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Ridge', N'Rd');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Creek', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Brook', N'Ln');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Pond', N'Dr');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Stone', N'Rd');
INSERT INTO sdm.lkp_street_names (street, type) VALUES (N'Mill', N'Rd');
END;

-- ZIP / City / State

IF NOT EXISTS (SELECT 1 FROM sdm.lkp_zip_city_state)
BEGIN
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43215', N'Columbus', N'OH', N'Franklin');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43085', N'Columbus', N'OH', N'Franklin');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43201', N'Columbus', N'OH', N'Franklin');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43220', N'Columbus', N'OH', N'Franklin');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44114', N'Cleveland', N'OH', N'Cuyahoga');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44106', N'Cleveland', N'OH', N'Cuyahoga');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44120', N'Cleveland', N'OH', N'Cuyahoga');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44130', N'Cleveland', N'OH', N'Cuyahoga');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45202', N'Cincinnati', N'OH', N'Hamilton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45219', N'Cincinnati', N'OH', N'Hamilton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45229', N'Cincinnati', N'OH', N'Hamilton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45238', N'Cincinnati', N'OH', N'Hamilton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45402', N'Dayton', N'OH', N'Montgomery');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45409', N'Dayton', N'OH', N'Montgomery');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45424', N'Dayton', N'OH', N'Montgomery');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43604', N'Toledo', N'OH', N'Lucas');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43606', N'Toledo', N'OH', N'Lucas');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43612', N'Toledo', N'OH', N'Lucas');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44308', N'Akron', N'OH', N'Summit');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44313', N'Akron', N'OH', N'Summit');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44320', N'Akron', N'OH', N'Summit');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44503', N'Youngstown', N'OH', N'Mahoning');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44512', N'Youngstown', N'OH', N'Mahoning');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45601', N'Chillicothe', N'OH', N'Ross');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45701', N'Athens', N'OH', N'Athens');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43055', N'Newark', N'OH', N'Licking');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43015', N'Delaware', N'OH', N'Delaware');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43123', N'Grove City', N'OH', N'Franklin');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43068', N'Reynoldsburg', N'OH', N'Franklin');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43081', N'Westerville', N'OH', N'Franklin');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43026', N'Hilliard', N'OH', N'Franklin');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'43235', N'Columbus', N'OH', N'Franklin');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44035', N'Elyria', N'OH', N'Lorain');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44256', N'Medina', N'OH', N'Medina');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'44691', N'Wooster', N'OH', N'Wayne');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45066', N'Springboro', N'OH', N'Warren');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45040', N'Mason', N'OH', N'Warren');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'45069', N'West Chester', N'OH', N'Butler');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40202', N'Louisville', N'KY', N'Jefferson');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40205', N'Louisville', N'KY', N'Jefferson');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40214', N'Louisville', N'KY', N'Jefferson');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40220', N'Louisville', N'KY', N'Jefferson');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40241', N'Louisville', N'KY', N'Jefferson');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40258', N'Louisville', N'KY', N'Jefferson');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40502', N'Lexington', N'KY', N'Fayette');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40508', N'Lexington', N'KY', N'Fayette');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40513', N'Lexington', N'KY', N'Fayette');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40517', N'Lexington', N'KY', N'Fayette');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'41011', N'Covington', N'KY', N'Kenton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'41017', N'Ft Mitchell', N'KY', N'Kenton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'41042', N'Florence', N'KY', N'Boone');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'41048', N'Hebron', N'KY', N'Boone');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'42001', N'Paducah', N'KY', N'McCracken');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'42101', N'Bowling Green', N'KY', N'Warren');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'42301', N'Owensboro', N'KY', N'Daviess');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40601', N'Frankfort', N'KY', N'Franklin');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40701', N'Corbin', N'KY', N'Whitley');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'40741', N'London', N'KY', N'Laurel');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'41501', N'Pikeville', N'KY', N'Pike');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'41101', N'Ashland', N'KY', N'Boyd');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'46204', N'Indianapolis', N'IN', N'Marion');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'46220', N'Indianapolis', N'IN', N'Marion');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'46237', N'Indianapolis', N'IN', N'Marion');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'46250', N'Indianapolis', N'IN', N'Marion');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'46268', N'Indianapolis', N'IN', N'Marion');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'46802', N'Fort Wayne', N'IN', N'Allen');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'46815', N'Fort Wayne', N'IN', N'Allen');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'46901', N'Kokomo', N'IN', N'Howard');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'47374', N'Richmond', N'IN', N'Wayne');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'47906', N'West Lafayette', N'IN', N'Tippecanoe');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'47401', N'Bloomington', N'IN', N'Monroe');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'46060', N'Noblesville', N'IN', N'Hamilton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'46032', N'Carmel', N'IN', N'Hamilton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'46143', N'Greenwood', N'IN', N'Johnson');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'47130', N'Jeffersonville', N'IN', N'Clark');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30301', N'Atlanta', N'GA', N'Fulton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30309', N'Atlanta', N'GA', N'Fulton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30318', N'Atlanta', N'GA', N'Fulton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30324', N'Atlanta', N'GA', N'DeKalb');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30340', N'Atlanta', N'GA', N'DeKalb');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30004', N'Alpharetta', N'GA', N'Fulton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30022', N'Alpharetta', N'GA', N'Fulton');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30060', N'Marietta', N'GA', N'Cobb');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30080', N'Smyrna', N'GA', N'Cobb');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30043', N'Lawrenceville', N'GA', N'Gwinnett');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30044', N'Lawrenceville', N'GA', N'Gwinnett');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30096', N'Duluth', N'GA', N'Gwinnett');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30188', N'Woodstock', N'GA', N'Cherokee');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30501', N'Gainesville', N'GA', N'Hall');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'31201', N'Macon', N'GA', N'Bibb');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'30901', N'Augusta', N'GA', N'Richmond');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'31601', N'Valdosta', N'GA', N'Lowndes');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'25301', N'Charleston', N'WV', N'Kanawha');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'25302', N'Charleston', N'WV', N'Kanawha');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'25314', N'Charleston', N'WV', N'Kanawha');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'25701', N'Huntington', N'WV', N'Cabell');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'26003', N'Wheeling', N'WV', N'Ohio');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'26501', N'Morgantown', N'WV', N'Monongalia');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'26505', N'Morgantown', N'WV', N'Monongalia');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'25401', N'Martinsburg', N'WV', N'Berkeley');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'26101', N'Parkersburg', N'WV', N'Wood');
INSERT INTO sdm.lkp_zip_city_state (zip, city, state, county) VALUES (N'25801', N'Beckley', N'WV', N'Raleigh');
END;

-- Tag vocabulary (synonym resolution for keyword search)

IF NOT EXISTS (SELECT 1 FROM sdm.tag_vocabulary)
BEGIN
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'pediatric', N'pediatric', N'age', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'pediatric', N'child', N'age', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'pediatric', N'children', N'age', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'pediatric', N'minor', N'age', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'pediatric', N'under-18', N'age', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'adult', N'adult', N'age', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'adult', N'working-age', N'age', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'senior', N'senior', N'age', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'senior', N'elderly', N'age', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'senior', N'65+', N'age', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'senior', N'medicare-age', N'age', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'new-member', N'new-member', N'tenure', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'new-member', N'new', N'tenure', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'new-member', N'recent', N'tenure', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'long-term', N'long-term', N'tenure', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'long-term', N'established', N'tenure', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'long-term', N'loyal', N'tenure', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'family', N'family', N'family', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'family', N'with-dependents', N'family', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'single', N'single', N'family', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'single', N'individual', N'family', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'single', N'no-dependents', N'family', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'dental', N'dental', N'plan', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'dental', N'dental-plan', N'plan', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'medical', N'medical', N'plan', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'medical', N'med', N'plan', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'vision', N'vision', N'plan', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'vision', N'eye', N'plan', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'medicaid', N'medicaid', N'lob', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'medicare', N'medicare', N'lob', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'medicare-advantage', N'medicare-advantage', N'lob', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'medicare-advantage', N'ma', N'lob', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'exchange', N'exchange', N'lob', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'exchange', N'marketplace', N'lob', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'exchange', N'aca', N'lob', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'edge-case', N'edge-case', N'quality', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'edge-case', N'rare', N'quality', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'edge-case', N'anomaly', N'quality', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'edge-case', N'outlier', N'quality', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'edge-case', N'unusual', N'quality', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'high-volume', N'high-volume', N'quality', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'high-volume', N'common', N'quality', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'high-volume', N'dominant', N'quality', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'ohio', N'ohio', N'state', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'ohio', N'oh', N'state', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'kentucky', N'kentucky', N'state', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'kentucky', N'ky', N'state', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'indiana', N'indiana', N'state', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'indiana', N'in', N'state', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'georgia', N'georgia', N'state', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'georgia', N'ga', N'state', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'west-virginia', N'west-virginia', N'state', 0);
INSERT INTO sdm.tag_vocabulary (canonical_tag, synonym, category, sme_confirmed) VALUES (N'west-virginia', N'wv', N'state', 0);
END;

-- Default generation rules (names and addresses — always synthetic)
-- Each only when absent, so a rebuild neither duplicates nor overwrites them.
IF NOT EXISTS (SELECT 1 FROM sdm.generation_rules WHERE field_name = N'MEME_FIRST_NAME')
INSERT INTO sdm.generation_rules (field_name, field_label, field_category, gen_method, data_type, length, lookup_source, updated_by)
VALUES (N'MEME_FIRST_NAME', N'Member First Name', N'lookup', N'lookup', N'text', 0, N'first_names', N'system');

IF NOT EXISTS (SELECT 1 FROM sdm.generation_rules WHERE field_name = N'MEME_LAST_NAME')
INSERT INTO sdm.generation_rules (field_name, field_label, field_category, gen_method, data_type, length, lookup_source, updated_by)
VALUES (N'MEME_LAST_NAME', N'Member Last Name', N'lookup', N'lookup', N'text', 0, N'last_names', N'system');

IF NOT EXISTS (SELECT 1 FROM sdm.generation_rules WHERE field_name = N'SBSB_FIRST_NAME')
INSERT INTO sdm.generation_rules (field_name, field_label, field_category, gen_method, data_type, length, lookup_source, updated_by)
VALUES (N'SBSB_FIRST_NAME', N'Subscriber First Name', N'lookup', N'lookup', N'text', 0, N'first_names', N'system');

IF NOT EXISTS (SELECT 1 FROM sdm.generation_rules WHERE field_name = N'SBSB_LAST_NAME')
INSERT INTO sdm.generation_rules (field_name, field_label, field_category, gen_method, data_type, length, lookup_source, updated_by)
VALUES (N'SBSB_LAST_NAME', N'Subscriber Last Name', N'lookup', N'lookup', N'text', 0, N'last_names', N'system');

IF NOT EXISTS (SELECT 1 FROM sdm.generation_rules WHERE field_name = N'STREET_1')
INSERT INTO sdm.generation_rules (field_name, field_label, field_category, gen_method, data_type, length, lookup_source, updated_by)
VALUES (N'STREET_1', N'Street Address 1', N'lookup', N'lookup', N'text', 0, N'street_names', N'system');

IF NOT EXISTS (SELECT 1 FROM sdm.generation_rules WHERE field_name = N'ZIP_CODE')
INSERT INTO sdm.generation_rules (field_name, field_label, field_category, gen_method, data_type, length, lookup_source, updated_by)
VALUES (N'ZIP_CODE', N'ZIP Code', N'lookup', N'lookup', N'text', 5, N'zip_city_state', N'system');


-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT 'lkp_first_names' AS table_name, COUNT(*) AS row_count FROM sdm.lkp_first_names
UNION ALL SELECT 'lkp_last_names', COUNT(*) FROM sdm.lkp_last_names
UNION ALL SELECT 'lkp_street_names', COUNT(*) FROM sdm.lkp_street_names
UNION ALL SELECT 'lkp_zip_city_state', COUNT(*) FROM sdm.lkp_zip_city_state
UNION ALL SELECT 'tag_vocabulary', COUNT(*) FROM sdm.tag_vocabulary
UNION ALL SELECT 'generation_rules', COUNT(*) FROM sdm.generation_rules;

PRINT 'SDM Platform database setup complete.';
GO

-- ============================================================================
-- VALIDATION RULES — Configurable rules for validating generated data
-- ============================================================================

IF OBJECT_ID('sdm.validation_rules', 'U') IS NULL
CREATE TABLE sdm.validation_rules (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    rule_name       NVARCHAR(200)   NOT NULL,
    field_name      NVARCHAR(100)   NOT NULL,
    rule_type       NVARCHAR(50)    NOT NULL,   -- required, range, regex, cross_field, values
    expression      NVARCHAR(MAX)   NOT NULL,   -- JSON: {"min":0,"max":115} or {"pattern":"^[A-Z]"} or {"values":["M","F"]}
    severity        NVARCHAR(20)    NOT NULL DEFAULT 'error',  -- error or warning
    active          BIT             NOT NULL DEFAULT 1,
    created_by      NVARCHAR(100)   DEFAULT 'system',
    created_at      DATETIME2       NOT NULL DEFAULT GETDATE(),
    updated_at      DATETIME2       NOT NULL DEFAULT GETDATE()
);
GO

-- ============================================================================
-- GENERATION RUNS — Store parameters for replay / audit
-- ============================================================================

IF OBJECT_ID('sdm.generation_runs', 'U') IS NULL
CREATE TABLE sdm.generation_runs (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    run_name        NVARCHAR(200)   NOT NULL,
    pattern_ids     NVARCHAR(MAX)   NOT NULL,   -- JSON array
    data_type       NVARCHAR(50)    NOT NULL,   -- members, enrollments, claims
    volume          INT             NOT NULL,
    seed            INT             NOT NULL,   -- random seed for reproducibility
    rules_snapshot  NVARCHAR(MAX),              -- JSON snapshot of generation_rules at time of run
    filters_json    NVARCHAR(MAX),              -- JSON of hierarchy filters per pattern
    weighting       NVARCHAR(MAX),              -- JSON of pattern weights
    validation_result NVARCHAR(MAX),            -- JSON summary of validation pass/fail
    created_by      NVARCHAR(100)   DEFAULT 'user',
    created_at      DATETIME2       NOT NULL DEFAULT GETDATE()
);
GO

-- ============================================================================
-- Created on demand, deliberately not here
-- ============================================================================
-- sdm.layouts and sdm.pattern_baseline are created by the analyzer itself, on
-- first use, from the DDL that lives beside the code reading them. Declaring
-- them here as well produced two definitions that drifted apart: the copy in
-- this file was missing the columns the service selects, and because the table
-- then existed, the auto-create path saw nothing to do and the screens failed
-- on a column name instead. One definition, next to its reader.

-- ============================================================================
-- sdm.patterns, brought up to what the code reads
-- ============================================================================
-- The analyzer's setup script is older than the analyzer. Its sdm.patterns is
-- missing columns the service selects by name, and the database it was running
-- against had clearly been altered by hand -- the cached results carried
-- cspi_id, pdpd_id, saved_by and saved_at, none of which the script creates.
-- The provenance and certification columns shipped as a separate migration.
--
-- Everything below is guarded, so this runs on a fresh schema and on one that
-- has already been upgraded.

-- Hierarchy levels the pattern was found at. The script stops at plan
-- category; the code selects plan and product too.
IF COL_LENGTH('sdm.patterns', 'cspi_id') IS NULL
    ALTER TABLE sdm.patterns ADD cspi_id NVARCHAR(20) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'pdpd_id') IS NULL
    ALTER TABLE sdm.patterns ADD pdpd_id NVARCHAR(20) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'pdds_desc') IS NULL
    ALTER TABLE sdm.patterns ADD pdds_desc NVARCHAR(200) NULL;
GO

-- Who kept the pattern, and when. The saved screen reads both, and the change
-- counter uses COUNT(saved_at) to notice a save that did not change the row
-- count.
IF COL_LENGTH('sdm.patterns', 'saved_by') IS NULL
    ALTER TABLE sdm.patterns ADD saved_by NVARCHAR(100) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'saved_at') IS NULL
    ALTER TABLE sdm.patterns ADD saved_at DATETIME2 NULL;
GO

-- The entity a pattern describes. Members and claims both persist here, and
-- without this they collide on one row: the dedup key is built from hierarchy
-- plus cluster, which is identical across domains for the same group.
IF COL_LENGTH('sdm.patterns', 'entity') IS NULL
    ALTER TABLE sdm.patterns ADD entity NVARCHAR(20) NOT NULL
        CONSTRAINT DF_patterns_entity DEFAULT 'members';
GO

-- Provenance and certification, from SDM_Migration_Pattern_Provenance.sql.
-- A discovered pattern is evidence; a user-defined one is a hypothesis an SME
-- stated, and the tool cannot vouch for it.
IF COL_LENGTH('sdm.patterns', 'origin') IS NULL
    ALTER TABLE sdm.patterns ADD origin NVARCHAR(20) NOT NULL
        CONSTRAINT DF_patterns_origin DEFAULT 'discovered';
GO

IF COL_LENGTH('sdm.patterns', 'combo_key') IS NULL
    ALTER TABLE sdm.patterns ADD combo_key NVARCHAR(400) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'created_by') IS NULL
    ALTER TABLE sdm.patterns ADD created_by NVARCHAR(100) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'certified_at') IS NULL
    ALTER TABLE sdm.patterns ADD certified_at DATETIME2 NULL;
GO

IF COL_LENGTH('sdm.patterns', 'certified_by') IS NULL
    ALTER TABLE sdm.patterns ADD certified_by NVARCHAR(100) NULL;
GO

IF COL_LENGTH('sdm.patterns', 'certified_against_id') IS NULL
    ALTER TABLE sdm.patterns ADD certified_against_id INT NULL;
GO

-- ----------------------------------------------------------------------------
-- sdm.pattern_tags: the column the code reads is called `source`
-- ----------------------------------------------------------------------------
-- The setup script creates it as `tag_source`; every query in db.py selects and
-- inserts `source`. Nothing reads `tag_source` at all, so the script is simply
-- out of step with the code it ships beside -- which only surfaces when tagging
-- is reached, deep inside Story to Data.

IF COL_LENGTH('sdm.pattern_tags', 'tag_source') IS NOT NULL
   AND COL_LENGTH('sdm.pattern_tags', 'source') IS NULL
    EXEC sp_rename 'sdm.pattern_tags.tag_source', 'source', 'COLUMN';
GO

IF COL_LENGTH('sdm.pattern_tags', 'source') IS NULL
    ALTER TABLE sdm.pattern_tags ADD source NVARCHAR(20) NULL;
GO

-- ============================================================================
-- The denormalized views the analyzer reads
-- ============================================================================
-- The analyzer was written against two flat tables that something else had to
-- keep in step with the source. They are views here instead, so there is no
-- copy to refresh and no moment when the analyzer is describing data the
-- generator has already moved on from.
GO

-- The analysis store: the two denormalized tables pattern analysis reads.
--
-- These are the customer's tables, column for column and type for type, as
-- their SDM platform holds them (sdm.member_denorm, sdm.claims_denorm). The
-- customer keeps them filled from their own FACETS; nothing here may change
-- them, so this script only creates them where they are absent -- locally,
-- where the extract fills them from the demo source. There is no source
-- column: a store holds one landscape, and an extract replaces it.
--
-- Written for schema sdm; seed/bootstrap.py runs it in the configured one.
-- Indexes are not part of the customer's tables: see denorm_indexes.sql.
--
-- A table with a source column is this tool's own, from a version before the
-- store took the customer's shape: an extract, refilled by the next extract.
-- It is replaced. The customer's tables have no such column and are never
-- touched.

IF COL_LENGTH('sdm.member_denorm', 'source') IS NOT NULL
    DROP TABLE sdm.member_denorm;
IF COL_LENGTH('sdm.claims_denorm', 'source') IS NOT NULL
    DROP TABLE sdm.claims_denorm;
GO

IF OBJECT_ID('sdm.member_denorm', 'U') IS NULL
BEGIN
CREATE TABLE sdm.[member_denorm] (
    [MEME_CK] int NULL,
    [SBSB_CK] int NULL,
    [GRGR_CK] int NULL,
    [MEME_SFX] int NULL,
    [MEME_REL] char(1) NULL,
    [MEME_LAST_NAME] nvarchar(100) NULL,
    [MEME_FIRST_NAME] nvarchar(100) NULL,
    [MEME_MID_INIT] char(1) NULL,
    [MEME_SEX] char(1) NULL,
    [MEME_BIRTH_DT] date NULL,
    [MEME_SSN] bigint NULL,
    [MEME_MCTR_STS] nvarchar(10) NULL,
    [MEME_ORIG_EFF_DT] date NULL,
    [MEME_MARITAL_STATUS] char(1) NULL,
    [MEME_MEDCD_NO] nvarchar(50) NULL,
    [MEME_HICN] nvarchar(50) NULL,
    [MEME_MCTR_RACE_NVL] nvarchar(50) NULL,
    [MEME_MCTR_ETHN_NVL] nvarchar(50) NULL,
    [SBSB_ID] nvarchar(50) NULL,
    [SBSB_LAST_NAME] nvarchar(100) NULL,
    [SBSB_FIRST_NAME] nvarchar(100) NULL,
    [SBSB_ORIG_EFF_DT] date NULL,
    [SBSB_MCTR_STS] nvarchar(10) NULL,
    [SBSB_EMPLOY_ID] nvarchar(50) NULL,
    [SGSG_CK] int NULL,
    [SBSG_EFF_DT] date NULL,
    [SBSG_TERM_DT] date NULL,
    [SBSG_MCTR_TRSN] nvarchar(10) NULL,
    [SGSG_ID] nvarchar(50) NULL,
    [SGSG_NAME] nvarchar(200) NULL,
    [CSCS_ID] nvarchar(50) NULL,
    [SGSG_STATE] char(2) NULL,
    [SGSG_STS] nvarchar(10) NULL,
    [SGSG_ORIG_EFF_DT] date NULL,
    [SGSG_TERM_DT] date NULL,
    [GRGR_ID] nvarchar(50) NULL,
    [GRGR_NAME] nvarchar(200) NULL,
    [GRGR_STATE] char(2) NULL,
    [GRGR_COUNTY] nvarchar(100) NULL,
    [GRGR_STS] nvarchar(10) NULL,
    [GRGR_ORIG_EFF_DT] date NULL,
    [GRGR_TERM_DT] date NULL,
    [GRGR_MCTR_TYPE] nvarchar(10) NULL,
    [PAGR_CK] int NULL,
    [CSPI_ID] nvarchar(50) NULL,
    [CSPD_CAT] char(1) NULL,
    [CSPI_EFF_DT] date NULL,
    [CSPI_TERM_DT] date NULL,
    [PDPD_ID] nvarchar(50) NULL,
    [CSPI_SEL_IND] nvarchar(10) NULL,
    [CSPI_HIOS_ID_NVL] nvarchar(50) NULL,
    [CSPD_CAT_DESC] nvarchar(200) NULL,
    [CSPD_TYPE] nvarchar(50) NULL,
    [LOBD_ID] nvarchar(50) NULL,
    [PDPD_RISK_IND] nvarchar(10) NULL,
    [PDPD_MCTR_CCAT] nvarchar(50) NULL,
    [PLDS_DESC] nvarchar(200) NULL,
    [PDDS_DESC] nvarchar(200) NULL,
    [EMAIL] varchar(200) NULL
);
END;
GO

IF OBJECT_ID('sdm.claims_denorm', 'U') IS NULL
BEGIN
CREATE TABLE sdm.[claims_denorm] (
    [CLCL_ID] char(12) NOT NULL,
    [CDML_SEQ_NO] smallint NOT NULL,
    [CLCL_CL_TYPE] char(1) NULL,
    [CLCL_CL_SUB_TYPE] char(1) NULL,
    [CLCL_CUR_STS] char(2) NULL,
    [CLST_MCTR_REAS] char(4) NULL,
    [CLCL_NTWK_IND] char(1) NULL,
    [CLCL_INPUT_DT] datetime NULL,
    [CLCL_RECD_DT] datetime NULL,
    [CLCL_PAID_DT] datetime NULL,
    [CLCL_LOW_SVC_DT] datetime NULL,
    [CLCL_HIGH_SVC_DT] datetime NULL,
    [CLCL_TOT_CHG] money NULL,
    [CLCL_TOT_PAYABLE] money NULL,
    [MEME_CK] int NULL,
    [SBSB_CK] int NULL,
    [CLCL_ME_AGE] smallint NULL,
    [MEME_SEX] char(1) NULL,
    [MEME_REL] char(1) NULL,
    [MEPE_FI] char(1) NULL,
    [GRGR_CK] int NULL,
    [GRGR_NAME] varchar(200) NULL,
    [SGSG_CK] int NULL,
    [CSPD_CAT] char(1) NULL,
    [CSPI_ID] char(8) NULL,
    [PLDS_DESC] varchar(70) NULL,
    [PDPD_ID] char(8) NULL,
    [PDDS_PROD_TYPE] char(1) NULL,
    [IDCD_ID_PRIMARY] varchar(10) NULL,
    [IDCD_DESC_PRIMARY] varchar(70) NULL,
    [IDCD_ID_ADMIT] varchar(10) NULL,
    [CLMD_DIAG_COUNT] smallint NULL,
    [IPCD_ID] char(7) NULL,
    [IPCD_DESC] varchar(70) NULL,
    [IPCD_TYPE] char(2) NULL,
    [CDML_UNITS] smallint NULL,
    [CDML_UNITS_ALLOW] smallint NULL,
    [PSCD_ID] char(4) NULL,
    [RCRC_ID] char(4) NULL,
    [LOBD_ID] char(4) NULL,
    [PRPR_ID] char(12) NULL,
    [PRPR_NAME] varchar(60) NULL,
    [PRPR_NPI] varchar(10) NULL,
    [PRPR_MCTR_SPEC] char(4) NULL,
    [NWNW_ID] char(12) NULL,
    [CDML_CHG_AMT] money NULL,
    [CDML_ALLOW] money NULL,
    [CDML_PAID_AMT] money NULL,
    [CDML_DED_AMT] money NULL,
    [CDML_COPAY_AMT] money NULL,
    [CDML_COINS_AMT] money NULL,
    [CDML_DISALL_AMT] money NULL,
    [CDML_DISC_AMT] money NULL,
    [CDML_TOT_PA_LIAB] money NULL,
    [CDML_FROM_DT] datetime NULL,
    [CDML_TO_DT] datetime NULL,
    [CDML_CUR_STS] char(2) NULL,
    [CLCL_EXT_AUTH_NO] char(18) NULL,
    [CDML_PRE_AUTH_IND] char(1) NULL,
    [CLCL_PRPR_ID_REF] char(12) NULL,
    [CLCL_PRPR_ID_PCP] char(12) NULL,
    [CLCL_PCP_IND] char(1) NULL
);
END;
GO

-- 03_denorm_837_tables.sql: add-only. Tables that let generated EDI 837
-- (professional and institutional) claims agree across member, plan, benefit
-- and provider.
--
-- For the customer's SDM platform database, schema sdm. To use another
-- schema, replace "sdm." throughout. sdm.member_denorm and sdm.claims_denorm
-- are not touched. Each table is created only if absent and each index only
-- if missing, so the script can be run again safely. Nothing is dropped,
-- renamed, retyped or deleted.
--
-- Column names and types are FACETS's own (from the FACETS data dictionary);
-- the few derived columns are noted. Tables are narrow and keyed for the
-- joins the generator makes (by MEME_CK, SBSB_CK, PRPR_ID, PDPD_ID, CSPI_ID,
-- CLCL_ID + CDML_SEQ_NO). Fill them with 04_denorm_837_extract.sql.
-- Design and 837 crosswalk: docs/facets-837-sources.md.
--
-- Tables:
--   Provider : provider_denorm, provider_address, provider_network, provider_relation
--   Member   : member_elig, subscriber_denorm, member_address, member_pcp, member_cob
--   Plan     : plan_denorm, plan_network, plan_benefit_denorm, plan_accumulator,
--              service_code_map, place_of_service
--   Claims   : claims_header_ext_denorm, claims_detail_denorm, claims_diag,
--              claims_icd_proc, claims_ub_code, claims_auth

-- sdm.provider_denorm
-- Grain: One row per provider (PRPR_ID): the non-dated facts plus names, NPI, taxonomy and tax ID. Addresses, networks and relationships are dated and live in their own tables.
IF OBJECT_ID('sdm.provider_denorm', 'U') IS NULL
CREATE TABLE sdm.provider_denorm (
    PRPR_ID                  char(12)       NOT NULL,
    PRPR_ENTITY              char(1)        NULL,
    NM1_ENTITY_TYPE          char(1)        NULL,
    PRPR_NAME                char(55)       NULL,
    PRCP_ID                  char(12)       NULL,
    PRCP_LAST_NAME           char(35)       NULL,
    PRCP_FIRST_NAME          char(15)       NULL,
    PRCP_MID_INIT            char(1)        NULL,
    PRCP_TITLE               char(10)       NULL,
    PRFA_NAME                char(50)       NULL,
    PRPR_NPI                 char(10)       NULL,
    PRPR_TAXONOMY_CD         char(12)       NULL,
    PRPR_MCTR_TYPE           char(4)        NULL,
    PRCF_MCTR_SPEC           char(4)        NULL,
    PRCF_MCTR_SPEC2          char(4)        NULL,
    PRPR_MCTR_PRTY           char(4)        NULL,
    TPCT_MCTR_TCAT           char(1)        NULL,
    PRAD_ID                  char(12)       NULL,
    PRAD_TYPE_PRIM           char(3)        NULL,
    PRAD_TYPE_CHECK          char(3)        NULL,
    MCTN_ID                  char(9)        NULL,
    MCTN_TYPE                char(1)        NULL,
    MCTN_NAME                char(55)       NULL,
    PRPR_STS                 char(2)        NULL,
    PRPR_TERM_DT             datetime       NULL,
    PRPR_PREAUTH_IND         char(1)        NULL,
    PRCR_ID                  char(12)       NULL,
    CONSTRAINT PK_provider_denorm PRIMARY KEY CLUSTERED (PRPR_ID)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_provider_denorm_npi' AND object_id = OBJECT_ID('sdm.provider_denorm'))
CREATE INDEX ix_provider_denorm_npi ON sdm.provider_denorm (PRPR_NPI) INCLUDE (PRPR_ID, PRPR_ENTITY);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_provider_denorm_spec' AND object_id = OBJECT_ID('sdm.provider_denorm'))
CREATE INDEX ix_provider_denorm_spec ON sdm.provider_denorm (PRPR_ENTITY, PRCF_MCTR_SPEC) INCLUDE (PRPR_ID);
GO

-- sdm.provider_address
-- Grain: One row per provider x address type x effective date (PRPR_ID, PRAD_TYPE, PRAD_EFF_DT). Shared addresses (PRAD_ID of a group) are copied onto each provider that uses them, so a lookup never needs PRAD_ID.
IF OBJECT_ID('sdm.provider_address', 'U') IS NULL
CREATE TABLE sdm.provider_address (
    PRPR_ID                  char(12)       NOT NULL,
    PRAD_ID                  char(12)       NULL,
    PRAD_TYPE                char(3)        NOT NULL,
    PRAD_EFF_DT              datetime       NOT NULL,
    PRAD_TERM_DT             datetime       NULL,
    IS_PRIMARY               char(1)        NULL,
    IS_REMIT                 char(1)        NULL,
    PRAD_PRACTICE_IND        char(1)        NULL,
    PRAD_TYPE_MAIL           char(3)        NULL,
    PRAD_ADDR1               char(40)       NULL,
    PRAD_ADDR2               char(40)       NULL,
    PRAD_CITY                char(19)       NULL,
    PRAD_STATE               char(2)        NULL,
    PRAD_ZIP                 char(11)       NULL,
    PRAD_COUNTY              char(20)       NULL,
    PRAD_CTRY_CD             char(4)        NULL,
    PRAD_PHONE               char(20)       NULL,
    CONSTRAINT PK_provider_address PRIMARY KEY CLUSTERED (PRPR_ID, PRAD_TYPE, PRAD_EFF_DT)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_provider_address_role' AND object_id = OBJECT_ID('sdm.provider_address'))
CREATE INDEX ix_provider_address_role ON sdm.provider_address (PRPR_ID, IS_PRIMARY, IS_REMIT, PRAD_EFF_DT) INCLUDE (PRAD_TERM_DT, PRAD_ZIP, PRAD_STATE);
GO

-- sdm.provider_network
-- Grain: One row per provider network participation (PRPR_ID, NWNW_ID, NWPR_PFX, NWPR_PCP_IND, NWPR_EFF_DT), with the network and the agreement (the latest agreement row overlapping the participation dates).
IF OBJECT_ID('sdm.provider_network', 'U') IS NULL
CREATE TABLE sdm.provider_network (
    PRPR_ID                  char(12)       NOT NULL,
    NWNW_ID                  char(12)       NOT NULL,
    NWPR_PFX                 char(4)        NOT NULL,
    NWPR_PCP_IND             char(1)        NOT NULL,
    NWPR_EFF_DT              datetime       NOT NULL,
    NWPR_TERM_DT             datetime       NULL,
    AGAG_ID                  char(12)       NULL,
    NWPR_ACC_PAT_IND         char(1)        NULL,
    NWPR_MIN_AGE             smallint       NULL,
    NWPR_MAX_AGE             smallint       NULL,
    NWPR_SEX                 char(1)        NULL,
    NWNW_NAME                char(50)       NULL,
    NWNW_MCTR_TYPE           char(4)        NULL,
    AGAG_EFF_DT              datetime       NULL,
    AGAG_TERM_DT             datetime       NULL,
    AGAG_MCTR_TYPE           char(4)        NULL,
    AGAG_DESC                varchar(70)    NULL,
    CONSTRAINT PK_provider_network PRIMARY KEY CLUSTERED (PRPR_ID, NWNW_ID, NWPR_PFX, NWPR_PCP_IND, NWPR_EFF_DT)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_provider_network_net' AND object_id = OBJECT_ID('sdm.provider_network'))
CREATE INDEX ix_provider_network_net ON sdm.provider_network (NWNW_ID, NWPR_PFX, NWPR_EFF_DT) INCLUDE (PRPR_ID, NWPR_TERM_DT, NWPR_PCP_IND, AGAG_ID);
GO

-- sdm.provider_relation
-- Grain: One row per dated provider relationship: PRER (practitioner/facility to group, IPA or sponsor), PRDS (claims payee, resolved to a provider ID) and PRAF (practitioner to affiliated facility). REL_SOURCE says which.
IF OBJECT_ID('sdm.provider_relation', 'U') IS NULL
CREATE TABLE sdm.provider_relation (
    PRPR_ID                  char(12)       NOT NULL,
    REL_SOURCE               char(4)        NULL,
    REL_ENTITY               char(1)        NULL,
    REL_EFF_DT               datetime       NULL,
    REL_TERM_DT              datetime       NULL,
    REL_PRPR_ID              char(12)       NULL,
    REL_PRPR_ENTITY          char(1)        NULL,
    REL_PRPR_NAME            char(55)       NULL,
    REL_PRPR_NPI             char(10)       NULL,
    REL_PRPR_TAXONOMY_CD     char(12)       NULL,
    REL_MCTN_ID              char(9)        NULL,
    PRAF_PRIM_IND            char(1)        NULL,
    PRAF_STS                 char(2)        NULL
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'cx_provider_relation' AND object_id = OBJECT_ID('sdm.provider_relation'))
CREATE CLUSTERED INDEX cx_provider_relation ON sdm.provider_relation (PRPR_ID, REL_SOURCE, REL_EFF_DT);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_provider_relation_rel' AND object_id = OBJECT_ID('sdm.provider_relation'))
CREATE INDEX ix_provider_relation_rel ON sdm.provider_relation (REL_PRPR_ID, REL_SOURCE) INCLUDE (PRPR_ID, REL_EFF_DT, REL_TERM_DT);
GO

-- sdm.member_elig
-- Grain: One row per member eligibility span (MEME_CK, CSPD_CAT, MEPE_EFF_DT). The bridge from member_denorm to plans: it carries CSCS_ID, which member_denorm lacks and which CMC_CSPI_CS_PLAN and CMC_CSCS_CLASS need.
IF OBJECT_ID('sdm.member_elig', 'U') IS NULL
CREATE TABLE sdm.member_elig (
    MEME_CK                  int            NOT NULL,
    CSPD_CAT                 char(1)        NOT NULL,
    MEPE_EFF_DT              datetime       NOT NULL,
    MEPE_TERM_DT             datetime       NULL,
    MEPE_ELIG_IND            char(1)        NULL,
    GRGR_CK                  int            NULL,
    SGSG_CK                  int            NULL,
    CSCS_ID                  char(4)        NULL,
    CSPI_ID                  char(8)        NULL,
    PDPD_ID                  char(8)        NULL,
    MEPE_FI                  char(1)        NULL,
    MEPE_PLAN_ENTRY_DT       datetime       NULL,
    CONSTRAINT PK_member_elig PRIMARY KEY CLUSTERED (MEME_CK, CSPD_CAT, MEPE_EFF_DT)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_member_elig_plan' AND object_id = OBJECT_ID('sdm.member_elig'))
CREATE INDEX ix_member_elig_plan ON sdm.member_elig (GRGR_CK, CSCS_ID, CSPD_CAT, CSPI_ID) INCLUDE (MEME_CK, MEPE_EFF_DT, MEPE_TERM_DT, PDPD_ID);
GO

-- sdm.subscriber_denorm
-- Grain: One row per subscriber (SBSB_CK): 2000B / 2010BA, the subscriber's name, group number and home address.
IF OBJECT_ID('sdm.subscriber_denorm', 'U') IS NULL
CREATE TABLE sdm.subscriber_denorm (
    SBSB_CK                  int            NOT NULL,
    GRGR_CK                  int            NULL,
    GRGR_ID                  char(8)        NULL,
    SBSB_ID                  char(9)        NULL,
    SBSB_LAST_NAME           char(35)       NULL,
    SBSB_FIRST_NAME          char(15)       NULL,
    SBSB_MID_INIT            char(1)        NULL,
    SBAD_TYPE_HOME           char(1)        NULL,
    SBAD_ADDR1               char(40)       NULL,
    SBAD_ADDR2               char(40)       NULL,
    SBAD_CITY                char(19)       NULL,
    SBAD_STATE               char(2)        NULL,
    SBAD_ZIP                 char(11)       NULL,
    SBAD_COUNTY              char(20)       NULL,
    SBAD_CTRY_CD             char(4)        NULL,
    CONSTRAINT PK_subscriber_denorm PRIMARY KEY CLUSTERED (SBSB_CK)
);
GO

-- sdm.member_address
-- Grain: One row per member x address role (MEME_CK, ADDR_ROLE = HOME or MAIL), resolved the way Facets does: the member's own address type, else the subscriber's home. 2010CA patient address (and 2010BA when the member is the subscriber).
IF OBJECT_ID('sdm.member_address', 'U') IS NULL
CREATE TABLE sdm.member_address (
    MEME_CK                  int            NOT NULL,
    ADDR_ROLE                char(4)        NOT NULL,
    SBSB_CK                  int            NULL,
    SBAD_TYPE                char(1)        NULL,
    FROM_SUBSCRIBER          char(1)        NULL,
    SBAD_ADDR1               char(40)       NULL,
    SBAD_ADDR2               char(40)       NULL,
    SBAD_CITY                char(19)       NULL,
    SBAD_STATE               char(2)        NULL,
    SBAD_ZIP                 char(11)       NULL,
    SBAD_COUNTY              char(20)       NULL,
    SBAD_CTRY_CD             char(4)        NULL,
    SBAD_PHONE               char(20)       NULL,
    CONSTRAINT PK_member_address PRIMARY KEY CLUSTERED (MEME_CK, ADDR_ROLE)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_member_address_zip' AND object_id = OBJECT_ID('sdm.member_address'))
CREATE INDEX ix_member_address_zip ON sdm.member_address (SBAD_ZIP) INCLUDE (MEME_CK, SBAD_STATE);
GO

-- sdm.member_pcp
-- Grain: One row per member PCP assignment (MEME_CK, MEPR_PCP_TYPE, MEPR_EFF_DT), with the PCP's NPI and entity.
IF OBJECT_ID('sdm.member_pcp', 'U') IS NULL
CREATE TABLE sdm.member_pcp (
    MEME_CK                  int            NOT NULL,
    MEPR_PCP_TYPE            char(2)        NOT NULL,
    MEPR_EFF_DT              datetime       NOT NULL,
    MEPR_TERM_DT             datetime       NULL,
    GRGR_CK                  int            NULL,
    PRPR_ID                  char(12)       NULL,
    PRPR_NPI                 char(10)       NULL,
    PRPR_ENTITY              char(1)        NULL,
    CONSTRAINT PK_member_pcp PRIMARY KEY CLUSTERED (MEME_CK, MEPR_PCP_TYPE, MEPR_EFF_DT)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_member_pcp_prov' AND object_id = OBJECT_ID('sdm.member_pcp'))
CREATE INDEX ix_member_pcp_prov ON sdm.member_pcp (PRPR_ID) INCLUDE (MEME_CK, MEPR_EFF_DT, MEPR_TERM_DT);
GO

-- sdm.member_cob
-- Grain: One row per member other-coverage span (MEME_CK, MECB_INSUR_TYPE, MECB_INSUR_ORDER, MECB_MCTR_STYP, MECB_EFF_DT), with the other carrier's name and address: 2000B SBR01, 2320, 2330A, 2330B.
IF OBJECT_ID('sdm.member_cob', 'U') IS NULL
CREATE TABLE sdm.member_cob (
    MEME_CK                  int            NOT NULL,
    MECB_INSUR_TYPE          char(1)        NULL,
    MECB_INSUR_ORDER         char(1)        NULL,
    MECB_MCTR_STYP           char(4)        NULL,
    MECB_EFF_DT              datetime       NULL,
    MECB_TERM_DT             datetime       NULL,
    MECB_POLICY_ID           varchar(25)    NULL,
    MECB_PRIM_LAST_NM        varchar(35)    NULL,
    MECB_PRIM_FIRST_NM       varchar(15)    NULL,
    MECB_PRIM_ID             varchar(40)    NULL,
    MECB_MCTR_MSP            char(4)        NULL,
    MCRE_ID                  char(9)        NULL,
    MCRE_NAME                char(50)       NULL,
    MCRE_ADDR1               char(40)       NULL,
    MCRE_ADDR2               char(40)       NULL,
    MCRE_CITY                char(19)       NULL,
    MCRE_STATE               char(2)        NULL,
    MCRE_ZIP                 char(11)       NULL
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'cx_member_cob' AND object_id = OBJECT_ID('sdm.member_cob'))
CREATE CLUSTERED INDEX cx_member_cob ON sdm.member_cob (MEME_CK, MECB_EFF_DT);
GO

-- sdm.plan_denorm
-- Grain: One row per class/plan row (GRGR_CK, CSCS_ID, CSPD_CAT, CSPI_ID, CSPI_EFF_DT): product, network set, service conversion prefix, line of business and the payer (2010BB) in force at the plan's start.
IF OBJECT_ID('sdm.plan_denorm', 'U') IS NULL
CREATE TABLE sdm.plan_denorm (
    GRGR_CK                  int            NOT NULL,
    CSCS_ID                  char(4)        NOT NULL,
    CSPD_CAT                 char(1)        NOT NULL,
    CSPI_ID                  char(8)        NOT NULL,
    CSPI_EFF_DT              datetime       NOT NULL,
    CSPI_TERM_DT             datetime       NULL,
    PDPD_ID                  char(8)        NULL,
    NWST_PFX                 char(4)        NULL,
    CSPI_PDPD_BEG_MMDD       smallint       NULL,
    PLDS_DESC                char(70)       NULL,
    TPCT_PFX                 char(4)        NULL,
    LOBD_ID                  char(4)        NULL,
    PDDS_DESC                varchar(70)    NULL,
    PDDS_PROD_TYPE           char(1)        NULL,
    PDDS_MCTR_BCAT           char(4)        NULL,
    PDDS_UM_IND              char(1)        NULL,
    PDDS_OON_IND             char(1)        NULL,
    PYPY_ID                  char(8)        NULL,
    PYPY_PAYOR_NAME          char(50)       NULL,
    PYPY_NATL_PLAN_ID        varchar(80)    NULL,
    PYPY_NAIC_CODE           varchar(50)    NULL,
    PYPY_TAX_ID              char(9)        NULL,
    PYPY_ADDR1               char(40)       NULL,
    PYPY_ADDR2               char(40)       NULL,
    PYPY_CITY                char(19)       NULL,
    PYPY_STATE               char(2)        NULL,
    PYPY_ZIP                 char(11)       NULL,
    CONSTRAINT PK_plan_denorm PRIMARY KEY CLUSTERED (GRGR_CK, CSCS_ID, CSPD_CAT, CSPI_ID, CSPI_EFF_DT)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_plan_denorm_pdpd' AND object_id = OBJECT_ID('sdm.plan_denorm'))
CREATE INDEX ix_plan_denorm_pdpd ON sdm.plan_denorm (PDPD_ID) INCLUDE (CSPI_ID, NWST_PFX, TPCT_PFX);
GO

-- sdm.plan_network
-- Grain: One row per network-set row (NWST_PFX, NWST_EFF_DT, NWST_SEQ_NO): which networks a plan uses, in-network vs participating, and the tier.
IF OBJECT_ID('sdm.plan_network', 'U') IS NULL
CREATE TABLE sdm.plan_network (
    NWST_PFX                 char(4)        NOT NULL,
    NWST_EFF_DT              datetime       NOT NULL,
    NWST_SEQ_NO              smallint       NOT NULL,
    NWST_TERM_DT             datetime       NULL,
    NWNW_ID                  char(12)       NULL,
    NWPR_PFX                 char(4)        NULL,
    NWST_PR_NW_STS           char(1)        NULL,
    PDVC_TIER                smallint       NULL,
    NWNW_NAME                char(50)       NULL,
    NWNW_MCTR_TYPE           char(4)        NULL,
    CONSTRAINT PK_plan_network PRIMARY KEY CLUSTERED (NWST_PFX, NWST_EFF_DT, NWST_SEQ_NO)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_plan_network_net' AND object_id = OBJECT_ID('sdm.plan_network'))
CREATE INDEX ix_plan_network_net ON sdm.plan_network (NWNW_ID, NWPR_PFX) INCLUDE (NWST_PFX, NWST_EFF_DT, NWST_TERM_DT, PDVC_TIER);
GO

-- sdm.plan_benefit_denorm
-- Grain: One row per product variable component x covered Service ID x cost-share tier: (PDPD_ID, PDVC_TIER, PDVC_TYPE, PDVC_SEQ_NO, PDVC_EFF_DT, SESE_ID, SEPY_EFF_DT, SETR_TIER_NO). BEN_EFF_DT / BEN_TERM_DT is where the PDVC and SEPY windows overlap; a service is covered for a member on svc_dt when a row exists for the member's PDPD_ID and network tier with BEN_EFF_DT <= svc_dt <= BEN_TERM_DT and SESE_RULE_TYPE is not Disallow.
IF OBJECT_ID('sdm.plan_benefit_denorm', 'U') IS NULL
CREATE TABLE sdm.plan_benefit_denorm (
    PDPD_ID                  char(8)        NOT NULL,
    PDVC_TIER                smallint       NULL,
    PDVC_TYPE                char(1)        NULL,
    PDVC_SEQ_NO              smallint       NULL,
    PDVC_EFF_DT              datetime       NULL,
    PDVC_TERM_DT             datetime       NULL,
    PDVC_PR_PCP              char(1)        NULL,
    PDVC_PR_IN               char(1)        NULL,
    PDVC_PR_PAR              char(1)        NULL,
    PDVC_PR_NONPAR           char(1)        NULL,
    PDVC_PC_NR               char(1)        NULL,
    PDVC_PC_OBT              char(1)        NULL,
    PDVC_PC_VIOL             char(1)        NULL,
    PDVC_REF_NR              char(1)        NULL,
    PDVC_REF_OBT             char(1)        NULL,
    PDVC_REF_VIOL            char(1)        NULL,
    PDVC_LOBD_PTR            char(1)        NULL,
    SEPY_PFX                 char(4)        NULL,
    DEDE_PFX                 char(4)        NULL,
    LTLT_PFX                 char(4)        NULL,
    SEPY_EFF_DT              datetime       NULL,
    SEPY_TERM_DT             datetime       NULL,
    BEN_EFF_DT               datetime       NULL,
    BEN_TERM_DT              datetime       NULL,
    SESE_ID                  char(4)        NULL,
    SESE_RULE                char(3)        NULL,
    SEDS_DESC                char(70)       NULL,
    SEDS_TYPE                char(1)        NULL,
    SESE_RULE_TYPE           char(1)        NULL,
    SESE_CALC_IND            char(1)        NULL,
    SESE_VALID_SEX           char(1)        NULL,
    SESE_MIN_AGE             smallint       NULL,
    SESE_MAX_AGE             smallint       NULL,
    SESE_COV_TYPE            char(1)        NULL,
    SETR_TIER_NO             smallint       NULL,
    SETR_ALLOW_AMT           money          NULL,
    SETR_ALLOW_CTR           smallint       NULL,
    SETR_COPAY_AMT           money          NULL,
    SETR_COIN_PCT            money          NULL,
    ACAC_ACC_NO              smallint       NULL,
    SEDF_UM_REQ_IND          char(1)        NULL,
    SEDF_UM_BP_REF_IND       char(1)        NULL,
    SEDF_CAP_IND             char(1)        NULL
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'cx_plan_benefit_denorm' AND object_id = OBJECT_ID('sdm.plan_benefit_denorm'))
CREATE CLUSTERED INDEX cx_plan_benefit_denorm ON sdm.plan_benefit_denorm (PDPD_ID, SESE_ID, BEN_EFF_DT);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_plan_benefit_tier' AND object_id = OBJECT_ID('sdm.plan_benefit_denorm'))
CREATE INDEX ix_plan_benefit_tier ON sdm.plan_benefit_denorm (PDPD_ID, PDVC_TIER, BEN_EFF_DT) INCLUDE (BEN_TERM_DT, SESE_ID, SESE_RULE, SESE_RULE_TYPE);
GO

-- sdm.plan_accumulator
-- Grain: One row per product variable component x accumulator (x limited Service ID): deductibles (ACCUM_KIND = 'DED', from DEDE) and limits / stop-loss (ACCUM_KIND = 'LMT', from LTLT + LTSE).
IF OBJECT_ID('sdm.plan_accumulator', 'U') IS NULL
CREATE TABLE sdm.plan_accumulator (
    PDPD_ID                  char(8)        NOT NULL,
    PDVC_TIER                smallint       NULL,
    PDVC_TYPE                char(1)        NULL,
    PDVC_SEQ_NO              smallint       NULL,
    PDVC_EFF_DT              datetime       NULL,
    PDVC_TERM_DT             datetime       NULL,
    ACCUM_KIND               char(3)        NULL,
    ACCUM_PFX                char(4)        NULL,
    ACAC_ACC_NO              smallint       NULL,
    ACCUM_DESC               varchar(70)    NULL,
    DEDE_RULE                smallint       NULL,
    DEDE_PERIOD_IND          char(1)        NULL,
    DEDE_MEME_AMT            money          NULL,
    DEDE_FAM_AMT             money          NULL,
    LTLT_CAT                 char(1)        NULL,
    LTLT_LEVEL               char(1)        NULL,
    LTLT_PERIOD_IND          char(1)        NULL,
    LTLT_RULE                char(1)        NULL,
    LTLT_IX_IND              char(1)        NULL,
    LTLT_IX_TYPE             char(1)        NULL,
    LTLT_AMT1                money          NULL,
    SESE_ID                  char(4)        NULL,
    LTSE_WT_CTR              int            NULL
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'cx_plan_accumulator' AND object_id = OBJECT_ID('sdm.plan_accumulator'))
CREATE CLUSTERED INDEX cx_plan_accumulator ON sdm.plan_accumulator (PDPD_ID, ACCUM_KIND, ACAC_ACC_NO);
GO

-- sdm.service_code_map
-- Grain: One row per conversion range: procedure ranges (MAP_KIND = 'PROC', CMC_TPCT_CPT_CONV), revenue-code ranges ('REV', CMC_RCCT_CONV) and default services ('SVC', CMC_SECT_CONV), for the TPCT_PFX values of the plans in scope. Procedure / revenue code + setting -> Service ID.
IF OBJECT_ID('sdm.service_code_map', 'U') IS NULL
CREATE TABLE sdm.service_code_map (
    TPCT_PFX                 char(4)        NOT NULL,
    MAP_KIND                 char(4)        NULL,
    TPCT_MCTR_TCAT           char(1)        NULL,
    MCTR_SETG                char(1)        NULL,
    CODE_LOW                 char(7)        NULL,
    CODE_HIGH                char(7)        NULL,
    TPCT_MODIFIER            char(2)        NULL,
    SESE_ID                  char(4)        NULL,
    CSPD_CAT                 char(1)        NULL,
    RPTC_RPT_CAT             char(4)        NULL
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'cx_service_code_map' AND object_id = OBJECT_ID('sdm.service_code_map'))
CREATE CLUSTERED INDEX cx_service_code_map ON sdm.service_code_map (TPCT_PFX, MAP_KIND, CODE_LOW);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_service_code_map_sese' AND object_id = OBJECT_ID('sdm.service_code_map'))
CREATE INDEX ix_service_code_map_sese ON sdm.service_code_map (TPCT_PFX, SESE_ID) INCLUDE (MAP_KIND, MCTR_SETG, CODE_LOW, CODE_HIGH, TPCT_MODIFIER);
GO

-- sdm.place_of_service
-- Grain: One row per place of service (PSCD_ID): its setting, which selects the procedure-to-service rows in service_code_map.
IF OBJECT_ID('sdm.place_of_service', 'U') IS NULL
CREATE TABLE sdm.place_of_service (
    PSCD_ID                  char(2)        NOT NULL,
    PSCD_DESC                char(70)       NULL,
    PSCD_POS_IND             char(1)        NULL,
    TPCT_MCTR_TCAT           char(1)        NULL,
    TPCT_MCTR_SETG           char(1)        NULL,
    CONSTRAINT PK_place_of_service PRIMARY KEY CLUSTERED (PSCD_ID)
);
GO

-- sdm.claims_header_ext_denorm
-- Grain: One row per claim (CLCL_ID): the 2300-level and claim-provider fields claims_denorm does not carry (it repeats header fields on each line; this table does not).
IF OBJECT_ID('sdm.claims_header_ext_denorm', 'U') IS NULL
CREATE TABLE sdm.claims_header_ext_denorm (
    CLCL_ID                  char(12)       NOT NULL,
    MEME_CK                  int            NULL,
    CSCS_ID                  char(4)        NULL,
    PRPR_ID                  char(12)       NULL,
    PRAD_TYPE                char(3)        NULL,
    CLCL_PAYEE_PR_ID         char(12)       NULL,
    NWPR_PFX                 char(4)        NULL,
    AGAG_ID                  char(12)       NULL,
    CLCL_PA_ACCT_NO          varchar(35)    NULL,
    CLCL_PAY_PR_IND          char(1)        NULL,
    CLCL_REL_INFO_IND        char(1)        NULL,
    CLCL_MED_ASSGN_IND       char(1)        NULL,
    CLCL_ACD_IND             char(1)        NULL,
    CLCL_ACD_STATE           char(2)        NULL,
    CLCL_ACD_DT              datetime       NULL,
    CLCL_CURR_ILL_DT         datetime       NULL,
    CLCL_SIMI_ILL_DT         datetime       NULL,
    CLCL_UNABL_FROM_DT       datetime       NULL,
    CLCL_UNABL_TO_DT         datetime       NULL,
    CLCL_RELHP_FROM_DT       datetime       NULL,
    CLCL_RELHP_TO_DT         datetime       NULL,
    CLCL_OUT_LAB_IND         char(1)        NULL,
    CLCL_ID_ADJ_FROM         char(12)       NULL,
    CLCL_MECD_RESUB_NO       char(15)       NULL,
    CLCL_OTHER_BN_IND        char(1)        NULL,
    CLCL_EXT_REF_IND         char(1)        NULL,
    CLM_FREQUENCY            char(1)        NULL,
    CLHP_FAC_TYPE            char(2)        NULL,
    CLHP_BILL_CLASS          char(1)        NULL,
    CLHP_FREQUENCY           char(1)        NULL,
    CLHP_ADM_TYP             char(2)        NULL,
    CLHP_ADM_SOURCE          char(1)        NULL,
    CLHP_DC_STAT             char(2)        NULL,
    CLHP_ADM_DT              datetime       NULL,
    CLHP_ADM_HOUR_CD         char(2)        NULL,
    CLHP_DC_DT               datetime       NULL,
    CLHP_DC_HOUR_CD          char(2)        NULL,
    CLHP_STAMENT_FR_DT       datetime       NULL,
    CLHP_STAMENT_TO_DT       datetime       NULL,
    CLHP_MED_REC_NO          char(17)       NULL,
    AGRG_ID                  char(4)        NULL,
    CLHP_INPUT_AGRG_ID       char(4)        NULL,
    CLHP_PRPR_ID_ADM         char(12)       NULL,
    CLHP_PRPR_AD_NPI         varchar(10)    NULL,
    CLHP_PRPR_ID_OPER        char(12)       NULL,
    CLHP_PRPR_OP_NPI         varchar(10)    NULL,
    CLHP_PRPR_ID_OTH1        char(12)       NULL,
    CLHP_PRPR_O1_NPI         varchar(10)    NULL,
    CLHP_ICD_QUAL_IND        char(1)        NULL,
    CLHP_BIRTH_WGT           smallint       NULL,
    CLMF_PRPR_ID_FAC         char(12)       NULL,
    CLMF_PRPR_FA_NPI         varchar(10)    NULL,
    CLMF_PRPR_RF_NPI         varchar(10)    NULL,
    CLMF_INPUT_TXNM_CD       char(12)       NULL,
    CLMF_EXT_REFRAL_NO       varchar(18)    NULL,
    CLMF_EXT_PREATH_NO       varchar(18)    NULL,
    CLMF_ICD_IND_PROC        char(1)        NULL,
    CLSD_PRPR_ID_REND_NVL    varchar(12)    NULL,
    CLSD_PRPR_RE_NPI_NVL     varchar(10)    NULL,
    CLED_HIPAA_VERSION       varchar(12)    NULL,
    CLED_EXT_REF             varchar(50)    NULL,
    CLED_TRAD_PARTNER        char(15)       NULL,
    CLCB_COB_TYPE            char(1)        NULL,
    CLCB_COB_AMT             money          NULL,
    CLCB_COB_ALLOW           money          NULL,
    CLCB_COB_DED_AMT         money          NULL,
    CLCB_COB_COPAY_AMT       money          NULL,
    CLCB_COB_COINS_AMT       money          NULL,
    CLCB_COB_REAS_CD         char(4)        NULL,
    CONSTRAINT PK_claims_header_ext_denorm PRIMARY KEY CLUSTERED (CLCL_ID)
);
GO

-- sdm.claims_detail_denorm
-- Grain: One row per claim line (CLCL_ID, CDML_SEQ_NO): the 2400-level fields claims_denorm does not carry (modifiers, line diagnosis pointers, NDC, line rendering provider, service ID, UM links, line COB).
IF OBJECT_ID('sdm.claims_detail_denorm', 'U') IS NULL
CREATE TABLE sdm.claims_detail_denorm (
    CLCL_ID                  char(12)       NOT NULL,
    CDML_SEQ_NO              smallint       NOT NULL,
    CDML_EXT_LINE_NO         smallint       NULL,
    PROC_CODE                char(5)        NULL,
    IPCD_MOD1                char(2)        NULL,
    CDML_IPCD_MOD2           char(2)        NULL,
    CDML_IPCD_MOD3           char(2)        NULL,
    CDML_IPCD_MOD4           char(2)        NULL,
    IDCD_ID                  varchar(10)    NULL,
    IDCD_ID_REL              varchar(10)    NULL,
    CDML_CLMD_TYPE2          char(2)        NULL,
    CDML_CLMD_TYPE3          char(2)        NULL,
    CDML_CLMD_TYPE4          char(2)        NULL,
    CDML_CLMD_TYPE5          char(2)        NULL,
    SESE_ID                  char(4)        NULL,
    SESE_RULE                char(3)        NULL,
    SEPY_PFX                 char(4)        NULL,
    DEDE_PFX                 char(4)        NULL,
    LTLT_PFX                 char(4)        NULL,
    PDVC_LOBD_PTR            char(1)        NULL,
    CDML_ROOM_TYPE           char(2)        NULL,
    CDML_HCPCS_AMT           money          NULL,
    CDML_REF_IND             char(1)        NULL,
    CDML_PC_IND              char(1)        NULL,
    CDML_UMREF_ID            char(9)        NULL,
    CDML_REFSV_SEQ_NO        smallint       NULL,
    CDML_UMAUTH_ID           char(9)        NULL,
    CDML_AUTHSV_SEQ_NO       smallint       NULL,
    CDML_CL_NTWK_IND         char(1)        NULL,
    CDML_DISALL_EXCD         char(3)        NULL,
    CDSD_PRPR_ID_REND        varchar(12)    NULL,
    CDSD_PRPR_RE_NPI         varchar(10)    NULL,
    CDSD_NDC_CODE            varchar(11)    NULL,
    CDSD_NDC_UNITS           varchar(15)    NULL,
    CDSD_NDC_MCTR_TYPE       char(4)        NULL,
    CDSD_SERV_LOC_ZIP        varchar(11)    NULL,
    CDSD_MED_AMB_ZIP         varchar(11)    NULL,
    CDCB_COB_TYPE            char(1)        NULL,
    CDCB_COB_AMT             money          NULL,
    CDCB_COB_ALLOW           money          NULL,
    CDCB_COB_DED_AMT         money          NULL,
    CDCB_COB_COPAY_AMT       money          NULL,
    CDCB_COB_COINS_AMT       money          NULL,
    CDCB_COB_REAS_CD         char(4)        NULL,
    CONSTRAINT PK_claims_detail_denorm PRIMARY KEY CLUSTERED (CLCL_ID, CDML_SEQ_NO)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_claims_detail_sese' AND object_id = OBJECT_ID('sdm.claims_detail_denorm'))
CREATE INDEX ix_claims_detail_sese ON sdm.claims_detail_denorm (SESE_ID) INCLUDE (CLCL_ID, CDML_SEQ_NO, SEPY_PFX);
GO

-- sdm.claims_diag
-- Grain: One row per claim diagnosis (CLCL_ID, CLMD_TYPE): every diagnosis, not only the primary and admitting ones in claims_denorm.
IF OBJECT_ID('sdm.claims_diag', 'U') IS NULL
CREATE TABLE sdm.claims_diag (
    CLCL_ID                  char(12)       NOT NULL,
    CLMD_TYPE                char(2)        NOT NULL,
    IDCD_ID                  varchar(10)    NULL,
    CLMD_POA_IND             char(1)        NULL,
    IDCD_ID_SUB              varchar(10)    NULL,
    CONSTRAINT PK_claims_diag PRIMARY KEY CLUSTERED (CLCL_ID, CLMD_TYPE)
);
GO

-- sdm.claims_icd_proc
-- Grain: One row per institutional claim procedure (CLCL_ID, CLHI_TYPE): 837I HI*BBR / BBQ.
IF OBJECT_ID('sdm.claims_icd_proc', 'U') IS NULL
CREATE TABLE sdm.claims_icd_proc (
    CLCL_ID                  char(12)       NOT NULL,
    CLHI_TYPE                char(2)        NOT NULL,
    IPCD_ID                  char(7)        NULL,
    CLHI_IP_DT               datetime       NULL,
    CONSTRAINT PK_claims_icd_proc PRIMARY KEY CLUSTERED (CLCL_ID, CLHI_TYPE)
);
GO

-- sdm.claims_ub_code
-- Grain: One row per UB condition, occurrence or value code (CLCL_ID, CODE_KIND, CODE_SEQ): 837I HI*BG / BH / BI / BE.
IF OBJECT_ID('sdm.claims_ub_code', 'U') IS NULL
CREATE TABLE sdm.claims_ub_code (
    CLCL_ID                  char(12)       NOT NULL,
    CODE_KIND                char(4)        NOT NULL,
    CODE_SEQ                 smallint       NOT NULL,
    UB_CODE                  char(2)        NULL,
    FROM_DT                  datetime       NULL,
    TO_DT                    datetime       NULL,
    VALUE_AMT                money          NULL,
    VALUE_UNITS              smallint       NULL,
    CONSTRAINT PK_claims_ub_code PRIMARY KEY CLUSTERED (CLCL_ID, CODE_KIND, CODE_SEQ)
);
GO

-- sdm.claims_auth
-- Grain: One row per claim line x UM link (CLCL_ID, CDML_SEQ_NO, AUTH_KIND = 'AUTH' or 'REF'): the authorized or referred service the line points to, so generated lines fall inside the authorized dates, provider, POS and units.
IF OBJECT_ID('sdm.claims_auth', 'U') IS NULL
CREATE TABLE sdm.claims_auth (
    CLCL_ID                  char(12)       NOT NULL,
    CDML_SEQ_NO              smallint       NOT NULL,
    AUTH_KIND                char(4)        NOT NULL,
    UMUM_REF_ID              char(9)        NULL,
    UMSV_SEQ_NO              smallint       NULL,
    UMSV_FROM_DT             datetime       NULL,
    UMSV_TO_DT               datetime       NULL,
    UMSV_PRPR_ID_REQ         char(12)       NULL,
    UMSV_PRPR_ID_SVC         char(12)       NULL,
    UMSV_PRPR_ID_FAC         char(12)       NULL,
    UMSV_PSCD_ID_AUTH        char(2)        NULL,
    IPCD_ID                  char(7)        NULL,
    SESE_ID                  char(4)        NULL,
    UMSV_UNITS_AUTH          smallint       NULL,
    UMVT_STS                 char(2)        NULL,
    UMSV_AUTH_DT             datetime       NULL,
    CONSTRAINT PK_claims_auth PRIMARY KEY CLUSTERED (CLCL_ID, CDML_SEQ_NO, AUTH_KIND)
);
GO

-- Indexes on the denorm tables, for the reads pattern analysis makes.
--
-- Optional, and separate from the tables: an index adds no column and changes
-- no row, but it is still a change to tables the customer owns, so they decide.
-- Each is created only if absent. Written for schema sdm; to run on another,
-- replace "sdm." throughout.
--
-- What the tool reads, and which index serves it:
--   * a scope -- group, plan category, plan, product -- loaded for analysis:
--       WHERE GRGR_CK / CSPD_CAT / CSPI_ID / PDPD_ID IN (...)
--   * one row per member, the latest enrollment:
--       ROW_NUMBER() OVER (PARTITION BY MEME_CK ORDER BY MEME_ORIG_EFF_DT DESC)
--   * a pattern's members read back by key: WHERE MEME_CK IN (...)
--   * claim lines in claim order: ORDER BY CLCL_ID, CDML_SEQ_NO, and a claims
--     scope by group, plan, product and claim type.
-- Aggregate reads -- counts by feature, combinations of codes -- scan once and
-- are not helped by narrow indexes; they are cached by the tool instead.

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_member_denorm_meme_latest'
               AND object_id = OBJECT_ID('sdm.member_denorm'))
CREATE INDEX ix_member_denorm_meme_latest
    ON sdm.member_denorm (MEME_CK, MEME_ORIG_EFF_DT DESC);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_member_denorm_scope'
               AND object_id = OBJECT_ID('sdm.member_denorm'))
CREATE INDEX ix_member_denorm_scope
    ON sdm.member_denorm (GRGR_CK, CSPD_CAT, CSPI_ID, PDPD_ID) INCLUDE (MEME_CK);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_member_denorm_plan'
               AND object_id = OBJECT_ID('sdm.member_denorm'))
CREATE INDEX ix_member_denorm_plan
    ON sdm.member_denorm (CSPI_ID) INCLUDE (MEME_CK, CSPD_CAT, PDPD_ID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_claims_denorm_line'
               AND object_id = OBJECT_ID('sdm.claims_denorm'))
CREATE INDEX ix_claims_denorm_line
    ON sdm.claims_denorm (CLCL_ID, CDML_SEQ_NO);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_claims_denorm_scope'
               AND object_id = OBJECT_ID('sdm.claims_denorm'))
CREATE INDEX ix_claims_denorm_scope
    ON sdm.claims_denorm (GRGR_CK, CSPI_ID, PDPD_ID, CLCL_CL_TYPE);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_claims_denorm_member'
               AND object_id = OBJECT_ID('sdm.claims_denorm'))
CREATE INDEX ix_claims_denorm_member
    ON sdm.claims_denorm (MEME_CK);
GO

            IF OBJECT_ID(N'sdm.discovery_features', N'U') IS NULL
            CREATE TABLE sdm.discovery_features (
                entity     NVARCHAR(20)  NOT NULL,
                feature    NVARCHAR(60)  NOT NULL,
                chosen_by  NVARCHAR(100) NULL,
                chosen_at  DATETIME2     NULL,
                CONSTRAINT PK_discovery_features PRIMARY KEY (entity, feature)
            )
GO

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.layouts') AND type = N'U')
CREATE TABLE sdm.layouts (
    id           INT IDENTITY(1,1) PRIMARY KEY,
    name         NVARCHAR(200) NOT NULL,
    kind         NVARCHAR(10)  NOT NULL,          -- 'csv' or 'fixed'
    delimiter    NVARCHAR(5)   NULL,              -- csv only
    status       NVARCHAR(20)  NOT NULL DEFAULT 'pending_review',
    field_spec   NVARCHAR(MAX) NOT NULL,          -- parsed fields + assignments
    sample_name  NVARCHAR(400) NULL,
    created_by   NVARCHAR(100) NULL,
    created_at   DATETIME2     NOT NULL DEFAULT GETDATE(),
    approved_by  NVARCHAR(100) NULL,
    approved_at  DATETIME2     NULL,
    -- What the layout is for. A generation layout assigns generation rules to
    -- its fields; a masking layout assigns masking rules. The two catalogs are
    -- separate, so a layout has to declare which one it draws from.
    purpose      NVARCHAR(20)  NOT NULL DEFAULT 'generation',
    CONSTRAINT UQ_layouts_name UNIQUE (name)
);
GO

IF COL_LENGTH('sdm.layouts', 'purpose') IS NULL
    ALTER TABLE sdm.layouts
        ADD purpose NVARCHAR(20) NOT NULL DEFAULT 'generation';
GO

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.generation_rule_aliases') AND type = N'U')
CREATE TABLE sdm.generation_rule_aliases (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    rule_id     INT           NOT NULL,
    -- One column name can only ever mean one element. The constraint is the
    -- point: without it two rules could both claim MEME_FIRST_NAME and
    -- resolution would pick whichever row came back first, which is a bug that
    -- only shows up as quietly wrong data.
    column_name NVARCHAR(200) NOT NULL UNIQUE,
    created_by  NVARCHAR(100) NULL,
    created_at  DATETIME2     NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_gen_rule_alias_rule FOREIGN KEY (rule_id)
        REFERENCES sdm.generation_rules(id) ON DELETE CASCADE
);
GO

IF COL_LENGTH('sdm.generation_rules', 'min_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD min_value FLOAT NULL;
IF COL_LENGTH('sdm.generation_rules', 'max_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD max_value FLOAT NULL;
IF COL_LENGTH('sdm.generation_rules', 'decimals') IS NULL
    ALTER TABLE sdm.generation_rules ADD decimals INT NULL;
IF COL_LENGTH('sdm.generation_rules', 'weights') IS NULL
    ALTER TABLE sdm.generation_rules ADD weights NVARCHAR(MAX) NULL;
IF COL_LENGTH('sdm.generation_rules', 'distribution') IS NULL
    ALTER TABLE sdm.generation_rules ADD distribution NVARCHAR(20) NULL;
IF COL_LENGTH('sdm.generation_rules', 'mean_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD mean_value FLOAT NULL;
IF COL_LENGTH('sdm.generation_rules', 'stddev_value') IS NULL
    ALTER TABLE sdm.generation_rules ADD stddev_value FLOAT NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.masking_config') AND type = N'U')
CREATE TABLE sdm.masking_config (
    setting  NVARCHAR(60)  NOT NULL PRIMARY KEY,
    value    NVARCHAR(400) NOT NULL,
    set_at   DATETIME2     NOT NULL DEFAULT GETDATE()
);

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.masking_lookups') AND type = N'U')
CREATE TABLE sdm.masking_lookups (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    name        NVARCHAR(120) NOT NULL UNIQUE,
    -- 'pool'  : one column of candidate values, chosen from by hash
    -- 'map'   : two columns, value -> replacement, matched exactly
    kind        NVARCHAR(10)  NOT NULL,
    -- Either a registered sdm.lkp_* table or a file on this machine.
    source_kind NVARCHAR(10)  NOT NULL,      -- 'table' | 'file'
    source      NVARCHAR(400) NOT NULL,
    value_col   NVARCHAR(120) NULL,          -- pool: which column to draw from
    n_rows      INT           NULL,
    created_by  NVARCHAR(100) NULL,
    created_at  DATETIME2     NOT NULL DEFAULT GETDATE()
);

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.masking_rules') AND type = N'U')
CREATE TABLE sdm.masking_rules (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    name        NVARCHAR(120) NOT NULL UNIQUE,
    algorithm   NVARCHAR(30)  NOT NULL,
    -- The instance's own configuration, shaped by its algorithm.
    config      NVARCHAR(MAX) NOT NULL,
    description NVARCHAR(400) NULL,
    created_by  NVARCHAR(100) NULL,
    created_at  DATETIME2     NOT NULL DEFAULT GETDATE(),
    updated_at  DATETIME2     NULL
);

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.layout_masking') AND type = N'U')
CREATE TABLE sdm.layout_masking (
    id         INT IDENTITY(1,1) PRIMARY KEY,
    layout_id  INT           NOT NULL,
    field_name NVARCHAR(200) NOT NULL,
    rule_id    INT           NOT NULL,
    assigned_by NVARCHAR(100) NULL,
    assigned_at DATETIME2    NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_layout_masking UNIQUE (layout_id, field_name)
);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.objects
    WHERE object_id = OBJECT_ID(N'sdm.pattern_baseline') AND type = N'U'
)
CREATE TABLE sdm.pattern_baseline (
    id            INT IDENTITY(1,1) PRIMARY KEY,
    entity        NVARCHAR(20)  NOT NULL,   -- 'members' or 'claims'
    scope_key     NVARCHAR(200) NOT NULL,   -- 'ALL', or 'GRGR:10042'
    scope_label   NVARCHAR(300) NULL,
    n_patterns    INT           NOT NULL DEFAULT 0,
    total_count   BIGINT        NOT NULL DEFAULT 0,
    detail_json   NVARCHAR(MAX) NULL,
    computed_at   DATETIME2     NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_pattern_baseline UNIQUE (entity, scope_key)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.objects
               WHERE object_id = OBJECT_ID(N'sdm.sample_gen_configs') AND type = N'U')
CREATE TABLE sdm.sample_gen_configs (
    id           INT IDENTITY(1,1) PRIMARY KEY,
    name         NVARCHAR(200) NOT NULL,
    format       NVARCHAR(20)  NOT NULL,       -- x12
    kind         NVARCHAR(40)  NOT NULL,       -- 834 | 837
    version      NVARCHAR(40)  NULL,           -- 005010X222A1 ...
    based_on     NVARCHAR(400) NULL,           -- the master it was built from
    config_json  NVARCHAR(MAX) NOT NULL,       -- genSegments
    sample_name  NVARCHAR(400) NULL,
    sample_text  NVARCHAR(MAX) NOT NULL,       -- the file it is modeled on
    created_by   NVARCHAR(100) NULL,
    created_at   DATETIME2     NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_sample_gen_configs_name UNIQUE (name)
);
GO

-- The fields a pattern's counts are made on (Configure, Fields counted in patterns).
IF OBJECT_ID(N'sdm.report_fields', N'U') IS NULL
CREATE TABLE sdm.report_fields (
    entity     NVARCHAR(20)  NOT NULL,
    field      NVARCHAR(140) NOT NULL,
    position   INT           NOT NULL,
    chosen_by  NVARCHAR(100) NULL,
    chosen_at  DATETIME2     NULL,
    CONSTRAINT PK_report_fields PRIMARY KEY (entity, field)
);
GO

IF OBJECT_ID(N'sdm.extract_log', N'U') IS NULL CREATE TABLE [sdm].[extract_log] (source NVARCHAR(100) NOT NULL, table_name NVARCHAR(128) NOT NULL, row_count BIGINT NOT NULL, error NVARCHAR(1000) NULL, finished_at DATETIME2 NOT NULL)
GO

PRINT 'SDM tables ready. Next: the extract (scripts\customer\extract.cmd).';
GO

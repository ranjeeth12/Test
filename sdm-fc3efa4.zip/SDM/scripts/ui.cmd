@echo off
setlocal
rem The free-threaded Python (python3.14t) runs with the GIL on, as pyodbc needs.
set PYTHON_GIL=1
cd /d "%~dp0.."
if not exist ui\dist (
  echo Building the interface...
  pushd ui
  call npm install
  call npm run build
  popd
)
.venv\Scripts\python.exe -m sdg.cli.main ui %*

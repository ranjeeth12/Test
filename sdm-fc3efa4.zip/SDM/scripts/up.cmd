@echo off
setlocal
cd /d "%~dp0.."
.venv\Scripts\python.exe seed\create_databases.py %* || exit /b 1
.venv\Scripts\python.exe -m sdg.cli.main connect

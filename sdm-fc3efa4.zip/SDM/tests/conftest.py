"""The suite works in a copy of the working directory, never in work/ itself.

Tests that import the app use whatever working directory the settings name, and
that used to be the real one: the suite wrote plans and decisions into the
user's own working files, and ran against whichever database had last been
chosen on Connect. Now that choosing a database moves the whole pipeline, that
would mean shelving the user's files and testing against something else.

So the session starts from the source database's working state -- copied from
wherever it is, in work/ or set aside under work/databases -- with no database
chosen, and the copy is removed at the end. When the source has no state to
copy -- another database is being worked on and the source was offboarded, or
this is a fresh machine -- it is built in the copy: read, the project's
recorded review decisions applied, planned. The suite never depends on what
somebody happens to have onboarded.
"""

from __future__ import annotations

import json
import os
import shutil
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
_COPY: Path | None = None


def _source_files(real: Path, source_key: str, marker_name: str) -> Path | None:
    """Where the source database's working files are, if anywhere."""
    if not real.exists():
        return None
    marker = real / marker_name
    owner = marker.read_text(encoding="utf-8").strip() if marker.exists() else source_key
    if owner == source_key and (real / "physical-model.json").exists():
        return real
    shelved = real / "databases" / source_key
    if (shelved / "physical-model.json").exists():
        return shelved
    return None


def pytest_configure(config):
    global _COPY
    if os.environ.get("SDG_WORK_DIR"):
        return  # somebody chose one deliberately

    from sdg.api.service import Service
    from sdg.config import get_settings

    settings = get_settings()
    real = settings.work_dir
    source_key = Service._key_for(settings.mssql.server, settings.source_db)
    _COPY = Path(tempfile.mkdtemp(prefix="sdm-suite-work-"))

    # What belongs to the installation rather than to one database.
    for name in ("ui-settings.json",):
        if (real / name).exists():
            shutil.copy2(real / name, _COPY / name)
    for found in real.glob("landscape-*.json") if real.exists() else []:
        shutil.copy2(found, _COPY / found.name)

    chosen = _COPY / "ui-settings.json"
    if chosen.exists():
        data = json.loads(chosen.read_text(encoding="utf-8"))
        data.pop("targetDb", None)
        chosen.write_text(json.dumps(data, indent=2), encoding="utf-8")

    origin = _source_files(real, source_key, Service.MARKER)
    if origin is not None:
        for item in origin.iterdir():
            if item.is_file() and item.name not in Service.STAYS \
                    and not item.name.startswith("landscape-"):
                shutil.copy2(item, _COPY / item.name)
    (_COPY / Service.MARKER).write_text(source_key, encoding="utf-8")
    os.environ["SDG_WORK_DIR"] = str(_COPY)

    if origin is None:
        _build_source_state(_COPY)


def _build_source_state(work: Path) -> None:
    """Read the source and plan it, as first-run does, inside the copy."""
    import importlib.util

    from sdg.api.service import Service

    service = Service(work_dir=work)
    service.connect()
    service.discover()
    service.profile()
    service.map()
    service.review()
    spec = importlib.util.spec_from_file_location("seed_decisions", ROOT / "seed" / "decisions.py")
    decisions = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(decisions)
    for decision in decisions.DECIDED:
        service.record_decision(dict(decision))
    service.build()


# Saved patterns are people's work, and nothing recreates them. Every saved
# pattern there when the suite starts must be there, unchanged, when it ends --
# a test may delete only a row it created. Twice on 2026-10-04 a cleanup
# removed somebody's pattern because saving returned theirs; this fails the
# run if anything like that happens again.
_SAVED_AT_START: dict | None = None


def _saved_patterns() -> dict | None:
    try:
        import hashlib

        from sdg.analyzer import db
        from sdg.analyzer.config import SQL_SCHEMA

        with db.get_connection() as conn:
            rows = conn.cursor().execute(
                f"SELECT id, pattern_key, contextual_name, updated_at, saved_at, profile_json "
                f"FROM {SQL_SCHEMA}.patterns WHERE saved_by IS NOT NULL"
            ).fetchall()
    except Exception:
        return None  # no database: nothing to protect
    return {r[0]: (r[1], r[2], str(r[3]), str(r[4]),
                   hashlib.sha256((r[5] or "").encode()).hexdigest()) for r in rows}


def pytest_sessionstart(session):
    global _SAVED_AT_START
    _SAVED_AT_START = _saved_patterns()


def pytest_sessionfinish(session, exitstatus):
    if _SAVED_AT_START is None:
        return
    now = _saved_patterns() or {}
    gone = sorted(set(_SAVED_AT_START) - set(now))
    changed = sorted(i for i in _SAVED_AT_START if i in now and now[i] != _SAVED_AT_START[i])
    if gone or changed:
        session.config.pluginmanager.get_plugin("terminalreporter").write_line(
            f"SAVED PATTERNS DISTURBED -- deleted: {gone}, changed: {changed}. "
            f"A test touched patterns it did not create.", red=True, bold=True)
        session.exitstatus = 1


def pytest_unconfigure(config):
    if _COPY is not None:
        os.environ.pop("SDG_WORK_DIR", None)
        shutil.rmtree(_COPY, ignore_errors=True)

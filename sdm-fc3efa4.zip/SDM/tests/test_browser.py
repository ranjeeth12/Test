"""The screens, driven in a real browser the way a person drives them.

A server of its own, on a copy of the suite's working files, opened in the
Edge or Chrome already installed on the machine (no browser is downloaded).
In order, as somebody would go:

1. Connect names the database being worked on, and the pattern store the
   patterns come from;
2. every screen opens without an error, on its Database and Files tabs;
   files are connected, profiled and mapped; under Map & Review a sample read
   and a layout defined by hand each get a rule picked for every field, are
   edited, approved and written through;
3. a database is onboarded from Connect, read, planned, written, validated
   and cleaned up, all from the screens;
4. records chosen under a pattern go into that database;
5. a saved pattern is listed under Generation's Files tab and writes an 834 that
   passes every SNIP level;
6. back on the source, its work is as it was, and the onboarded database is
   offboarded from Connect.

No console error, failed request or alarm banner is allowed anywhere. The
onboarded database is a throwaway copy; patterns saved here are removed by
the ids the screens returned for them, and no others.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

import pytest

from tests import facets_copies

pytestmark = [pytest.mark.db, pytest.mark.slow, pytest.mark.browser]

playwright = pytest.importorskip("playwright.sync_api")

ROOT = Path(__file__).resolve().parent.parent
A = "SDM_TEST_BROWSER_A"
LONG = 600_000  # ms: reading a database or writing a run


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def server():
    """The app on a port of its own, on a copy of the suite's working files."""
    from sdg.config import get_settings

    work = Path(tempfile.mkdtemp(prefix="sdm-browser-"))
    shutil.copytree(get_settings().work_dir, work, dirs_exist_ok=True)
    # The log is kept outside work/: switching databases moves work/'s files,
    # and Windows will not move one a process holds open.
    log = open(str(work) + "-server.log", "w")
    port = _free_port()
    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "sdg.api.app:app", "--port", str(port),
         "--log-level", "warning"],
        cwd=ROOT, env=dict(os.environ, SDG_WORK_DIR=str(work)),
        stdout=subprocess.DEVNULL, stderr=log,
    )
    url = f"http://127.0.0.1:{port}"
    try:
        for _ in range(240):
            try:
                urllib.request.urlopen(url + "/api/state", timeout=2)
                break
            except Exception:
                if proc.poll() is not None:
                    raise RuntimeError("the server stopped while starting")
                time.sleep(0.5)
        facets_copies.build(A)
        yield url
    finally:
        proc.terminate()
        proc.wait(timeout=30)
        log.close()
        facets_copies.drop(A)
        shutil.rmtree(work, ignore_errors=True)
        Path(str(work) + "-server.log").unlink(missing_ok=True)


class Trouble:
    """What went wrong in the browser: console errors, failed requests."""

    def __init__(self):
        self.seen: list[str] = []
        self.kept: list[int] = []  # pattern ids the screens created
        self.saves: list[dict] = []  # every save the screens made
        self.aliases: list[str] = []  # names a layout save taught the rules

    def take(self) -> list[str]:
        seen, self.seen = self.seen, []
        return seen


@pytest.fixture(scope="module")
def browser_page(server):
    from playwright.sync_api import sync_playwright

    trouble = Trouble()
    with sync_playwright() as p:
        browser = None
        for channel in ("msedge", "chrome"):
            try:
                browser = p.chromium.launch(channel=channel, headless=True)
                break
            except Exception:
                continue
        if browser is None:
            pytest.skip("neither Edge nor Chrome is installed")
        context = browser.new_context(accept_downloads=True,
                                      viewport={"width": 1400, "height": 1000})
        page = context.new_page()
        page.set_default_timeout(60_000)
        page.on("console", lambda m: m.type == "error" and trouble.seen.append(m.text))
        page.on("pageerror", lambda e: trouble.seen.append(f"page error: {e}"))

        def on_response(response):
            if "/api/" not in response.url:
                return
            if response.status >= 500:
                trouble.seen.append(f"{response.status} from {response.url}")
            if response.url.endswith("/api/patterns/scenarios/keep") and response.ok:
                try:
                    body = response.json()
                except Exception:
                    return
                for entry in body.get("kept") or []:
                    trouble.saves.append(entry)
                    if entry.get("created"):
                        trouble.kept.append(int(entry["pattern_id"]))
                return
            if response.url.endswith("/api/patterns/keep") and response.ok:
                try:
                    body = response.json()
                except Exception:
                    return
                # A pattern somebody had already saved comes back as theirs,
                # created False: it is never this test's to delete.
                trouble.saves.append(body)
                if body.get("created"):
                    trouble.kept.append(int(body["pattern_id"]))

            if "/api/layouts" in response.url and response.ok \
                    and response.request.method in ("POST", "PUT"):
                try:
                    body = response.json()
                except Exception:
                    return
                if isinstance(body, dict):
                    trouble.aliases.extend(body.get("aliased") or [])

        page.on("response", on_response)
        page.goto(server)
        page.wait_for_load_state("networkidle")
        try:
            yield page, trouble
        finally:
            _forget(trouble.kept)
            _unteach(trouble.aliases)
            browser.close()


@pytest.fixture
def page(browser_page):
    """The page, and after each test: nothing went wrong on it."""
    page, trouble = browser_page
    trouble.take()
    yield page
    problems = trouble.take()
    alarms = page.locator(".banner--alarm").all_inner_texts()
    assert not problems, f"the browser saw: {problems}"
    assert not alarms, f"the screen shows: {alarms}"


@pytest.fixture
def kept(browser_page):
    """Every save the screens made, whether it created a row or found one."""
    return browser_page[1].saves


def _forget(pattern_ids) -> None:
    if not pattern_ids:
        return
    from sdg.analyzer import db
    from sdg.analyzer.config import SQL_SCHEMA

    with db.get_connection() as conn:
        cur = conn.cursor()
        for pattern_id in set(pattern_ids):
            cur.execute(f"DELETE FROM {SQL_SCHEMA}.patterns WHERE id = ?", (pattern_id,))
        conn.commit()


def _unteach(aliases) -> None:
    """Remove the aliases the screens' layout saves reported creating."""
    from sdg.analyzer.services import layout_service

    for name in set(aliases):
        layout_service.remove_alias(name)


def _drop_layouts(names) -> None:
    """Remove the layouts this run saved, by the names it gave them."""
    from sdg.analyzer.services import layout_service

    for row in layout_service.list_layouts(include_archived=True):
        if row["name"] in names:
            layout_service.delete_layout(row["id"])


# ---------------------------------------------------------------------------
# Moving about
# ---------------------------------------------------------------------------

def _go(page, step: str, side: str = "Database") -> None:
    """A step on the rail, on its Database or Files tab where it has both."""
    page.locator(".rail__step", has_text=step).first.click()
    page.wait_for_load_state("networkidle")
    tabs = page.locator(".sidetabs")
    if tabs.count():
        tabs.get_by_role("tab", name=side, exact=True).click()
        page.wait_for_load_state("networkidle")


def _settled(page, timeout: int = LONG) -> None:
    """Every button that was busy has finished."""
    page.wait_for_function("() => !document.querySelector('.btn--busy')", timeout=timeout)
    page.wait_for_load_state("networkidle")


def _rail(page) -> dict[str, str]:
    out = {}
    for step in page.locator(".rail__step").all():
        label = step.locator(".rail__label").inner_text().strip()
        out[label] = step.locator(".rail__detail").inner_text().strip()
    out["footer"] = page.locator(".rail__target-db").inner_text().strip()
    return out


def _setup_facts(page) -> dict[str, str]:
    facts = {}
    for item in page.locator(".setup__target > div").all():
        facts[item.locator("dt").inner_text().strip()] = item.locator("dd").inner_text().strip()
    return facts


def _choose_database(page, name: str) -> None:
    _go(page, "Connect")
    page.get_by_label("Database").select_option(name)
    page.get_by_role("button", name="Use this database").click()
    _settled(page)
    page.wait_for_function(
        "name => document.querySelector('.rail__target-db')?.textContent.trim() === name",
        arg=name)


def _source():
    from sdg.config import get_settings

    return get_settings().source_db


# ---------------------------------------------------------------------------
# 1-2. Where things stand
# ---------------------------------------------------------------------------

def test_1_connect_names_the_database_worked_on_and_the_pattern_store(page):
    from sdg.config import get_settings

    settings = get_settings()
    _go(page, "Connect")
    facts = _setup_facts(page)
    assert facts["Working on"] == settings.source_db
    assert facts["Patterns from"] == settings.denorm_db
    rail = _rail(page)
    assert rail["Connect"] == settings.source_db
    assert rail["footer"] == settings.source_db


def test_2_every_screen_opens_without_an_error(page):
    for step in ("Connect", "Discover and Profile", "Map & Review", "Patterns", "Generation"):
        for side in ("Database", "Files"):
            _go(page, step, side)
            page.wait_for_timeout(500)
            text = page.locator(".app__body").inner_text()
            assert "Traceback" not in text and "Internal Server Error" not in text, (step, side)


# ---------------------------------------------------------------------------
# 2a. Files, through the same steps as a database
# ---------------------------------------------------------------------------

def test_2a_files_are_connected_profiled_and_mapped_like_a_database(page, tmp_path):
    (tmp_path / "sdmt-members.txt").write_text(
        "SDMT_NO|SDMT_GIVEN|SDMT_SEX\nX1|Dana|F\nX2||M\nX3|Lee|F\n")

    _go(page, "Connect", "Files")
    page.get_by_label("Folder").fill(str(tmp_path))
    page.get_by_role("button", name="Use this folder").click()
    page.locator(".app__body td", has_text="sdmt-members.txt").wait_for()

    _go(page, "Discover and Profile", "Files")
    file = page.locator(".files__file", has_text="sdmt-members.txt")
    file.wait_for()
    assert "3 fields" in file.inner_text() and "3 rows" in file.inner_text()
    given = file.locator("tr", has_text="SDMT_GIVEN").inner_text()
    assert "33%" in given, given  # one of three is empty

    _go(page, "Map & Review", "Files")
    page.get_by_label("A file from the folder").select_option("sdmt-members.txt")
    parsed = page.locator(".parsed")
    parsed.wait_for()
    assert parsed.get_by_label("Rule for SDMT_GIVEN").count() == 1


# ---------------------------------------------------------------------------
# 2b. Layouts: a rule for every field
# ---------------------------------------------------------------------------

PIPE_LAYOUT = "SDMT browser pipe layout"
FIXED_LAYOUT = "SDMT browser fixed layout"
PIPE_COPY = "SDMT browser pipe copy"


def _rule_ids(server) -> dict[str, int]:
    with urllib.request.urlopen(server + "/api/layouts/rules", timeout=30) as r:
        return {x["field_name"]: x["id"] for x in json.load(r)["rules"]}


def _layout_row(page, name: str):
    return page.locator(".panel__table tr", has_text=name)


def _write(page, name: str) -> str:
    """Approve a layout under Map & Review, write through it under Generation."""
    row = _layout_row(page, name)
    row.get_by_role("button", name="Approve").click()
    _settled(page)
    _go(page, "Generation", "Files")
    with page.expect_download(timeout=LONG) as download:
        _layout_row(page, name).get_by_role("button", name="Write a file").click()
    text = Path(download.value.path()).read_text(encoding="utf-8")
    _settled(page)
    _go(page, "Map & Review", "Files")
    return text


def test_2b_every_layout_field_takes_a_rule_when_read_defined_or_edited(page, server):
    rules = _rule_ids(server)
    for needed in ("MEMBER_ID", "FIRST_NAME", "LAST_NAME"):
        if needed not in rules:
            pytest.skip(f"the rule repository has no {needed}")
    _drop_layouts({PIPE_LAYOUT, PIPE_COPY, FIXED_LAYOUT})
    try:
        _go(page, "Map & Review", "Files")

        # Read: a pipe-delimited sample whose names nothing knows.
        page.locator(".panel input[type=file]").set_input_files(files=[{
            "name": "sdmt-browser.txt", "mimeType": "text/plain",
            "buffer": (b"SDMT_BR_ID|SDMT_BR_GIVEN|SDMT_BR_PAD\n"
                       b"X1|Dana|zz\nX2|Lee|zz\n"),
        }])
        _settled(page)
        parsed = page.locator(".parsed")
        assert parsed.get_by_text("nothing matched", exact=True).count() == 3
        parsed.get_by_label("Rule for SDMT_BR_ID").select_option(str(rules["MEMBER_ID"]))
        parsed.get_by_label("Rule for SDMT_BR_GIVEN").select_option(str(rules["FIRST_NAME"]))
        assert parsed.get_by_text("chosen", exact=True).count() == 2
        parsed.get_by_label("Name", exact=True).fill(PIPE_LAYOUT)
        parsed.get_by_role("button", name="Save this layout").click()
        _settled(page)
        assert "bind by alias" in page.locator(".banner--affirm").first.inner_text()

        # Edit it: the pad field was blank by default; choose it blank on
        # purpose, and the given name becomes the last name instead.
        _layout_row(page, PIPE_LAYOUT).get_by_role("button", name="Edit").click()
        editor = page.locator(".editor")
        editor.get_by_label("Rule for SDMT_BR_PAD").select_option("blank")
        editor.get_by_label("Rule for SDMT_BR_GIVEN").select_option(str(rules["LAST_NAME"]))
        assert editor.get_by_label("Separated by").input_value() == "|"
        editor.get_by_role("button", name="Save changes").click()
        _settled(page)

        text = _write(page, PIPE_LAYOUT)
        lines = [line for line in text.splitlines() if line]
        assert lines[0] == "SDMT_BR_ID|SDMT_BR_GIVEN|SDMT_BR_PAD", lines[0]
        assert len(lines) > 1, "nothing was written"
        for line in lines[1:]:
            ident, given, pad = line.split("|")
            assert ident and given and pad == "", line

        # Save a copy under a new name, then drop both: the copy was never
        # approved and is deleted; the original was, and is archived.
        _layout_row(page, PIPE_LAYOUT).get_by_role("button", name="Edit").click()
        editor = page.locator(".editor")
        editor.get_by_label("Called").fill(PIPE_COPY)
        editor.get_by_role("button", name="Save as a new layout").click()
        _layout_row(page, PIPE_COPY).wait_for()
        _settled(page)
        assert _layout_row(page, PIPE_LAYOUT).count() == 1, "the original was replaced"
        for name, said in ((PIPE_COPY, "deleted"), (PIPE_LAYOUT, "archived")):
            _layout_row(page, name).get_by_role("button", name="Drop", exact=True).click()
            _layout_row(page, name).get_by_role("button", name=f"Drop {name}").click()
            _layout_row(page, name).wait_for(state="detached")
            _settled(page)
            assert said in page.locator(".banner--affirm").first.inner_text()

        # Define: a fixed-width layout, a field renamed, a filler between.
        designer = page.locator(".designer").first
        designer.get_by_role("button", name="Fixed width").click()
        designer.get_by_label("Called").fill(FIXED_LAYOUT)
        designer.get_by_label("Add a field").select_option(str(rules["MEMBER_ID"]))
        designer.get_by_label("Add a field").select_option("__blank__")
        designer.get_by_label("Add a field").select_option(str(rules["FIRST_NAME"]))
        designer.get_by_label("Name of field 1").fill("SDMT_BR_MEMBER")
        designer.get_by_label("Rule for FIRST_NAME").select_option(str(rules["LAST_NAME"]))
        designer.get_by_role("button", name="Save this layout").click()
        _settled(page)

        detail_rows = _write(page, FIXED_LAYOUT)
        rows = [line for line in detail_rows.splitlines() if line]
        assert rows, "nothing was written"
        with urllib.request.urlopen(server + "/api/layouts", timeout=30) as r:
            layout = next(x for x in json.load(r)["layouts"] if x["name"] == FIXED_LAYOUT)
        with urllib.request.urlopen(server + f"/api/layouts/{layout['id']}", timeout=30) as r:
            fields = json.load(r)["fields"]
        assert [f["name"] for f in fields] == ["SDMT_BR_MEMBER", "FILLER_1", "FIRST_NAME"]
        assert fields[2]["rule_id"] == rules["LAST_NAME"]
        id_width, filler = fields[0]["length"], fields[1]["length"]
        for row in rows:
            assert row[:id_width].strip(), f"the renamed field is blank: {row!r}"
            assert row[id_width:id_width + filler] == " " * filler, row
            assert row[id_width + filler:].strip(), f"the re-ruled field is blank: {row!r}"
    finally:
        _drop_layouts({PIPE_LAYOUT, PIPE_COPY, FIXED_LAYOUT})


# ---------------------------------------------------------------------------
# 2c. A pattern defined by its rules
# ---------------------------------------------------------------------------

def test_2c_a_pattern_defined_by_rules_is_measured_saved_and_looked_inside(page, server, kept):
    _go(page, "Patterns")
    page.get_by_role("tab", name="Define a pattern").click()
    page.get_by_label("Pattern name").fill("SDMT women 30 to 45")
    page.get_by_label("Add a feature").select_option(label="Gender")
    page.get_by_role("group", name="Gender").get_by_label("F", exact=True).check()
    page.get_by_label("Add a feature").select_option(label="Age")
    page.get_by_label("Age from").fill("30")
    page.get_by_label("Age to").fill("45")

    page.get_by_role("button", name="Measure it").click()
    summary = page.locator(".patterns__summary")
    summary.wait_for(timeout=LONG)
    _settled(page)
    assert "meet these rules" in summary.inner_text()
    assert page.locator("li.pattern").count() == 1

    before = len(kept)
    card = page.locator("li.pattern").first
    card.get_by_role("button", name="Save pattern").click()
    card.get_by_role("button", name="Saved").wait_for()
    assert len(kept) == before + 1
    saved = kept[-1]
    assert saved["name"] == "SDMT women 30 to 45"
    with urllib.request.urlopen(server + "/api/patterns/for-files", timeout=30) as r:
        listed = {p["pattern_id"]: p for p in json.load(r)["patterns"]}
    assert listed[saved["pattern_id"]]["origin"] == "user_defined"

    page.get_by_role("button", name="Find patterns inside").click()
    page.wait_for_function(
        "() => document.querySelectorAll('li.pattern').length > 1", timeout=LONG)
    _settled(page)
    assert "split into" in page.locator(".patterns__summary").inner_text()

    # Counts and %: every field's values, the pattern's scenarios, and how
    # generation uses each; all patterns downloadable on one sheet.
    card = page.locator("li.pattern").first
    card.locator(".pattern__head").click()
    card.get_by_role("button", name="Counts and %").click()
    counts = card.locator(".counts")
    counts.locator(".counts__field").first.wait_for(timeout=LONG)
    said = counts.inner_text()
    for words in ("Age band", "Sex", "Plan", "Product", "Diagnosis", "Generation:",
                  "Scenarios by"):
        assert words in said, words
    with page.expect_download(timeout=LONG) as download:
        page.get_by_role("button", name="Download counts (one sheet)").click()
    assert download.value.suggested_filename == "members-patterns.xlsx"
    import io as _io

    from openpyxl import load_workbook

    sheet = load_workbook(_io.BytesIO(Path(download.value.path()).read_bytes()))
    assert sheet.sheetnames == ["Patterns"]
    _settled(page)
    # The panel itself exports as it shows: CSV here.
    counts.get_by_label("Export as").select_option("csv")
    with page.expect_download(timeout=LONG) as download:
        counts.get_by_role("button", name="Export", exact=True).click()
    assert download.value.suggested_filename.endswith(".csv")
    head = Path(download.value.path()).read_text(encoding="utf-8-sig").splitlines()[0]
    assert head.startswith("Domain,Pattern,Pattern size")
    _settled(page)
    card.locator(".pattern__head").click()

    # One scenario, many: the same rules across both plan categories, each
    # measured, both saved.
    variants = page.locator(".define__variants")
    variants.get_by_label("Vary by").select_option(label="Product category")
    group = variants.get_by_role("group", name="Vary Product category")
    for box in group.get_by_role("checkbox").all():
        box.check()
    before = len(kept)
    variants.get_by_role("button", name="Make 2 variants").click()
    variants.get_by_role("button", name="Save all 2").wait_for(timeout=LONG)
    counts = variants.locator("tbody tr td.num").all_inner_texts()
    assert len(counts) == 2 and all(c.replace(",", "").isdigit() for c in counts), counts
    variants.get_by_role("button", name="Save all 2").click()
    page.wait_for_function(
        "() => document.querySelectorAll('.define__variants tbody .chip').length === 2",
        timeout=LONG)
    # The screen can show both saved before the second response has reached
    # the listener that records it.
    for _ in range(100):
        if len(kept) >= before + 2:
            break
        page.wait_for_timeout(100)
    assert len(kept) == before + 2
    assert all("SDMT women 30 to 45 · Product category" in k["name"] for k in kept[-2:])

    # Kept patterns export from the screen too: the one saved above, chosen.
    page.get_by_role("tab", name="Walk the book").click()
    row = page.locator("li.kept__row").filter(
        has=page.locator(".kept__name", has_text=re.compile(r"^SDMT women 30 to 45$"))).first
    row.get_by_role("checkbox").check()
    with page.expect_download(timeout=LONG) as download:
        page.get_by_role("button", name="Export 1 chosen").click()
    assert download.value.suggested_filename == "saved-patterns.xlsx"
    rows = list(load_workbook(_io.BytesIO(Path(download.value.path()).read_bytes()))
                .active.iter_rows(values_only=True))
    assert {r[1] for r in rows[1:]} == {"SDMT women 30 to 45"}
    _settled(page)


# ---------------------------------------------------------------------------
# 2d. A requirement analyzed; a pattern's scenarios written together
# ---------------------------------------------------------------------------

def test_2d_a_requirement_is_analyzed_and_a_patterns_scenarios_written_together(page, kept):
    _go(page, "Patterns")
    page.get_by_role("tab", name="From a requirement").click()
    page.get_by_label("Requirement").fill(
        "claims for type 2 diabetes from female members over 40")
    page.get_by_role("button", name="Find Patterns", exact=True).first.click()
    analysis = page.locator(".story__analysis")
    analysis.wait_for()
    rules = analysis.locator(".story__rules").inner_text()
    assert "Diagnosis" in rules and "Type 2 diabetes" in rules and "Gender" in rules, rules
    # Analyze is the pattern analysis: the patterns appear with nothing more to press.
    analysis.locator(".pattern__head").first.wait_for(timeout=LONG)
    _settled(page)
    assert not analysis.get_by_role("button", name="Measure it").count()

    # A found pattern, split into scenarios, all of them into one 834.
    card = analysis.locator("li.pattern").first
    card.locator(".pattern__head").click()
    card.get_by_role("button", name="Scenarios", exact=True).click()
    scenarios = card.locator(".scenarios")
    scenarios.get_by_role("button", name="List the scenarios").click()
    scenarios.locator("tbody tr").first.wait_for(timeout=LONG)
    _settled(page)
    listed = scenarios.locator("tbody tr").count()
    assert listed >= 2
    before = len(kept)
    scenarios.get_by_role("button", name=f"Write {listed} as one file").click()
    page.wait_for_function(
        "() => document.querySelector('.app__heading')?.textContent.trim() === 'Generation'",
        timeout=LONG)
    # The screen can move on before the response reaches the listener.
    for _ in range(100):
        if len(kept) >= before + listed:
            break
        page.wait_for_timeout(100)
    assert len(kept) >= before + listed
    assert page.get_by_label("Written for").input_value() == "scenarios"
    page.get_by_role("tab", name="EDI", exact=True).click()
    page.get_by_label("Transaction set").select_option("834")
    with page.expect_download(timeout=LONG) as download:
        page.get_by_role("button", name="Write the file").click()
    text = Path(download.value.path()).read_text(encoding="utf-8")
    _settled(page)
    assert text.startswith("ISA") and text.count("INS*") >= 2, text[:300]


# ---------------------------------------------------------------------------
# 2e. A rule tried on the Rules screen makes real values
# ---------------------------------------------------------------------------

def test_2e_a_rule_is_tried_on_the_rules_screen_and_makes_real_values(page, server):
    if "STREET_1" not in _rule_ids(server):
        pytest.skip("the rule repository has no STREET_1")
    _go(page, "Map & Review", "Files")
    page.get_by_role("tab", name="Rules", exact=True).click()
    page.get_by_label("Find").fill("STREET_1")
    row = page.locator("tr.rules__row", has_text="STREET_1").first
    row.get_by_role("button", name="Edit").click()
    editor = page.locator("tr.rules__editor")
    editor.get_by_role("button", name="Try it").click()
    shown = editor.locator(".rules__sample .mono")
    shown.wait_for(timeout=LONG)
    streets = [s.strip() for s in shown.inner_text().split("·")]
    assert len(streets) == 5 and all(re.fullmatch(r"\d{3,4} [A-Za-z' .]+", s) for s in streets), streets


def test_2f_a_column_takes_a_business_element_and_only_custom_offers_algorithms(page):
    _go(page, "Map & Review", "Database")
    rows = page.locator("table tbody tr[tabindex='0']")
    if not rows.count():
        pytest.skip("nothing has been read on this database")
    rows.first.click()
    detail = page.locator("aside.detail")
    detail.get_by_role("button", name=re.compile(r"^Change")).click()
    editor = detail.locator(".editor")
    element = editor.get_by_label("Business element")
    rule = editor.get_by_label("Rule")

    # An element brings its rule: nothing to choose.
    names = [o for o in element.locator("option").all_inner_texts() if o != "Custom (no business element)"]
    element.select_option(names[0])
    assert not rule.count() or rule.evaluate("e => e.tagName") != "SELECT"
    assert editor.locator(".editor__rule").inner_text().strip()

    # Custom: every algorithm the engine has, to choose from.
    element.select_option(label="Custom (no business element)")
    offered = rule.locator("option").all_inner_texts()
    assert {"Street address", "Template"} <= set(offered) and len(offered) >= 10, offered
    editor.get_by_role("button", name="Cancel").click()


def test_2g_a_layout_field_with_no_element_gets_a_custom_rule_of_its_own(page, server):
    _drop_layouts({PIPE_LAYOUT})
    _go(page, "Map & Review", "Files")
    page.locator(".panel input[type=file]").set_input_files(files=[{
        "name": "sdmt-custom.txt", "mimeType": "text/plain",
        "buffer": b"SDMT_CUSTOM_CODE|SDMT_BR_OTHER\nA1|x\nA2|y\n",
    }])
    _settled(page)
    choice = page.get_by_label("Rule for SDMT_CUSTOM_CODE")
    choice.select_option("custom")
    form = page.locator("tr.fields__rule .rules__form")
    form.wait_for(timeout=LONG)
    form.get_by_role("button", name="Try it").click()
    shown = form.locator(".rules__sample .mono")
    shown.wait_for(timeout=LONG)
    assert len([v for v in shown.inner_text().split("·") if v.strip()]) == 5
    assert "SDMT_CUSTOM_CODE" in choice.locator("option:checked").inner_text()
    # The rule made for this test goes, by its own exact name.
    from sdg.analyzer import db

    db.delete_generation_rule("SDMT_CUSTOM_CODE")


def test_2h_the_top_menu_configures_discovery_and_shows_each_elements_algorithm(page):
    from sdg.analyzer.services import discovery_features, report_fields

    before = discovery_features.chosen("members")
    counted = report_fields._stored("members")
    try:
        menu = page.get_by_role("navigation", name="Settings")
        menu.get_by_role("button", name="Configure").click()
        assert page.locator(".app__heading").inner_text().strip() == "Configure"
        config = page.locator("section[aria-label='Pattern discovery features']")
        members = config.locator(".discoveryconfig__entity").first
        members.get_by_label("PCP specialty").check()
        members.get_by_role("button", name="Save").click()
        config.locator(".banner", has_text="PCP specialty").wait_for(timeout=LONG)

        # The fields a pattern's counts are made on: a default switched off, a
        # denorm column added, saved; then back to the defaults.
        fields = page.locator("section[aria-label='Fields counted in patterns']")
        counted_members = fields.locator(".discoveryconfig__entity").first
        counted_members.get_by_label("ZIP", exact=True).uncheck()
        counted_members.get_by_label("Add a member denorm column").select_option("col:GRGR_STATE")
        counted_members.get_by_role("button", name="Add", exact=True).click()
        counted_members.get_by_text("Group State", exact=True).wait_for()
        counted_members.get_by_role("button", name="Save").click()
        fields.locator(".banner", has_text="now counted on").wait_for(timeout=LONG)
        keys = report_fields.chosen("members")
        assert "col:GRGR_STATE" in keys and "zip" not in keys
        counted_members.get_by_role("button", name="Defaults").click()
        fields.locator(".banner", has_text="default fields again").wait_for(timeout=LONG)
        assert "col:GRGR_STATE" not in report_fields.chosen("members")

        # Back on the workflow, the patterns screen says what it finds them on.
        page.locator(".rail__step", has_text="Patterns").first.click()
        assert page.locator(".app__heading").inner_text().strip() != "Configure"
        lede = page.locator(".patterns__lede")
        lede.get_by_text("PCP specialty").wait_for(timeout=LONG)

        menu.get_by_role("button", name="Algorithms").click()
        assert page.locator(".app__heading").inner_text().strip() == "Algorithms"
        page.locator("tr.rules__row").first.wait_for(timeout=LONG)
        assert page.locator("tr.rules__row").count() > 10
    finally:
        discovery_features.choose("members", before)
        if counted is None:
            report_fields.reset("members")
        else:
            report_fields.choose("members", counted)


# ---------------------------------------------------------------------------
# 3. Onboarding a database, all from the screens
# ---------------------------------------------------------------------------

def test_3_a_database_is_onboarded_read_planned_written_and_cleaned_from_the_screens(page):
    _choose_database(page, A)
    assert _setup_facts(page)["Working on"] == A
    rail = _rail(page)
    assert rail["Connect"] == A and rail["Discover and Profile"] == "not run", rail

    page.get_by_role("button", name="Read the database").click()
    page.wait_for_function(
        "() => [...document.querySelectorAll('.rail__step')].some(s => "
        "s.querySelector('.rail__label')?.textContent.trim() === 'Map & Review' && "
        "/auto-mapped/.test(s.querySelector('.rail__detail').textContent.trim()))",
        timeout=LONG)
    _settled(page)
    rail = _rail(page)
    assert rail["Discover and Profile"].endswith("columns"), rail
    assert "tables" in rail["Discover and Profile"], rail

    # From the read to the load by the Next button on each screen, as somebody
    # new to it would go; the plan builds itself on arrival.
    for step in ("Map & Review", "Patterns", "Generation"):
        page.get_by_role("button", name=f"Next: {step} →").click()
        page.wait_for_function(
            "t => document.querySelector('.app__heading')?.textContent.trim() === t",
            arg=step)
    _planned(page)
    page.get_by_text("rows in this plan").wait_for(timeout=LONG)
    # What the load does to each kind of table is said before anything runs.
    kinds = page.locator(".cascade__kinds").inner_text().lower()
    assert "transactional — generated" in kinds and "reference — kept as is" in kinds
    assert page.locator(".cascade__kind--kept").count() > 0

    page.get_by_role("button", name="Next: look at sample rows →").click()
    _settled(page)
    page.get_by_text("Sample rows", exact=True).first.wait_for()
    assert _step_done(page, "Sample rows")
    page.get_by_role("button", name="Generate", exact=True).click()
    _settled(page)
    page.get_by_text("Written", exact=True).wait_for()
    assert _step_done(page, "Write the rows")
    written = facets_copies.counts(A)
    assert written["CMC_MEME_MEMBER"] and written["CMC_CLCL_CLAIM"], written
    assert _rail(page)["Generation"].endswith("written")

    page.get_by_role("button", name="Validate", exact=True).click()
    _settled(page)
    checked = page.locator(".app__body").inner_text()
    assert "checks passed" in checked and "failed" not in checked.lower(), checked[-1500:]
    assert _step_done(page, "Check them")

    page.get_by_role("button", name="Remove the rows").click()
    _settled(page)
    assert facets_copies.counts(A) == dict.fromkeys(written, 0)


# ---------------------------------------------------------------------------
# 4. Chosen records into that database
# ---------------------------------------------------------------------------

def _step_done(page, label: str) -> bool:
    step = page.locator(".gensteps__step", has_text=label)
    return "gensteps__step--done" in (step.get_attribute("class") or "")


def _planned(page) -> None:
    """DB Generation is open and its plan is built and current."""
    page.wait_for_function(
        "() => [...document.querySelectorAll('.gensteps__step--done')]"
        ".some(s => s.textContent.includes('The plan'))",
        timeout=LONG)
    _settled(page)


def _find_patterns(page) -> None:
    _go(page, "Patterns")
    page.get_by_role("button", name="Find patterns").click()
    page.locator(".pattern__head").first.wait_for(timeout=LONG)
    _settled(page)


def _open_first_pattern(page):
    card = page.locator("li.pattern").first
    card.locator(".pattern__head").click()
    card.get_by_role("button", name="Save pattern").wait_for()
    return card


def test_4_chosen_records_go_into_the_onboarded_database(page, kept):
    assert page.locator(".rail__target-db").inner_text().strip() == A
    _find_patterns(page)
    card = _open_first_pattern(page)
    card.get_by_role("button", name="The rows underneath").click()
    boxes = card.get_by_label("Choose member", exact=False)
    boxes.first.wait_for(timeout=LONG)
    for i in range(3):
        boxes.nth(i).check()
    assert "3 members chosen" in card.inner_text()

    before = len(kept)
    card.get_by_role("button", name="Generate into the database", exact=True).click()
    _settled(page)
    page.locator(".banner--affirm", has_text="records set the rules").wait_for()
    assert len(kept) == before + 1, "the chosen records were not saved as a pattern"

    # Straight on to the load, with the plan rebuilt there without asking.
    _planned(page)
    page.get_by_role("button", name="Next: look at sample rows →").click()
    _settled(page)
    page.get_by_role("button", name="Generate", exact=True).click()
    _settled(page)
    written = facets_copies.counts(A)
    assert written["CMC_MEME_MEMBER"], written

    page.get_by_role("button", name="Validate", exact=True).click()
    _settled(page)
    assert "checks passed" in page.locator(".app__body").inner_text()
    page.get_by_role("button", name="Remove the rows").click()
    _settled(page)
    assert facets_copies.counts(A) == dict.fromkeys(written, 0)


# ---------------------------------------------------------------------------
# 5. A saved pattern, to a file
# ---------------------------------------------------------------------------

def test_5_a_saved_pattern_is_listed_for_files_and_writes_an_834_that_passes_snip(page, kept):
    from sdg.writers.snip import validate

    _find_patterns(page)
    card = _open_first_pattern(page)
    before = len(kept)
    card.get_by_role("button", name="Save pattern").click()
    card.get_by_role("button", name="Saved").wait_for()
    assert len(kept) == before + 1
    pattern_id = kept[-1]["pattern_id"]

    _go(page, "Generation", "Files")
    page.get_by_label("Written for").select_option(f"saved:{pattern_id}")
    page.get_by_role("tab", name="EDI", exact=True).click()
    page.get_by_label("Transaction set").select_option("834")
    with page.expect_download(timeout=LONG) as download:
        page.get_by_role("button", name="Write the file").click()
    text = Path(download.value.path()).read_text(encoding="utf-8")
    _settled(page)

    assert text.startswith("ISA") and "INS*" in text and "N4*" in text, text[:400]
    report = validate(text)
    failing = [(lv["level"], lv["errors"]) for lv in report["levels"] if lv["errors"]]
    assert not failing, f"SNIP errors by level: {failing}"

    page.get_by_role("button", name="Run SNIP checks").click()
    _settled(page)
    summary = page.locator(".snip__summary").inner_text()
    assert summary, "the SNIP report did not appear"


def test_5b_an_837_is_modeled_on_a_sample_and_written_for_a_saved_pattern(page, kept):
    """Read a sample against the masking config, change a proposal, save as a
    new config, and write the file: the sample everywhere but where chosen."""
    from sdg.analyzer.services import sample_gen_configs
    from sdg.writers.snip import validate

    fixtures = ROOT / "tests" / "fixtures" / "edi"
    sample = (fixtures / "claim.837").read_text(encoding="utf-8")
    master = (fixtures / "master-837-masking.json").read_text(encoding="utf-8")
    name = f"browser test 837 {int(time.time())}"
    pattern_id = kept[-1]["pattern_id"]

    _go(page, "Generation", "Files")
    page.get_by_label("Written for").select_option(f"saved:{pattern_id}")
    page.get_by_role("tab", name="From a sample").click()
    page.locator("input[aria-label='Sample file']").set_input_files(files=[{
        "name": "claim.837", "mimeType": "text/plain", "buffer": sample.encode()}])
    page.locator("input[aria-label='Config file']").set_input_files(files=[{
        "name": "master-837-masking.json", "mimeType": "application/json",
        "buffer": master.encode()}])
    page.get_by_role("button", name="Read the sample").click()
    _settled(page)

    # The master's proposals, read from its masking names.
    assert page.get_by_label("Algorithm for NM1*IL NM103").input_value() == "LAST_NAME"
    assert page.get_by_label("Algorithm for REF*EI REF02").input_value() == ""
    # The person's change: procedure codes from the pattern, not the sample.
    page.get_by_label("Algorithm for SV1 SV101-2").select_option("PROCEDURE_CODE")
    page.get_by_label("New config name").fill(name)
    page.get_by_role("button", name="Save config as").click()
    _settled(page)
    page.locator(".chip", has_text=f"saved as {name}").wait_for()
    saved = next(c for c in sample_gen_configs.list_configs() if c["name"] == name)
    try:
        body = sample_gen_configs.get_config(saved["id"])["config"]
        assert "genSegments" in body and body["based_on"] == "master-837-masking.json"
        assert page.get_by_label("Generation config").input_value() == str(saved["id"])

        with page.expect_download(timeout=LONG) as download:
            page.get_by_role("button", name="Write the file").click()
        text = Path(download.value.path()).read_text(encoding="utf-8")
        _settled(page)

        assert "NM1*85*2*RIVERSIDE FAMILY CLINIC" in text, "the sample's provider is kept"
        codes = {s.split("*")[1].split(":")[1] for s in text.split("~") if s.strip().startswith("SV1*")}
        assert codes and not codes <= {"99213", "85025"}, "procedure codes still the sample's"
        failing = [(lv["level"], lv["errors"]) for lv in validate(text)["levels"]
                   if lv["level"] <= 4 and lv["errors"]]
        assert not failing, f"SNIP errors by level: {failing}"

        page.get_by_role("button", name="Run SNIP checks").click()
        _settled(page)
        assert page.locator(".snip__summary").inner_text()
    finally:
        # Only the config this test saved, by the id the name it chose found.
        sample_gen_configs.delete_config(saved["id"])


def test_5c_fhir_claims_are_modeled_on_a_bundle_the_same_way(page, kept):
    """The same screen, steps and engine as 5b, for a FHIR Bundle and the
    masking tool's FHIR config: the format is read off the sample."""
    import json as _json

    from sdg.analyzer.services import sample_gen_configs

    fixtures = ROOT / "tests" / "fixtures" / "fhir"
    sample = (fixtures / "claims-bundle.json").read_text(encoding="utf-8")
    master = (fixtures / "master-fhir-masking.json").read_text(encoding="utf-8")
    name = f"browser test fhir {int(time.time())}"
    pattern_id = kept[-1]["pattern_id"]

    _go(page, "Generation", "Files")
    page.get_by_label("Written for").select_option(f"saved:{pattern_id}")
    page.get_by_role("tab", name="From a sample").click()
    page.locator("input[aria-label='Sample file']").set_input_files(files=[{
        "name": "claims-bundle.json", "mimeType": "application/json",
        "buffer": sample.encode()}])
    page.get_by_label("Start from").select_option("file")
    page.locator("input[aria-label='Config file']").set_input_files(files=[{
        "name": "master-fhir-masking.json", "mimeType": "application/json",
        "buffer": master.encode()}])
    page.get_by_role("button", name="Read the sample").click()
    _settled(page)

    page.locator(".chip", has_text="patients").wait_for()
    assert page.get_by_label("Algorithm for Patient name[*].family").input_value() == "LAST_NAME"
    assert page.get_by_label("Algorithm for Organization name").input_value() == ""
    page.get_by_role("button", name="Accept").click()
    page.get_by_label("New config name").fill(name)
    page.get_by_role("button", name="Save config as").click()
    _settled(page)
    page.locator(".chip", has_text=f"saved as {name}").wait_for()
    saved = next(c for c in sample_gen_configs.list_configs() if c["name"] == name)
    try:
        assert (saved["format"], saved["kind"], saved["subject"]) == ("fhir", "claims", "claims")
        assert page.get_by_role("button", name="Run SNIP checks").count() == 0, "SNIP is X12's"
        page.get_by_role("button", name="Run FHIR checks").click()
        _settled(page)
        summary = page.locator(".snip__summary").inner_text()
        assert "No errors" in summary and "resources" in summary, summary

        with page.expect_download(timeout=LONG) as download:
            page.get_by_role("button", name="Write the file").click()
        doc = _json.loads(Path(download.value.path()).read_text(encoding="utf-8"))
        _settled(page)

        resources = [e["resource"] for e in doc["entry"]]
        patients = {f"Patient/{r['id']}" for r in resources if r["resourceType"] == "Patient"}
        claims = [r for r in resources if r["resourceType"] == "Claim"]
        assert patients and claims, "members and their claims written"
        assert {c["patient"]["reference"] for c in claims} <= patients, "claims point at their member"
        assert {r["id"] for r in resources if r["resourceType"] == "Organization"} == {"hl7"}
    finally:
        sample_gen_configs.delete_config(saved["id"])


def test_5d_cda_documents_are_modeled_on_a_ccd_the_same_way(page, kept):
    """The same screen again, for a CCD and the masking tool's CDA config: a
    document per claim, downloaded as a zip of documents."""
    import io as _io
    import zipfile as _zipfile

    from sdg.analyzer.services import sample_gen_configs

    fixtures = ROOT / "tests" / "fixtures" / "cda"
    sample = (fixtures / "ccd.xml").read_text(encoding="utf-8")
    master = (fixtures / "master-cda-masking.json").read_text(encoding="utf-8")
    name = f"browser test cda {int(time.time())}"
    pattern_id = kept[-1]["pattern_id"]

    _go(page, "Generation", "Files")
    page.get_by_label("Written for").select_option(f"saved:{pattern_id}")
    page.get_by_role("tab", name="From a sample").click()
    page.locator("input[aria-label='Sample file']").set_input_files(files=[{
        "name": "ccd.xml", "mimeType": "application/xml", "buffer": sample.encode()}])
    page.get_by_label("Start from").select_option("file")
    page.locator("input[aria-label='Config file']").set_input_files(files=[{
        "name": "master-cda-masking.json", "mimeType": "application/json",
        "buffer": master.encode()}])
    page.get_by_role("button", name="Read the sample").click()
    _settled(page)

    page.locator(".chip", has_text="sections").wait_for()
    family = "Algorithm for recordTarget/patientRole/patient/name/family"
    assert page.get_by_label(family).input_value() == "LAST_NAME"
    author = "Algorithm for author/assignedAuthor/assignedPerson/name/family"
    assert page.get_by_label(author).input_value() == ""
    page.get_by_role("button", name="Accept").click()
    page.get_by_label("New config name").fill(name)
    page.get_by_role("button", name="Save config as").click()
    _settled(page)
    page.locator(".chip", has_text=f"saved as {name}").wait_for()
    saved = next(c for c in sample_gen_configs.list_configs() if c["name"] == name)
    try:
        assert (saved["format"], saved["kind"], saved["subject"]) == ("cda", "CCD", "claims")
        page.get_by_role("button", name="Show the start of the file").click()
        _settled(page)
        assert page.locator(".edi__sample").inner_text().startswith("<?xml")
        page.get_by_role("button", name="Run CDA checks").click()
        _settled(page)
        summary = page.locator(".snip__summary").inner_text()
        assert "No errors" in summary and "documents" in summary, summary

        with page.expect_download(timeout=LONG) as download:
            page.get_by_role("button", name="Write the file").click()
        assert download.value.suggested_filename.endswith(".zip")
        packed = Path(download.value.path()).read_bytes()
        _settled(page)
        with _zipfile.ZipFile(_io.BytesIO(packed)) as archive:
            docs = [archive.read(n).decode("utf-8") for n in archive.namelist()]
        assert docs and all("<ClinicalDocument" in d for d in docs)
        assert all("<family>Primary</family>" in d for d in docs), "the author is the sample's"
    finally:
        sample_gen_configs.delete_config(saved["id"])


def test_5e_hl7_messages_are_modeled_on_an_adt_and_checked_the_same_way(page, kept):
    """The same screen for an HL7 v2 ADT and the masking tool's HL7 config: a
    message per member, checked as HL7 (structure, control ids, dates, tables)."""
    from sdg.analyzer.services import sample_gen_configs

    fixtures = ROOT / "tests" / "fixtures" / "hl7"
    sample = (fixtures / "adt_a01.hl7").read_bytes()
    master = (fixtures / "master-hl7-masking.json").read_bytes()
    name = f"browser test hl7 {int(time.time())}"
    pattern_id = kept[-1]["pattern_id"]

    _go(page, "Generation", "Files")
    page.get_by_label("Written for").select_option(f"saved:{pattern_id}")
    page.get_by_role("tab", name="From a sample").click()
    page.locator("input[aria-label='Sample file']").set_input_files(files=[{
        "name": "adt_a01.hl7", "mimeType": "text/plain", "buffer": sample}])
    page.get_by_label("Start from").select_option("file")
    page.locator("input[aria-label='Config file']").set_input_files(files=[{
        "name": "master-hl7-masking.json", "mimeType": "application/json",
        "buffer": master}])
    page.get_by_role("button", name="Read the sample").click()
    _settled(page)

    page.locator(".chip", has_text="messages").wait_for()
    page.get_by_role("button", name="Accept").click()
    page.get_by_label("New config name").fill(name)
    page.get_by_role("button", name="Save config as").click()
    _settled(page)
    page.locator(".chip", has_text=f"saved as {name}").wait_for()
    saved = next(c for c in sample_gen_configs.list_configs() if c["name"] == name)
    try:
        assert (saved["format"], saved["kind"], saved["subject"]) == ("hl7v2", "ADT", "members")
        assert page.get_by_role("button", name="Run SNIP checks").count() == 0
        page.get_by_role("button", name="Run HL7 checks").click()
        _settled(page)
        summary = page.locator(".snip__summary").inner_text()
        assert "No errors" in summary and "messages" in summary, summary
    finally:
        sample_gen_configs.delete_config(saved["id"])


# ---------------------------------------------------------------------------
# 6. Back to the source; offboard
# ---------------------------------------------------------------------------

def test_6_back_on_the_source_its_work_is_as_left_and_the_copy_is_offboarded(page):
    source = _source()
    _choose_database(page, source)
    rail = _rail(page)
    assert rail["Connect"] == source and "tables" in rail["Discover and Profile"], rail
    assert _setup_facts(page)["Working on"] == source

    row = page.locator(".target__onboarded-row", has_text=A)
    row.get_by_role("button", name="Offboard").click()
    row.get_by_role("button", name=f"Offboard {A}").click()
    _settled(page)
    page.wait_for_function(
        "name => ![...document.querySelectorAll('.target__onboarded-row')]"
        ".some(r => r.textContent.includes(name))", arg=A)
    listed = json.loads(urllib.request.urlopen(
        page.url.split("#")[0].rstrip("/") + "/api/databases/onboarded").read())
    assert A not in {d["database"] for d in listed["databases"]}
